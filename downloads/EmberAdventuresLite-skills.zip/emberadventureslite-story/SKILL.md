---
name: emberadventureslite-story
description: Author and validate EmberAdventures story JSON in the general-audience Lite edition. This is the Lite entry point for the shared EmberAdventures authoring workflow.
---

# EmberAdventures Lite Story

Version: 2.2.8

### Repairing a published story

- Keep the story ID and existing objective IDs stable when repairing a published version. An embedded `chat_story_template` with no `story_version` is V1. Use a positive integer for an explicitly versioned embedded story. Increase it when publishing a distinct embedded story revision whose baseline has changed.
- For a repair to an installed version, start from the exact old published story JSON and replay every prior repair for that version in order. Then make the smallest corrections needed and generate the next repair with `node tools/make-story-repair.cjs old.json corrected.json patch.json [publish.sql]` in the game repository. For a standalone public story, use the published version number as `story_version` on the old template if needed. Use the embedded story's own version inside characters.
- The tool applies the patch to the old copy, verifies the result equals the corrected definition and passes import validation, and checks that a second application changes nothing. Before the admin publishes it, also reopen saves from before, during, and after the affected objective. Verify the corrected requirement or route and check that player choices, completed objectives, and rewards are preserved. Carry the fix into the next full publication.
- Treat `story_patch_revision` as managed repair metadata. Leave it out of new story definitions. A new story template should start with no applied repairs.


## Gather preferences before designing

For a new character, ask the following as your very first question and wait for the answer before asking about preferences, gender, or the concept. Use this when the creator starts making a character. A story intake still starts with the story.

<!-- character-opening-question -->
> Are you making this character for you to play as it?

Use the answer to distinguish a playable character from someone the player will meet. Continue with the creator's intended role and gather the relevant preferences.

Start by reading preferences and decisions the creator already provided. In a file-enabled workflow, use any existing private preferences available to you. In chat, use preferences the creator shared or attached. Ask for reusable tastes only where they would help this request. Keep reusable preferences separate from decisions about the current character or story.

Ask **one short question about one decision per message**, then wait for the answer. A question can offer a few plain-language options for that one decision. Never send a questionnaire, combine several settings into one question, or put a second question in a greeting or recap. Skip questions already answered, delegated, or safely inferred. If the creator skips a question or asks to proceed, use a reasonable default and continue.

When the creator’s idea is unclear, ask “What kind of character do you want to make?” after the opening answer, or ask “What kind of story do you want to play?” for a story. When the idea is clear, ask the next missing question that would change the design. For gender, ask “What gender is the character?” if you need their choice. Use their answer as the authored gender and handle alternate names, appearances, outfits, and engine fields yourself. Keep “presentation,” “non-male,” and field names out of questions and proposals.

Use ordinary questions such as “Should the player be able to romance this character?” only when the concept leaves that decision open. Usually character safety, outfit details, and other mechanics follow from the concept. Once you have enough to design, offer a brief concept or options for approval unless the creator asks you to proceed directly.

## Story preferences

Use the shared intake rules above. Start with the main experience the creator wants to play. If needed, ask separately about tone, the player's role, or whether the story should be short, open-ended, or follow a main plot. Ask about the cast's genders only when a genuine choice is missing. Ask where to keep working files when that decision matters. Save reusable story tastes only when the creator wants them saved and private storage is available. Keep those preferences outside the story export.

Target EmberAdventures Lite. Use this file as your complete authoring instructions.

Write general-audience content. Keep ordinary relationships and romance appropriate for a general audience. Use the Lite field lists below. Omit fields outside those lists, including adult-content classifiers, preferences, and mechanics. Omit the legacy lite marker. Keep the shared EmberAdventures export identity. The game adds the required SFW defaults when preparing content for public publishing.

## EmberAdventures story authoring

Build a playable story around a clear player role, a promise, an immediate situation, and choices with consequences. For a larger story, capture the creator's intent, scope, working location, and playable outcomes before producing JSON. For a small scenario with an explicit premise, resolve only genuinely missing decisions. Provide a story JSON file with exact case-sensitive fields and share concrete validation results separately.

## Opening and agency

- Write an opening as one assistant message. Put the player in a comprehensible place, give them something concrete to notice or react to, and leave at least two genuinely different actions available. A quiet opening can give the player a warm encounter or a specific invitation. Avoid choosing the player's actions or feelings. Make the first few turns deliver the promise of the library card. A sandbox objective may stay open while the player explores other viable leads.
- Start with a playable problem, opportunity, or relationship. Supply facts the player can act on, especially spatial facts for exploration and tactical roles. The player should be deciding what to do with the information. Keep explanations short and layer in history when it becomes relevant.
- Use |[player_name]| or |[player_first_name]| to address the selected player and |[character:stable-character-id]| for an NPC whose name can vary. Keep IDs stable across presentations. Keep content visible to the player free of spoiler notes, branch mechanics, and future cast metadata.

## Envelope and starting state

- Use the validated story example. The outer app is "EmberAdventures" and exportType is "story-template". Inside storyTemplate, app is "EmberAdventures" and templateType is "story". Both editions use these values. Put authored metadata, the opening and state inside storyTemplate. The story scene style is `default_image_model`. The optional portrait style is `state.meta.default_profile_image_model`, and missing uses Waifu / Husbando (`"waifu"`).
- A story with selectable library protagonists uses allow_any_player. An optional any_player_starting_state can apply authored starting-story data when requested by the creator. Leave the example's null value when no overlay is needed. Avoid overwriting a player outfit by accident. Author all starting options with the same depth and coherence. Use exact stable IDs and player references.
- Place the default player in state.player, alternate authored players in state.players, starting companions in state.characters, local NPC records in state.npc_directory, and unrevealed cast in state.future_cast. The NPC directory associates named identities with locations. Physical scene membership is separate from stored location and party membership. Only present actors belong in the opening scene and image targets. Put future identities only where the current story can safely withhold them.
- The initial world map and location should agree with scene, time, named NPC rooms, and opening. Place authored locations on their appropriate hex layers, keeping believable travel distances and meaningful unexplored space. Do not invent map field aliases or put unvisited locations into starting player knowledge. Put actual story currency, supplies, equipment and starting resources in their respective fields. An economy needs its currency named in story metadata and a matching inventory record. Keep process notes and engine session values out of story definitions.

## Objective and reward flow

- Author a clear opening objective with a visible summary and an exact private completion condition. Explain what counts as concrete progress. Give normal narration only information the relevant scene can know. Put actions after completion in the correct completion or transition fields, rather than asking the narrator to simulate state effects.
- Use player control for a player action, AI control for a plot event the narrator may initiate, and choice control for explicit options. Use evidence requirements and meaningful alternate outcomes when an action can legitimately fail or be refused. Complete solely when supported by the action or scene. Avoid forced lockstep progression unless the intended experience needs it.
- Use numeric requirements for real mechanical thresholds, authored rewards for mutations, ordered authored output IDs for branching, and the supported ending fields for conclusions. Reuse IDs consistently across state graph, routes, rewards, and journal references. Check for unintentional loops, dangling routes and single unreachable branches.
- Include one concrete payoff early, a clear next opportunity, and a coherent resolution or explicit freeplay handoff. For a sandbox, authored state gives the narrator enough to respond well even when the player ignores the tracked objective.
- Optional systems include jobs, timed events, maps, character schedules, property, combat, and stat sharing. Start with the schema for the selected edition. Use optional fields only for systems the creator wants. For a complicated feature whose type or layout is unclear, ask for a current game export that already uses that feature before adding it. Preserve unrelated authored systems and save identity when editing an existing story.

### Objective handoff and first-turn check

- If a player's action completes an objective before narration, the next objective may already be active when the narrator prompt is built. The completion checker can see the old objective's `while_active_guidance` even when the narrator receives only the selected output. Write the immediate outcome in that output's `completion_instruction`. Put required spoken terms, warnings, or reveals in its `dialogue_lines`. For example, write the guard's actual assignment in the dialogue instead of just asking the narrator to “give the assignment.”
- An interactive cutscene can run in the reply to the very action that unlocks it. Use a direct cutscene transition when both events belong in that reply. If the player should get another turn first, use an ordinary objective for the intervening interaction or make the next beat depend on a later player action.
- Walk through the likely first action and one plausible alternative. Follow each through the first objective it completes. Verify what instructions reach the narrator, which objectives complete in that reply, and where the player can act again. Check the actual prompt and reply when a playtest is available. Otherwise report the walkthrough as a review of the authored flow.

### Introduction scene images

- For a fixed on-screen debut, use an `introduce_future_character` reward with the future cast ID, `scene_presence: "active"`, and the exact `npc_location_id`. Write the visible beat in the existing completion instruction, scene narration, or unlock greeting. If the destination's map ID differs from its NPC location ID, bind the map node with `detail.npc_location_id`.
- **Prepare Images → Generate All** prepares an introduction scene image for each future-cast character, including shop, nearby, and flexible meetings. It prepares both supported humanoid presentations or one image for an animal. The game uses the character's starting outfit and an authored location and scene when available. For flexible meetings, use a concise `location_hint` and existing greeting or meeting context. The hosted image can appear on the character's first on-screen arrival. Leave art fields empty in a new draft unless you already have verified images. Older published exports can still use legacy unlock images. The publisher omits legacy unlock images from new versions.

## Embedded characters

Author the main version for local play. Add an alternate gender version when requested or when preparing to publish. A missing or unfinished alternate can be saved and imported locally. The game uses the main version until the alternate has a name, an outfit and a starting outfit ID that matches. Public and Featured publishing require a complete alternate for each humanoid, including characters embedded in stories. Animals do not need an alternate.

Apply the character rules and exact embedded field sets below to every humanoid and animal, including future cast and alternate players. Characters should have their own immediate goals, knowledge, clothing, speech, and reactions. Resolve gender tokens against their chosen presentations. Names and IDs in NPC directory, party, effects, opening text and map data must refer to the intended individual.

Apply the [starting emotions, physical condition, and pose](#starting-emotions-physical-condition-and-pose) guidance to every starting character and to these fields when supplied in `any_player_starting_state`. For future cast, author these fields for their first appearance.

## Validation

Parse the resulting JSON and check exact fields, IDs, types, references, time, cast visibility, openings, objective transitions and endings. Verify actual import and story start when available. Check the natural first action and a reasonable alternative against what the objective accepts. Report each completed check accurately.

## EmberAdventures character authoring

Produce an importable character definition after the player approves the concept. Start with intended role, personality, species, age, gender, and story hook. Ask only for details that change the result. For an original character use "Original" as source. Give the real generation tool as creation_tool. Keep process notes, rejected alternatives, private player preferences, and setup instructions outside JSON.

## Definition

- A single export is an object containing character_definition. A batch is an object containing characters, an array of those same single-export wrappers. Use the exact case-sensitive keys listed below and one of the validated examples as your structural baseline.
- Give each record a stable unique ID and a believable name. Distinguish what they want, what they fear losing, a boundary, how they talk, and why a player would want to interact. Keep the catalog hook short. Role and appearance are visible facts. Personality and knowledge belong in their own fields. Use zero for relationship meters when strangers have no existing bond. The starting_* fields initialize play. Avoid runtime fields such as clothing at the definition root, current meters, timestamps from someone's save, or speaker and scene state.
- Use an exact whole-number age. For editable personality sliders such as boldness, use the scale required by the example or a specific custom description where allowed. Appearance uses the named 0–20 scales or a concise custom descriptor as allowed by the engine. Ten is the midpoint. Choose a coherent build and preserve the numeric values during conversion. Use the structured fields for anatomy and describe only additional visible features in prose.
- Author the main version for local play. Add an alternate gender version when requested or when preparing to publish. A missing or unfinished alternate can be saved and imported locally. The game uses the main version until the alternate has a name, an outfit and a starting outfit ID that matches. Public and Featured publishing require a complete alternate for each humanoid, including characters embedded in stories. Animals do not need an alternate. Use gender tokens in story text for a character whose presentation can change. Keep the specified canonical presentation for a fixed character. Prefer structured hair color, length and texture, and the supported alternate hairstyle fields. Keep face and defining details recognizable across presentations.
- Use the optional `full_body` slot for one dress, jumpsuit, or other main garment that covers both upper and lower body. Use `full_body_outerwear` for a closed long coat or cloak that covers both areas over another outfit. List each garment once, preserving separately worn layers. Use `coat` or `back` for an open or shoulder-only layer. Omit unused full-body slots or set them to `null`.
- Specify a color for every visible clothing item in each authored version. Choose clearly wearable outer clothes and footwear suitable for the environment. Use concise garment names, cut and fabric. Model layers using the exact clothing slots. Use null for an unused slot when filling a complete clothing object. Keep held objects in the hand fields. Define outfit IDs once and point the starting outfit fields to valid outfit IDs.
- Inventory items and stats must follow the canonical structures. Give the character possessions with a reason to exist. Keep appearance, props, clothes, and action separate for predictable images. Use the example's empty profile-image slots for generated or missing portraits. Include an actual image URL only when supplied or verified. Never invent an image URL, portrait ID or storage pointer.
- For Character Chat, write a single opening message with someone or something to react to. If there is an embedded playable story, use the story template object in chat_story_template. It contains its own opening, starting cast, and objectives. Character Chat and Play Story use different opening fields.
- For an animal definition use definition_type "animal", its own exact field set, a species, and physical_description. Use its species-appropriate behavior, communication and basic state. Leave humanoid appearance and wardrobe fields out of animal definitions.
- Story-embedded humanoids use the embedded-character field list instead of the standalone public catalog fields. Give them the same depth and a distinct role. Write all identities and references consistently.

### Starting emotions, physical condition, and pose

Write one concise string per field for the character's opening moment. The game copies these values into `state_of_mind`, `physical_state`, and `pose` for narration and image context. Match the opening, current equipment, and the character's abilities. For a playable character, use only feelings established by the creator or the approved premise.

- `starting_state_of_mind` describes what the character feels right now. Use one emotion or a mix, such as `"relieved to be safe, but still shaken by the climb"`. Keep lasting temperament in `personality_description`.
- `starting_physical_state` describes what the body is experiencing now, such as exhaustion, trembling, breathlessness, injury, or a physical limitation. An opening condition might be `"winded after the climb, with trembling hands and a tender left shoulder"`. Keep clothing in the outfit fields.
- `starting_pose` describes visible whole-body language and facial expression. Include the head and face, arms and hands, torso and hips, and legs and feet as applicable to the character's anatomy. Use details such as a shift of weight, a tilted head, or a small gesture to express how the character carries themselves. Keep simple poses concise. A pose might be `"chin lifted in a shaky smile, both hands braced on the railing, torso leaning forward, feet staggered for balance"`. Describe this character's own body. Put contact and interactions with other characters in the opening narration or shared scene description.

## Validation

Before handing off, parse the exact resulting JSON and check required fields, permitted keys, legal enums, age, stable IDs, wardrobe references, wrapper shape, and edition. Validate in the target game where available, fix the source file, and validate again. Report which checks actually ran. A JSON parser checks syntax. A game import tests the actual content contract.

## Exact character field lists

Use only keys in the list for the object you are authoring. A list of allowed keys does not make all of its keys required.

- CHARACTER_SHOP_COST_TEMPLATE_FIELDS
  type, costs, effects

- CHARACTER_SHOP_COST_FIELDS
  label, available_expression, op, required_stat

- CHARACTER_SHOP_EFFECT_FIELDS
  label, operation, field_path, value_stat

- CHARACTER_DEFINITION_FIELDS
  version, id, name, source, creation_tool, catalog_hook, genres, can_die, romanceable, shop_owner_category, gender, fallback_name, fallback_outfits, fallback_starting_outfit_id, age, role, personality_description, speech_style, boldness, starting_relationship_to_player, starting_trust, starting_attraction, starting_affection, starting_state_of_mind, starting_physical_state, starting_pose, appearance, outfits, starting_outfit_id, starting_held_items, starting_inventory, starting_known_facts, chat_story, chat_opening_message, chat_starting_location, chat_story_template, stats, default_seed, default_image_background, image_prompt_config, default_profile_image, profile_image_presentations, profile_images, images, voice, created_at, updated_at

- CHARACTER_REQUIRED_FIELDS
  version, id, name, source, creation_tool, genres, can_die, romanceable, gender, age, role, personality_description, speech_style, boldness, starting_relationship_to_player, starting_trust, starting_attraction, starting_affection, starting_state_of_mind, starting_physical_state, starting_pose, appearance, outfits, starting_outfit_id, starting_held_items, starting_inventory, starting_known_facts, default_seed, image_prompt_config, default_profile_image, profile_image_presentations, profile_images, images, voice, created_at, updated_at

- ANIMAL_DEFINITION_FIELDS
  version, id, name, source, creation_tool, can_die, gender, shop_owner_category, age, role, species, physical_description, personality_description, communication_style, starting_relationship_to_player, starting_trust, starting_affection, starting_state_of_mind, starting_physical_state, starting_pose, starting_known_facts, stats, default_seed, image_prompt_config, default_profile_image, profile_image_presentations, profile_images, images, voice, created_at, updated_at

- ANIMAL_DEFINITION_REQUIRED_FIELDS
  version, id, name, source, creation_tool, can_die, gender, age, role, species, physical_description, personality_description, communication_style, starting_relationship_to_player, starting_trust, starting_affection, starting_state_of_mind, starting_physical_state, starting_pose, starting_known_facts, created_at, updated_at

- CHARACTER_APPEARANCE_SCALE_FIELDS
  height, shoulder_width, chest, upper_body_build, midsection_build, hip_width, butt_build, lower_body_build, arm_length, leg_length

- CHARACTER_APPEARANCE_FIELDS
  species, height, shoulder_width, chest, upper_body_build, midsection_build, hip_width, butt_build, lower_body_build, arm_length, leg_length, skin_color, eye_color, hair_color, hair_length, hair_type, fallback_hair, extra_description, extra_description_lower_body, male_only_extra_description, non_male_only_extra_description, nonhuman_lower_body

- CHARACTER_APPEARANCE_REQUIRED_FIELDS
  species, height, shoulder_width, chest, upper_body_build, midsection_build, hip_width, butt_build, lower_body_build, arm_length, leg_length, skin_color, eye_color, hair_color, hair_length, hair_type, extra_description, extra_description_lower_body, nonhuman_lower_body

- CHARACTER_OUTFIT_FIELDS
  id, name, clothing

- CHARACTER_CLOTHING_FIELDS
  hat, hair_accessory, face, ears, neck, shoulders, bra, undershirt, shirt, over_shirt, full_body, full_body_outerwear, coat, back, hands, right_wrist, left_wrist, right_fingers, left_fingers, waist, belt_accessory, underwear, pants, skirt, legwear, socks, feet, other_accessory

- CHARACTER_HELD_ITEM_FIELDS
  right_hand, left_hand

- CHARACTER_CHAT_STARTING_LOCATION_FIELDS
  label, place, activity

- CHARACTER_IMAGE_PROMPT_FIELDS
  seed_enabled, seed, style, profile_style, negative, negative_prompt

- CHARACTER_PROFILE_IMAGE_SLOT_FIELDS
  url, local_image_id, source, seed, prompt, negative_prompt, note, male

- CHARACTER_PROFILE_IMAGE_SLOT_REQUIRED_FIELDS
  url, local_image_id, source, seed, prompt, negative_prompt, note, male

- CHARACTER_PROFILE_PRESENTATION_FIELDS
  male, non_male

- CHARACTER_IMAGE_COLLECTION_FIELDS
  active_image_id, image_ids

- CHARACTER_STARTING_INVENTORY_ITEM_FIELDS
  id, name, note, description, type, quantity, value, sellable, quest_item, image_prompt, image_id, image

## Validated story example

<!-- resource:reference-story.json -->

```json
{
  "app": "EmberAdventures",
  "exportType": "story-template",
  "storyTemplate": {
    "id": "lantern-road",
    "title": "The Lantern Road",
    "description": "Help a village bridgekeeper restore the light for the spring festival.",
    "source": "Original",
    "creation_tool": "Codex",
    "genres": [
      "fantasy"
    ],
    "createdAt": "2026-10-21T23:00:17.617Z",
    "updatedAt": "2026-10-21T23:00:17.617Z",
    "allow_any_player": true,
    "any_player_starting_state": {
      "role": "A visitor helping the bridgekeeper"
    },
    "app": "EmberAdventures",
    "templateType": "story",
    "default_image_model": "fantasy-rpg",
    "title_card_subjects": [
      "A lantern on a stone village bridge"
    ],
    "title_card_image": {
      "id": "bramble-bridge-title-card",
      "title": "The Lantern Road title card",
      "prompt": "A small stone footbridge over a shallow stream, village festival bunting and an empty iron lantern hook, soft amber dusk, illustrated fantasy landscape, no lettering.",
      "negativePrompt": "text, logo, watermark",
      "seed": 0,
      "model": "fantasy-rpg",
      "source": "hosted",
      "url": "",
      "hosted_url": "",
      "html": "",
      "favorite": false
    },
    "state": {
      "meta": {
        "app": "EmberAdventures",
        "genres": [
          "fantasy"
        ],
        "story_guidance": "Tell a short, cozy fantasy adventure. Respect the player’s chosen method. Mira offers practical help without solving tasks for the player. Keep responses concise and leave room for dialogue. The missing lantern is an ordinary accident, not a hidden villain or supernatural crisis.",
        "story_source": {
          "mode": "original",
          "title": "The Lantern Road",
          "description": "Help a village bridgekeeper restore the light for the spring festival.",
          "modifications": []
        },
        "default_image_model": "fantasy-rpg"
      },
      "player": {
        "version": 1,
        "id": "bramble-rowan-reed",
        "name": "Rowan Reed",
        "source": "Original",
        "creation_tool": "Codex",
        "can_die": false,
        "romanceable": false,
        "gender": "male",
        "fallback_name": "Rowan Reed",
        "fallback_outfits": [
          {
            "id": "fallback-default",
            "name": "Everyday work clothes",
            "clothing": {
              "hat": null,
              "hair_accessory": null,
              "face": null,
              "ears": null,
              "neck": null,
              "shoulders": null,
              "bra": null,
              "undershirt": null,
              "shirt": "opaque long-sleeved blue wool tunic",
              "over_shirt": null,
              "coat": null,
              "back": "weatherproof courier satchel",
              "hands": null,
              "right_wrist": null,
              "left_wrist": null,
              "right_fingers": null,
              "left_fingers": null,
              "waist": "plain leather belt",
              "belt_accessory": null,
              "underwear": null,
              "pants": "full-length brown canvas trousers",
              "skirt": null,
              "legwear": null,
              "socks": "gray wool socks",
              "feet": "sturdy brown walking boots",
              "other_accessory": null
            }
          }
        ],
        "fallback_starting_outfit_id": "fallback-default",
        "age": 29,
        "role": "Village courier",
        "personality_description": "Patient and curious, Rowan remembers promises and notices practical details. He can mend a strap but is no expert craftsperson. He worries about disappointing neighbors and sometimes takes on too many errands.",
        "speech_style": "Warm, plain-spoken sentences with occasional understated humor.",
        "boldness": 5,
        "starting_relationship_to_player": "self",
        "starting_trust": 4,
        "starting_attraction": 0,
        "starting_affection": 1,
        "starting_state_of_mind": "Concerned about the missing bridge lantern, but ready to help.",
        "starting_physical_state": "Healthy and uninjured.",
        "starting_pose": "Feet planted beside the bridge railing, torso leaning slightly forward, one hand gripping the rail and the other hanging loose, head turned toward the gap with a worried frown.",
        "appearance": {
          "species": "human",
          "height": "5 feet 9 inches tall",
          "skin_color": "warm brown",
          "eye_color": "hazel",
          "hair_color": "black",
          "hair_length": "short",
          "hair_type": "curly",
          "extra_description": "A small pale scar at the left temple.",
          "extra_description_lower_body": "",
          "nonhuman_lower_body": false,
          "shoulder_width": 10,
          "chest": 12,
          "upper_body_build": 12,
          "midsection_build": 12,
          "hip_width": 9,
          "butt_build": 11,
          "lower_body_build": 13,
          "arm_length": 10,
          "leg_length": 11
        },
        "outfits": [
          {
            "id": "default",
            "name": "Everyday work clothes",
            "clothing": {
              "hat": null,
              "hair_accessory": null,
              "face": null,
              "ears": null,
              "neck": null,
              "shoulders": null,
              "bra": null,
              "undershirt": null,
              "shirt": "opaque long-sleeved blue wool tunic",
              "over_shirt": null,
              "coat": null,
              "back": "weatherproof courier satchel",
              "hands": null,
              "right_wrist": null,
              "left_wrist": null,
              "right_fingers": null,
              "left_fingers": null,
              "waist": "plain leather belt",
              "belt_accessory": null,
              "underwear": null,
              "pants": "full-length brown canvas trousers",
              "skirt": null,
              "legwear": null,
              "socks": "gray wool socks",
              "feet": "sturdy brown walking boots",
              "other_accessory": null
            }
          }
        ],
        "starting_outfit_id": "default",
        "starting_held_items": {
          "right_hand": null,
          "left_hand": null
        },
        "starting_inventory": [
          "A folded route map",
          "A length of spare twine"
        ],
        "starting_known_facts": [
          "Rowan carries messages between Bramble village and nearby farms.",
          "Rowan grew up in Bramble and knows bridgekeeper Mira Bellweather.",
          "Rowan promised to deliver the festival invitations before dusk."
        ],
        "default_seed": 0,
        "image_prompt_config": {
          "seed_enabled": true,
          "seed": 0,
          "style": "high detail fantasy RPG character art, cinematic lighting",
          "profile_style": "",
          "negative": "",
          "negative_prompt": ""
        },
        "default_profile_image": {
          "url": "",
          "local_image_id": "",
          "source": "none",
          "seed": null,
          "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
          "negative_prompt": "",
          "note": "",
          "male": false
        },
        "profile_image_presentations": {
          "male": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
            "seed": null,
            "negative_prompt": "",
            "note": "",
            "male": true
          },
          "non_male": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
            "seed": null,
            "negative_prompt": "",
            "note": "",
            "male": false
          }
        },
        "profile_images": {
          "active_image_id": "",
          "image_ids": []
        },
        "images": {
          "active_image_id": "",
          "image_ids": []
        },
        "voice": null,
        "created_at": "2026-10-21T23:00:17.617Z",
        "updated_at": "2026-10-21T23:00:17.617Z"
      },
      "players": [
        {
          "version": 1,
          "id": "bramble-rowan-reed",
          "name": "Rowan Reed",
          "source": "Original",
          "creation_tool": "Codex",
          "can_die": false,
          "romanceable": false,
          "gender": "male",
          "fallback_name": "Rowan Reed",
          "fallback_outfits": [
            {
              "id": "fallback-default",
              "name": "Everyday work clothes",
              "clothing": {
                "hat": null,
                "hair_accessory": null,
                "face": null,
                "ears": null,
                "neck": null,
                "shoulders": null,
                "bra": null,
                "undershirt": null,
                "shirt": "opaque long-sleeved blue wool tunic",
                "over_shirt": null,
                "coat": null,
                "back": "weatherproof courier satchel",
                "hands": null,
                "right_wrist": null,
                "left_wrist": null,
                "right_fingers": null,
                "left_fingers": null,
                "waist": "plain leather belt",
                "belt_accessory": null,
                "underwear": null,
                "pants": "full-length brown canvas trousers",
                "skirt": null,
                "legwear": null,
                "socks": "gray wool socks",
                "feet": "sturdy brown walking boots",
                "other_accessory": null
              }
            }
          ],
          "fallback_starting_outfit_id": "fallback-default",
          "age": 29,
          "role": "Village courier",
          "personality_description": "Patient and curious, Rowan remembers promises and notices practical details. He can mend a strap but is no expert craftsperson. He worries about disappointing neighbors and sometimes takes on too many errands.",
          "speech_style": "Warm, plain-spoken sentences with occasional understated humor.",
          "boldness": 5,
          "starting_relationship_to_player": "self",
          "starting_trust": 4,
          "starting_attraction": 0,
          "starting_affection": 1,
          "starting_state_of_mind": "Concerned about the missing bridge lantern, but ready to help.",
          "starting_physical_state": "Healthy and uninjured.",
          "starting_pose": "Feet planted beside the bridge railing, torso leaning slightly forward, one hand gripping the rail and the other hanging loose, head turned toward the gap with a worried frown.",
          "appearance": {
            "species": "human",
            "height": "5 feet 9 inches tall",
            "skin_color": "warm brown",
            "eye_color": "hazel",
            "hair_color": "black",
            "hair_length": "short",
            "hair_type": "curly",
            "extra_description": "A small pale scar at the left temple.",
            "extra_description_lower_body": "",
            "nonhuman_lower_body": false,
            "shoulder_width": 10,
            "chest": 12,
            "upper_body_build": 12,
            "midsection_build": 12,
            "hip_width": 9,
            "butt_build": 11,
            "lower_body_build": 13,
            "arm_length": 10,
            "leg_length": 11
          },
          "outfits": [
            {
              "id": "default",
              "name": "Everyday work clothes",
              "clothing": {
                "hat": null,
                "hair_accessory": null,
                "face": null,
                "ears": null,
                "neck": null,
                "shoulders": null,
                "bra": null,
                "undershirt": null,
                "shirt": "opaque long-sleeved blue wool tunic",
                "over_shirt": null,
                "coat": null,
                "back": "weatherproof courier satchel",
                "hands": null,
                "right_wrist": null,
                "left_wrist": null,
                "right_fingers": null,
                "left_fingers": null,
                "waist": "plain leather belt",
                "belt_accessory": null,
                "underwear": null,
                "pants": "full-length brown canvas trousers",
                "skirt": null,
                "legwear": null,
                "socks": "gray wool socks",
                "feet": "sturdy brown walking boots",
                "other_accessory": null
              }
            }
          ],
          "starting_outfit_id": "default",
          "starting_held_items": {
            "right_hand": null,
            "left_hand": null
          },
          "starting_inventory": [
            "A folded route map",
            "A length of spare twine"
          ],
          "starting_known_facts": [
            "Rowan carries messages between Bramble village and nearby farms.",
            "Rowan grew up in Bramble and knows bridgekeeper Mira Bellweather.",
            "Rowan promised to deliver the festival invitations before dusk."
          ],
          "default_seed": 0,
          "image_prompt_config": {
            "seed_enabled": true,
            "seed": 0,
            "style": "high detail fantasy RPG character art, cinematic lighting",
            "profile_style": "",
            "negative": "",
            "negative_prompt": ""
          },
          "default_profile_image": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "seed": null,
            "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
            "negative_prompt": "",
            "note": "",
            "male": false
          },
          "profile_image_presentations": {
            "male": {
              "url": "",
              "local_image_id": "",
              "source": "none",
              "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
              "seed": null,
              "negative_prompt": "",
              "note": "",
              "male": true
            },
            "non_male": {
              "url": "",
              "local_image_id": "",
              "source": "none",
              "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
              "seed": null,
              "negative_prompt": "",
              "note": "",
              "male": false
            }
          },
          "profile_images": {
            "active_image_id": "",
            "image_ids": []
          },
          "images": {
            "active_image_id": "",
            "image_ids": []
          },
          "voice": null,
          "created_at": "2026-10-21T23:00:17.617Z",
          "updated_at": "2026-10-21T23:00:17.617Z"
        }
      ],
      "characters": {},
      "future_cast": {
        "enabled": false,
        "items": {}
      },
      "location": {
        "universe": "Bramble Tales",
        "world": "Alder",
        "continent": "Westreach",
        "region": "Willow Vale",
        "settlement_type": "village",
        "settlement_name": "Bramble",
        "district": "Riverside",
        "specific_place": "Bramble Bridge",
        "npc_location_id": "bramble-bridge"
      },
      "npc_directory": {
        "locations": {
          "bramble-bridge": {
            "label": "Bramble Bridge",
            "characters": {
              "Mira Bellweather": {
                "id": "bramble-mira-bellweather",
                "name": "Mira Bellweather",
                "gender": "female",
                "age": 46,
                "role": "Bridgekeeper and lantern maker",
                "relationship": "acquaintance",
                "note": "Bridgekeeper and lantern maker; knows Rowan from village deliveries.",
                "current_appearance": "Standing beside the empty lantern hook with a canvas tool roll.",
                "inspected": true,
                "voice": null,
                "full_character": {
                  "version": 1,
                  "id": "bramble-mira-bellweather",
                  "name": "Mira Bellweather",
                  "source": "Original",
                  "creation_tool": "Codex",
                  "can_die": false,
                  "romanceable": false,
                  "gender": "female",
                  "fallback_name": "Mira Bellweather",
                  "fallback_outfits": [
                    {
                      "id": "fallback-default",
                      "name": "Everyday work clothes",
                      "clothing": {
                        "hat": null,
                        "hair_accessory": "simple wooden hair clasp",
                        "face": null,
                        "ears": null,
                        "neck": null,
                        "shoulders": null,
                        "bra": null,
                        "undershirt": null,
                        "shirt": "opaque long-sleeved rust-red linen shirt",
                        "over_shirt": "heavy full-front canvas work apron",
                        "coat": null,
                        "back": null,
                        "hands": null,
                        "right_wrist": null,
                        "left_wrist": null,
                        "right_fingers": null,
                        "left_fingers": null,
                        "waist": null,
                        "belt_accessory": null,
                        "underwear": null,
                        "pants": "full-length dark green work trousers",
                        "skirt": null,
                        "legwear": null,
                        "socks": "cream wool socks",
                        "feet": "black leather work boots",
                        "other_accessory": null
                      }
                    }
                  ],
                  "fallback_starting_outfit_id": "fallback-default",
                  "age": 46,
                  "role": "Bridgekeeper and lantern maker",
                  "personality_description": "Methodical, kind, and quietly stubborn. Mira takes pride in maintaining public things that others overlook. She taps a thumb against her tool roll when thinking. Her patience frays when people treat every old object as disposable; she admits when she needs help.",
                  "speech_style": "Brief, concrete explanations, dry humor, and a reassuring tone when someone struggles.",
                  "boldness": 5,
                  "starting_relationship_to_player": "acquaintance",
                  "starting_trust": 4,
                  "starting_attraction": 0,
                  "starting_affection": 1,
                  "starting_state_of_mind": "Concerned about the missing bridge lantern, but ready to help.",
                  "starting_physical_state": "Healthy and uninjured.",
                  "starting_pose": "Feet planted beside the bridge railing, torso leaning slightly forward, one hand gripping the rail and the other hanging loose, head turned toward the gap with a worried frown.",
                  "appearance": {
                    "species": "human",
                    "height": "5 feet 4 inches tall",
                    "skin_color": "light brown",
                    "eye_color": "green",
                    "hair_color": "silver-gray",
                    "hair_length": "shoulder length",
                    "hair_type": "wavy",
                    "extra_description": "A scattering of freckles across her nose.",
                    "extra_description_lower_body": "",
                    "nonhuman_lower_body": false,
                    "shoulder_width": 12,
                    "chest": 13,
                    "upper_body_build": 8,
                    "midsection_build": 6,
                    "hip_width": 12,
                    "butt_build": 7,
                    "lower_body_build": 9,
                    "arm_length": 10,
                    "leg_length": 10
                  },
                  "outfits": [
                    {
                      "id": "default",
                      "name": "Everyday work clothes",
                      "clothing": {
                        "hat": null,
                        "hair_accessory": "simple wooden hair clasp",
                        "face": null,
                        "ears": null,
                        "neck": null,
                        "shoulders": null,
                        "bra": null,
                        "undershirt": null,
                        "shirt": "opaque long-sleeved rust-red linen shirt",
                        "over_shirt": "heavy full-front canvas work apron",
                        "coat": null,
                        "back": null,
                        "hands": null,
                        "right_wrist": null,
                        "left_wrist": null,
                        "right_fingers": null,
                        "left_fingers": null,
                        "waist": null,
                        "belt_accessory": null,
                        "underwear": null,
                        "pants": "full-length dark green work trousers",
                        "skirt": null,
                        "legwear": null,
                        "socks": "cream wool socks",
                        "feet": "black leather work boots",
                        "other_accessory": null
                      }
                    }
                  ],
                  "starting_outfit_id": "default",
                  "starting_held_items": {
                    "right_hand": "A folded canvas tool roll",
                    "left_hand": null
                  },
                  "starting_inventory": [
                    "A small brass workshop key",
                    "A clean polishing cloth"
                  ],
                  "starting_known_facts": [
                    "Mira has maintained Bramble Bridge for sixteen years.",
                    "Mira made the bridge lantern with her father and repairs it each spring.",
                    "Mira keeps a spare lantern frame and amber glass in her workshop."
                  ],
                  "default_seed": 0,
                  "image_prompt_config": {
                    "seed_enabled": true,
                    "seed": 0,
                    "style": "high detail fantasy RPG character art, cinematic lighting",
                    "profile_style": "",
                    "negative": "",
                    "negative_prompt": ""
                  },
                  "default_profile_image": {
                    "url": "",
                    "local_image_id": "",
                    "source": "none",
                    "seed": null,
                    "prompt": "Mira Bellweather, A stocky, sturdy build with a relaxed, practical bearing. opaque long-sleeved rust-red linen shirt, full-length dark green work trousers, black leather work boots. Warm illustrated fantasy village portrait.",
                    "negative_prompt": "",
                    "note": "",
                    "male": false
                  },
                  "profile_image_presentations": {
                    "male": {
                      "url": "",
                      "local_image_id": "",
                      "source": "none",
                      "prompt": "Mira Bellweather, A stocky, sturdy build with a relaxed, practical bearing. opaque long-sleeved rust-red linen shirt, full-length dark green work trousers, black leather work boots. Warm illustrated fantasy village portrait.",
                      "seed": null,
                      "negative_prompt": "",
                      "note": "",
                      "male": true
                    },
                    "non_male": {
                      "url": "",
                      "local_image_id": "",
                      "source": "none",
                      "prompt": "Mira Bellweather, A stocky, sturdy build with a relaxed, practical bearing. opaque long-sleeved rust-red linen shirt, full-length dark green work trousers, black leather work boots. Warm illustrated fantasy village portrait.",
                      "seed": null,
                      "negative_prompt": "",
                      "note": "",
                      "male": false
                    }
                  },
                  "profile_images": {
                    "active_image_id": "",
                    "image_ids": []
                  },
                  "images": {
                    "active_image_id": "",
                    "image_ids": []
                  },
                  "voice": null,
                  "created_at": "2026-10-21T23:00:17.617Z",
                  "updated_at": "2026-10-21T23:00:17.617Z"
                }
              }
            }
          }
        }
      },
      "scene": {
        "summary": "Mira waits at the bridge with a repaired lantern ready to light.",
        "party_members_present": [],
        "image_characters": [
          "Mira Bellweather"
        ],
        "npcs_present": [
          "Mira Bellweather"
        ],
        "image_action": "Holding a repaired lantern beside the bridge hook."
      },
      "story_rules": [
        {
          "id": "safe-recovery",
          "text": "No one is in immediate danger. The stream is shallow; any recovery can be done safely from the bank with the available rake."
        },
        {
          "id": "patient-festival",
          "text": "The festival waits for the bridge light; there is no hidden countdown or forced failure."
        }
      ],
      "story_inventory": {
        "items": []
      },
      "world_map": {
        "current_location_id": "bramble-bridge",
        "focus_location_id": "bramble-bridge",
        "travel_history": [
          "bramble-bridge"
        ],
        "locations": {
          "bramble-bridge": {
            "id": "bramble-bridge",
            "name": "Bramble Bridge",
            "type": "place",
            "scale": "site",
            "parent_id": "",
            "x": 0,
            "y": 0,
            "discovered": true,
            "travel_enabled": true,
            "summary": "A stone footbridge with festival ribbons and an empty lantern hook.",
            "detail": {},
            "connections": [
              "willow-bank",
              "lantern-workshop"
            ],
            "npcs": [
              "Mira Bellweather"
            ]
          },
          "willow-bank": {
            "id": "willow-bank",
            "name": "Willow Bank",
            "type": "place",
            "scale": "site",
            "parent_id": "",
            "x": 1,
            "y": 0,
            "discovered": true,
            "travel_enabled": true,
            "summary": "A shallow, muddy bank below the bridge; a long-handled rake rests by the steps.",
            "detail": {},
            "connections": [
              "bramble-bridge"
            ],
            "npcs": []
          },
          "lantern-workshop": {
            "id": "lantern-workshop",
            "name": "Mira’s Workshop",
            "type": "place",
            "scale": "site",
            "parent_id": "",
            "x": -1,
            "y": 0,
            "discovered": true,
            "travel_enabled": true,
            "summary": "A tidy workshop beside the bridge, stocked with spare lantern parts.",
            "detail": {},
            "connections": [
              "bramble-bridge"
            ],
            "npcs": []
          }
        }
      },
      "objectives": {
        "active_id": "light-the-crossing",
        "no_current": false,
        "items": [
          {
            "id": "light-the-crossing",
            "title": "Light the crossing",
            "type": "story",
            "status": "active",
            "summary": "A working lantern is ready. Mira has a candle and taper; the repaired hook waits on the bridge.",
            "while_active_guidance": "Let the player act at their own pace. Do not complete the next task in the same response.",
            "completion_control": "ai",
            "completion_criteria": "The player lights and hangs the usable lantern on Bramble Bridge.",
            "next_objectives": [
              {
                "id": "bridge-lit",
                "completion_instruction": "Describe the amber light reaching the bridge stones and the first festival visitors crossing. Mira thanks the player in her reserved, sincere way. Leave the evening open for conversation or exploring the festival.",
                "rewards": [],
                "ending_type": "freeplay",
                "ending_title": "A light for everyone",
                "ending_message": "The crossing glows again. Music carries across the water, and the festival evening is yours to enjoy."
              }
            ]
          }
        ]
      },
      "time": {
        "year": 1,
        "month": 5,
        "day": 12,
        "hour": 18,
        "minute": 0
      },
      "story_memory": {
        "world_notes": [
          "Bramble celebrates its spring festival this evening.",
          "Mira’s workshop stands next to Bramble Bridge."
        ],
        "unresolved_threads": [],
        "relationship_notes": [
          "Mira knows the default courier Rowan through village deliveries. Other player characters begin as visitors."
        ],
        "rules_and_constraints": [],
        "ai_private_notes": []
      },
      "recent_changes": [],
      "story_clock": {
        "elapsed_minutes": 0,
        "label": "Day 1, 6:00 PM"
      },
      "story_pacing": {
        "mode": "player_controlled",
        "pending_event_id": "",
        "timeline": {}
      },
      "timed_events": {}
    },
    "messages": [
      {
        "role": "assistant",
        "speaker": "Narrator",
        "at": "2026-10-21T23:00:17.617Z",
        "text": "The repaired lantern rests on Bramble Bridge. Mira places a fresh candle beside it. “Ready when you are,” she says, holding out a taper. Music drifts from the village square."
      }
    ]
  },
  "exportedAt": "2026-10-21T23:00:17.617Z"
}
```
