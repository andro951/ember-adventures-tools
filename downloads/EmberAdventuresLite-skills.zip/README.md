# EmberAdventuresLite authoring skills

Extract the ZIP. For ChatGPT or another chat assistant, attach the single matching
Markdown file under attachments/. The story instructions include character
authoring. The character instructions cover stand-alone exports and embedded stories.

For Codex, install the named skill folders into your skills directory.
The optional character scripts/validate-content.cjs helper validates JSON against
a current shared game checkout. Run with --edition lite.

Public distribution is ZIP-only. After skill maintenance, validate resources,
update installed copies, rebuild using maintainer/package_skills.py, replace the
matching archive under downloads/ in ember-adventures-tools and skills/ in the
game repository, then push. Do not publish extracted folders or version files.
Use --source <editable-root> --kind authoring --normal-repo <shared-game>
to regenerate from the current schema. For an unchanged extracted bundle, use
--source <extracted-root> --kind lite.

Versions:
- emberadventureslite-character: 2.1.1
- emberadventureslite-story: 2.1.1