# EmberAdventuresLite authoring skills

Each skill directory contains one complete SKILL.md. Use it directly as an AI attachment or install that directory in Codex. The game downloads the same file.

Rebuild archives with maintainer/package_skills.py. Supply --normal-repo <shared game checkout> to validate the embedded examples and update both installed game bundles.
