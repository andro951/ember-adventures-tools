"""Build complete, reproducible skill archives; public repositories contain ZIPs only."""
import argparse
import hashlib
import json
import pathlib
import re
import shutil

import subprocess
import zipfile

PRODUCTS = {
    "normal": ("EmberAdventures", ["emberadventures-character", "emberadventures-story"]),
    "lite": ("EmberAdventuresLite", ["emberadventureslite-character", "emberadventureslite-story"]),
    "play": ("EmberAdventures-play", ["emberadventures-play"]),
}

def digest(data):
    return hashlib.sha256(data).hexdigest()

BUNDLED_INSTRUCTIONS = "\n<!-- bundled-authoring -->\n"

def authoring_attachment(product, kind, data, source):
    lite = product.endswith("Lite")
    edition = "Lite" if lite else "Full"
    heading = f"# {product} {kind} instructions\n\nTarget EmberAdventures {edition}. Use this file as your complete authoring instructions."
    if lite:
        mode = """Write general-audience content. Keep ordinary relationships and romance appropriate for a general audience. Use the Lite field lists below. Omit fields outside those lists, including adult-content classifiers, preferences, and mechanics. Omit the legacy lite marker. Keep the shared EmberAdventures export identity. The game adds the required SFW defaults when preparing content for public publishing."""
    else:
        mode = """Use the Full field lists below. Set the exact content classification fields based on the actual content. Match the creator's requested boundaries and retain required defaults from the example where appropriate. Omit the legacy lite marker."""
    sections = [heading, mode]
    order = ["story", "character"] if kind == "story" else ["character", "story"]
    for section in order:
        guide = source / f"emberadventures-{section}" / "references" / "authoring-attachment.md"
        sections.append(re.sub(r"^# ", "## ", guide.read_text(encoding="utf-8-sig").strip(), count=1))
    for section in order:
        lines = [f"## Exact {section} field lists", "Use only keys in the list for the object you are authoring. A list of allowed keys does not make all of its keys required."]
        for key, fields in data["fields"][section].items():
            if fields:
                lines.append(f'- {key}\n  {", ".join(fields)}')
        sections.append("\n\n".join(lines))
    example_kinds = ["story"] if kind == "story" else order
    for section in example_kinds:
        example = json.dumps(data["examples"][section], indent=2, ensure_ascii=False)
        note = "\n\nFor an embedded character story, use the inner storyTemplate object of this example as chat_story_template." if kind == "character" and section == "story" else ""
        sections.append(f"## Validated {section} example{note}\n\n```json\n{example}\n```")
    return ("\n\n".join(sections) + "\n").encode("utf-8")

def package(source, product, names, script, authoring):
    files = {}
    versions = {}
    lite = product.endswith("Lite")
    is_authoring = len(names) == 2
    for name in names:
        folder = source / name
        skill_file = folder / "SKILL.md"
        if not skill_file.is_file():
            raise ValueError(f"Missing skill: {folder}")
        text = skill_file.read_text(encoding="utf-8-sig")
        version = re.search(r"(?:Current skill version: `|Version: )(\d+\.\d+\.\d+)", text)
        if not version:
            raise ValueError(f"Missing version: {name}")
        versions[name] = version.group(1)
        for file in sorted(folder.rglob("*")):
            if not file.is_file():
                continue
            relative = file.relative_to(folder)
            if any(part.startswith(".") or part in {"__pycache__", "node_modules", "private-data", "test-output"} for part in relative.parts):
                raise ValueError(f"Do not package private/cache files: {file}")
            if file.suffix not in {".md", ".json", ".yaml", ".cjs", ".mjs"}:
                raise ValueError(f"Unexpected resource: {file}")
            if lite and authoring and relative.parts[0] not in {"SKILL.md", "agents"}:
                continue
            files[f"{name}/{relative.as_posix()}"] = file.read_bytes()

        if is_authoring:
            kind = name.rsplit("-", 1)[-1]
            attachment_name = f"attachments/{product}-{kind.capitalize()}-Instructions.md"
            if authoring:
                edition = "lite" if lite else "full"
                files[attachment_name] = authoring_attachment(product, kind, authoring[edition], source)
                if lite:
                    files[f"{name}/SKILL.md"] = text.split(BUNDLED_INSTRUCTIONS)[0].rstrip().encode() + BUNDLED_INSTRUCTIONS.encode() + files[attachment_name]
                else:
                    files[f"{name}/references/authoring-lite.md"] = authoring_attachment("EmberAdventuresLite", kind, authoring["lite"], source)
            else:
                files[attachment_name] = (source / attachment_name).read_bytes()

    if lite and authoring:
        validator = source / "emberadventures-character/scripts/validate-content.cjs"
        files[f"{names[0]}/scripts/validate-content.cjs"] = validator.read_bytes()
        for name in names:
            kind = name.rsplit("-", 1)[-1]
            reference = json.dumps(authoring["lite"]["examples"][kind], indent=2, ensure_ascii=False)
            files[f"{name}/references/reference-{kind}.json"] = (reference + "\n").encode()
    files["maintainer/package_skills.py"] = script.read_bytes()
    if is_authoring:
        generator = script.with_name("build_authoring_data.cjs")
        if generator.is_file():
            files["maintainer/build_authoring_data.cjs"] = generator.read_bytes()

    readme = f"""# {product} authoring skills

Extract the ZIP. For ChatGPT or another chat assistant, attach the single matching
Markdown file under attachments/. The story instructions include character
authoring. The character instructions cover stand-alone exports and embedded stories.

For Codex, install the named skill folders into your skills directory.
The optional character scripts/validate-content.cjs helper validates JSON against
a current shared game checkout. Run with --edition {"lite" if lite else "full"}.

Public distribution is ZIP-only. After skill maintenance, validate resources,
update installed copies, rebuild using maintainer/package_skills.py, replace the
matching archive under downloads/ in ember-adventures-tools and skills/ in the
game repository, then push. Do not publish extracted folders or version files.
Use --source <editable-root> --kind authoring --normal-repo <shared-game>
to regenerate from the current schema. For an unchanged extracted bundle, use
--source <extracted-root> --kind {"lite" if lite else "normal"}.

Versions:
""" + "".join(f"- {name}: {versions[name]}\n" for name in names)
    files["README.md"] = readme.rstrip().encode()
    if names == ["emberadventures-play"]:
        files["README.md"] = ("""# EmberAdventures play skill

Extract this archive and install emberadventures-play/ in the Codex skills directory.
Start with its SKILL.md and read references/live-session.md for the tested commands.
The skill uses the existing harness in a local normal EmberAdventures checkout;
it does not bundle a game, provider session, browser profile, or credentials.

Editable sources stay local. Validate with the skill-creator quick validator,
then rebuild this complete ZIP using maintainer/package_skills.py --kind play.
Use --source <extracted-root> --public <public-tools-checkout> and optionally
--normal-repo <game-checkout> --install-root <Codex-skills-directory>.
Public distribution is ZIP-only. Update archive links and push the ZIP after changes.

Versions:
""" + "".join(f"- {name}: {versions[name]}\n" for name in names)).rstrip().encode()
    manifest = {"product": product, "skills": versions, "files": {name:digest(data) for name,data in sorted(files.items())}}
    files["manifest.json"] = json.dumps(manifest, indent=2, ensure_ascii=False).encode()
    return files

def write_zip(file, files):
    file.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(file, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data, compresslevel=9)
    with zipfile.ZipFile(file) as archive:
        if archive.testzip() is not None or set(archive.namelist()) != set(files):
            raise ValueError(f"ZIP verification failed: {file}")
        for name,data in files.items():
            if archive.read(name) != data:
                raise ValueError(f"ZIP entry mismatch: {name}")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=pathlib.Path, required=True)
    parser.add_argument("--public", type=pathlib.Path, required=True, help="Public ember-adventures-tools checkout")
    parser.add_argument("--kind", choices=[*PRODUCTS, "authoring", "all"], default="all")
    parser.add_argument("--normal-repo", type=pathlib.Path)
    parser.add_argument("--lite-repo", type=pathlib.Path)
    parser.add_argument("--install-root", type=pathlib.Path)
    parser.add_argument("--node", default="node")
    args = parser.parse_args()
    if (args.public.resolve() / ".git").exists():
        tracked = subprocess.run(["git", "ls-files"], cwd=args.public, check=True, capture_output=True, text=True).stdout.splitlines()
        if any(not name.endswith(".zip") for name in tracked):
            raise ValueError("The public skill repository must track ZIP files only. Preserve editable sources locally before removing loose published files.")
    source = args.source.resolve()
    if (source / "skills").is_dir():
        source /= "skills"
    selected = list(PRODUCTS) if args.kind == "all" else ["normal", "lite"] if args.kind == "authoring" else [args.kind]
    authoring = None
    generator = pathlib.Path(__file__).with_name("build_authoring_data.cjs")
    if any(kind in {"normal", "lite"} for kind in selected) and (source / "emberadventures-character/references/authoring-attachment.md").exists() and args.normal_repo:
        generated = subprocess.run(
            [args.node, str(generator), str(args.normal_repo.resolve()), str(source)],
            check=True, capture_output=True, encoding="utf-8",
        )
        authoring = json.loads(generated.stdout)
    for kind in selected:
        product, names = PRODUCTS[kind]
        repo = (args.lite_repo or args.normal_repo) if kind == "lite" else args.normal_repo
        files = package(source, product, names, pathlib.Path(__file__).resolve(), authoring)
        output = args.public.resolve()/"downloads"/(product+"-skills.zip")
        write_zip(output,files)
        if repo:
            destination=repo.resolve()/"skills"/output.name
            destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(output,destination)
        if args.install_root:
            for entry, data in files.items():
                if entry.split("/", 1)[0] not in names:
                    continue
                destination = args.install_root.resolve() / entry
                if destination.resolve() == (source / entry).resolve():
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
        print(f"Packaged {product}: {len(files)} files; SHA-256 {digest(output.read_bytes())}")

if __name__ == "__main__":
    main()
