"use strict";

const fs = require("node:fs");
const path = require("node:path");

const [repository, sources] = process.argv.slice(2).map(value => path.resolve(value));
const {createProductionContext} = require(path.join(repository,"tools/lib/production-declarations.cjs"));
const adapter = require(path.join(repository,"src/editions/lite/shared-library-format.js"));
const normalFormat = require(path.join(repository,"src/contracts/lite-import-format.js"));

function reference(skill,file) {
    const contents = fs.readFileSync(path.join(sources,"emberadventures-"+skill,"references",file),"utf8");
    return JSON.parse(contents.replace(/^\uFEFF/,""));
}

const examples = {
    character: reference("character","reference-character.json"),
    story: reference("story","reference-story.json"),
};
const fieldNames = Object.fromEntries(["character","story"].map(skill => [
    skill,
    Object.keys(reference(skill,"field-sets.json")).filter(name =>
        !name.startsWith("CHARACTER_LIBRARY_") && !name.startsWith("RUNTIME_") &&
        !name.startsWith("STORY_TITLE_CARD_STORE_")
    ),
]));

const serializable = value => JSON.parse(JSON.stringify(value));
function checkResult(result,label) {
    if (!result.ok) throw new Error(label + ": " + JSON.stringify(result.errors));
}
const data = {};
for (const edition of ["full","lite"]) {
    const production = createProductionContext(repository,{edition});
    const contents = edition === "lite"
        ? Object.fromEntries(Object.entries(examples).map(([name, value])=>[name, adapter.toLite(value)]))
        : examples;
    const fields = {};
    for (const [kind, names] of Object.entries(fieldNames)) {
        fields[kind] = {};
        for (const name of names) {
            if (edition === "lite" && name.startsWith("MAIN_PLOT_POINT_")) continue;

            production.load(name);
            const value = production.context[name];
            if (!Array.isArray(value) || !value.every(item=>typeof item==="string"))
                throw new Error(edition+" field list must contain only strings: "+name);

            fields[kind][name] = [...value].filter(field=>field!=="lite");
        }
    }
    for (const [kind, payload] of Object.entries(contents)) {
        const method = kind === "character" ? "validateCharacterExport" : "validateStoryExport";
        const native = serializable(payload);
        checkResult(production.invoke(method,native),edition+" "+kind+" example");
        if (edition === "lite") {
            const fullExample = normalFormat.addSfwDefaults(native);
            checkResult(data.full.production.invoke(method,fullExample),"Full accepts published Lite "+kind);
            if (JSON.stringify(adapter.toLite(fullExample)) !== JSON.stringify(native))
                throw new Error("Published Lite "+kind+" does not round trip to its local form.");
        }
    }
    data[edition] = {production,examples:contents,fields};
}

process.stdout.write(JSON.stringify(Object.fromEntries(
    Object.entries(data).map(([edition,{examples,fields}])=>[edition,{examples,fields}])
)));
