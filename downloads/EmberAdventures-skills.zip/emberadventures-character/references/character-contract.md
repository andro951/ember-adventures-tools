# Character contract

Use [reference-character.json](reference-character.json) for a complete validated export.
`field-sets.json` snapshots the current canonical field names; the game validator remains authoritative.

## Character Schema And Rules

This skill must be shareable as a standalone skill. Do not depend on any shared EmberAdventures reference files at runtime. The only external file this skill should require is the optional private preference file described in this skill.

If you are not aware of the user's preference file, and the user has not explicitly told you they don't want one, the first step of using this skill is asking the user if they want to create a private preference file to use when creating characters so that created characters will match their prefernces.

### Required Metadata

Every standalone character-library definition must include non-null `source`,
`creation_tool`, approved `genres`, boolean `nsfw`, boolean `loli`, and boolean
`can_die`. Original characters use `source: "Original"`; `creation_tool` records
the actual tool/model/reasoning label. `genres` belongs on standalone library
exports, not story-embedded definitions. `kink_tags` is optional searchable
metadata only for standalone library definitions; story-embedded definitions,
future-cast shells, and future-cast `full_character` definitions must omit it.
Use `can_die: false` by default for standalone definitions. The field
contract below is authoritative for meanings, allowed shapes, and runtime-field
exclusions. Do not emit `creator` or `creator_id`; EmberAdventures assigns
creator ownership during import. This is an internal maintenance rule: never
add creator fields back to this skill, never show them in examples, and never
ask the user for a creator name or alias during preference intake.

### Character Export Shape

The field contract below is authoritative. Keep the example and contract synchronized; there are no exception rules for older examples.

Use `character_definition` as the single immutable/default character object. Do
not use other top level fields. Story/runtime placement decides whether this
definition becomes a player, party character, future character, or inspected NPC.
For creating batches of characters, use a characters array as shown below, or make a separate file for each character. Do not add any other top level fields to the export. Ask the user if they want seperate files or 1 file with all characters in it when creating multiple at once. The game is capable of importing either, but for batches, it will import all of them, so a batch file should only be created if it's intended to import all of them into the game together.
```json
{
  "characters": [
    {
      "character_definition": {
        ...
      }
    }
  ]
}
```

Before final export, run a field-purpose and process-leakage pass. For every
field, ask what the field is for, how EmberAdventures uses/displays it, whether the
value serves that purpose, and whether it can be clearer or or match the intended use better.
Character information should never mention how the character will be or how it will change in
the future. Character definitions are meant to be a snapshot of a character in a specific
point in time. You should describe them exactly as they are at that moment, and you can also
include include the backstory/history of that character. The only future related information
that is allowed is future asperations, desires, and goals.

Before final export, run a character-depth pass. A final character definition
must be useful in EmberAdventures, not just technically valid. Characters should have
concrete `starting_known_facts` covering identity, role, personality under pressure,
combat/usefulness or social usefulness, household/social role when relevant, quirks/preferences,
and relationship dynamics.

Before final export, run the standalone release pass. Do not assume an
EmberAdventures maintainer or a later main thread will repair the character after
output. If schema fields are questionable, metadata is missing, durable facts
are generic, outfit slots are incomplete, or the character concept is underdeveloped,
fix it before final output or clearly ask the user for the missing decision.

If creating a batch of characters, or if there is a known library of existing characters, run a duplicate-name-and-id validation pass where you make sure that there are no exact matches for character names. If there is an exact name match, or if the newly created character has only a first name and it matches an existing first name, a new name should be chosen. If a last name matches an existing character, it should be changed unless the two characters sharing a last name (being related) is intended.

The timestamp strings in the example below are documentation placeholders
only. Replace them with real ISO 8601 timestamps in every final file.

```json
{
  "character_definition": {
    "version": 1,
    "id": "character-name",
    "name": "Character Name",
    "source": "Original",
    "creation_tool": "<Tool> <Model Number> (<Reasoning or Intelligence Level>)",
    "catalog_hook": "A concise, spoiler-free reason to start a game with this character.",
    "default_image_background": "a candlelit apothecary lined with dried herbs and glass bottles",
    "genres": ["fantasy"],
    "kink_tags": [],
    "nsfw": false,
    "loli": false,
    "can_die": false,
    "romanceable": true,
    "gender": "female",
    "fallback_name": "Fallback Name",
    "fallback_outfits": [
      {
        "id": "default",
        "name": "Default",
        "nsfw": false,
        "clothing": {
          "hat": "hat",
          "hair_accessory": "hair accessory",
          "face": "face",
          "ears": "ears",
          "neck": "neck",
          "shoulders": "shoulders",
          "bra": "bra",
          "undershirt": "undershirt",
          "shirt": "shirt",
          "over_shirt": "over shirt",
          "coat": "coat",
          "back": "back",
          "hands": "hands",
          "right_wrist": "right wrist",
          "left_wrist": "left wrist",
          "right_fingers": "right fingers",
          "left_fingers": "left fingers",
          "waist": "waist",
          "belt_accessory": "belt accessory",
          "underwear": "underwear",
          "pants": "pants",
          "skirt": "skirt",
          "legwear": "legwear",
          "socks": "socks",
          "feet": "feet",
          "other_accessory": "other accessory"
        }
      }
    ],
    "fallback_starting_outfit_id": "default",
    "age": 25,
    "role": "Short role",
    "personality_description": "Durable personality and behavior summary.",
    "speech_style": "Concise durable dialogue style.",
    "boldness": 5,
    "starting_relationship_to_player": "none",
    "starting_trust": 0,
    "starting_attraction": 0,
    "starting_affection": 0,
    "starting_arousal": 0,
    "starting_state_of_mind": "",
    "starting_physical_state": "",
    "starting_pose": "",
    "appearance": {
      "species": "complete species identity, including meaningful subtype or qualifier",
      "height": 10,
      "shoulder_width": 10,
      "chest": 13,
      "upper_body_build": 8,
      "midsection_build": 8,
      "hip_width": 10,
      "butt_build": 8,
      "lower_body_build": 8,
      "arm_length": 10,
      "leg_length": 10,
      "penis_size": 10,
      "skin_color": "",
      "eye_color": "",
      "hair_color": "",
      "hair_length": "",
      "hair_type": "",
      "extra_description": "",
      "extra_description_lower_body": "",
      "nonhuman_lower_body": false
    },
    "outfits": [
      {
        "id": "default",
        "name": "Default",
        "nsfw": false,
        "clothing": {
          "hat": "hat",
          "hair_accessory": "hair accessory",
          "face": "face",
          "ears": "ears",
          "neck": "neck",
          "shoulders": "shoulders",
          "bra": "bra",
          "undershirt": "undershirt",
          "shirt": "shirt",
          "over_shirt": "over shirt",
          "coat": "coat",
          "back": "back",
          "hands": "hands",
          "right_wrist": "right wrist",
          "left_wrist": "left wrist",
          "right_fingers": "right fingers",
          "left_fingers": "left fingers",
          "waist": "waist",
          "belt_accessory": "belt accessory",
          "underwear": "underwear",
          "pants": "pants",
          "skirt": "skirt",
          "legwear": "legwear",
          "socks": "socks",
          "feet": "feet",
          "other_accessory": "other accessory"
        }
      }
    ],
    "starting_outfit_id": "default",
    "starting_held_items": {
      "right_hand": null,
      "left_hand": null
    },
    "starting_inventory": [],
    "starting_known_facts": [],
    "starting_nsfw_known_facts": [],
    "chat_story": "",
    "chat_opening_message": "",
    "chat_starting_location": {
      "label": "",
      "place": "",
      "activity": ""
    },
    "chat_story_template": null,
    "default_seed": 0,
    "image_prompt_config": {
      "seed_enabled": true,
      "seed": 0,
      "style": "",
      "profile_style": "",
      "negative": "",
      "negative_prompt": ""
    },
    "default_profile_image": {
      "url": "",
      "local_image_id": "",
      "source": "none",
      "seed": null,
      "prompt": "",
      "negative_prompt": "",
      "note": "",
      "male": false
    },
    "profile_image_presentations": {
      "male": {
        "url": "",
        "local_image_id": "",
        "source": "none",
        "seed": null,
        "prompt": "",
        "negative_prompt": "",
        "note": "",
        "male": true
      },
      "non_male": {
        "url": "",
        "local_image_id": "",
        "source": "none",
        "seed": null,
        "prompt": "",
        "negative_prompt": "",
        "note": "",
        "male": false
      }
    },
    "profile_images": {
      "active_image_id": "",
      "image_ids": []
    },
    "images": {
      "active_image_id": "",
      "image_ids": []
    },
    "voice": null,
    "created_at": "<actual ISO 8601 creation timestamp>",
    "updated_at": "<actual ISO 8601 update timestamp>"
  }
}
```

Keep all image and voice fields blank exactly as shown. The application supplies image
styles, generated image records, ownership ids, voices, and active-image metadata after
import. All of these top level fields should be exactly the same as the example above:
"default_seed",
"image_prompt_config",
"default_profile_image",
"profile_image_presentations",
"profile_images",
"images",
"voice"

### Character Definition Field Contract

Use this contract when creating EmberAdventures character definitions. Do not add
fields that are absent from the example and field rules. Standalone library
characters and characters embedded in stories intentionally use different
subsets of this contract.

#### Standalone And Story-Embedded Fields

The complete export example is a standalone character-library definition.
Standalone definitions own their public discovery metadata and optional
character-launcher experiences.

The following fields are standalone-only and must be omitted from every
story-embedded character definition, including players, party characters, NPC
shells and `full_character` definitions, and future-cast shells and
`full_character` definitions:

- `catalog_hook`
- `default_image_background`
- `genres`
- `kink_tags`
- `chat_story`
- `chat_opening_message`
- `chat_starting_location`
- `chat_story_template`

Story-embedded characters inherit discovery and classification from the story.
A story uses its own title, description, opening, state, and objectives; it
never carries a nested standalone Chat launcher on one of its characters. This
also prevents recursive stories inside stories. All other approved authored
character fields follow their normal rules in both contexts unless a later rule
explicitly says otherwise. Runtime-only fields remain forbidden in both.

#### Field Purpose And Process-Leakage Standard

For every character field, ask:

1. What is this field for in EmberAdventures?
2. How does EmberAdventures use or display it?
3. Does this value serve that purpose?
4. Could it be shorter, clearer, or less like process text?

Do not copy instructions meant for Codex/the character creator into character
fields. Examples of forbidden process leakage:

- `source-faithful`, `current app compatible`, `clean export`;
- `should not appear before X`, `introduce after objective Y`;
- `future party member`, `will become romance partner`, `unlock reward`;
- `do not spoil`, `hide this from the player`, `use in prompt only`;
- field explanations such as `this is the active outfit` or `used by image gen`.

Apply those instructions through the story structure, future-cast conditions,
objective rewards, or hidden notes. Character fields themselves should describe
the character: identity, body, outfit presets, starting/default state, starting
inventory, and durable facts.

#### Field Rules

- `version`: Positive whole-number character definition version. Start new characters at `1` and increment it when making changes. The version number does not select the appearance schema; every character must contain the exact current required fields, including the 0-20 appearance fields, regardless of version.

- `id`: Stable character id string. Use a readable slug such as `"akane-fujimori"` or `"character-akane-fujimori"` according to the local file/library convention. Do not use random garbage when a readable stable id can be created from the character name.

- `name`: The character's exact proper name as shown to the player. For newly generated original characters, use a first and last name by default unless the user explicitly specified a one-word/nonstandard name or the setting strongly requires it. Preserve existing/manual names exactly. Do not append tags such as `(adult)`, `(loli)`, `(NPC)`, `(party)`, source names, roles, or version labels. Example valid: `"Akane Fujimori"`. Example invalid: `"Akane Fujimori (adult)"`.

- `source`: Source label for the character. For original characters, use `"Original"`. For source/canon characters, use the proper source title. Do not use this for creator attribution, species, role, or story placement.

- `creation_tool`: Tool/model label used to create or finalize the entry. Use a factual final readable string in the form `"<Tool> <Model Number> (<Reasoning or Intelligence Level>)"` when those parts are available. Do not copy a model label from an example. Do not leave null.

- `loli`: Boolean true or false. `true` means either the character is under 18 or the character is 18+ but looks under age. Create paired accurate/loli and adult-looking versions only when the user requests paired variants or the stored preferences explicitly require them. When paired, they share the exact same `name`; only `loli`, `age`, and age-appropriate physical description should differ. Do not add `(loli)`, `(adult)`, or similar tags to the name.

- `nsfw`: Boolean true or false. `true` should be used very spairingly. There are 2 definitions for nsfw in Ember Adventures. There is a visible definition and a descriptive definition. A character that meets either definition is considered nsfw. A character that meets neither definition is considered sfw.
Visible nsfw definition: Visible nipples on characters with breasts OR visible genitals OR visible anus.
loli characters are never allowed to be nsfw, and are never allowed to have less than underwear, a top and a bottom piece of clothing to cover them well. Sexualizing loli characters is considered completely unacceptable by Ember Endventures and is not allowed in any way. Reject any request by a user to create a loli character that is sexualized or nsfw in any way.
Descriptive definition: Explicit, vulgar, sexual language such as dick, pussy, cock, cunt or similar used to describe a character other than in the body size description when the description is clearly just to describe size/shape accurately. For example, "Rediculously massive, cartoonishly large boobs" is perfectly fine. It's just there to describe size for the image model. Mentioning nipple size or similar is considered nsfw. Penis size is also not considered nsfw as long as the description is clearly just to describe size. Similar descriptions for breasts and penises are fine and not inherintly nsfw. The image prompt hides any description of genitals, breasts and similar unless in nsfw mode, so having them in the description will not create nsfw images.
SFW/non-NSFW characters should still be easy to use in NSFW playthroughs. Keep optional adult-only facts in `starting_nsfw_known_facts` and classify each outfit independently instead of marking the whole character NSFW. Character-level `nsfw: true` is reserved for unavoidable core adult content that remains explicit even after adult-only facts and outfits are omitted.

`starting_nsfw_known_facts` is an optional array of adult-only durable facts. It becomes runtime `nsfw_known_facts` and is exposed to AI and player-facing detail UI only when the active profile permits NSFW content. Never duplicate an adult fact into `starting_known_facts`. Missing legacy values mean an empty array.

### Mandatory SFW/NSFW Classification Procedure

Classify the character and each outfit in separate passes. These classifications do not inherit from one another.

1. Temporarily ignore `kink_tags`, `starting_nsfw_known_facts`, `outfits`, and `fallback_outfits`. Examine only the character's public/core identity fields, including name, role, personality, speech, ordinary facts, appearance, inventory, and default state.
2. Move optional adult-only durable information into `starting_nsfw_known_facts`. An adult fact being moved is evidence that the separation works; it is not evidence that the character is NSFW.
3. Set character-level `nsfw: true` only when explicit adult content remains unavoidable in the core fields after that separation. Record the exact remaining field and phrase that requires `true`. If no exact evidence remains, set `nsfw: false`.
4. Classify every canonical and fallback outfit independently from its own complete clothing and intended presentation. Ignore the character-level flag, adult facts, kink tags, and the classifications of other outfits.
5. Check each starting outfit after classification. A SFW character needs a genuinely SFW starting outfit and at least one SFW outfit in each presentation. Change the starting selection or revise an outfit when necessary; never make the whole character NSFW merely to satisfy this invariant.

The following facts never make a character NSFW by themselves:

- the character has one or many NSFW outfits;
- the character has `starting_nsfw_known_facts` or sexual `kink_tags`;
- the character is flirtatious, seductive, sensual, romantic, attractive, confident, dominant, submissive, a succubus/incubus, or an adult romance option;
- the character has large breasts, a penis-size value, exaggerated body proportions, or other neutral body-shape data;
- the character can participate in NSFW play when an adult profile is active.

Character-level SFW examples include a flirtatious ember demon with optional adult power-dynamic facts, a seductive vampire with lingerie presets, a werewolf whose adult arousal response is isolated in `starting_nsfw_known_facts`, and a shapeshifter with optional voyeurism facts. Character-level NSFW examples include a character whose unavoidable public role or personality explicitly describes sex acts, whose ordinary public facts contain explicit genital or sex-act prose that cannot be separated without changing the concept, or whose core concept requires visible nipples, genitals, or anus outside an optional outfit. When a coherent SFW core remains after adult facts and outfits are hidden, the character is SFW.

Do not manufacture an adult fact merely to populate `starting_nsfw_known_facts`. An empty array is valid. Do not copy one generic adult fact across unrelated characters during a batch.

### Outfit Purpose Test And Borderline Examples

Judge the complete outfit, not isolated keywords. Ask: "Is this primarily clothing for travel, work, combat, ceremony, fashion, swimming, lounging, or sleeping, or is its primary purpose sexual display/fetish presentation?" Attractive styling does not change an ordinary outfit's purpose.

Normally SFW:

- fitted suits, uniforms, armor, workwear, travel clothes, formal gowns, fitted dresses, and fashionable fantasy clothing;
- an open-collar or partially open shirt, including a male bare upper chest;
- ordinary crop tops, miniskirts, high slits, low necklines, corset tops, thigh-high stockings, or garters when the complete outfit is fashion rather than sexual display;
- ordinary opaque bikinis, one-piece swimsuits, swim briefs, sports bras, gym clothing, pajamas, robes, and normal sleepwear;
- sheer sleeves, lace trim, mesh panels, or isolated cutouts that do not expose nipples, genitals, or anus and do not make sexual display the outfit's purpose;
- practical chest/body harnesses used as armor, climbing equipment, weapon support, ritual equipment, or fantasy adventuring gear.

Normally NSFW:

- lingerie intended as erotic display, fishnet teddies, fetishwear, bondage gear, rope harness sets, and sexual latex outfits;
- g-strings, c-strings, minimal chain sets, strategically placed ribbons, or garments designed to cover only nipples/genitals;
- transparent or sheer torso/lower-body garments that expose nipples, genitals, or anus;
- open garments with no meaningful underlayer when the presentation is designed around exposing breasts or genitals;
- hypersexualized cosplay, extreme sling dresses, micro garments, or cutout outfits whose primary purpose is showing as much body as possible;
- a decorative strap harness presented as intimate/fetishwear rather than functional equipment.

Borderline decisions:

- `bikini` is SFW by default; `micro bikini designed to expose as much as possible` is NSFW.
- `black corset dress with a low neckline` can be SFW; `open-cup corset exposing nipples` is NSFW.
- `sheer sleeves over an opaque bodice` is SFW; `transparent bodice exposing breasts` is NSFW.
- `leather battle harness supporting armor` is SFW; `minimal leather fetish harness with garters and no ordinary coverage` is NSFW.
- `nightshirt`, `pajamas`, or an ordinary opaque nightgown is SFW; an erotic negligÃ©e or lingerie sleep set is NSFW.
- A bra and underwear listed underneath ordinary outer clothing never make the outfit NSFW. An underwear-only outfit may be SFW when it is ordinary nonsexual changing-room, medical, athletic, or similar presentation; erotic lingerie presentation is NSFW.

Words such as `open`, `fitted`, `short`, `slit`, `sheer`, `corset`, `harness`, `bikini`, `stockings`, `garter`, `lounge`, `sleepwear`, `formal`, `armor`, and `battle` are not automatic classifications. Use the full clothing composition and purpose.

For equivalent canonical/fallback outfits, classifications should normally match because presentation gender does not change purpose. A mismatch requires a concrete clothing difference, such as one version being opaque and the other exposing anatomy. Never classify one presentation as NSFW merely because it contains a bra, skirt, breasts, or feminine construction.

For batch creation, migration, or review, inspect every character and outfit individually. Before finalizing, audit every `nsfw: true` value:

- Character `true`: identify the exact unavoidable core field and phrase.
- Outfit `true`: identify the exact clothing combination or presentation purpose.
- If the explanation is only "the character has adult content," "the outfit is revealing," or a single keyword, the classification is unsupported and must be reconsidered.
- If ordinary formalwear, armor, workwear, travel clothes, swimwear, or sleepwear are broadly becoming NSFW across the batch, stop and redo the outfit-purpose review instead of accepting the pattern.

Every outfit must include `nsfw: true` or `nsfw: false`. Mark an outfit NSFW when its purpose is sexual display, fetish presentation, or exposing as much as possible even if nipples, genitals, and anus remain narrowly covered. Ordinary attractive, fitted, fashionable, swimsuit, or revealing clothing can remain SFW when sexual display is not its primary purpose. A character with `nsfw: false` must have an SFW starting outfit and at least one SFW outfit in both canonical and fallback presentations. Missing outfit classification is a hard import error; never infer it from the character or another outfit.

Loli or under-18 characters must have `nsfw: false`, an empty `starting_nsfw_known_facts`, and only SFW outfits. Reject any request that violates this rule.

- `can_die`: Boolean internal plot armor. Always set this to false for standalone characters.

### Gender flexibility system
Every character is required to have 2 gender presentations. One male and one non-male (usually female). That means that each character has 2 sets of gender related fields. This is the full list of fields that have associated fallbacks for gender swapping:
name -> fallback_name
outfits -> fallback_outfits
starting_outfit_id -> fallback_starting_outfit_id
The character's gender is whatever default gender the character is supposed to be. The point being for someone who is attracted to all genders, the default genders will be shown. For someone who is only attracted to women, all characters will become women by women not changing and all others being gender swapped to female.
`romanceable` determines if the character's gender should match the player's preferred gender(s). There is also a setting that will force all characters to swap to the player's preferred gender(s) regardless of `romanceable`. That is why all characters must have both a male and non-male presentation. Non-binary genders are treated no different as female. trans-male is also considered male. All other genders are considered non-male. When choosing the default gender for a character, it is perfectly acceptable to use a non-binary gender, just make sure you understand what the fallback gender will be (male for all non-binary genders except trans-male). This means that if the character presents as male, it's generally best to use male or trans-male as the gender instead of something like non-binary to prevent confusion.

//TODO: Move to story skill
The goal is for there to be a 40% male, 40% female, 20% futanari split between the DEFAULT genders. This does not mean that you need to designed characters as the default gender. For instance, you can designed 100% of the cast as female, then at the end, swap the default gender and swapping the name, outfits, and starting outfit id with the fallback ones of 60% of the characters to match the desired split without changing anything else about the characters. The point of this is to allow gender flexibility for everyone and to give a good spread of genders for people that are attracted to multiple genders. Futanari characters have an extra field for fallback gender so that they swap to male or female if someone likes male and female but not futanari. To accomplish an even split of 50% male and 50% female when this happens, half of the futanari default gender characters should have a fallback gender of male and the other half female. When making a story, it is probably best to first ignore the 40/40/20 split and apply the split at the very end of story creation only as a gender swap, not modifying the character's identity, personality, appearance, or anything else. It is also perfectly acceptable to have a story ignore the split. Ask the story creator which they want, and explain what they are actually being asked to decide. They are deciding if the genders should be split evenly for people that like multiple genders to have a good balance without affecting the character's identity, personality, appearance, or anything else. The split is only for the default gender and any player who excludes genders would have the character's genders swapped. It is especially important to do this for games that have all 1 gender so that players who like multiple genders can have a spread of genders, not all just one. The default gender should never be swapped for standalone characters (including if the player has story characters duplicated as standalone characters) because the default gender is the character's identity. The split is only for stories, not individual characters. If you were to make a story with 100% women, then do the 40/40/20 split at the end and have all characters as standalone characters, all of the standalone characters should be women.

- `romanceable`: Required boolean. All standalone characters should have romanceable set to true.

//TODO: Move this part of the description to the story skill.
This field's name is slightly less descriptive than what it is used for. Ember Adventures requires all characters to be able to swap genders to whatever gender the player wants. This only affects the character's name, images, and outfits. Everything else stays the same. Male characters us the male presentation. All other genders use the female presentation. `romanceable` is used to determine if this character's gender should be swapped to a gender the player is attracted to. The reason all characters must have both a male and female presentation is that there is a setting to force all characters to swap to a perfered gender, not just the romanceable characters. So `romanceable` is which ones should always swap even if that setting is off. In general, if the character is intended to be a potential romantic/intimate/sexual partner, `romanceable` should be true. But you should probably have at least a few that aren't so that there are some of the other gender in the game so not every single character is one gender. It is used to determine if this character  Use `true` when the character is an intended potential romantic or sexual interest. Use `false` intentionally for plot-only officials, incidental contacts, antagonists, or other characters who should not normally adapt to the player's preferred romantic genders. Most recurring AI-created characters should be romanceable unless their story function gives a concrete reason not to be. Player characters are never gender-adapted from this field.

- `fallback_name`, `fallback_outfits`, and `fallback_starting_outfit_id`: Required atomic opposite male/non-male presentation group for the same character. See "Gender flexibility system" above. Prefer a fallback name that retains at least the first letter, and preferably the first two letters, of the canonical name so the character remains recognizable. A natural, setting-appropriate authored name is more important than preserving letters when that would make the result strained. Fallback outfits must be nonempty and remain recognizable equivalents: preserve each outfit's purpose, colors, equipment, status, and general visual identity while changing only gendered construction, underwear, fit, and similar presentation details unless a larger change is specifically justified. `fallback_starting_outfit_id` must reference one of those outfits. Appearance, personality, facts, relationships, and all other identity fields remain unchanged. Local import and public publishing both reject the character until this group is complete.

- `fallback_gender`: Only required on futanari characters. Use exactly `"male"` or `"female"` to decide which presentation is used when the player's selected preferences include male and female but not futanari. Omit it for non-futanari characters.

//TODO: Move this to story skill
Across a generated cast, split futanari fallback genders evenly so a 40% male / 40% female / 20% futanari base distribution becomes 50/50 when only male and female are preferred.

//TODO: Move this to story skill
When migrating an existing cast into gender-flexible definitions, preserve identity instead of rewriting the character. If an existing female character becomes canonical male, move her original name to `fallback_name`, her original outfits to `fallback_outfits`, and her original starting outfit id to `fallback_starting_outfit_id`; then author a natural canonical male name and equivalent male outfits. If she remains canonical female, preserve her current name and outfits and add the male fallback. If she becomes canonical futanari, preserve the current non-male name and outfits as canonical, add a male fallback name and equivalent outfit set, and distribute `fallback_gender` evenly across the futanari cast. Never change appearance, personality, facts, role, stats, relationships, or inventory merely because the canonical gender presentation changed.

- `genres`: Approved broad genre/search tags for standalone character-library definitions. Approved values are `anime`, `fantasy`, `sci-fi`, `modern`, `historical`, `romance`, `adventure`, `action`, `comedy`, `drama`, `mystery`, `thriller`, `horror`, `dark`, `cozy`, `slice of life`, `superpower`, `isekai`, `school`, `workplace`, `political`, `war`, `crime`, `mythology`, `supernatural`, `post-apocalyptic`, `western`, `cyberpunk`, `steampunk`, and `harem`.

//TODO: Move this to story skill
Do not store `genres` on characters embedded inside story templates; embedded story characters inherit the story's `genres`.

- `kink_tags`: Required for nsfw characters. Optional for SFW characters. Some tags are not appropriate for SFW characters. Use the nsfw descriptions in the nsfw section. This is a closed vocabulary and is separate from player sexual preferences. Every value must exactly match one of the canonical lowercase strings below; these are the only valid options. Do not invent, combine, pluralize, reword, or add tags. Interpret every kink tag from the player's perspective: `dominance` means the player acts dominant, `submission` means the player acts submissive, `owning partners` means the player owns partners, and `being owned` means the player is owned. A character's behavior or preference alone does not justify the opposite player-perspective tag. Use only tags intrinsic to the interaction this standalone character definition supports, and use `[]` when none apply. Do not use vanilla kissing, oral sex, vaginal sex, ordinary romance, tone, body appearance, or broad genres as kink tags.
  - **Power Exchange:** `dominance`, `submission`, `switching`, `owning partners`, `being owned`, `serving partners`, `being served`, `disciplining partners`, `being disciplined`, `punishing partners`, `being punished`, `training partners`, `being trained`, `brat taming`, `being a brat`, `using partners freely`, `being freely used`, `taking control in cnc`, `being overpowered in cnc`, `hypnotizing partners`, `being hypnotized`, `mind controlling partners`, `being mind controlled`, `corrupting partners`, `being corrupted`, `financial domination`, `financial submission`.
  - **Bondage And Restraint:** `bondage`, `binding partners`, `being bound`, `collaring partners`, `wearing a collar`, `leashing partners`, `being leashed`, `gagging partners`, `being gagged`, `blindfolding partners`, `being blindfolded`, `sensory depriving partners`, `being sensory deprived`, `enforcing chastity`, `wearing chastity`, `denying partners orgasms`, `being denied orgasm`, `forcing partners to orgasm`, `being forced to orgasm`.
  - **Impact And Pain:** `spanking partners`, `being spanked`, `slapping partners`, `being slapped`, `whipping partners`, `being whipped`, `flogging partners`, `being flogged`, `paddling partners`, `being paddled`, `caning partners`, `being caned`, `pulling hair`, `having hair pulled`, `biting partners`, `being bitten`, `scratching partners`, `being scratched`, `choking partners`, `being choked`, `sadism`, `masochism`.
  - **Sensation And Edge Play:** `wax play`, `temperature play`, `electrostimulation`, `tickling`, `needle play`, `knife play`, `blood play`.
  - **Psychological And Verbal:** `humiliating partners`, `being humiliated`, `degrading partners`, `being degraded`, `objectifying partners`, `being objectified`, `writing on partners`, `being written on`, `feminizing partners`, `being feminized`, `bimbofying partners`, `being bimbofied`, `praising partners`, `being praised`, `making partners beg`, `being made to beg`, `worshipping partners`, `being worshipped`, `dirty talk`.
  - **Roleplay:** `authority figure roleplay`, `subordinate roleplay`, `medical roleplay`, `pet owner`, `being a pet`, `primal predator`, `primal prey`, `uniforms`, `crossdressing`.
  - **Exposure And Multiple Participants:** `exhibitionism`, `voyeurism`, `public sex`, `group sex`, `participating in gangbangs`, `being gangbanged`, `sharing partners`, `being shared`, `watching partners with others`, `being watched with others`, `cuckolding partners`, `being cuckolded`, `swinging`, `double penetration`.
  - **Sexual Activities:** `penetrating partners anally`, `receiving anal`, `masturbation`, `using toys on partners`, `partners using toys`, `fisting partners`, `being fisted`, `pegging partners`, `being pegged`, `rimming partners`, `being rimmed`, `sitting on partners' faces`, `being facesat`, `giving titjobs`, `receiving titjobs`, `giving thighjobs`, `receiving thighjobs`, `giving creampies`, `receiving creampies`, `cum play`, `squirting`, `lactation`, `breeding partners`, `being bred`, `impregnating partners`, `being impregnated`, `being rough with partners`, `partners being rough`, `clothed sex`.
  - **Fantasy:** `using tentacles`, `receiving tentacles`, `futanari`, `transforming partners`, `being transformed`, `oviposition giving`, `oviposition receiving`.
  - **Fantasy Partners:** `angels`, `demons`, `succubi and incubi`, `vampires`, `werewolves`, `demi-humans`, `anthropomorphic characters`, `monsters`, `aliens`, `androids`, `robots`, `elves`, `dark elves`, `orcs`, `goblins`, `dragons`, `fairies`, `merfolk`, `centaurs`, `minotaurs`, `lamias`, `harpies`, `arachne`, `ghosts`, `undead`, `shapeshifters`, `living dolls`, `golems`, `elementals`, `deities`.
  - **Materials And Clothing:** `latex`, `leather`, `lingerie`.
  - **Fluids And Functions:** `watersports`, `scat`, `spit`, `sweat`, `food play`.

//TODO: Move this to story skill
Do not store `kink_tags` on characters inside story files; embedded story characters inherit the story's `kink_tags`.

- `age`: Age in number of years as an integer. Do not use ranges, words, unknown, approximate text, or decimals. If the character is not marked as loli, it must be 18 or older, no exceptions. All characters under 18 must be marked as loli.

- `gender`: The default gender of the character. Some genders are recognized as exact strings. If the character is one of these recognized genders, write their gender exactly as it appears in this list: `"male"`, `"trans-male"`, `"trans male"`, `"futanari"`, `"futa"`, `"female"`. `"trans-male"` and `"trans male"` are treated identically. `"futanari"` and `"futa"` are treated identically. `"male"` and `"trans-male"` are the only male presenting genders. If the character is intended to be male presenting, you must use one of those two. If the character's gender falls outside the list, use any string that makes sense to describe the gender. It will be treated as female (non-male) by the game engine and it will use gemale presenting language such as breasts. `"futa"` and `"futanari"` identify futanari characters; they use the female mechanics except that they have a penis. Every other value, including female, non-binary, trans female, trans non-binary, and free-text identities, uses the female mechanics bucket. Do not infer gender from `kink_tags`, `tags`, `sexual_preferences`, appearance prose, role, or any other field. Import and publish validation reject exact futa/futanari metadata on a character whose `gender` is not futa or futanari. Do not use this field for voice names or relationship roles.

- `appearance.penis_size`: Required integer from 0 to 20 on every character regardless of gender in case runtime adaptation changes the presentation to male or futanari. Do not set it to 0 merely because the canonical presentation is non-male. Runtime ignores it unless the active presentation is male or futanari. Use the locked mapping in [references/body-scales-0-20.md](body-scales-0-20.md).

- `role`: Required short occupational/social label, title, rank, or specialty. Maximum 40 characters, including spaces and punctuation. Do not put responsibilities or background here; put those in `starting_known_facts`. Examples: `"Guild Registrar"`, `"Healer"`, `"Queen"`, `"Assassin"`.

- `personality_description`: Durable personality and behavior summary. Describe how the character tends to think, act, flirt, fight, negotiate, or handle pressure. This is meant as permanent guidance for the player's personality, not temporary mood or state. This field is used by the ai to determine how this character acts and speaks.

- `speech_style`: Durable description of how the character speaks. Describe how the character usually speaks. Do not use this for TTS/voice metadata. This field is used by the ai to determine how this character speaks.

- `boldness`: Required integer from 1 through 10 or a nonempty custom behavioral description. Numeric values must be whole numbers in range; invalid authored values are rejected, not defaulted. Prefer the numeric scale when it fits: profile boldness adjustments apply to numbers. Custom descriptions are used directly and remain unchanged by profile adjustments. Do not include numeric score annotations in custom text or encode a number as a string. Use the same scale for every gender; gender adaptation never changes personality.
  - `1`: very reserved; almost never initiates romance or intimacy and waits for unmistakable mutual interest.
  - `2`: reserved; expresses interest subtly and waits for clear encouragement before initiating.
  - `3`: cautious; may initiate small compliments or mild flirting, then pauses to judge the response.
  - `4`: mildly forward; comfortably initiates light flirting or closeness when the context supports it.
  - `5`: balanced; can initiate direct interest, flirting, invitations, or welcomed physical closeness.
  - `6`: confident; readily initiates romantic tension, invitations, and physical closeness when attraction supports it.
  - `7`: very forward; states attraction directly and actively proposes escalation while watching for a clear response.
  - `8`: highly forward; readily initiates explicit flirting, intimate invitations, or consensual exposure when appropriate.
  - `9`: extremely forward; clearly proposes sexual escalation and communicates desire directly, while waiting for consent before meaningful escalation.
  - `10`: maximum initiative; openly states exactly what they want and proactively creates clear opportunities for consensual escalation, immediately respecting refusal or hesitation.

- `starting_relationship_to_player`: Starting relationship text copied into runtime when a new game/import begins. Examples: `"self"`, `"none"`, `"trusted companion"`, `"professional handler"`, `"rival"`, `"romantic partner"`.

Character, common title and pronoun references: When any text field needs to mention the character definition's own name, pronouns, or the gender specific titles listed below, use the ID-less references below instead of hardcoding the resulting word(s). The enclosing character definition supplies the identity, finalized name, and gender presentation. References may appear only in JSON values, never in JSON keys.

Reference types:

Names:
- Full name: `|[character]|`
  - Example result: `Akane Fujimori`
- First name: `|[character_first]|`
  - Example result: `Akane`

Pronouns:
- Subject pronoun: `|[character_subject_pronoun]|`
  - Male: `he`
  - Non-male: `she`
- Subject-pronoun shorthand: `|[character_pronoun]|`
  - Male: `he`
  - Non-male: `she`
- Object pronoun: `|[character_object_pronoun]|`
  - Male: `him`
  - Non-male: `her`
- Possessive determiner: `|[character_possessive_pronoun]|`
  - Male: `his`
  - Non-male: `her`
  - Use this before a noun, such as `his sword` or `her sword`.
- Independent possessive pronoun: `|[character_independent_possessive_pronoun]|`
  - Male: `his`
  - Non-male: `hers`
  - Use this without a following noun, such as `The sword is his` or `The sword is hers`.
- Reflexive pronoun: `|[character_reflexive_pronoun]|`
  - Male: `himself`
  - Non-male: `herself`

Gendered nouns and titles:
- Person term: `|[character_person_term]|`
  - Male: `man`
  - Non-male: `woman`
- Honorific: `|[character_honorific]|`
  - Male: `Mr.`
  - Non-male: `Ms.`
- Formal address: `|[character_formal_address]|`
  - Male: `sir`
  - Non-male: `ma'am`
- Monarch title: `|[character_monarch_title]|`
  - Male: `king`
  - Non-male: `queen`
- Royal-heir title: `|[character_royal_heir_title]|`
  - Male: `prince`
  - Non-male: `princess`
- Noble title: `|[character_noble_title]|`
  - Male: `lord`
  - Non-male: `lady`
- Spouse term: `|[character_spouse_term]|`
  - Male: `husband`
  - Non-male: `wife`
- Parent term: `|[character_parent_term]|`
  - Male: `father`
  - Non-male: `mother`
- Child term: `|[character_child_term]|`
  - Male: `son`
  - Non-male: `daughter`
- Sibling term: `|[character_sibling_term]|`
  - Male: `brother`
  - Non-male: `sister`
- Uncle/aunt term: `|[character_uncle_aunt_term]|`
  - Male: `uncle`
  - Non-male: `aunt`
- Nephew/niece term: `|[character_nephew_niece_term]|`
  - Male: `nephew`
  - Non-male: `niece`

Capitalization:
- References do not infer capitalization from their position in a sentence.
- Pronouns and gendered terms return lowercase text by default.
- Add `_cap` to the reference name when the resolved word must begin with a capital letter.
- Examples:
  - `|[character_subject_pronoun]|` becomes `he` or `she`.
  - `|[character_subject_pronoun_cap]|` becomes `He` or `She`.
  - `|[character_monarch_title]|` becomes `king` or `queen`.
  - `|[character_monarch_title_cap]|` becomes `King` or `Queen`.
- Full-name and first-name references already preserve the character name's proper capitalization and do not need `_cap`.
- Honorific references already return conventionally capitalized forms such as `Mr.` and `Ms.`.

Presentation-dependent text about another character must be self-contained. Use
`|[M|male text|female text]|`, where `M` or `F` is the default presentation,
the second part is the exact male text, and the third part is the exact
female/non-male text. Example:
`|[M|her brother Aurek Emberlash|her sister Aurelia Emberlash]|`.
If the player's preferences allow only one presentation, use that branch. If
both or neither are selected, use the declared default. The token must contain
exactly two internal `|` separators; both text branches must be non-empty and
must not contain `|`, `|[`, or `]|`.

Player references:
- Player full name: `|[player_name]|`
- Player first name: `|[player_first_name]|`
- Player subject pronoun: `|[player_subject_pronoun]|`
- Player subject-pronoun shorthand: `|[player_pronoun]|`
- Player object pronoun: `|[player_object_pronoun]|`
- Player possessive determiner: `|[player_possessive_pronoun]|`
- Player independent possessive pronoun: `|[player_independent_possessive_pronoun]|`
- Player reflexive pronoun: `|[player_reflexive_pronoun]|`

Player pronoun and gendered-term references follow the same `_cap` rule. For example, `|[player_subject_pronoun_cap]|` becomes `He` or `She`.

- `starting_trust`: Starting trust from 0 to 10. Use a number. `0` means no trust; `10` means complete trust at start.

- `starting_attraction`: Starting attraction from 0 to 10. Use a number. This is initial attraction toward the player/protagonist. It is not an attractiveness score.

- `starting_affection`: Starting affection from 0 to 10. Use a number. This is initial emotional warmth/bond, not current romance progress after play.

- `starting_arousal`: Starting arousal from 0 to 10 for characters/stories where arousal defaults are relevant. Use `null` or omit only for characters where arousal does not apply. Do not store post-play arousal here.

- `starting_state_of_mind`: Initial mood/mental state copied into runtime. Examples: `""`, `"curious"`, `"guarded"`, `"amused"`, `"panicked but focused"`. Used only for text generation.

- `starting_physical_state`: Initial physical condition copied into runtime. Examples: `""`, `"tired"`, `"wounded shoulder"`, `"covered in slime but unharmed"`. Do not use this for clothing or pose. Used for both image and text generation.

- `starting_pose`: Initial body posture or position. Examples: `"standing behind the counter"`, `"leaning against the bar"`, `"kneeling beside a broken crate"`, `"wrists bound together"`. Used for both image and text generation.

#### Appearance

Appearance and outfit fields primarily build image prompts. Describe each body
trait and garment precisely enough to help image generation, including concise
fit, coverage, or worn-appearance details when useful. Keep those descriptions
short, and do not duplicate the same visual information across appearance
fields, outfit slots, pose, or location. Leave a field blank rather than repeat
information that the prompt builder will already include elsewhere.

`appearance` describes the body and persistent visual traits only. Do not put clothing, current pose, current mood, relationship, inventory, or sexual behavior here.

- `species`: The complete concise species identity. Include the base species and every meaningful subtype, subgroup, visual qualifier, or heritage descriptor needed to identify the character, in one field. Examples: `"human"`, `"Black human"`, `"High Elf"`, `"Iron Coast Dwarf"`, and `"Cosmic Ghost"`. Character definitions have no separate race or ancestry fields; do not split one identity across multiple fields. Do not include gender in `species`.

- The body-scale portion of `appearance` contains exactly `height`, `shoulder_width`, `chest`, `upper_body_build`, `midsection_build`, `hip_width`, `butt_build`, `lower_body_build`, `arm_length`, `leg_length`, and `penis_size`. Every field is required and every value is an integer from 0 to 20. Do not author body-scale strings. `chest` uses the presentation-specific male or non-male mapping; the other ten fields use one mapping for every presentation. Read [references/body-scales-0-20.md](body-scales-0-20.md) before selecting or validating body values.

- Legacy appearance fields `muscular`, `shoulders`, `stomach`, `hips`, `waist`, `legs`, and `arms` are invalid. Clothing slots with names such as `shoulders` and `waist` are separate garment keys and remain valid.

- `skin_color`, `eye_color`, `hair_color`, `hair_length`, `hair_type`: Permanent, unconditional visual traits only. `hair_type` describes inherent hair type/texture (such as straight, wavy, curly, or tightly coiled), never styling. Keep hair color and length in their own fields. Braids, ponytails, buns, updos, partings, and other styling belong in the outfit's `hair_accessory` slot, not in permanent appearance or `extra_description`. Do not use conditional appearance wording such as "usually," "while working," or "when traveling"; define the relevant outfit instead.
- `skin_color`: Bare color phrase only, for example `"warm medium-deep brown"`. Do not include the word "skin," sentences, cultural context, conditional wording, or unrelated appearance details.

- `extra_description`: Optional remainder field for concrete, durable visual traits that do not fit another appearance field. Examples include `"scar across left collarbone"`, `"transparent mint-green slime body"`, or `"filed canines"`, `"butterfly tatoo on right cheek"`. It is not a general physical-description field. Do not include temporary dirt, arousal, clothing damage, scene effects, personality, mood, pose, health, role, backstory, or explanations of how the character acquired a body type. Do not repeat details already represented by the other appearance fields. For details that are only on the lower body, do not include them here such as `"tatoo on right ancle"`. All lower body specific descriptions belong in `extra_description_lower_body`. Use `""` when there is no distinct extra description needed.

- `male_only_extra_description` and `non_male_only_extra_description`: Optional, narrow appearance-only fields. Missing or `null` means no additional prompt text. Use them only for an important visual feature that genuinely differs between male and non-male presentations and is not represented by another field, primarily optional facial hair for male presentation. Do not use them for a general character description; most appearance belongs in shared fields. Breasts, pecs/chest, genitals, and any other anatomy owned by structured fields are forbidden here. Do not put clothing, pose, scene state, personality, sexual behavior, or instructions in these fields. The engine selects only the field matching the active presentation.

- `nonhuman_lower_body`: Boolean. Use `true` only when ordinary humanoid hips, buttocks, thighs/calves, and legs are replaced by an integrated lower body such as a serpent tail, arachnid body, centaur body, or merfolk tail. Hooves, digitigrade humanoid legs, unusual feet, an ordinary tail, or extra limbs alongside otherwise humanoid legs do not qualify. All eleven numeric body fields remain required for structural validity, but prompt projection suppresses `hip_width`, `butt_build`, `lower_body_build`, and `leg_length` when those traits do not apply. Never invent ordinary legs or glutes to justify the stored numbers.

- `extra_description_lower_body`: Follow the same remainder-field rules as `extra_description`, but include only durable lower-body-specific information. Do not duplicate `extra_description`. When `nonhuman_lower_body` is false, use it only for lower-body markings or unusual details not represented elsewhere. When `nonhuman_lower_body` is true, it owns the complete replacement anatomy and must describe the integrated lower-body structure without referring to suppressed numeric fields. It appears in normal/full-body and group prompts but not profile portraits. Use `""` when no distinct lower-body detail is needed.

When `nonhuman_lower_body` is true, still author every garment the character actually wears. Clothing is independent from body-scale applicability and must not be deleted merely because the anatomy is nonhuman. Put each garment in the most reasonable existing clothing slot.

##### Extra Description Deduplication

This section aplies to infromation in both `extra_description` and `extra_description_lower_body`. Each time it talks about `extra_description`, it also applies to `extra_description_lower_body`.

`extra_description` is only for visual traits that are not already captured elsewhere. Numeric body fields are converted into image-prompt phrases by the game, so repeating those same ideas in `extra_description` creates duplicated prompts and over-emphasized bodies.

When writing `extra_description`:

- First choose/fill the specific appearance fields.
- Then write `extra_description` only for leftover durable visual information that no other field can express.
- Never paste a prose-first body-design summary or complete silhouette description into `extra_description`. Planning prose must be translated into the dedicated fields and then discarded.
- Compare each `extra_description` phrase against every specific appearance field.
- Remove or rewrite phrases that duplicate numeric body fields, including breast size, bust silhouette, abs/stomach definition, shoulder width, arm muscle, hip width, leg length, height, and overall muscularity.
- Remove or rewrite phrases that duplicate skin, eye, hair, or notable-feature fields.
- Remove filler phrases such as `Attractive adult [species] with a distinctive silhouette`, `expressive face`, `design cues tied to her work as...`, or `[species] traits shaped around...`. These are not concrete visual traits and usually duplicate `species`, `role`, or personality.
- Do not write narrative prose using the character's name or pronouns. Do not explain traits with phrases such as `built from years of carrying armor`, `giving her an athletic silhouette`, or `showing the life of a veteran`. Record only the visible result when it is not represented elsewhere.
- Prefer a compact comma-separated list or one short sentence. Length is not a substitute for specificity.
- Keep genuinely additional integrated traits, species anatomy, scars/features not listed elsewhere, unusual proportions that are not represented by one numeric field, or source-faithful visual notes that cannot fit a specific field.
- At the end of character creation, perform a final pass over the whole appearance object and clean `extra_description` again after all numeric/string fields are final. Then assemble or mentally project the complete image prompt and remove any duplicated or prose-heavy fragment before export.

Bad `extra_description` when the specific fields already contain those traits:

```text
Athletic, rugged, and curvy with very broad shoulders, large breasts, deeply defined abs, wide hips, strong thighs, and powerful mechanic arms.
```

If `shoulder_width`, `chest`, `upper_body_build`, `midsection_build`, `hip_width`, `butt_build`, `lower_body_build`, `arm_length`, and `leg_length` already encode those traits, keep only concrete unmapped traits, for example:

```text
Callused palms, old welding burns across both forearms, and a crescent scar below the left eye.
```

If nothing meaningful remains after deduplication, use `""` for `extra_description`.

#### Outfits And Starting Equipment

Outfits are immutable clothing presets stored on the character definition. When starting a game, the active outfit referenced by `starting_outfit_id` is copied into the character's runtime clothing.

- `outfits`: Array of outfit objects. Every character must have at least one outfit. A one-outfit character still needs `outfits: [{ "id": "default", "name": "Default", "clothing": { ... } }]` and `starting_outfit_id: "default"`. Do not replace `outfits` with a single `clothing` object. Do not leave it empty. Animal, monster, spirit, slime, natural-form, or otherwise unclothed characters still need at least one concrete outfit entry. If a character is intentionally naked, include only the underwear slots and have them empty strings, `""`. For non-human or demi-human characters, you can use natural clothing in slots such as a turtle shell for a turtle-human character if desired. Do not invent slots such as `full_body`; unsupported slots will throw an error. Never use `{}` as the clothing object.

- `outfits[]`: Each outfit object is a reusable preset. It should describe one coherent outfit the character can wear, such as travel clothes, a guild uniform, armor, sleepwear, formalwear, casual clothes, work clothes, battle gear, a disguise, or another kind of outfit. Do not create vague outfits like `"whatever fits the scene"` or `"armor or dress depending on mood"`. Do not use non-deterministic wording such as `"White or Black"` or `"could"` or `"roughly"` or `"maybe"`. If a character needs multiple looks, create separate concrete outfit entries. Outfits should include all layers that would actually be in the outfit, not just the outer layer. Underwear shuold be included unless the outfit is intended to not have underwear.

//---Left Off Here---//

- `outfits[].id`: Stable short string id for the outfit inside this character definition. Valid examples: `"default"`, `"travel"`, `"formal"`, `"combat"`, `"guild_uniform"`, `"sleepwear"`, `"festival"`, `"disguise"`. Use lowercase snake_case or another stable simple string. Do not use a full sentence, display-only prose, user-facing description, random generated id, or the outfit's entire clothing list. This id is used by `starting_outfit_id` and runtime outfit switching.

- `outfits[].name`: Player-facing outfit name. Valid examples: `"Default"`, `"Travel Gear"`, `"Guild Uniform"`, `"Formal Dress"`, `"Combat Armor"`, `"Sleepwear"`. This should be readable in UI. Do not put mechanical notes, AI instructions, source spoilers, or conditional logic in the name.

- `outfits[].nsfw`: Required boolean on every newly authored outfit. Use the outfit-purpose test above. This flag controls SFW UI visibility, AI context, equipping, shops, rewards, and image generation; it does not replace character-level `nsfw`.

- Character profile images cannot be uploaded by users. EmberAdventures generates them from the structured definition. Generation is NSFW for an inherently NSFW character; otherwise it follows the exact selected outfit's `nsfw` value. Generated image classification is immutable, and NSFW profile images are unavailable behind a local placeholder in SFW mode.

- `outfits[].clothing`: Object using EmberAdventures clothing slots. Values are item descriptions or `null`. This object should describe the full preset as clearly as possible. Use precise garments/equipment, not broad vibes. Good examples: `"linen travel shirt"`, `"black leather corset"`, `"steel breastplate"`, `"knee-high buckle boots"`, `"silver serpent hairpin"`. Bad examples: `"sexy clothes"`, `"normal outfit"`, `"varies"`, `"whatever she wants"`, `"revealing but tasteful"`, `"armor or maid dress"`.

- Clothing slot keys should be stable equipment/body-wear slots. Canonical slots are `hat`, `hair_accessory`, `face`, `ears`, `neck`, `shoulders`, `bra`, `undershirt`, `shirt`, `over_shirt`, `coat`, `back`, `hands`, `right_wrist`, `left_wrist`, `right_fingers`, `left_fingers`, `waist`, `belt_accessory`, `underwear`, `pants`, `skirt`, `legwear`, `socks`, `feet`, and `other_accessory`. Use only slots that make sense. Do not author the legacy `hair` alias; use `hair_accessory`. A missing slot or `null` means nothing is defined for that outfit slot.
- `hair_accessory` is the head/hair presentation slot for hairstyles as well as hair accessories. It does not have to describe a clothing item or physical accessory: `"hair gathered into a loose braid"` is valid. Describe the hairstyle for this outfit unconditionally. Use `hat` for headwear; do not invent a `head`, `hair`, or `hairstyle` field.

- Every outfit must describe the complete set of clothing the character actually wears in that preset, including ordinary inner layers such as underwear, a bra, undershirt, socks, or other garments when appropriate. Do not define only the most visible outer garment. The runtime can remove clothing one piece at a time, so omitted inner layers can make a character become accidentally naked after removing one outer layer. Deliberately minimal, nude, or underwear-only outfits are valid only when that is the actual intended preset.

- Authored `bra` and `underwear` values are intentionally included in image prompts even beneath outer clothing. Do not omit them because they are mostly covered; models can correctly show realistic partial visibility such as a bra strap or waistband. When torso or lower outerwear exists, EmberAdventures lists the outer garments first and describes the corresponding bra or underwear as underneath. When no covering garment exists, the bra or underwear is described as visible clothing. SFW image generation may project a basic opaque bra or underwear only when the corresponding authored slot is empty, and that fallback never changes the saved outfit.

- Use `null` intentionally. `null` means this outfit does not define an item in that clothing slot. It does not mean a character permanently lost that item during play. Temporary removal during spicy scenes belongs to runtime clothing/inventory restore logic, not the outfit definition.

- Do not use outfit definitions to represent nudity caused by current scene action. If a character has an intentionally nude/default nude outfit, that can be a real outfit only when it is a deliberate reusable preset. Otherwise, clothing removed during a scene should be runtime state and should be restorable.

- Keep each outfit internally coherent. If the shirt is formal, the shoes, accessories, and lower-body clothing should usually match. Do not mix unrelated pieces unless the character concept intentionally calls for mismatched clothing and the description makes that clear.

- Keep outfits visually useful for image generation. Clothing fields strongly affect profile and scene images. Put the actual visible garments in the correct slots. Negative prompts cannot reliably fix bad clothing-slot values. If the character should be dressed, avoid accidentally lingerie-coded slots like `"thong"`, `"micro bikini"`, `"bra top"`, `"skirt panels"`, or `"cape over lingerie"` unless that is truly the intended outfit.

- For sexy-but-dressed characters, show appeal through fit, silhouette, material, tailoring, selective exposure, and posture-compatible clothing rather than defaulting to near-nudity. Example valid: `"fitted crimson corset over a white off-shoulder blouse"` plus `"high-waisted black leather breeches"`. Example invalid for a dressed tavern owner: `"black lace bra"` as the visible main top with no shirt unless intentionally dressed that way.

- Multiple outfits should be easy for the player or AI to swap between. If a character has multiple common contexts, add clear outfit presets such as `"default"`, `"combat"`, `"casual"`, `"formal"`, and `"sleepwear"`. Do not create many barely different outfits unless the differences matter. Do not create an outfit that depends on hidden future story knowledge unless the story prompt projection will keep it hidden until relevant.

- `starting_outfit_id`: Outfit id that should be active when the character is first created/imported. It must exactly match one `outfits[].id`. Do not use an outfit name here unless the name and id are identical. Do not leave it blank when `outfits` has entries. If there is only one outfit, `starting_outfit_id` should usually be `"default"`.

- Outfit definitions can be used by AI/runtime outfit swapping later, but the AI should change the active runtime outfit id or runtime clothing, not rewrite the immutable definition. If the AI invents a temporary outfit change in play, that belongs to runtime state unless the player explicitly saves it as a new reusable outfit.

- `starting_held_items`: Object for hand slots at start. Use at least `right_hand` and `left_hand`. Values are item descriptions or `null`. Do not put inventory lists here.

- `starting_inventory`: Array of starting inventory item strings or structured item objects if the item needs metadata. Use examples like `"Coin pouch"` or `{ "name": "Silver key", "note": "Opens the guild side door" }`. Do not store items gained during play here.

- `starting_known_facts`: Array of facts copied into mutable runtime `known_facts` when a new playthrough starts. Use concise strings. This is definition data, not chat history, current scene memory, or a field that changes during play. Avoid future spoilers unless the prompt projection system will hide them until relevant. For public/standalone character definitions, prefer facts safe for library/editor display; put story-only secrets in hidden story objectives, future cast notes, or private prompt projections instead.

- `starting_nsfw_known_facts`: Optional array of adult-only facts copied into runtime `nsfw_known_facts`. Keep it separate from `starting_known_facts`; EmberAdventures exposes it only when the active profile permits NSFW content. Use `[]` when there are no adult-only facts.

- `catalog_hook`: Optional concise, spoiler-free player-facing pitch for the
  standalone character in catalog and discovery UI. Explain why someone would
  want to start a game with this character, usually in one or two sentences.
  Keep it accurate without revealing hidden routes, twists, transformations, or
  endings. It is display metadata, not personality guidance, AI instructions,
  chat context, or a substitute for `chat_story` or
  `chat_story_template.description`. Use `""` when no distinct hook is needed.
  A SFW character's hook must itself be SFW. Omit it from every story-embedded
  character definition.

- `default_image_background`: Optional standalone-character image-setting
  guidance. When present, use a trimmed, nonempty string describing only the
  environment or background that normally suits this character, such as
  `"a candlelit apothecary lined with dried herbs and glass bottles"`. Do not
  put pose, camera, action, anatomy, clothing, or character-description prose
  in this field. EmberAdventures may use it for profile images and other solo
  standalone-character images when no story, scene, location, or explicit user
  setting is authoritative. It never overrides an explicit setting and does
  not apply to multi-character scene images. Omit the field when the normal
  genre-derived/default background is preferable; do not emit a blank string.
  Omit it from every story-embedded character definition.

#### Standalone Character Chat Scenario

Standalone characters may include a lightweight authored starting scenario for the
character library's Chat action. These fields are optional. Use blank strings and a
blank location object when no authored scenario is needed. They do not create
objectives, branches, rewards, shops, or other full-story systems.

- `chat_story`: Inspectable setup context for a new game started through this
  character's Chat action. Describe the immediate premise, relevant history, current
  situation, and durable constraints that the AI needs to continue the interaction.
  Keep it self-contained and focused on this character and the player. The player can
  inspect this text before starting and may replace it with their own opening guidance,
  so do not store secrets that must remain hidden from the player. This field is not a
  transcript and must not prescribe the player's dialogue, thoughts, feelings, or
  important decisions.
- `chat_opening_message`: Exact first visible message for the authored Chat scenario.
  Write finished in-game prose and dialogue rather than an instruction to generate a
  message. Establish an actionable moment and leave control of the player to the
  player. Use supported runtime tokens such as `|[player_name]|` when the text needs
  the selected player's identity. Leave this blank when the AI should generate the
  opening from `chat_story` instead.
- `chat_starting_location`: Exact object with only `label`, `place`, and `activity`.
  `label` is a short player-facing location name. `place` concretely describes where
  the scene occurs. `activity` describes what the character and player are presently
  doing and should work as scene/image context. Either provide all three nonblank
  strings or leave all three blank. Do not add coordinates, world-map topology, NPC
  lists, objectives, or runtime location ids.

Authored Chat fields are defaults, not commands the player must accept. The game tells
the player when authored content exists, lets them inspect it, and lets them override
the location or opening guidance before creating the save. Author these fields so the
scenario still makes sense when the player chooses a different valid location or
direction. Once a Chat game begins, the chosen authored or overridden setup is copied
into that save; later edits to the library character must not retroactively change an
existing game. Importing this character into a normal story does not start or inject
the Chat scenario.

- `chat_story_template`: Optional complete EmberAdventures `storyTemplate` object for
  players who want a full authored story with this character instead of an open-ended
  chat. Use `null` when no full story is included. Never hand-author, summarize,
  partially copy, or invent fields inside this object using the Character skill. Load
  and follow the EmberAdventures Story skill, create the story there, and place only
  its complete inner `storyTemplate` object in this field, never the outer export
  wrapper or any non-story data. The lightweight Chat fields may remain filled when a
  full story exists: they define the separately selectable Just Chat opening and do
  not override, merge into, or replace the full story. The inner story must set
  `allow_any_player: true`. Do not duplicate the surrounding standalone character
  in `state.player`, `state.players`, `state.characters`, NPC entries, or
  `future_cast`. The engine automatically registers the authoritative surrounding
  character under its stable standalone id before validating and launching the
  attached story. The story may reference that stable id in supported character
  references; a second embedded definition with the same id is invalid.

- `stats`: Optional object of game-specific numeric stats. Keys are authored,
  readable stable identifiers such as `strength`, `agility`, `mana`,
  `capacity_cost`, or `pack_share`; EmberAdventures does not prescribe a fixed
  stat list for ordinary custom mechanics. Values normally must be JavaScript
  safe integers. Negative, zero, and positive custom integers are valid; numeric
  strings, booleans, null and unsafe values are invalid. A complete optional
  [fixed combat profile](combat-stats.md) has built-in decimal precision and
  health bounds, including in reusable library characters. Omit `stats` when the
  character does not participate in an authored numeric system. Do not add
  generic RPG stats merely to fill the field. Stats are shown with full
  character information and supplied to the AI for characters present in the
  scene, but omitted from reduced absent-character context.

  Story-embedded copies may use decimal stat values only when the containing
  story declares that custom stat key and its allowed 1-6 decimal places in
  `state.numeric_precision.character_stats`. Other standalone custom stats
  remain integer-only; the complete fixed combat profile is the documented
  exception and does not require story-specific precision metadata.

  Do not put unlock timing, objective requirements, creator instructions, or
  scheduling notes here. Bad: `Should not appear before Harz politics become
  relevant.` Good: `Serves House Harz as a cautious noble contact.`

  Important characters need enough facts to be useful in play. Main party
  members usually need 6-10 specific facts. Major NPCs usually need 4-6. Cover
  identity, role, personality under pressure, combat/usefulness or social
  usefulness, household/social role when relevant, quirks/preferences,
  relationship dynamics, and story/concept-specific complications or arcs. One
  generic fact is draft quality except for truly minor one-scene utility
  characters.

#### Player-Facing Visibility

Character definitions may be shown in public libraries, local libraries, editor
views, character definition panels, and story setup screens. Before exporting,
audit fields that can be visible to players: `name`, `source`, `genres`,
`kink_tags`, `nsfw`, `loli`, `gender`, `age`, `role`,
`personality_description`, `speech_style`, appearance, outfits, starting state, inventory,
durable known facts, voice metadata, and default image metadata.

Visible character fields must not reveal hidden story objectives, future party
roles, future relationship outcomes, private AI instructions, source twists, or
story-specific secrets unless the character entry is intentionally published as
spoiler-heavy and appropriate for that context.

If the character is intended to be used as a player character, visible fields
should establish who they are at the start while preserving the user's future
agency.

#### Image Defaults

- Character-creation AIs do not have the application-owned image records needed to assign image metadata correctly. Always emit blank image defaults. Do not invent, infer, copy, promote, or attach image ids, URLs, prompts, styles, seeds from generated images, or ownership history. The application manages real image metadata after import.

- `default_seed`: Use `0`.

- `image_prompt_config`: Emit the blank object shape from the canonical example.

- `image_prompt_config.seed_enabled`: Use `true` in the blank authored shape.

- `image_prompt_config.seed`: Use `0`.

- `image_prompt_config.style`: Use `""`.

- `image_prompt_config.profile_style`: Use `""`.

- `image_prompt_config`: Use exactly the blank fields shown in the canonical example. The current EmberAdventures exporter emits `negative` and `negative_prompt`, so include both as `""` for round-trip schema consistency. Never put generated or inferred image guidance in them.

- `default_profile_image`: Emit the complete blank object shown in the canonical example, including blank `local_image_id`.

- `default_profile_image.url`: Use `""`.

- `default_profile_image.local_image_id`: Use `""`.

- `default_profile_image.source`: Use `"none"`.

- `default_profile_image.seed`: Use `null`.

- `default_profile_image.prompt`: Use `""`.

- `default_profile_image.negative_prompt`: Use `""`.

- `default_profile_image.note`: Use `""`.

- `default_profile_image.male`: Required boolean profile-presentation metadata. Use `true` only for a male or trans-male presentation. Use `false` for female, futanari, non-binary, and every other non-male presentation. Female and futanari profile images intentionally share the non-male bucket. For a blank authored slot, initialize this from the canonical character presentation. For a configured image, describe the presentation actually shown by that image, even when it is the character's fallback rather than canonical presentation. Never infer this value later from the character's current gender.

- `profile_image_presentations`: Application-managed pair of default profile-image slots named `male` and `non_male`. Each slot uses the same shape as `default_profile_image`; `male.male` must be `true` and `non_male.male` must be `false` when a real image slot is populated. Character-creation AIs emit both keys with blank/null image values and never invent real URLs, local ids, prompts, seeds, data URLs, transparent images, or placeholder image objects. Leave image values blank for EmberAdventures to fill when real images are generated or selected.

A character may be locally drafted or imported with empty profile-image slots, but public publishing requires one real resolving hosted profile image for the male presentation and one real resolving hosted profile image for the female/futanari presentation. Both `profile_image_presentations.male.url` and `profile_image_presentations.non_male.url` must resolve as real images before public upload, and the character must also have the required alternate name/outfit group. Do not use fake image data to satisfy this requirement. `default_profile_image` remains the canonical/default presentation slot and should be null/blank until it can match one of the two real presentation slots. At runtime, a profile image is eligible only when its `male` value matches the character's active male/female presentation; never display the opposite bucket as a fallback. This metadata applies only to profile images. Normal/full-body, group, story, item, outfit, title-card, and other images must not receive a `male` field.

- `created_at`: Required ISO 8601 timestamp for when this definition was first created. Use the actual creation time for new entries; never leave it blank or use an empty placeholder. Preserve it unchanged when editing an existing definition.

- `updated_at`: Required ISO 8601 timestamp for the most recent definition change. Set it to the actual edit time for a new or modified entry. When reviewing without changing the definition, preserve the existing value.

- `profile_images`: Always emit `{ "active_image_id": "", "image_ids": [] }`.

- `images`: Always emit `{ "active_image_id": "", "image_ids": [] }`.

#### Voice

- `voice`: Always use `null`. Character-creation AIs do not have the installed TTS/screen-reader voice information needed to populate this correctly. Do not infer a voice bucket, assign a character name, use a voice actor, or ask the user for voice metadata during normal character creation.

#### Forbidden Definition Fields

Do not include these in `character_definition`: `kind`, `entity_kind`, duplicate name fields, `creator`, `creator_id`, `short_description`, `creator_notes`, `character_version`, `power`, `consent_state`, current `relationship_to_player`, current `trust`, current `attraction`, current `affection`, current `arousal`, current `state_of_mind`, current `physical_state`, current `pose`, `active_outfit_id`, active/current `clothing`, current `held_items`, current `inventory`, current `known_facts`, `profile_image_id`, `profile_images_list`, current location, scene lists, inspected status, invite status, party membership, NPC status, death state, or image inclusion state. `starting_outfit_id` is allowed because it identifies the immutable default preset; `active_outfit_id` is runtime state and is forbidden.


### Physical Attribute Phrase List

The current effective image-prompt mappings and presentation rules are in [references/body-scales-0-20.md](body-scales-0-20.md). Read that reference when selecting or reviewing character appearance values. It describes existing engine behavior and supplies no automatic legacy conversion.

Starting relationship stats `starting_trust`, `starting_attraction`, `starting_affection`, and `starting_arousal` are also base-10 values from 0 to 10. Do not use legacy 0-100 values for those fields.

`bodyStatKeys`: `height`, `shoulder_width`, `chest`, `upper_body_build`, `midsection_build`, `hip_width`, `butt_build`, `lower_body_build`, `arm_length`, `leg_length`, `penis_size`.

All eleven keys must exist exactly once and contain integers from 0 through 20. The old appearance keys `muscular`, `shoulders`, `stomach`, `hips`, `waist`, `legs`, and `arms` must not appear. Do not automatically rescale existing values or repair older exports from this phrase reference. Handle an explicitly requested file repair separately under the canonical character contract.
