# Preference intake and private preference schema

## Private Preference File

Preference file path:

`${CODEX_HOME}/private/emberadventures-character-preferences.json`, or
`~/.codex/private/emberadventures-character-preferences.json` when
`CODEX_HOME` is unset.

The first step for this skill is to locate and read that file. Do not store private preferences inside the shareable skill folder.

If the file does not exist, enter preference-intake mode before doing substantial character generation.

If the file exists, inspect intake state before using preferences:

- Use ask-missing mode by default. Ask only missing or ambiguous preference slots that are relevant to the current request, the next useful global calibration, or a user-requested preference audit.
- If a required safety/default slot is missing, ask the next missing required question before generating explicit/NSFW originals.
- Do not block character creation on broad optional setup. Infer optional preferences from the existing file and the current request unless the missing answer would materially change the character.
- Do not treat a preference file as complete just because it exists, but do not run a full questionnaire just because optional slots remain.
- For story shop stock, auction stock, job-board NPC pools, generic world stock,
  and large batches meant to populate a setting, the story premise and requested
  stock role override private preferences unless the user explicitly says to
  apply those preferences. If the user gives a split such as "use my
  preferences for 25% only," obey that split exactly and explicitly ignore or
  de-emphasize private preferences for the remaining stock instead of merely
  complementing them.
- If minimum setup is complete but optional setup is incomplete, do not show all optional groups by default. Mention only the few relevant missing fields, or offer an audit if the user asks what remains.
- Apply workflow preferences once required safety/default slots are known, but keep the current character request moving.

## Preference Intake Mode

Preference intake is opportunistic. It supports the requested character; it should not take over the whole turn unless the user explicitly asks to configure preferences first.

Ask missing preferences in small, relevant batches. Prefer generic answer options over highly tailored options unless the user asks for a character-specific brainstorm. Do not repeatedly ask the same preference in different words.

If the user asks for an audit, list:

- missing preference slots that genuinely remain
- preference slots you can infer from existing answers
- any conflicts or weak calibrations worth confirming

When the user confirms a correction is general, save it to the preference file. When the correction is only about the current character, keep it character-specific.

### Initial NSFW Question

The first message should only ask exactly: "Before we start, do you want to be able to make NSFW characters?"

After the user answers, create/update the private JSON preference file immediately with `allow_nsfw`, metadata defaults, setup tracking fields, and the filtered question plan.

### Main Setup Message

After the NSFW answer is saved, send one well-formatted setup message that explains how the skill works and asks only the first relevant missing batch.

Explain:

- The default creation workflow is: ask missing preferences, infer the rest, propose a few suitable options, let the user review/pick/request more options or changes, then create the final character.
- If the user dislikes that flow, they can describe another workflow, such as direct creation without proposals, one proposal at a time, or a full preference setup first.
- Setup asks up to 10 questions at a time by default, but most turns should ask fewer.
- Questions are labeled with letters: `a`, `b`, `c`, etc.
- Multiple-choice answers use numbers: `0`, `1`, `2`, etc.
- The user can answer like a quiz (`a: 1, b: 2-6, c: free answer`) or just write naturally.
- The user can skip any question or stop setup and return to character creation at any time.

Then ask up to 10 highest-priority relevant missing questions in the same message. If only 1-3 questions matter for the current character, ask only those.

Always include this metadata question early when missing or when the stored answer may not describe the current tool/session:

- Model number and intelligence/reasoning level for the creation tool: ask for the actual tool, model number, and reasoning/intelligence label, then store the factual final label. Treat this as session-sensitive metadata rather than a permanent taste preference. Before each final export, verify that a saved label still matches the current tool/session; when it cannot be verified, ask instead of silently reusing it.

Do not ask for preference slots that do not map to EmberAdventures character fields unless the answer clearly informs existing fields. Collect preferences against the eleven current body fields. Keep broader body-shape notes only when they add information not represented by `upper_body_build`, `midsection_build`, `hip_width`, `butt_build`, and `lower_body_build`.

### Question Formatting

Use letter labels for questions and numeric labels for answer options.

Format every multiple-choice question as a nested list:

- The question line starts at the left margin.
- Every answer option is indented under that question by three spaces.
- Every answer option must have its own numeric label.
- Do not put option `0` at the same indentation level as the question.
- Do not omit numeric labels from later options.
- Do not insert blank lines between options.
- If using Markdown, prefer a fenced `text` block for setup batches so indentation is preserved exactly.

Example:

```text
a. What default spice mode should I use?
   0. Normal/SFW by default
   1. Sexy by default
   2. Ask or infer each time
   3. Free answer

b. What target genders do you usually want for original characters?
   0. Adult women/female characters
   1. Adult men/male characters
   2. Adult nonbinary/androgynous characters
   3. Mix of genders
   4. Ask or infer each time
   5. Free answer
```

For body scales, list the relevant 0-20 descriptions from [references/body-scales-0-20.md](body-scales-0-20.md) and ask for either a range, a single number, or a natural-language answer. Do not use joke descriptions.

Example:

```text
d. What chest-size range do you usually like for adult female characters?
   Answer with a range like 8-14, a single number like 12, or words.
   0. completely flat chest with no breast projection
   1. nearly flat chest with slight soft breast contour
   ...
   20. absurd extreme-fantasy breast size with impossible torso-dominating projection
```

For broad catch-all body/anatomy questions, include concrete examples and, when there is an active requested character concept, include 6-10 optional uniqueness hooks tailored to that character. Make clear that the user can pick, combine, rewrite, or ignore the hooks. Store recurring preferences in `body_preferences.custom_body_notes` or the relevant specific preference slot. Store character-specific picks as guidance for that character only, not as a universal preference.

Example:

```text
j. Any recurring body/anatomy preferences I should remember for adult female or monster-girl characters?
   Examples: elegant monster anatomy, visible fangs, extra eyes, glossy chitin, soft fantasy anatomy, horror-leaning anatomy, powerful lower bodies, delicate human torsos, avoid insectoid faces, avoid too many limbs on the upper body.

   For this arachne character specifically, here are optional uniqueness hooks you can pick from or ignore:
   0. Silk-weaver artisan who makes beautiful restraints, clothing, and traps
   1. Venom alchemist who creates medicines from carefully diluted venom
   2. Dungeon ambusher with a cozy web-nest full of trophies and handmade gifts
   3. Gothic widow aesthetic with lace veils, mourning jewelry, and courtly manners
   4. Socially awkward monster girl who is terrifying in combat but shy in conversation
   5. Predatory noblewoman who treats every room like a chessboard
   6. Gentle caretaker who uses webs for comfort, safety, and healing
   7. Horror-leaning arachne with beautiful human features and unsettling spider instincts
   8. Traveling silk merchant who hides spy networks in trade routes
   9. Shrine guardian spider spirit with old rituals, taboos, and sacred thread
```

### SFW/NSFW Branching

Relationship-role options and question sets must branch by SFW/NSFW:

- Ask character-role questions before relationship questions. The character creator can create player characters, main story protagonists, party members, and NPCs, so do not assume every character needs a relationship to the player.
- Preferred relationship intake wording: "What type of character are you creating? Is it the main character of a story, a party member of the main character, or an NPC? If it is a party member or NPC, what is the relationship to the player?"
- Always include a no-relationship option for player characters, main characters, or standalone protagonists.
- For a compact setup batch, combine character type and relationship in one question unless the user's answer needs follow-up. Example options:
  - `0. Player character/main character; no relationship to player`
  - `1. Party member; ally/friend relationship`
  - `2. Party member; romantic or erotic companion`
  - `3. Party member; dominant consensual fantasy partner`
  - `4. NPC; neutral or powerful standalone NPC`
  - `5. NPC; rival or antagonist`
  - `6. NPC; mentor, client, quest-giver, or patron`
  - `7. Ask or infer each time`
  - `8. Free answer`
- If `allow_nsfw` is false, do not offer NSFW relationship roles such as consensual slave-by-choice, erotic companion, or dominant sexual partner. Use SFW options such as player/main character with no relationship, neutral NPC, friend/ally, romantic-but-SFW companion, rival/antagonist, party member, mentor, client, quest-giver, patron, or ask each time.
- If `allow_nsfw` is false, omit NSFW-only question groups and answer options.
- If `allow_nsfw` is true, include NSFW-capable options only when relevant, such as consensual slave-by-choice, erotic companion, or ask each time.
- Keep SFW-safe public descriptions free of explicit kink prose. `kink_tags` are
  metadata for NSFW-capable filtering and adult-appropriate views, not text to
  paste into SFW browsing descriptions.
- In final character JSON, `starting_relationship_to_player` may be `"none"` or a natural-language no-relationship value for player characters, main characters, or standalone protagonists. Do not force an NPC relationship when the character type makes that inappropriate.

### Batching And Follow-Up

Ask up to 10 questions at a time by default. If fewer than 10 relevant unanswered questions remain, ask fewer. In normal character-creation turns, prefer 1-5 highly relevant missing questions.

After each user response:

- Extract answers by matching question letters, option numbers, ranges, and natural-language statements.
- Update the preference file.
- Mark answered questions in `answered_questions`.
- Mark explicitly skipped questions in `skipped_questions`.
- Track unanswered questions from the batch.
- If any batch questions were not answered or skipped, give one follow-up opportunity at the bottom of the next response:

```text
It looks like you did not answer these questions. If you want to leave them blank, that is fine; this is just a last chance before I mark them skipped.

k. [unanswered question]
l. [unanswered question]
```

Use the next letters after the original batch when listing unanswered follow-up questions. If the user still does not answer them, mark them skipped.

When the user says "you pick", "priority order", or "I'll do all of them", choose the highest-priority relevant missing questions. Do not ask stale, already answered, or only loosely relevant optional questions.

### Optional Groups

Maintain optional groups as internal coverage tracking, not as a mandatory questionnaire. When presenting optional setup, include group counts only if the user asks what remains or explicitly wants setup/audit mode. In normal character creation, ask only the missing optional questions that matter for the requested character.

Suggested groups:

- Looks and body
- Genders and attraction
- Species/races
- Personality and boldness
- Jobs/concepts
- Relationship dynamics
- Clothing/style
- Names
- Sexual/NSFW preferences if allowed
- Limits and icks
- Batch uniqueness and similarity to existing characters

### Stable Question Bank

Use the stable ids below for `answered_questions`, `skipped_questions`, batch
tracking, and remaining counts. The ids are internal; continue labeling the
questions shown to the user with letters. Ask only relevant unanswered ids and
generate concise multiple-choice options plus a free-answer option. Filter all
`nsfw.*` questions when `allow_nsfw` is false. Compute remaining group counts
from unanswered applicable ids instead of copying hardcoded totals.

```text
required_setup (not included in optional group counts)
setup.allow_nsfw -> general.allow_nsfw -> whether NSFW character creation is allowed
setup.creation_tool -> general.default_creation_tool and default_creation_tool_parts -> current tool, model, and reasoning/intelligence label
setup.spice_mode -> general.default_spice_mode -> normal, sexy, explicit, or ask/infer default when NSFW is allowed

looks_and_body (12)
looks.height -> body_preferences.height_range -> preferred height range
looks.shoulder_width -> body_preferences.shoulder_width_range -> preferred shoulder-width range
looks.chest -> body_preferences.chest_range -> preferred chest range
looks.upper_body_build -> body_preferences.upper_body_build_range -> preferred upper-body build range
looks.midsection_build -> body_preferences.midsection_build_range -> preferred midsection build range
looks.hip_width -> body_preferences.hip_width_range -> preferred hip-width range
looks.butt_build -> body_preferences.butt_build_range -> preferred butt/glute build range
looks.lower_body_build -> body_preferences.lower_body_build_range -> preferred lower-body build range
looks.arm_length -> body_preferences.arm_length_range -> preferred arm-length range
looks.leg_length -> body_preferences.leg_length_range -> preferred leg-length range
looks.penis_size -> body_preferences.penis_size_range -> preferred penis-size range when relevant
looks.custom_anatomy -> body_preferences.custom_body_notes -> recurring anatomy or body details not covered by scales

genders_and_attraction (4)
gender.targets -> genders_and_attraction.target_genders -> genders the user wants created
gender.focus -> genders_and_attraction.gender_focus -> default gender focus or ask/infer behavior
gender.body_by_gender -> genders_and_attraction.body_type_focus_by_gender -> body preferences that differ by gender
gender.variation -> genders_and_attraction.variation_preference -> desired gender variation across batches

species_and_races (6)
species.likes -> species_and_race.liked_species -> liked species/races
species.dislikes -> species_and_race.disliked_species -> disliked species/races
species.human_detail -> species_and_race.human_race_detail_preference -> whether human ethnicity/visual ancestry should be specific, varied, inferred, or omitted
species.diversity -> species_and_race.diversity_expectation -> desired species/race diversity in batches
species.anatomy -> species_and_race.nonhuman_anatomy_preferences -> recurring nonhuman anatomy preferences
species.horror -> species_and_race.horror_appearance_tolerance -> tolerance for genuinely disturbing or horror-like designs

personality_and_boldness (7)
personality.boldness -> personality.boldness_range -> preferred numeric 1-10 boldness range or text guidance
personality.likes -> personality.liked_traits -> liked personality traits
personality.dislikes -> personality.disliked_traits -> disliked personality traits
personality.subversion -> personality.mismatch_or_subversion_preference -> preference for archetype subversion or mismatched traits
personality.aggression -> personality.aggression_preference -> aggression preference independent of boldness
personality.power_dynamic -> personality.power_dynamic_preference -> dominant, submissive, switch, neutral, varied, or ask/infer behavior
personality.tone -> personality.humor_and_tone_preference -> preferred humor, seriousness, warmth, darkness, or tonal mix

jobs_and_concepts (5)
concept.likes -> jobs_and_concepts.liked_jobs -> liked jobs, roles, and concepts
concept.dislikes -> jobs_and_concepts.disliked_jobs -> disliked jobs, roles, and concepts
concept.priority -> jobs_and_concepts.concept_priority -> whether job, archetype, appearance, personality, or another hook should lead design
concept.power -> jobs_and_concepts.overpowered_preference -> desired power level
concept.role_style -> jobs_and_concepts.role_style_preference -> ordinary, fantastical, setting-grounded, origin-driven, or varied role style

relationship_dynamics (5)
relationship.character_type -> relationship_defaults.default_character_type -> player character, party member, NPC, or ask/infer
relationship.default -> relationship_defaults.default_relationship_to_player -> default relationship to player
relationship.allowed -> relationship_defaults.allowed_relationship_types -> allowed relationship types
relationship.none -> relationship_defaults.allow_no_relationship -> whether no player relationship must remain available
relationship.special -> relationship_defaults.special_relationship_dynamics -> optional romance, ownership, oath, rival, family, erotic, or other special dynamics; omit NSFW options when NSFW is disabled

clothing_style (5)
clothing.likes -> clothing_and_style.liked_styles -> liked clothing styles
clothing.dislikes -> clothing_and_style.disliked_styles -> disliked clothing styles
clothing.count -> clothing_and_style.outfit_count_guidance -> how many outfits to create
clothing.plan -> clothing_and_style.default_outfit_plan -> recurring wardrobe composition
clothing.special -> clothing_and_style.special_outfit_notes -> special outfit requirements, including sexual outfit guidance only when NSFW is enabled

names (4)
names.likes -> names.name_style_likes -> liked naming styles
names.dislikes -> names.name_style_dislikes -> disliked naming styles
names.theming -> names.over_themed_name_tolerance -> tolerance for concept-themed names
names.length -> names.word_count_preference -> preferred name length and structure

sexual_nsfw_preferences (8; NSFW only)
nsfw.level -> nsfw_preferences.spice_level -> desired explicitness
nsfw.frequency -> nsfw_preferences.spice_frequency -> desired frequency of sexual characterization
nsfw.kinks -> nsfw_preferences.liked_kinks -> liked kinks and dynamics
nsfw.limits -> nsfw_preferences.limits -> sexual hard limits
nsfw.forwardness -> nsfw_preferences.default_sexual_forwardness -> default sexual forwardness
nsfw.anatomy -> nsfw_preferences.anatomy_preferences -> sexual anatomy preferences
nsfw.role -> nsfw_preferences.role_preferences -> preferred sexual roles or power dynamics
nsfw.clothing -> nsfw_preferences.clothing_preferences -> explicit clothing and exposure preferences

limits_and_icks (3)
limits.hard -> limits_and_icks.hard_limits -> content or traits never to create
limits.soft -> limits_and_icks.soft_avoids -> content or traits generally to avoid
limits.context -> limits_and_icks.contextual_limits -> content allowed only in specific contexts or when explicitly requested

batch_uniqueness (3)
batch.priority -> batch_uniqueness.uniqueness_priority -> desired uniqueness level
batch.compare -> batch_uniqueness.compare_against_existing_characters -> whether to compare against existing libraries
batch.similarity -> batch_uniqueness.similarity_to_existing_characters -> whether new characters should fit with or differ from existing characters
```

Most questions should be multiple choice with an explicit free-answer option. The user can skip any question or stop setup at any time.

When the user says they are done, happy enough, wants to stop questions, wants to skip setup, or wants to return to the character request, record that state in the preference file and proceed using the answered preferences plus reasonable defaults.

If optional counters or `answered_questions` disagree with populated preference fields, trust the populated fields, repair the counters, and avoid re-asking the same topic.

Use a shape like:

"Setup is saved.

There are 11 preference groups with unanswered questions:
- Looks and body: 10 questions
- Genders and attraction: 4 questions
- Species/races: 6 questions
- Personality and boldness: 7 questions
- Jobs/concepts: 5 questions
- Relationship dynamics: 5 questions
- Clothing/style: 5 questions
- Names: 4 questions
- Sexual/NSFW preferences: 8 questions
- Limits and icks: 3 questions
- Batch uniqueness and similarity: 3 questions

Do you want to answer the next 10 questions in highest-priority order, pick a group, skip a group, or stop setup and return to the character request?"

If NSFW is disabled, omit NSFW-only groups/questions from the count and prompt.

## Preference Schema

Use a structured JSON preference file with one general section and otherwise specific question/answer slots.

Suggested shape:

```json
{
  "schema": "emberadventures-character-preferences-v1",
  "updated_at": "<actual ISO 8601 update timestamp>",
  "general": {
    "setup_complete": false,
    "minimum_setup_complete": false,
    "optional_setup_complete": false,
    "user_stopped_setup": false,
    "user_stopped_optional_setup": false,
    "intake_status": "in_progress",
    "allow_nsfw": null,
    "default_spice_mode": "ask_or_infer",
    "default_source": "Original",
    "default_creation_tool": "<actual tool/model> (<reasoning level>)",
    "default_creation_tool_parts": {
      "tool": "",
      "model": "",
      "intelligence": ""
    },
    "preferred_workflow": "ask_missing_propose_review_approve_make",
    "workflow_notes": "Default: ask only relevant missing preferences, infer the rest, propose a few options, let the user review/pick/request changes, then create. User may override with direct creation or another flow.",
    "compare_existing_library": "ask",
    "existing_library_paths": [],
    "last_question_batch": [],
    "unanswered_from_last_batch": [],
    "answered_questions": [],
    "skipped_questions": [],
    "question_plan": {
      "question_label_style": "letters",
      "answer_option_label_style": "numbers",
      "batch_size": 10,
      "stable_question_bank_version": 1,
      "priority_order": []
    },
    "remaining_required_questions": [
      "setup.allow_nsfw",
      "setup.creation_tool",
      "setup.spice_mode"
    ],
    "remaining_optional_groups": {
      "looks_and_body": 10,
      "genders_and_attraction": 4,
      "species_and_races": 6,
      "personality_and_boldness": 7,
      "jobs_and_concepts": 5,
      "relationship_dynamics": 5,
      "clothing_style": 5,
      "names": 4,
      "sexual_nsfw_preferences": 8,
      "limits_and_icks": 3,
      "batch_uniqueness": 3
    }
  },
  "genders_and_attraction": {
    "target_genders": [],
    "gender_focus": "ask",
    "body_type_focus_by_gender": {},
    "variation_preference": "ask"
  },
  "body_preferences": {
    "height_range": null,
    "shoulder_width_range": null,
    "chest_range": null,
    "upper_body_build_range": null,
    "midsection_build_range": null,
    "hip_width_range": null,
    "butt_build_range": null,
    "lower_body_build_range": null,
    "arm_length_range": null,
    "leg_length_range": null,
    "penis_size_range": null,
    "custom_body_notes": ""
  },
  "species_and_race": {
    "liked_species": [],
    "disliked_species": [],
    "human_race_detail_preference": "ask",
    "diversity_expectation": "ask",
    "nonhuman_anatomy_preferences": [],
    "horror_appearance_tolerance": "ask"
  },
  "personality": {
    "boldness_range": null,
    "liked_traits": [],
    "disliked_traits": [],
    "mismatch_or_subversion_preference": "ask",
    "aggression_preference": "ask",
    "power_dynamic_preference": "ask",
    "humor_and_tone_preference": "ask"
  },
  "jobs_and_concepts": {
    "liked_jobs": [],
    "disliked_jobs": [],
    "concept_priority": "ask",
    "overpowered_preference": "ask",
    "role_style_preference": "ask"
  },
  "relationship_defaults": {
    "default_character_type": "ask",
    "default_relationship_to_player": "ask",
    "allow_no_relationship": true,
    "allowed_relationship_types": [],
    "slave_by_choice_default": "ask",
    "special_relationship_dynamics": []
  },
  "clothing_and_style": {
    "liked_styles": [],
    "disliked_styles": [],
    "ambiguity_rule": "pick_one_precise_outfit",
    "outfit_count_guidance": "ask",
    "default_outfit_plan": "ask",
    "normal_outfit_count": null,
    "sexual_outfit_count": null,
    "required_outfit_types": [],
    "disallowed_outfit_types": [],
    "sexual_outfit_notes": "",
    "special_outfit_notes": ""
  },
  "names": {
    "name_style_likes": [],
    "name_style_dislikes": [],
    "over_themed_name_tolerance": "ask",
    "word_count_preference": "ask"
  },
  "proposal_preferences": {
    "format": "ask",
    "detail_level": "ask",
    "include_race_parenthetical": "ask"
  },
  "nsfw_preferences": {
    "spice_level": null,
    "spice_frequency": null,
    "liked_kinks": [],
    "limits": [],
    "default_sexual_forwardness": "ask",
    "anatomy_preferences": [],
    "role_preferences": [],
    "clothing_preferences": []
  },
  "limits_and_icks": {
    "hard_limits": [],
    "soft_avoids": [],
    "contextual_limits": []
  },
  "batch_uniqueness": {
    "uniqueness_priority": "ask",
    "compare_against_existing_characters": "ask",
    "similarity_to_existing_characters": "ask"
  },
  "observed_acceptance_patterns": [],
  "preference_mismatches_to_discuss": []
}
```

If the user accepts/rejects characters in a way that conflicts with recorded preferences, tell them the mismatch you observe and work with them to update preferences or explain why your inference was wrong.

When feedback includes a calibration correction, ask or infer whether it is general or character-specific. Save general calibrations in the relevant preference slot. Examples:

- "This image is a 6, not an 8" -> save as body-scale calibration.
- "Spider women should have spider legs from the back, not a realistic abdomen" -> save as monster-girl anatomy guidance if general.
- "This outfit reads like lingerie" -> save clothing-slot and prompt guidance if general.