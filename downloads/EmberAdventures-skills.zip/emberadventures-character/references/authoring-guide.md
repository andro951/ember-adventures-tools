# Character authoring guidance

## Metadata Fallbacks

Use the preference file and user answers first. If a required value is still
missing, ask before final export whenever practical. For an immediate export,
use only these safe fallbacks:

- `source`: `"Original"`
- `creation_tool`: the actual current tool/model/reasoning label, never a copied example label
- `genres`: `["fantasy"]` only when the concept is clearly broad fantasy and no more accurate approved set is known
- `nsfw`: `true` only when the character definition itself is inherently
  explicit/NSFW as stored or displayed; otherwise `false`
- `loli`: `false`
- `can_die`: `false`
- `voice`: `null`

For original characters, always use `source: "Original"`. Do not ask the user for a default original-character source label. Do not leave `source`, `creation_tool`, approved `genres`, `nsfw`, or `loli` null. `nsfw` and `loli` must be true or false. Do not emit or ask about `creator` or `creator_id`; EmberAdventures assigns both during import.

Set `voice` to `null`. Do not ask for or infer voice information.

Before final export, verify that saved `creation_tool` metadata describes the current tool/session. If it is missing, stale, or unverifiable, ask for the actual tool name, model number, and intelligence/reasoning level, then format the label as `{tool} {model} ({intelligence})` when intelligence is present. Do not silently use the skill's example or a label saved by a different model/session.

## NSFW And Consent

- Original spicy characters must be adults and physically adult.
- Never create sexualized minors or minor-coded characters.
- Original characters can be extremely sexually forward only when the user requests that style or preferences clearly set that as the default.
- If the user asks for submissive/slave-by-choice dynamics, write them as adult consensual fantasy dynamics.
- Do not assume every original character is a willing slave by choice unless preferences or the current request say so.

## Character Design Goals

- Make characters interesting, distinct, and suited to the user's current request.
- Make batches diverse in species/variant, profession, personality, boldness, silhouette, outfit, and tone unless preferences request a narrower set.
- Include mismatch/subversion only when preferences or the prompt support it.
- Avoid making every character a generic archetype.
- Avoid making every character overpowered unless preferences or the current request support it.
- Use the user's job/concept preferences from the preference file.
- Follow `jobs_and_concepts.role_style_preference` and the current request when deciding whether a role should be ordinary, fantastical, setting-grounded, origin-driven, or varied. Do not hardcode one style for all users.
- If the user rejects a role or concept, use their explanation to revise the relevant preference instead of assuming every rejection means the role was too ordinary or job-like.
- Follow `species_and_race.human_race_detail_preference`. When that preference requests human ethnicity/visual ancestry, include the resulting qualifier in the single `species` value; otherwise infer, vary, omit, or ask as recorded.

## Existing Characters

Default to not touching existing characters unless the user asks to edit existing ones.

When creating unique characters, check whether an existing character library file is available or mentioned. If it exists, ask whether the user wants it reviewed so new characters are somewhat similar and fit in, or more distinct from the existing cast.

For uniqueness checks, scan current and relevant existing characters for repeated:

- personality phrasing
- inventory items
- known facts
- body language
- relationship wording
- names and name patterns
- jobs/concepts
- species/variant mix
- outfits

## Names

Use preference-file naming guidance. In general, names should sound like names unless the user wants comedy or aggressive theme names.

For newly generated original characters, use a first and last name by default unless the user explicitly specifies a one-word/nonstandard name or the concept strongly requires a different naming convention.

Do not rename existing or user-specified characters unless the user asks for edits. Manual/pre-existing names are allowed to be one-word or nonstandard.

For batches, shop stock, auction stock, job-board NPCs, and story-world stock,
use unique surnames unless characters are intentionally related. Do not reuse
surnames from player options, examples, templates, skill references, or
unrelated existing characters. If two characters share a surname, record the
relationship clearly in durable known facts; otherwise rename one before final
export.

## Proposal Format

When proposing original character options before final JSON, follow
`proposal_preferences`. If it is unanswered, use this compact neutral fallback:

```text
Name (species/variant)
Description.
```

Include the species/variant parenthetical only when the saved preference requests it or when it materially helps compare concepts. For humans, obey `human_race_detail_preference` rather than always forcing an ethnicity into the proposal.

## Personality

Use preference-file personality and boldness guidance. Make personalities durable and specific, not just current mood or a list of sexual behaviors. Boldness, aggression, and dominant/submissive dynamics are independent: a character may be extremely bold and submissive, quietly dominant, gentle and forward, or aggressive but romantically reserved.

For spicy originals, combine sexuality with identity: job, flaws, humor, fears, habits, principles, contradictions, and social style.

Avoid repetitive boilerplate unless the user explicitly asks for a uniform batch.

## Practical Body And Appearance Guidance

The field contract above defines the schema. This section adds creation guidance
for producing clean image prompts and should not introduce alternate field shapes.

- Body slots describe body only. Do not put clothing, personality, mood, job,
  relationship, pose, or sexual behavior in physical slots.
- Use integer 0-20 values for all eleven body-scale fields. Body-scale strings
  are invalid. Use the locked reference mappings as image-generator-friendly
  vocabulary and put genuinely exceptional anatomy in the appropriate remainder
  field instead of replacing a numeric body field.
- `personality_description` owns personality, behavior, motivations,
  temperament, and durable social style only. Do not put body shape, clothing,
  hair, skin, tattoos, scars, horns, pose, or image-prompt visual text in it.
- `speech_style` owns how the character usually talks. Write one concise
  sentence covering rhythm, formality, bluntness, warmth, guardedness, profanity,
  humor, flirtation, or similar dialogue behavior. Do not put current emotions,
  story instructions, TTS/voice metadata, or visual traits in it.
- `species` owns the complete biological/source identity, including meaningful subtype, subgroup, ethnicity, or lineage qualifiers. Do not create `race` or `ancestry` fields.
- `skin_color`, `eye_color`, `hair_color`, `hair_length`, and `hair_type` own
  only those exact traits.
- `extra_description` owns concrete durable visual traits that do not fit another specific appearance field, including horns, claws, fangs, ordinary tails, wings, extra eyes, unusual ears, nonhuman hands, tattoos, scars, birthmarks, body paint, facial markings, body markings, or a concise species trait that cannot be expressed by one numeric field. Replacement nonhuman lower-body anatomy belongs in `extra_description_lower_body`, not here. It is a remainder field, not a second full-body description.
- Do not duplicate specific appearance fields inside `appearance.extra_description`. The game converts the eleven numeric body fields plus hair, eyes, and skin into image-prompt text. Remove duplicated height, shoulder width, chest size, upper-body build, abdominal build, hip width, butt/glute build, thigh/calf build, arm length, leg length, penis size, hair, skin, and eyes. After final assembly, clean both remainder fields again; if nothing unique remains, use `""`.
- Do not use filler `extra_description` prose such as `Attractive adult [species] with a distinctive silhouette`, `expressive face`, `design cues tied to her work as...`, or `[species] traits shaped around...`. Those phrases are not concrete visual traits and usually duplicate `species`, `role`, body fields, or personality. Write only specific durable visuals that the other fields cannot express, such as scars, tattoos, horns, tails, wings, markings, ports, unusual anatomy, or similar.
- Do not paste prose-first body-design notes into `extra_description`, mention the character by name, use narrative pronouns, describe posture or current state, or explain a visual trait through profession/history. Prefer a compact list of visible leftovers. Before export, preview the fully assembled image prompt and reject `extra_description` if it repeats structured prompt phrases or reads like a character-sheet paragraph.
- For exaggerated features, use direct graphic description language when needed for accurate image output.
- Manual characters may use the full valid 0-20 range when appropriate.
- When the preference file contains a numeric or calibrated body range, final character body fields must explicitly match that scale. Do not rely on vague words like "huge", "massive", or "defined" if the user has calibrated the scale with concrete anchors.
- For clothed characters, use the normal female chest phrase and append `fully covered by the described clothing` when structured upper-body clothing is present. Do not invent a separate clothed scale.
- If the user supplies a concrete anchor such as "8 equals full watermelon-sized per breast", use it to calibrate and select the numeric value `8`. Keep the final mapped body field numeric. Put genuinely additional unmapped anatomy in `extra_description`; do not repeat the mapped trait there.
- If the user prefers impossible anatomy, state it directly and visually, e.g. "more visible ab blocks than realistic human anatomy", rather than just "defined abs".
- Keep species/variant anatomy consistent and visually useful.

### Image Prompt Projection Contract

Character files store facts; EmberAdventures decides what is visible for each image request. Authors must keep the structured facts complete rather than pre-composing a final image prompt.

- Profile portraits are framed from the top of the head through the waist. They include `shoulder_width`, `chest`, `upper_body_build`, `midsection_build`, `arm_length`, durable upper-body traits, and the visible upper clothing subset. They omit `hip_width`, `butt_build`, `lower_body_build`, `leg_length`, `extra_description_lower_body`, and genital-placement wording.
- Normal/full-body and group prompts include `extra_description_lower_body` whenever it is authored and the selected framing includes the lower body. It may describe lower-only markings or unusual humanoid details while `nonhuman_lower_body` is false, or the complete replacement anatomy while the flag is true.
- When `nonhuman_lower_body` is true and ordinary humanoid lower-body traits do not apply, image prompts suppress `hip_width`, `butt_build`, `lower_body_build`, and `leg_length`. Other body fields and all authored clothing remain available.
- Adult NSFW prompts may describe anatomy at the humanoid-to-nonhuman body junction. Male and futa/futanari characters use penis wording; every other character uses vulva/feminine-contour wording. Covered prompts describe only a covered contour. Genital placement never dictates softness, erection, or arousal state.
- Futa/futanari identity must be represented by `gender: "futa"` or `gender: "futanari"`. Tags, kink tags, sexual preferences, role, and appearance prose never establish or override gender. Do not place exact futa/futanari metadata on a non-futanari definition because import and publish validation reject that contradiction.
- Age wording is deterministic: known ages 18 or older are described as `{age}-year-old adult`; known younger ages use the numeric age without `adult`; missing/invalid ages default to adult unless the definition is explicitly minor-marked, in which case image generation is forced SFW.
- Clothing prompt order is: `hat`, `hair_accessory`, `face`, `ears`, `neck`, `shoulders`, `undershirt`, `shirt`, `over_shirt`, `coat`, `bra`, `back`, `hands`, `right_wrist`, `left_wrist`, `right_fingers`, `left_fingers`, `waist`, `belt_accessory`, `pants`, `skirt`, `legwear`, `underwear`, `socks`, `feet`, `other_accessory`. A bra is rendered as `with {bra} underneath` when an `undershirt`, `shirt`, `over_shirt`, or `coat` exists. Underwear is rendered the same way when `pants`, `skirt`, or `legwear` exists. These decisions use structured slot occupancy only, never clothing-word searches.

## Practical Clothing And Items Guidance

The field contract above defines the schema. This section adds workflow and
image-prompt guidance without adding alternate clothing fields.

- Clothing slots are precise item slots. Do not write ambiguous values like "adventuring outfit or maid clothes depending on scene."
- Create one or more precise outfit presets according to the request and saved wardrobe preferences. Never collapse multiple requested looks into one ambiguous outfit.
- Treat clothing like inventory/equipment slots.
  Characters created for Codex-version stories, story shops, auction stock, job
  boards, or generated NPC pools still use the same outfit system; do not move
  removable garments into prose fields just because the character is embedded
  inside a Codex story packet.
- During preference intake, ask what default outfit guidance should be saved for original characters. Offer options such as:
  - `0. You decide how many outfits based on the character`
  - `1. Make 1 normal outfit only unless I ask for more`
  - `2. Make 10 outfits for every character`
  - `3. Make a fixed wardrobe pattern, such as 1 normal, 1 formal, 1 casual, 1 sexy, 1 swimsuit, 1 cosplay, and variants`
  - `4. Free answer`
- Save the answer in `clothing_and_style.outfit_count_guidance`, `default_outfit_plan`, `normal_outfit_count`, `sexual_outfit_count`, `required_outfit_types`, `disallowed_outfit_types`, and `sexual_outfit_notes` as applicable. Use those saved preferences when the user asks for original characters unless the current request overrides them.
- Clothing slots are only for worn/removable items. Do not put tattoos, scars,
  birthmarks, body paint, facial markings, horns, claws, fangs, tails, wings,
  skin color, hair, eyes, body shape, anatomy, or other physical traits in any
  clothing slot, including `other_accessory`.
- If a physical feature is visible because of the outfit, keep the outfit in
  `clothing` and place the physical feature in `appearance.extra_description`.
- Fill every garment the character actually wears in each preset, including
  ordinary underlayers. A coat-only, dress-only, armor-only, or shirt-and-pants
  definition is incomplete when the intended character also wears underwear,
  a bra, undershirt, socks, or other removable layers. Omit a layer only when
  the character intentionally is not wearing it in that outfit.
- Use `starting_inventory`, `starting_known_facts`, and `starting_held_items` to make the character concrete and usable in game. Keep image metadata blank.
- Clothing slots strongly influence EmberAdventures image generation. Do not put lingerie-coded items in `bra`, `underwear`, `shirt`, `skirt`, or `back` unless the intended outfit is skimpy.
- If the user wants a dressed character, avoid values like `thong`, `bikini`, `bra top`, `skirt panels`, `plunging bodice`, or `cape over lingerie`. Use full garments such as tunic, robe, coat, dress, armor, pants, shorts, bodysuit, mantle, apron, or layered wraps.
- Negative image prompt wording cannot reliably overcome skimpy clothing slots. Fix the clothing slots first.
- For sexy-but-dressed characters, show appeal through fit, silhouette, material tension, posture, and selective exposure rather than defaulting to near-nudity.
- EmberAdventures's prompt builder checks top and bottom clothing coverage separately. If a one-piece garment covers the groin, hips, or legs, it must have a normal top/body slot entry and also a bottom-slot coverage entry. Otherwise the generated prompt may infer a naked bottom. Do not duplicate the whole garment description in both slots; put the main garment in the top/body slot, then use the bottom slot for concise lower-body coverage, length, or continuation information.
  - Fishnet teddy example: `shirt`: `"one-piece black fishnet teddy bodysuit"` and `underwear`: `"same teddy covers her groin with a high-cut panty shape"`.
  - Dress example: `shirt`: `"cute wine-red wrap dress with a soft neckline and short flutter sleeves"` and `skirt`: `"same wrap dress falls to mid-thigh"`.
  - Catsuit example: `shirt`: `"one-piece black latex catsuit with a front zipper"` and `pants`: `"same catsuit continues over her hips and legs to the ankles"`.