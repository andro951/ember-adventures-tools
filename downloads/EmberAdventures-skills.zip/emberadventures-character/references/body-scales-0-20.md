# EmberAdventures 0–20 body-scale reference

These are the current effective normal EmberAdventures image-prompt phrases:
12 tables and 252 presets for the eleven numeric body fields. Chest has separate
male and female/non-male presentation tables. The tables describe what the
engine requests from the image model; they do not guarantee the resulting image.

## Selecting values

- Every body-scale field is required. Use an integer from 0 through 20 or a
  nonempty custom description when the scale does not fit. Preserve existing
  values when only the reference wording changes.
- Use each table directly. These are discrete presets, not percentages. Some
  build and chest scales decrease toward the minimum at 10 and increase with a
  different kind of shape afterward. A larger number is not universally larger.
- Select chest using the character's active presentation. Male and trans-male
  presentations use the male table; other presentations use the female/non-male
  table. The same stored number can describe different shapes after adaptation.
- Keep clothing, pose, personality and image style out of numeric body fields.
  Put only additional durable visual details in the appropriate remainder fields,
  without repeating traits already represented by the scales.
- When `nonhuman_lower_body` is true, all eleven scale fields remain required, but
  prompt projection omits `hip_width`, `butt_build`, `lower_body_build` and
  `leg_length`. Describe the replacement anatomy in
  `extra_description_lower_body`; clothing remains independent.
- The non-male chest phrase gains the exact suffix
  `, fully covered, with their size and shape visible beneath the described clothing` when the prompt's structured `chestCovered` flag is true.
  Authors should not copy that clothing-state suffix into appearance data.
- Genital wording is emitted only for an applicable male/futanari presentation
  when the image includes an uncovered lower body and the request is not forced
  SFW. The required `penis_size` field remains present for every character.

## Prompt defaults

These are image-prompt defaults, not permission to fill missing required export
fields. Authored values still require canonical character validation.

| Field | Prompt default |
|---|---:|
| `height` | 10 |
| `shoulder_width` | 10 |
| `chest` | 13 |
| `upper_body_build` | 8 |
| `midsection_build` | 8 |
| `hip_width` | 10 |
| `butt_build` | 8 |
| `lower_body_build` | 8 |
| `arm_length` | 10 |
| `leg_length` | 10 |
| `penis_size` | 10 |

## Height

Field: `appearance.height`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurdly tiny adult figure, about 2'6" / 76 cm tall |
| 1 | extraordinarily tiny adult figure, about 3'0" / 91 cm tall |
| 2 | exceptionally tiny adult figure, about 3'6" / 107 cm tall |
| 3 | extremely short adult figure, about 4'0" / 122 cm tall |
| 4 | unusually short adult figure, about 4'4" / 132 cm tall |
| 5 | very short adult figure, about 4'8" / 142 cm tall |
| 6 | short adult figure, about 5'0" / 152 cm tall |
| 7 | moderately short adult figure, about 5'2" / 157 cm tall |
| 8 | slightly short adult figure, about 5'4" / 163 cm tall |
| 9 | a little below average height, about 5'6" / 168 cm tall |
| 10 | average adult height, about 5'8" / 173 cm tall |
| 11 | a little above average height, about 5'10" / 178 cm tall |
| 12 | moderately tall adult figure, about 6'0" / 183 cm tall |
| 13 | tall adult figure, about 6'3" / 191 cm tall |
| 14 | very tall adult figure, about 6'6" / 198 cm tall |
| 15 | exceptionally tall adult figure, about 7'0" / 213 cm tall |
| 16 | giant-scale adult figure, about 7'6" / 229 cm tall |
| 17 | extremely tall fantasy figure, about 8'0" / 244 cm tall |
| 18 | enormous fantasy figure, about 9'0" / 274 cm tall |
| 19 | colossal fantasy figure, about 10'6" / 320 cm tall |
| 20 | absurd extreme-fantasy height, about 12'0" / 366 cm tall |

## Shoulder width

Field: `appearance.shoulder_width`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-fantasy narrow shoulder span, outer-shoulder to outer-shoulder width about 0.75 head-widths |
| 1 | extraordinarily narrow shoulder span, outer-shoulder to outer-shoulder width about 1 head-width |
| 2 | exceptionally narrow shoulder span, outer-shoulder to outer-shoulder width about 1.25 head-widths |
| 3 | extremely narrow shoulder span, outer-shoulder to outer-shoulder width about 1.5 head-widths |
| 4 | unusually narrow shoulder span, outer-shoulder to outer-shoulder width about 1.75 head-widths |
| 5 | very narrow shoulder span, outer-shoulder to outer-shoulder width about 1.9 head-widths |
| 6 | narrow shoulder span, outer-shoulder to outer-shoulder width about 2.05 head-widths |
| 7 | narrow shoulder span, outer-shoulder to outer-shoulder width about 2.15 head-widths |
| 8 | slightly narrow shoulder span, outer-shoulder to outer-shoulder width about 2.25 head-widths |
| 9 | slightly narrow shoulder span, outer-shoulder to outer-shoulder width about 2.35 head-widths |
| 10 | average shoulder span, outer-shoulder to outer-shoulder width about 2.5 head-widths |
| 11 | slightly wide shoulder span, outer-shoulder to outer-shoulder width about 2.65 head-widths |
| 12 | slightly wide shoulder span, outer-shoulder to outer-shoulder width about 2.85 head-widths |
| 13 | wide shoulder span, outer-shoulder to outer-shoulder width about 3.05 head-widths |
| 14 | wide shoulder span, outer-shoulder to outer-shoulder width about 3.3 head-widths |
| 15 | very wide shoulder span, outer-shoulder to outer-shoulder width about 3.6 head-widths |
| 16 | very wide shoulder span, outer-shoulder to outer-shoulder width about 4 head-widths |
| 17 | extreme fantasy-wide shoulder span, outer-shoulder to outer-shoulder width about 4.5 head-widths |
| 18 | extreme fantasy-wide shoulder span, outer-shoulder to outer-shoulder width about 5.1 head-widths |
| 19 | colossal fantasy shoulder span, outer-shoulder to outer-shoulder width about 6 head-widths |
| 20 | absurd extreme-fantasy shoulder span, outer-shoulder to outer-shoulder width about 7 head-widths |

## Chest (female / non-male presentation)

Field: `appearance.chest`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-scale soft breasts, each about 12 head-volumes, extremely heavy and pancake-like, resting substantially on the ground |
| 1 | extraordinarily huge soft breasts, each about 10 head-volumes, with extreme sagging and the lower portion resting on the ground |
| 2 | gigantic soft breasts, each about 8 head-volumes, hanging to around ankle level |
| 3 | extremely huge soft breasts, each about 6 head-volumes, hanging to around mid-shin |
| 4 | massively oversized soft breasts, each about 4 head-volumes, hanging to around knee level |
| 5 | enormous soft heavy breasts, each about 3 head-volumes, hanging to around mid-thigh |
| 6 | very large soft breasts, each about 2 head-volumes, hanging to the upper thighs |
| 7 | large soft breasts, each about 1.25 head-volumes, severely sagging to around the hip crease / top of pelvis |
| 8 | moderately sized soft breasts, each about 0.75 head-volume, extremely sagging to the lower abdomen below the navel |
| 9 | small soft breasts, each about 0.25 head-volume, but extremely elongated/sagging into the upper abdomen |
| 10 | minimum-volume breasts, each under 0.1 head-volume, with minimal projection |
| 11 | small breasts, each about 0.2 head-volume, rounded and modestly projected |
| 12 | modest breasts, each about 0.35 head-volume, rounded with clear projection |
| 13 | medium breasts, each about 0.55 head-volume, full and rounded |
| 14 | large breasts, each about 0.8 head-volume, prominently projected |
| 15 | very large breasts, each about 1.1 head-volumes, full and strongly projected |
| 16 | huge breasts, each about 1.5 head-volumes, very full and strongly projected |
| 17 | enormous breasts, each about 2 head-volumes, strongly rounded and projected |
| 18 | massive breasts, each about 4 head-volumes, extremely full and oversized |
| 19 | colossal breasts, each about 7 head-volumes, overwhelmingly large |
| 20 | absurd extreme-scale breasts, each more than 10 head-volumes, enormous enough for the lowest curves to reach the ground |

## Chest (male presentation)

Field: `appearance.chest`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme fat-dominant chest with enormous soft adipose pectoral pads spread broadly across the chest wall and hanging as wide flattened folds rather than rounded breast-shaped mounds; soft pectoral-region projection about 2 head-lengths forward from the chest wall |
| 1 | extremely fat-dominant chest with massive soft adipose pectoral pads, very heavy downward chest-fat volume, and broad flattened folds; soft pectoral-region projection about 1.7 head-lengths forward from the chest wall |
| 2 | severely fat-dominant chest with very thick soft pectoral-region adipose pads and pronounced flattened chest-wall fullness; soft pectoral-region projection about 1.4 head-lengths forward from the chest wall |
| 3 | very fat-dominant chest with large soft adipose pads across the pectoral region and clearly heavy flattened chest volume; soft pectoral-region projection about 1.15 head-lengths forward from the chest wall |
| 4 | fat-dominant chest with thick soft adipose pectoral fullness, broad and flattened rather than breast-shaped; soft pectoral-region projection about 0.9 head-lengths forward from the chest wall |
| 5 | clearly soft/heavy chest with substantial adipose padding across the pectoral region and modest downward fold; soft pectoral-region projection about 0.7 head-lengths forward from the chest wall |
| 6 | mildly soft chest with noticeable adipose pectoral padding and limited visible pectoral definition; soft pectoral-region projection about 0.5 head-lengths forward from the chest wall |
| 7 | soft pectoral area with moderate chest-fat fullness; soft pectoral-region projection about 0.35 head-lengths forward from the chest wall |
| 8 | slightly soft pectoral area with a small amount of chest-fat padding; soft pectoral-region projection about 0.2 head-lengths forward from the chest wall |
| 9 | very lean nearly flat pectoral area with only trace soft tissue and almost no projection; soft pectoral-region projection about 0.1 head-lengths forward from the chest wall |
| 10 | minimum-volume point: completely flat chest with essentially no adipose padding and almost no pectoral projection, about 0 head-lengths beyond the chest wall |
| 11 | extremely lean chest with slight pectoral definition; pectoral muscle projects about 0.08 head-lengths forward from the chest wall |
| 12 | lean chest with modest pectoral shape; pectoral muscle projects about 0.12 head-lengths forward from the chest wall |
| 13 | fit chest with clear pectoral definition; pectoral muscle projects about 0.18 head-lengths forward from the chest wall |
| 14 | athletic pectorals with visible thickness and firm projection; pectoral muscle projects about 0.26 head-lengths forward from the chest wall |
| 15 | muscular pectorals with substantial thickness and forward projection; pectoral muscle projects about 0.36 head-lengths forward from the chest wall |
| 16 | very muscular pectorals with large thick muscle mass and strong projection; pectoral muscle projects about 0.5 head-lengths forward from the chest wall |
| 17 | bodybuilder pectorals with very large deeply defined muscle volume; pectoral muscle projects about 0.7 head-lengths forward from the chest wall |
| 18 | extreme bodybuilder pectorals with enormous hypertrophied thickness and rounded muscular projection; pectoral muscle projects about 0.95 head-lengths forward from the chest wall |
| 19 | hyper-muscular fantasy pectorals with colossal forward-projecting muscle mass; pectoral muscle projects about 1.35 head-lengths forward from the chest wall |
| 20 | absurd extreme-fantasy pectorals with gigantic impossible muscular projection and volume; pectoral muscle projects about 2 head-lengths forward from the chest wall |

## Upper-body build

Field: `appearance.upper_body_build`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd fat-volume extreme: enormously thick soft upper arms plus overwhelming soft tissue across the upper back and side torso with deep folds; upper-arm diameter about 2.2 head-widths |
| 1 | extreme fat-volume upper body: massive soft upper arms plus very heavy softness across the upper back and side torso; upper-arm diameter about 1.9 head-widths |
| 2 | severe fat-volume upper body: very thick soft upper arms plus substantial soft tissue across the upper back and side torso; upper-arm diameter about 1.6 head-widths |
| 3 | very heavy soft upper body with large soft upper arms and pronounced upper-back/side-torso fullness; upper-arm diameter about 1.4 head-widths |
| 4 | heavy soft upper body with thick upper arms and clearly substantial upper-back/side-torso soft-tissue volume; upper-arm diameter about 1.2 head-widths |
| 5 | clearly overweight upper-body build with full soft arms and noticeable extra upper-back/side-torso mass; upper-arm diameter about 1 head-width |
| 6 | mildly overweight upper-body build with soft upper arms and modest extra upper-back/side-torso fullness; upper-arm diameter about 0.85 head-widths |
| 7 | naturally soft upper-body build with moderate arm softness and ordinary upper-back/side-torso fullness; upper-arm diameter about 0.7 head-widths |
| 8 | average-soft upper-body build with ordinary arm mass and normal upper-back/side-torso soft-tissue volume; upper-arm diameter about 0.58 head-widths |
| 9 | very thin upper-body build with slender arms, very little fat, and very little muscle bulk through the upper arms/back; upper-arm diameter about 0.38 head-widths |
| 10 | absurd emaciated extreme: stick-thin arms with virtually no visible fat or muscle mass through the upper arms/back and sharply visible collarbone structure; upper-arm diameter about 0.22 head-widths |
| 11 | extremely thin upper-body build with very slim arms and only trace visible upper-arm/back muscle tone; upper-arm diameter about 0.3 head-widths |
| 12 | lean upper-body build with slim lightly toned arms and subtle upper-back definition; upper-arm diameter about 0.4 head-widths |
| 13 | fit upper-body build with clearly toned arms and upper-back definition but modest muscle bulk; upper-arm diameter about 0.52 head-widths |
| 14 | athletic upper-body build with visibly developed biceps, triceps, deltoids, traps, and upper-back muscles; upper-arm diameter about 0.65 head-widths |
| 15 | muscular upper-body build with substantial arm muscles and strongly developed deltoids, traps, and upper back; upper-arm diameter about 0.8 head-widths |
| 16 | very muscular upper-body build with large biceps/triceps and thick, strongly developed deltoids, traps, and upper-back musculature; upper-arm diameter about 1 head-width |
| 17 | bodybuilder upper-body build with very large deeply defined arms, deltoids, traps, and upper-back muscles; upper-arm diameter about 1.25 head-widths |
| 18 | extreme bodybuilder upper-body build with enormous rounded arm muscles and heavily hypertrophied deltoids, traps, and upper back; upper-arm diameter about 1.55 head-widths |
| 19 | hyper-muscular fantasy upper-body build with colossal bulging arm, deltoid, trap, and upper-back muscle mass; upper-arm diameter about 1.9 head-widths |
| 20 | absurd extreme-fantasy muscular upper-body build with gigantic impossible arm, deltoid, trap, and upper-back muscle mass; upper-arm diameter about 2.3 head-widths |

## Midsection build

Field: `appearance.midsection_build`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd fat-volume extreme: front abdominal projection about 3 head-lengths beyond the ribcage line; deep overhang reaching roughly knee level |
| 1 | fat/soft midsection: front abdominal projection about 2.5 head-lengths beyond the ribcage line; heavy overhang reaching around mid-thigh |
| 2 | fat/soft midsection: front abdominal projection about 2.1 head-lengths beyond the ribcage line; substantial overhang reaching the upper-mid thigh |
| 3 | fat/soft midsection: front abdominal projection about 1.7 head-lengths beyond the ribcage line; large overhang reaching the upper thigh |
| 4 | fat/soft midsection: front abdominal projection about 1.4 head-lengths beyond the ribcage line; pronounced overhang reaching around the groin/hip crease |
| 5 | fat/soft midsection: front abdominal projection about 1.1 head-lengths beyond the ribcage line; full rounded belly hanging several inches below the waistline |
| 6 | fat/soft midsection: front abdominal projection about 0.8 head-lengths beyond the ribcage line; soft belly with a modest overhang over the waistline |
| 7 | fat/soft midsection: front abdominal projection about 0.55 head-lengths beyond the ribcage line; rounded soft belly without a heavy overhang |
| 8 | fat/soft midsection: front abdominal projection about 0.3 head-lengths beyond the ribcage line; average-soft abdomen with mild natural fullness |
| 9 | fat/soft midsection: front abdominal projection about 0.12 head-lengths beyond the ribcage line; very thin nearly flat abdomen with very little body fat |
| 10 | absurd emaciated extreme: deeply sunken abdomen with virtually no fat or abdominal muscle, hollowed through the stomach, with faint ribs and minimal side definition |
| 11 | extremely lean flat abdomen with barely visible natural abdominal lines, a light central groove, very faint upper-ab structure, and minimal oblique definition |
| 12 | lean flat abdomen with a faint 2-pack, a subtle central groove, slight upper-ab definition, and light natural oblique lines |
| 13 | fit flat abdomen with a clear 2-pack, light horizontal separations, a visible central groove, gentle oblique definition, and the beginning of a subtle V-cut |
| 14 | athletic tight abdomen with a clear 4-pack, visible obliques, a defined central groove, moderate horizontal separations, and a noticeable V-cut / Adonis belt |
| 15 | muscular tight abdomen with a distinct 6-pack, strong obliques, clear horizontal and central grooves, a pronounced V-cut / Adonis belt, and light serratus definition beneath the ribs |
| 16 | very muscular abdomen with a deep 6-pack, thick sharply sculpted ab blocks, pronounced obliques, visible serratus muscles beneath the ribs, and a deep clearly carved V-cut |
| 17 | bodybuilder abdomen with a highly visible 8-pack, thick rounded ab blocks, deep central and horizontal grooves, prominent obliques, strong saw-toothed serratus definition, and a sharply defined V-cut |
| 18 | extreme bodybuilder abdomen with a thick sharply defined 8-pack, very deep abdominal segmentation, heavily developed obliques, pronounced serratus, a very deep V-cut / Adonis belt, and tightly contracted, sharply defined abdominal musculature |
| 19 | hyper-muscular fantasy abdomen with an exaggerated 10-pack formed by five clear rows of paired ab blocks, each block thick, dense, and sharply sculpted, with extremely deep grooves, colossal obliques, exaggerated serratus, and an extreme carved V-cut |
| 20 | absurd extreme-fantasy abdominal musculature with an impossible 12-pack formed by exactly six clearly visible horizontal rows of paired rectus-abdominis blocks, with no additional central ab rows; each row is thick, dense, rounded, and sharply sculpted, with extremely deep central and horizontal grooves; the lateral abdominal musculature follows the same overall row rhythm through thick diagonally angled oblique ridges that wrap outward from the central abs; exaggerated serratus muscles form sharp saw-toothed diagonal bands beneath the ribs and interlock visually with the upper abdominal rows; colossal external obliques create layered angled side-ab definition through the lower torso; an extremely deep sharply carved V-cut / Adonis belt frames the lower abdomen; the entire midsection has substantially more abdominal segmentation and muscular definition than anatomically possible |

## Hip width

Field: `appearance.hip_width`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-fantasy narrow hip span, lateral outer-hip width about 0.75 head-widths |
| 1 | extraordinarily narrow hip span, lateral outer-hip width about 1 head-width |
| 2 | exceptionally narrow hip span, lateral outer-hip width about 1.2 head-widths |
| 3 | extremely narrow hip span, lateral outer-hip width about 1.4 head-widths |
| 4 | unusually narrow hip span, lateral outer-hip width about 1.6 head-widths |
| 5 | very narrow hip span, lateral outer-hip width about 1.75 head-widths |
| 6 | narrow hip span, lateral outer-hip width about 1.85 head-widths |
| 7 | narrow hip span, lateral outer-hip width about 1.95 head-widths |
| 8 | slightly narrow hip span, lateral outer-hip width about 2.05 head-widths |
| 9 | slightly narrow hip span, lateral outer-hip width about 2.15 head-widths |
| 10 | average hip span, lateral outer-hip width about 2.25 head-widths |
| 11 | slightly wide hip span, lateral outer-hip width about 2.4 head-widths |
| 12 | slightly wide hip span, lateral outer-hip width about 2.6 head-widths |
| 13 | wide hip span, lateral outer-hip width about 2.8 head-widths |
| 14 | wide hip span, lateral outer-hip width about 3.05 head-widths |
| 15 | very wide hip span, lateral outer-hip width about 3.35 head-widths |
| 16 | very wide hip span, lateral outer-hip width about 3.7 head-widths |
| 17 | extreme fantasy-wide hip span, lateral outer-hip width about 4.1 head-widths |
| 18 | extreme fantasy-wide hip span, lateral outer-hip width about 4.6 head-widths |
| 19 | colossal fantasy hip span, lateral outer-hip width about 5.2 head-widths |
| 20 | absurd extreme-fantasy hip span, lateral outer-hip width about 6 head-widths |

## Butt / glute build

Field: `appearance.butt_build`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-fantasy soft/fat butt with enormously oversized plush glute volume, extreme roundness, and overwhelming glute projection; glute depth outward from the pelvis line about 3 head-lengths |
| 1 | extremely huge soft fat butt with massive plush glute volume and enormous rounded projection; glute depth outward from the pelvis line about 2.6 head-lengths |
| 2 | gigantic soft fat butt with very large plush glute volume and substantial rounded projection; glute depth outward from the pelvis line about 2.3 head-lengths |
| 3 | enormous soft fat butt with large rounded cheeks and pronounced glute volume; glute depth outward from the pelvis line about 2 head-lengths |
| 4 | very large soft fat butt with thick plush volume, strong roundness, and substantial projection; glute depth outward from the pelvis line about 1.7 head-lengths |
| 5 | large soft fat butt with noticeably full rounded cheeks and generous projection; glute depth outward from the pelvis line about 1.4 head-lengths |
| 6 | full soft butt with abundant natural fat volume and clear rounded projection; glute depth outward from the pelvis line about 1.15 head-lengths |
| 7 | nicely full soft butt with noticeable plush volume and natural roundness; glute depth outward from the pelvis line about 0.9 head-lengths |
| 8 | moderately full soft butt with gentle roundness and natural projection; glute depth outward from the pelvis line about 0.65 head-lengths |
| 9 | small lean butt with little soft volume and limited glute projection; glute depth outward from the pelvis line about 0.3 head-lengths |
| 10 | completely and totally flat butt with virtually no visible glute volume or outward projection; glute depth outward from the pelvis line is effectively 0 head-lengths |
| 11 | extremely small lean glutes with only slight muscular shape and minimal projection; glute depth outward from the pelvis line about 0.2 head-lengths |
| 12 | lean lightly toned glutes with modest muscular shape and little projection; glute depth outward from the pelvis line about 0.35 head-lengths |
| 13 | fit glutes with clear muscular shape and moderate projection; glute depth outward from the pelvis line about 0.5 head-lengths |
| 14 | athletic glutes with visibly developed muscle and firm rounded projection; glute depth outward from the pelvis line about 0.7 head-lengths |
| 15 | muscular glutes with substantial muscle volume, strong roundness, and pronounced projection; glute depth outward from the pelvis line about 0.9 head-lengths |
| 16 | very muscular glutes with large thick muscle mass and powerful rounded projection; glute depth outward from the pelvis line about 1.15 head-lengths |
| 17 | bodybuilder glutes with very large deeply developed muscular volume and strong separation; glute depth outward from the pelvis line about 1.45 head-lengths |
| 18 | extreme bodybuilder glutes with enormous hypertrophied muscle mass and exaggerated muscular projection; glute depth outward from the pelvis line about 1.8 head-lengths |
| 19 | hyper-muscular fantasy glutes with colossal bulging muscle volume and extreme projection; glute depth outward from the pelvis line about 2.3 head-lengths |
| 20 | absurd extreme-fantasy muscular glutes with gigantic impossible muscle volume and overwhelming glute projection; glute depth outward from the pelvis line about 3 head-lengths |

## Lower-body build

Field: `appearance.lower_body_build`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd fat-volume extreme with enormously thick soft thighs and calves, deep soft folds, and overwhelming lower-leg mass; thigh diameter about 3 head-widths and calf diameter about 2 head-widths |
| 1 | extreme fat-volume lower body with massive soft thighs and very thick soft calves; thigh diameter about 2.6 head-widths and calf diameter about 1.75 head-widths |
| 2 | severe fat-volume lower body with very large soft thighs and substantially thickened calves; thigh diameter about 2.3 head-widths and calf diameter about 1.55 head-widths |
| 3 | very heavy soft lower body with large thighs and noticeably heavy calves; thigh diameter about 2 head-widths and calf diameter about 1.35 head-widths |
| 4 | heavy soft lower body with clearly thick thighs and substantial calf softness; thigh diameter about 1.7 head-widths and calf diameter about 1.15 head-widths |
| 5 | clearly overweight lower body with full thighs and calves but still reasonably proportional; thigh diameter about 1.45 head-widths and calf diameter about 1 head-width |
| 6 | mildly overweight lower body with soft full thighs and modestly thick calves; thigh diameter about 1.25 head-widths and calf diameter about 0.85 head-widths |
| 7 | naturally soft lower body with moderate thigh/calf fullness; thigh diameter about 1.1 head-widths and calf diameter about 0.72 head-widths |
| 8 | average-soft lower body with ordinary thigh and calf mass; thigh diameter about 0.95 head-widths and calf diameter about 0.6 head-widths |
| 9 | very thin lower body with slender thighs/calves and very little fat or muscle; thigh diameter about 0.6 head-widths and calf diameter about 0.4 head-widths |
| 10 | absurd emaciated extreme with stick-thin thighs/calves and virtually no visible fat or muscle mass; thigh diameter about 0.35 head-widths and calf diameter about 0.25 head-widths |
| 11 | extremely thin lower body with very slim thighs/calves and only trace muscle tone; thigh diameter about 0.45 head-widths and calf diameter about 0.3 head-widths |
| 12 | lean lower body with slim lightly toned thighs/calves; thigh diameter about 0.6 head-widths and calf diameter about 0.4 head-widths |
| 13 | fit lower body with clearly toned thighs/calves but modest muscle bulk; thigh diameter about 0.8 head-widths and calf diameter about 0.5 head-widths |
| 14 | athletic lower body with visibly developed quadriceps, hamstrings, and calves; thigh diameter about 1 head-width and calf diameter about 0.65 head-widths |
| 15 | muscular lower body with substantial quadriceps, hamstrings, and calf development; thigh diameter about 1.25 head-widths and calf diameter about 0.8 head-widths |
| 16 | very muscular lower body with large thighs and heavily developed calves; thigh diameter about 1.5 head-widths and calf diameter about 1 head-width |
| 17 | bodybuilder lower body with very large deeply defined quadriceps, hamstrings, and calves; thigh diameter about 1.8 head-widths and calf diameter about 1.2 head-widths |
| 18 | extreme bodybuilder lower body with enormous rounded quadriceps/hamstrings and heavily hypertrophied calves; thigh diameter about 2.15 head-widths and calf diameter about 1.45 head-widths |
| 19 | hyper-muscular fantasy lower body with colossal bulging thigh and calf muscles; thigh diameter about 2.55 head-widths and calf diameter about 1.7 head-widths |
| 20 | absurd extreme-fantasy muscular lower body with gigantic impossible quadriceps, hamstrings, and calves; thigh diameter about 3 head-widths and calf diameter about 2 head-widths |

## Arm length

Field: `appearance.arm_length`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-fantasy short arms: shoulder-to-fingertip length about 15% of standing height; each hand is visibly longer than the entire shortened shoulder-to-wrist arm |
| 1 | impossibly short arms: shoulder-to-fingertip length about 18% of standing height; each hand is about as long as the shortened shoulder-to-wrist arm |
| 2 | extraordinarily short arms: shoulder-to-fingertip length about 22% of standing height |
| 3 | extremely short arms: shoulder-to-fingertip length about 26% of standing height |
| 4 | exceptionally short arms: shoulder-to-fingertip length about 29% of standing height |
| 5 | very short arms: shoulder-to-fingertip length about 32% of standing height |
| 6 | short arms: shoulder-to-fingertip length about 34% of standing height |
| 7 | moderately short arms: shoulder-to-fingertip length about 36% of standing height |
| 8 | slightly short arms: shoulder-to-fingertip length about 37% of standing height |
| 9 | a little below-average arm length: shoulder-to-fingertip length about 39% of standing height |
| 10 | average proportional arm length: shoulder-to-fingertip length about 41% of standing height |
| 11 | a little above-average arm length: shoulder-to-fingertip length about 43% of standing height |
| 12 | slightly long arms: shoulder-to-fingertip length about 45% of standing height |
| 13 | long arms: shoulder-to-fingertip length about 48% of standing height |
| 14 | noticeably long arms: shoulder-to-fingertip length about 52% of standing height |
| 15 | very long arms: shoulder-to-fingertip length about 57% of standing height |
| 16 | exceptionally long arms: shoulder-to-fingertip length about 63% of standing height |
| 17 | extremely long arms: shoulder-to-fingertip length about 70% of standing height |
| 18 | exaggerated fantasy-long arms: shoulder-to-fingertip length about 80% of standing height |
| 19 | extreme fantasy-long arms: shoulder-to-fingertip length about 115% of standing height; the upper-arm segment itself is long enough that the elbows hang close to the lower shins when standing upright |
| 20 | absurd extreme-fantasy arm length: shoulder-to-fingertip length about 160% of standing height; the upper-arm segment alone is about 85% of standing height, allowing the elbows to touch the ground while standing upright, with forearms and hands extending far beyond them |

## Leg length

Field: `appearance.leg_length`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-fantasy short legs; hip-to-ground leg length about 18% of total standing height, with the hips only a short distance above the ankles |
| 1 | impossibly short legs; hip-to-ground leg length about 22% of total standing height |
| 2 | extraordinarily short legs; hip-to-ground leg length about 27% of total standing height |
| 3 | extremely short legs; hip-to-ground leg length about 32% of total standing height |
| 4 | exceptionally short legs; hip-to-ground leg length about 36% of total standing height |
| 5 | very short legs; hip-to-ground leg length about 40% of total standing height |
| 6 | short legs; hip-to-ground leg length about 43% of total standing height |
| 7 | short legs; hip-to-ground leg length about 46% of total standing height |
| 8 | slightly short legs; hip-to-ground leg length about 48% of total standing height |
| 9 | slightly short legs; hip-to-ground leg length about 50% of total standing height |
| 10 | average proportional leg length; hip-to-ground leg length about 52% of total standing height |
| 11 | slightly long legs; hip-to-ground leg length about 54% of total standing height |
| 12 | slightly long legs; hip-to-ground leg length about 56% of total standing height |
| 13 | long legs; hip-to-ground leg length about 59% of total standing height |
| 14 | long legs; hip-to-ground leg length about 62% of total standing height |
| 15 | very long legs; hip-to-ground leg length about 66% of total standing height |
| 16 | very long legs; hip-to-ground leg length about 70% of total standing height |
| 17 | extreme fantasy-long legs; hip-to-ground leg length about 75% of total standing height |
| 18 | extreme fantasy-long legs; hip-to-ground leg length about 82% of total standing height, with leg length overwhelmingly dominating torso length |
| 19 | colossal fantasy-long legs; hip-to-ground leg length about 88% of total standing height, leaving only a very small upper-body portion above the hips |
| 20 | absurd extreme-fantasy leg length; hip-to-ground leg length about 94% of total standing height, leaving a proportionally tiny torso above the extremely high-set hips |

## Penis size

Field: `appearance.penis_size`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | almost no external projection penis, about 0.25 in / 0.6 cm long and about 0.25 in / 0.6 cm wide |
| 1 | extremely tiny penis, about 0.5 in / 1.3 cm long and about 0.35 in / 0.9 cm wide |
| 2 | extraordinarily tiny penis, about 0.75 in / 1.9 cm long and about 0.45 in / 1.1 cm wide |
| 3 | micropenis-scale penis, about 1 in / 2.5 cm long and about 0.6 in / 1.5 cm wide |
| 4 | exceptionally tiny penis, about 1.5 in / 3.8 cm long and about 0.7 in / 1.8 cm wide |
| 5 | tiny penis, about 2 in / 5.1 cm long and about 0.8 in / 2.0 cm wide |
| 6 | very small penis, about 2.5 in / 6.4 cm long and about 0.9 in / 2.3 cm wide |
| 7 | very small penis, about 3 in / 7.6 cm long and about 1 in / 2.5 cm wide |
| 8 | small penis, about 4.5 in / 11.4 cm long and about 1.2 in / 3.0 cm wide |
| 9 | moderately small penis, about 5.25 in / 13.3 cm long and about 1.3 in / 3.3 cm wide |
| 10 | average-sized penis, about 6 in / 15.2 cm long and about 1.35 in / 3.4 cm wide |
| 11 | large penis, about 7 in / 17.8 cm long and about 1.5 in / 3.8 cm wide |
| 12 | very large penis, about 8 in / 20.3 cm long and about 1.6 in / 4.1 cm wide |
| 13 | extremely large and thick penis, about 9 in / 22.9 cm long and about 1.75 in / 4.4 cm wide |
| 14 | massive fantasy-sized penis, about 12 in / 30.5 cm long and about 2 in / 5.1 cm wide |
| 15 | enormous fantasy-sized penis, about 15 in / 38.1 cm long and about 2.4 in / 6.1 cm wide |
| 16 | gigantic fantasy-sized penis, about 18 in / 45.7 cm long and about 2.75 in / 7.0 cm wide |
| 17 | colossal fantasy-sized penis, about 24 in / 61.0 cm long and about 3.5 in / 8.9 cm wide |
| 18 | absurd extreme-fantasy-scale penis, about 36 in / 91.4 cm long and about 5 in / 12.7 cm wide |
| 19 | surreal extreme-fantasy-scale penis, about 60 in / 152.4 cm long and about 8 in / 20.3 cm wide |
| 20 | absolute extreme-fantasy maximum penis, about 96 in / 243.8 cm long and about 12 in / 30.5 cm wide |

## Reference maintenance

The tables are generated from `bodyStatPhraseFromNumber`, including its chest
override, and `BODY_STAT_DEFAULTS` in a normal EmberAdventures checkout. They
replace the historical design/migration worksheet. This reference supplies no
automatic legacy conversion and must not be used to rewrite existing characters.

Maintainers can compare every preset with a local normal-game checkout:

```text
node "<skill-folder>/scripts/sync-body-scales.cjs" "<normal-EA-checkout>"
```

The default command only checks. Add `--write` to regenerate this reference;
it does not modify the game, stories or character files. Exercise the checker
and documented presentation/framing rules with:

```text
node "<skill-folder>/scripts/test-body-scales.cjs" "<normal-EA-checkout>"
```

After maintenance,
validate and rebuild the complete skill ZIP following SKILL.md.