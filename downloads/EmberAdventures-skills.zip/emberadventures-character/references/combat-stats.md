# Optional fixed combat profile

Characters may carry the complete six-value profile in `stats`. This snippet
illustrates the numeric fields; it is not a complete character export:

```json
{
  "stats": {
    "health": 200,
    "max_health": 200,
    "physical_attack": 100,
    "magical_attack": 60,
    "physical_defense": 700,
    "magical_defense": 180
  }
}
```

These are example values, not universal character defaults or a rebalance of
an existing cast. Author a coherent scale based on the character's established
capabilities. Preserve existing numbers unless a deliberate change is requested.

All six values use at most two decimal places. These complete-profile rules are
built into the character validator; other custom stat keys retain their normal
integer contract. Values must be finite safe numbers; only current health may
be negative, from minus maximum through maximum. Maximum health is positive.

Physical and magical Attack are effectiveness ratings, not damage amounts.
Per-hit Strength is BASE damage chosen from the technique, weapon, force and
intent. The engine computes ceil(Strength * 2 * Attack / (Attack + Defense)),
using physical_attack/physical_defense or magical_attack/magical_defense.
Attack zero always deals zero, including both ratings zero. Final damage is an
integer, rounded up once. No susceptibility multiplier or alternate equation.

A magical Attack rating does not grant a
new spell; describe actual learned abilities and restrictions in existing
character fields. Descriptive speed/reflexes belong in descriptions or facts,
not unsupported string-valued numeric stats.

Zero and negative HP above minus maximum mean conscious, speech permitted and
slow crawling only; no fighting, standing, walking or weapon use. At minus maximum
can_die true means dead, otherwise unconscious. Explicit nonlethal damage stops
at zero and cannot worsen negative HP. Stopping combat does not restore HP or
consciousness. There is no universal passive healing, mana or stamina pool.
Initial adjudication cannot invent death/permanent wounds; final narration follows
actual engine results. Full definitions still require their boolean can_die.
An uninspected shell's omitted optional flag follows native storage's false policy.
An uninspected NPC may already have current combat stats; completing their
definition by inspection preserves those existing values, including current HP.
Existing authored injuries, species traits and abilities remain part of the
character; do not erase them or add regeneration merely to fill this profile.

Combat stats are optional character data. Do not add generic RPG stats to a
character unless relevant to the requested design. Full character schema,
outfits, identity and quality requirements remain unchanged.
