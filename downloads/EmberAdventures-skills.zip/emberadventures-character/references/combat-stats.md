# Optional fixed combat profile

Characters may carry the complete six-value profile in `stats`. This snippet
illustrates the numeric fields; it is not a complete character export:

```json
{
  "stats": {
    "health": 200,
    "max_health": 200,
    "physical_attack": 100,
    "magical_attack": 60,
    "physical_susceptibility": 0.25,
    "magical_susceptibility": 0.5
  }
}
```

These are example values, not universal character defaults or a rebalance of
an existing cast. Author a coherent scale based on the character's established
capabilities. Preserve existing numbers unless a deliberate change is requested.

Health/current maximum and both attack values use at most two decimal places.
Susceptibilities use at most six. These complete-profile precision rules are
built into the character validator; other custom stat keys retain their normal
integer contract. Values must be finite nonnegative safe numbers. Maximum
health must be positive and current health cannot exceed it.

Susceptibility is the fraction TAKEN: 0.25 takes 25% of the relevant raw damage,
1 takes all of it, 0 is immunity, and values above 1 are vulnerability. It is not
the percentage blocked. Do not confuse physical and magical susceptibility.

An ordinary clean hit uses the corresponding attack value as BASE damage.
The engine applies susceptibility. A magical attack number does not grant a
new spell; describe actual learned abilities and restrictions in existing
character fields. Descriptive speed/reflexes belong in descriptions or facts,
not unsupported string-valued numeric stats.

Zero HP means incapacitated, not dead. There is no universal passive healing,
mana or stamina pool, and combat narration cannot invent permanent injuries.
An uninspected NPC may already have current combat stats; completing their
definition by inspection preserves those existing values, including current HP.
Existing authored injuries, species traits and abilities remain part of the
character; do not erase them or add regeneration merely to fill this profile.

Combat stats are optional character data. Do not add generic RPG stats to a
character unless relevant to the requested design. Full character schema,
outfits, identity and quality requirements remain unchanged.