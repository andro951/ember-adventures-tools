"use strict";

// Run directly: node test-body-scales.cjs "<normal-EA-checkout>".
const {test}=require("node:test");
const assert=require("node:assert/strict");
const fs=require("node:fs");
const os=require("node:os");
const path=require("node:path");
const {spawnSync}=require("node:child_process");
const engine=path.resolve(process.argv[2] || "");
assert.ok(process.argv[2],"Pass a normal EmberAdventures checkout.");
const {createProductionContext}=require(path.join(engine,"tools/lib/production-declarations.cjs"));
const script=path.join(__dirname,"sync-body-scales.cjs");
const reference=path.resolve(__dirname,"../references/body-scales-0-20.md");
const run=(file,args)=>spawnSync(process.execPath,[file,...args],{encoding:"utf8"});

function withFixture(action) {
    const tempRoot=fs.realpathSync(os.tmpdir());
    const folder=fs.mkdtempSync(path.join(tempRoot,"ea-body-scale-reference-"));
    try {
        fs.mkdirSync(path.join(folder,"scripts"));fs.mkdirSync(path.join(folder,"references"));
        const copy=path.join(folder,"scripts/sync-body-scales.cjs"),doc=path.join(folder,"references/body-scales-0-20.md");
        fs.copyFileSync(script,copy);fs.copyFileSync(reference,doc);
        return action(copy,doc);
    }
    finally {
        assert.equal(path.dirname(fs.realpathSync(folder)),tempRoot,"Cleanup must remain inside the dedicated temporary root.");
        assert.ok(path.basename(folder).startsWith("ea-body-scale-reference-"));
        fs.rmSync(folder,{recursive:true});
    }
}

test("all 252 documented presets match the actual production helper,including chest overrides",()=>{
    const production=createProductionContext(engine),text=fs.readFileSync(reference,"utf8");
    const tables=[...text.matchAll(/^## (.+)\n\nField: `appearance\.(\w+)`\.\n\n\| Value \| Image-prompt phrase \|\n\|---:\|---\|\n([\s\S]*?)(?=\n\n## |(?![\s\S]))/gm)];
    assert.equal(tables.length,12);let count=0;
    for (const [,title,slot,body] of tables) {
        const gender=title.includes("(male presentation)") ? "male" : "female";
        const rows=[...body.matchAll(/^\| (\d+) \| (.+) \|$/gm)];assert.equal(rows.length,21);
        rows.forEach(([,value,phrase],index)=>{
            assert.equal(Number(value),index);count++;
            assert.equal(phrase.replaceAll("\\|","|"),production.invoke("bodyStatPhraseFromNumber",slot,index,{gender}),`${slot}/${gender}/${index}`);
        });
    }
    assert.equal(count,252);
    assert.equal(new Set(tables.map(table=>table[2])).size,11);
    production.load("BODY_STAT_DEFAULTS");
    for (const [key,value] of Object.entries(production.context.BODY_STAT_DEFAULTS))
        assert.ok(text.includes(`| \`${key}\` | ${value} |`));
});

test("the default checker succeeds without rewriting the reference",()=>{
    const before=fs.readFileSync(reference),result=run(script,[engine]);
    assert.equal(result.status,0,result.stderr);assert.deepEqual(fs.readFileSync(reference),before);
});

test("stale phrases,missing rows,and wrong defaults are rejected without automatic repair",()=>{
    withFixture((copy,doc)=>{
        const original=fs.readFileSync(doc,"utf8");
        for (const altered of [original.replace("0.55 head-volume","0.99 head-volume"),original.replace(/^\| 20 \|.*\n/m,""),original.replace("| `height` | 10 |","| `height` | 9 |")]) {
            assert.notEqual(altered,original);fs.writeFileSync(doc,altered);
            const result=run(copy,[engine]);assert.equal(result.status,1);
            assert.match(result.stderr,/differs from the production helpers/);assert.equal(fs.readFileSync(doc,"utf8"),altered);
        }
    });
});

test("explicit refresh changes only the dedicated reference copy and produces a checkable document",()=>{
    withFixture((copy,doc)=>{
        const before=fs.readFileSync(reference);fs.writeFileSync(doc,"stale reference");
        const result=run(copy,[engine,"--write"]);assert.equal(result.status,0,result.stderr);
        assert.deepEqual(fs.readFileSync(doc),before);assert.deepEqual(fs.readFileSync(reference),before);
        assert.equal(run(copy,[engine]).status,0);
    });
});

test("invalid arguments and missing production source fail without changing the reference",()=>{
    withFixture((copy,doc)=>{
        const before=fs.readFileSync(doc);
        for (const args of [[],[engine,"--unknown"],[engine,"--write","--write"],[path.join(path.dirname(doc),"missing-engine")]]) {
            const result=run(copy,args);assert.equal(result.status,1);assert.deepEqual(fs.readFileSync(doc),before);
        }
    });
});

test("the documented presentation and framing rules still match actual prompt projection",()=>{
    const production=createProductionContext(engine),base=Object.fromEntries(Array.from(production.invoke("bodyStatKeys"),key=>[key,13]));
    const suffix=", fully covered, with their size and shape visible beneath the described clothing";
    for(let value=0;value<=20;value++) {
        const male=production.invoke("bodyStatPhraseFromNumber","chest",value,{gender:"male"});
        const female=production.invoke("bodyStatPhraseFromNumber","chest",value,{gender:"female"});
        assert.equal(production.invoke("bodyStatPhraseFromNumber","chest",value,{gender:"trans male"}),male);
        assert.equal(production.invoke("bodyStatPhraseFromNumber","chest",value,{gender:"futanari"}),female);
        assert.equal(production.invoke("bodyStatPhraseFromNumber","chest",value,{gender:"female"},{chestCovered:true}),female+suffix);
    }
    const context={includesLowerBody:true,effectiveClothing:{}},male={gender:"male"};
    const full=production.invoke("buildBodyStatPrompt",base,male,context);
    const replaced=production.invoke("buildBodyStatPrompt",{...base,nonhuman_lower_body:true},male,context);
    for (const slot of Object.keys(base)) {
        const phrase=production.invoke("bodyStatPhraseFromNumber",slot,13,male);
        assert.ok(full.includes(phrase));
        assert.equal(replaced.includes(phrase),!["hip_width","butt_build","lower_body_build","leg_length"].includes(slot));
    }
    const genital=production.invoke("bodyStatPhraseFromNumber","penis_size",13,male);
    for (const [entity,prompt] of [[{gender:"female"},context],[male,{...context,forceSfw:true}],[male,{...context,includesLowerBody:false}],[male,{...context,effectiveClothing:{pants:"canvas trousers"}}]])
        assert.ok(!production.invoke("buildBodyStatPrompt",base,entity,prompt).includes(genital));
});
