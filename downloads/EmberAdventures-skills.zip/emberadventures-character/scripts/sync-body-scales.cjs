"use strict";

// Maintainer-only: read the normal game's production helpers; never edit game or character data.
const assert=require("node:assert/strict");
const fs=require("node:fs");
const path=require("node:path");

const labels={
    height:"Height",shoulder_width:"Shoulder width",chest:"Chest",
    upper_body_build:"Upper-body build",midsection_build:"Midsection build",
    hip_width:"Hip width",butt_build:"Butt / glute build",lower_body_build:"Lower-body build",
    arm_length:"Arm length",leg_length:"Leg length",penis_size:"Penis size",
};

function productionScales(engineRoot) {
    const {createProductionContext}=require(path.join(engineRoot,"tools/lib/production-declarations.cjs"));
    const production=createProductionContext(engineRoot);
    const keys=Array.from(production.invoke("bodyStatKeys"));
    assert.deepEqual(keys,Object.keys(labels),"The body-field contract changed;review the reference generator before updating it.");
    production.load("BODY_STAT_DEFAULTS");
    const defaults=production.context.BODY_STAT_DEFAULTS;
    const tables=[];
    for (const slot of keys) {
        const presentations=slot==="chest" ? ["female","male"] : ["shared"];
        for (const presentation of presentations) {
            const phrases=Array.from({length:21},(_,value)=>production.invoke("bodyStatPhraseFromNumber",slot,value,{gender:presentation==="male" ? "male" : "female"}));
            assert.ok(phrases.every(phrase=>typeof phrase==="string" && phrase.trim()===phrase && phrase.length && !/[\r\n]/.test(phrase)),`Unexpected phrase format for ${slot}/${presentation}.`);
            tables.push({slot,presentation,phrases});
        }
    }
    assert.equal(tables.reduce((count,table)=>count+table.phrases.length,0),252);
    const coveredSuffix=", fully covered, with their size and shape visible beneath the described clothing";
    assert.equal(production.invoke("bodyStatPhraseFromNumber","chest",13,{gender:"female"},{chestCovered:true}),tables.find(table=>table.slot==="chest" && table.presentation==="female").phrases[13]+coveredSuffix,"Covered-chest projection changed;review its documented rule.");
    assert.equal(production.invoke("bodyStatPhraseFromNumber","chest",13,{gender:"trans male"}),tables.find(table=>table.slot==="chest" && table.presentation==="male").phrases[13],"Presentation routing changed;review its documented rule.");
    return {keys,defaults,tables,coveredSuffix};
}

function renderReference(scales) {
    const {keys,defaults,tables,coveredSuffix}=scales;
    const cell=value=>String(value).replaceAll("|","\\|");
    const sections=tables.map(({slot,presentation,phrases})=>{
        const suffix=presentation==="female" ? " (female / non-male presentation)" : presentation==="male" ? " (male presentation)" : "";
        return `## ${labels[slot]}${suffix}\n\nField: \`appearance.${slot}\`.\n\n| Value | Image-prompt phrase |\n|---:|---|\n${phrases.map((phrase,value)=>`| ${value} | ${cell(phrase)} |`).join("\n")}`;
    });
    return `# EmberAdventures 0–20 body-scale reference

These are the current effective normal EmberAdventures image-prompt phrases:
12 tables and 252 presets for the eleven numeric body fields. Chest has separate
male and female/non-male presentation tables. The tables describe what the
engine requests from the image model; they do not guarantee the resulting image.

## Selecting values

- Every body-scale field is required. Use an integer from 0 through 20 or a
  nonempty custom description when the scale does not fit. Preserve existing
  values when only the reference wording changes.
- Use each table directly. These are discrete presets, not percentages. Some
  build and chest scales decrease toward the minimum at 10 and increase with a
  different kind of shape afterward. A larger number is not universally larger.
- Select chest using the character's active presentation. Male and trans-male
  presentations use the male table; other presentations use the female/non-male
  table. The same stored number can describe different shapes after adaptation.
- Keep clothing, pose, personality and image style out of numeric body fields.
  Put only additional durable visual details in the appropriate remainder fields,
  without repeating traits already represented by the scales.
- When \`nonhuman_lower_body\` is true, all eleven scale fields remain required, but
  prompt projection omits \`hip_width\`, \`butt_build\`, \`lower_body_build\` and
  \`leg_length\`. Describe the replacement anatomy in
  \`extra_description_lower_body\`; clothing remains independent.
- The non-male chest phrase gains the exact suffix
  \`${coveredSuffix}\` when the prompt's structured \`chestCovered\` flag is true.
  Authors should not copy that clothing-state suffix into appearance data.
- Genital wording is emitted only for an applicable male/futanari presentation
  when the image includes an uncovered lower body and the request is not forced
  SFW. The required \`penis_size\` field remains present for every character.

## Prompt defaults

These are image-prompt defaults, not permission to fill missing required export
fields. Authored values still require canonical character validation.

| Field | Prompt default |
|---|---:|
${keys.map(key=>`| \`${key}\` | ${defaults[key]} |`).join("\n")}

${sections.join("\n\n")}

## Reference maintenance

The tables are generated from \`bodyStatPhraseFromNumber\`, including its chest
override, and \`BODY_STAT_DEFAULTS\` in a normal EmberAdventures checkout. They
replace the historical design/migration worksheet. This reference supplies no
automatic legacy conversion and must not be used to rewrite existing characters.

Maintainers can compare every preset with a local normal-game checkout:

\`\`\`text
node "<skill-folder>/scripts/sync-body-scales.cjs" "<normal-EA-checkout>"
\`\`\`

The default command only checks. Add \`--write\` to regenerate this reference;
it does not modify the game, stories or character files. Exercise the checker
and documented presentation/framing rules with:

\`\`\`text
node "<skill-folder>/scripts/test-body-scales.cjs" "<normal-EA-checkout>"
\`\`\`

After maintenance,
validate and rebuild the complete skill ZIP following SKILL.md.
`.trimEnd();
}

if (require.main===module) {
    try {
        const [engineArg,...flags]=process.argv.slice(2);
        if (!engineArg || flags.some(flag=>flag!=="--write") || flags.length>1)
            throw new Error('Usage: node sync-body-scales.cjs "<normal-EA-checkout>" [--write]');
        const reference=path.resolve(__dirname,"../references/body-scales-0-20.md");
        const expected=renderReference(productionScales(path.resolve(engineArg)));
        if (flags.includes("--write")) fs.writeFileSync(reference,expected,"utf8");
        else if (fs.readFileSync(reference,"utf8").replaceAll("\r\n","\n")!==expected)
            throw new Error("Body reference differs from the production helpers. Review the differences,then use --write to refresh the reference only.");
        console.log(`${flags.includes("--write") ? "Updated" : "Verified"} body reference:12 tables,252 presets;game and character files unchanged.`);
    }
    catch(error) {
        console.error(error.message);
        process.exitCode=1;
    }
}

module.exports={productionScales,renderReference};
