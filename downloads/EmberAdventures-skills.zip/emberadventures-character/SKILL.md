---
name: emberadventures-character
description: Authoritative base skill for EmberAdventures character definitions. Use directly for characters, preference intake, proposals, character JSON creation, review, repair, and library maintenance.
---

# EmberAdventures Character

Current skill version: `1.1.0`.

Target EmberAdventures Full. Use the Full schema and the creator's requested boundaries.

<!-- shared-intake:start -->
## Gather preferences before designing

Start by reading preferences and decisions the creator already provided. In a file-enabled workflow, use any existing private preferences available to you. In chat, use preferences the creator shared or attached. Ask for reusable tastes only where they would help this request. Keep reusable preferences separate from decisions about the current character or story.

Ask **one short question about one decision per message**, then wait for the answer. A question can offer a few plain-language options for that one decision. Never send a questionnaire, combine several settings into one question, or put a second question in a greeting or recap. Skip questions already answered, delegated, or safely inferred. If the creator skips a question or asks to proceed, use a reasonable default and continue.

When the creator's idea is unclear, begin with “What kind of character do you want to make?” or “What kind of story do you want to play?” for the requested skill. When the idea is clear, ask the next missing question that would change the design. For gender, ask “What gender is the character?” if you need their choice. Use their answer as the authored gender and handle alternate names, appearances, outfits, and engine fields yourself. Keep “presentation,” “non-male,” and field names out of questions and proposals.

Use ordinary questions such as “Should the player be able to romance this character?” only when the concept leaves that decision open. Usually character safety, outfit details, and other mechanics follow from the concept. Once you have enough to design, offer a brief concept or options for approval unless the creator asks you to proceed directly.
<!-- shared-intake:end -->

## Character definition and workflow

- A single export is an object containing character_definition. A batch is an object containing characters, an array of those same single-export wrappers. Use the exact case-sensitive keys listed below and one of the validated examples as your structural baseline.
- Give each record a stable unique ID and a believable name. Distinguish what they want, what they fear losing, a boundary, how they talk, and why a player would want to interact. Keep the catalog hook short. Role and appearance are visible facts. Personality and knowledge belong in their own fields. Use zero for relationship meters when strangers have no existing bond. The starting_* fields initialize play. Avoid runtime fields such as clothing at the definition root, current meters, timestamps from someone's save, or speaker and scene state.
- Use an exact whole-number age. For editable personality sliders such as boldness, use the scale required by the example or a specific custom description where allowed. Appearance uses the named 0–20 scales or a concise custom descriptor as allowed by the engine. Ten is the midpoint. Choose a coherent build and preserve the numeric values during conversion. Use the structured fields for anatomy and describe only additional visible features in prose.
- Set a primary and an alternate presentation when the character supports both. Supply a suitable name and outfit for each. Use gender tokens in story text for a character whose presentation can change. Keep the specified canonical presentation for a fixed character. Prefer structured hair color, length and texture, and the supported alternate hairstyle fields. Keep face and defining details recognizable across presentations.
- Specify a color for every visible clothing item, in both presentations. Choose clearly wearable outer clothes and footwear suitable for the environment. Use concise garment names, cut and fabric. Model layers using the exact clothing slots. Use null for an unused slot when filling a complete clothing object. Keep held objects in the hand fields. Define outfit IDs once and point the starting outfit fields to valid outfit IDs.
- Inventory items and stats must follow the canonical structures. Give the character possessions with a reason to exist. Keep appearance, props, clothes, and action separate for predictable images. Use the example's empty profile-image slots for generated or missing portraits. Include an actual image URL only when supplied or verified. Never invent an image URL, portrait ID or storage pointer.
- For Character Chat, write a single opening message with someone or something to react to. If there is an embedded playable story, use the story template object in chat_story_template. It contains its own opening, starting cast, and objectives. Character Chat and Play Story use different opening fields.
- For an animal definition use definition_type "animal", its own exact field set, a species, and physical_description. Use its species-appropriate behavior, communication and basic state. Leave humanoid appearance and wardrobe fields out of animal definitions.
- Story-embedded humanoids use the embedded-character field list instead of the standalone public catalog fields. Give them the same depth and a distinct role. Write all identities and references consistently.

## Validation

Before handing off, parse the exact resulting JSON and check required fields, permitted keys, legal enums, age, stable IDs, wardrobe references, wrapper shape, and edition. Validate in the target game where available, fix the source file, and validate again. Report which checks actually ran. A JSON parser checks syntax. A game import tests the actual content contract.

## Final Deterministic Validation

Before returning any character file, validate every entry in the batch using
this checklist. Do not call an entry finished until all checks pass:

1. The export wrapper is correct: one definition uses `character_definition`; a
   batch uses `characters[]` containing those wrappers; no app/type/export
   marker fields are present.
2. Required metadata exists and is valid: `source` is non-null, original
   entries use `"Original"`, `creation_tool` is factual rather than copied from
   an example, `genres` is approved where required, and `nsfw`, `loli`, and
   `can_die` are booleans.
3. `version` is numeric, `id` is stable, `name` is a proper display name, and
   `age` is an integer. Paired loli/adult entries are created only when
   requested or required by saved preferences, and both keep the same plain
   name without variant suffixes.
4. `boldness` is either a number from 1 to 10 or a non-empty descriptive
   string. Numeric `0` and all other out-of-range numeric values are rejected.
   Text boldness contains behavior only and does not contain score annotations.
5. `voice` is exactly `null`; no inferred or invented TTS metadata is present.
6. `created_at` and `updated_at` are real ISO 8601 timestamps. Existing
   `created_at` is preserved; `updated_at` changes only when the definition
   changes.
7. `outfits` is a non-empty array, every outfit has a unique stable `id` and
   coherent clothing object and explicit boolean `nsfw`, and
   `starting_outfit_id` matches an outfit id. SFW characters have SFW starting
   outfits and at least one SFW outfit in both presentations.
   Every outfit includes all intended visible and inner clothing layers.
   Check that every worn piece has an explicit color in its own description,
   including footwear, accessories and alternate presentations.
   Animal or natural-form outfits use concrete body-covering slot values and
   never use `{}` as placeholder clothing.
   `active_outfit_id` and other runtime clothing fields are absent.
8. Body fields contain body information only, `extra_description` contains
   only additional durable visuals, and no appearance fact is duplicated across
   body, hair/skin/eye, extra-description, personality, or clothing fields. The
   final assembled image prompt has been reviewed, and `extra_description` is a
   concise remainder rather than copied body-design prose or narrative text.
   Use optional `appearance.fallback_hair` only for traits that change with
   the alternate presentation. Check the canonical and alternate prompts.
   `nonhuman_lower_body` is a real boolean; when true,
   `extra_description_lower_body` contains a concise concrete replacement-body
   description and does not repeat numeric hips or legs. When false, the lower
   description is either blank or contains only a concrete humanoid lower-body
   detail that does not belong in another structured field.
9. All image metadata is blank exactly as shown in the canonical example:
   no image ids, URLs, prompts, styles, ownership, or invented image data is
   present; `default_profile_image.source` is `"none"`; `seed_enabled` is
   `true`; and both exported `negative` fields are present but empty.
10. Reusable definitions contain no current relationship/state/location,
   active outfit, current inventory, current known facts, scene membership,
   inspection, invite, death, or image-inclusion fields.
11. The entry contains no hidden process instructions, future unlock notes,
    story spoilers, or creator workflow text in player-visible character fields.
12. Batch names, ids, surnames, jobs, facts, personality wording, body language,
    inventory, and outfits are checked against the relevant existing library
    and against all entries in the current batch for accidental repetition.
13. The body-scale portion of `appearance` contains exactly the eleven current
    keys. Use a 0–20 integer or a nonempty custom description when the scale does not fit. The seven legacy appearance keys
    are absent. Chest uses the correct canonical presentation table. Replacement
    nonhuman lower bodies retain all required scale fields but suppress only the four
    inapplicable lower-body traits during prompt projection.
14. `creator`, `creator_id`, `short_description`, `creator_notes`,
    `character_version`, `consent_state`, and all other forbidden or obsolete
    fields are absent.
15. `starting_nsfw_known_facts` is an array, contains only adult-only durable
    facts, and duplicates none of `starting_known_facts`. Loli and under-18
    characters have no NSFW facts or outfits.
16. `catalog_hook` is a string containing an accurate, spoiler-free standalone
    catalog pitch, or `""`. It is omitted from story-embedded characters.
17. `default_image_background`, when present, is a trimmed nonempty string that
    describes only a suitable environment for solo standalone-character images.
    It is omitted rather than blank when unused, never overrides an explicit
    story/scene/location/user setting, and is omitted from story-embedded characters.
18. Optional Chat scenario fields use their exact shapes: `chat_story` and
    `chat_opening_message` are strings; `chat_starting_location` contains only
    `label`, `place`, and `activity`, which are either all nonblank or all blank.
    The opening never controls the player, the scenario is safe for player inspection,
    and the three fields describe one coherent starting situation.
    `chat_story_template` is either `null` or only a complete inner `storyTemplate`
    object created and validated under the EmberAdventures Story skill. It may coexist
    with the lightweight fields because Full Story and Just Chat are separate launch
    choices.

## Library Maintenance

When asked to maintain an original character library, support:

- metadata repair
- schema validation
- duplicate detection
- repetitive phrasing cleanup
- source/creation_tool/genres/nsfw/loli/can_die backfill
- style consistency
- species/variant balance review
- relationship/default-state consistency
- moving rejected entries aside without deleting unless asked


## Story Shop / Job Board Characters

When this skill is used to create characters for an EmberAdventures story shop, job
board, slave market, companion shop, auction, guild counter, or generated-job
role pool, create full normal character definitions. Do not output placeholder
labels such as `shopkeeper`, `worried baker`, `guild clerk`, or `slave girl`.
Owners, clients, witnesses, rivals, purchasable characters, and talkable shop
characters need real names, roles, personalities, speech styles, outfits,
appearance, and durable facts. The story skill should reference these
definitions from `future_cast`/NPC placement instead of duplicating them inside
shop item records.

For large-shop-stock mode, distinguish depth tiers:

- major/fixed story companions and important shop owners need full character
  depth, usually 6-10 concrete durable facts;
- ordinary purchasable/talkable stock characters should be compact but
  playable, usually 3-5 concrete durable facts plus a specific role, species or
  species/variant, appearance, outfit, personality, speech style, intended shop/stock
  category, unlock requirement when known, and a post-purchase or
  post-introduction hook;
- generated job-role NPCs such as recurring bakers, clerks, witnesses, or
  rivals can be shorter, but still need a proper name, real appearance, outfit,
  personality, speech style, and one reusable job-scene hook.

Do not make hundreds of stock characters main-character-length, but also do not
make them anonymous archetypes. They must be distinct enough that the player can
inspect, talk to, buy/recruit, remember, and use them in scenes.


## Canonical validation

Compare the export with this file's schema and examples, then test it through the game import UI when available.



## Reference authoring guide

# Character authoring guidance

## Metadata Fallbacks

Use the preference file and user answers first. If a required value is still
missing, ask before final export whenever practical. For an immediate export,
use only these safe fallbacks:

- `source`: `"Original"`
- `creation_tool`: the actual current tool/model/reasoning label, never a copied example label
- `genres`: `["fantasy"]` only when the concept is clearly broad fantasy and no more accurate approved set is known
- `nsfw`: `true` only when the character definition itself is inherently
  explicit/NSFW as stored or displayed; otherwise `false`
- `loli`: `false`
- `can_die`: `false`
- `voice`: `null`

For original characters, always use `source: "Original"`. Do not ask the user for a default original-character source label. Do not leave `source`, `creation_tool`, approved `genres`, `nsfw`, or `loli` null. `nsfw` and `loli` must be true or false. Do not emit or ask about `creator` or `creator_id`; EmberAdventures assigns both during import.

Set `voice` to `null`. Do not ask for or infer voice information.

Before final export, verify that saved `creation_tool` metadata describes the current tool/session. If it is missing, stale, or unverifiable, ask for the actual tool name, model number, and intelligence/reasoning level, then format the label as `{tool} {model} ({intelligence})` when intelligence is present. Do not silently use the skill's example or a label saved by a different model/session.

## NSFW And Consent

- Original spicy characters must be adults and physically adult.
- Never create sexualized minors or minor-coded characters.
- Original characters can be extremely sexually forward only when the user requests that style or preferences clearly set that as the default.
- If the user asks for submissive/slave-by-choice dynamics, write them as adult consensual fantasy dynamics.
- Do not assume every original character is a willing slave by choice unless preferences or the current request say so.

## Character Design Goals

- Make characters interesting, distinct, and suited to the user's current request.
- Make batches diverse in species/variant, profession, personality, boldness, silhouette, outfit, and tone unless preferences request a narrower set.
- Include mismatch/subversion only when preferences or the prompt support it.
- Avoid making every character a generic archetype.
- Avoid making every character overpowered unless preferences or the current request support it.
- Use the user's job/concept preferences from the preference file.
- Follow `jobs_and_concepts.role_style_preference` and the current request when deciding whether a role should be ordinary, fantastical, setting-grounded, origin-driven, or varied. Do not hardcode one style for all users.
- If the user rejects a role or concept, use their explanation to revise the relevant preference instead of assuming every rejection means the role was too ordinary or job-like.
- Follow `species_and_race.human_race_detail_preference`. When that preference requests human ethnicity/visual ancestry, include the resulting qualifier in the single `species` value; otherwise infer, vary, omit, or ask as recorded.

## Existing Characters

Default to not touching existing characters unless the user asks to edit existing ones.

When creating unique characters, check whether an existing character library file is available or mentioned. If it exists, ask whether the user wants it reviewed so new characters are somewhat similar and fit in, or more distinct from the existing cast.

For uniqueness checks, scan current and relevant existing characters for repeated:

- personality phrasing
- inventory items
- known facts
- body language
- relationship wording
- names and name patterns
- jobs/concepts
- species/variant mix
- outfits

## Names

Use preference-file naming guidance. In general, names should sound like names unless the user wants comedy or aggressive theme names.

For newly generated original characters, use a first and last name by default unless the user explicitly specifies a one-word/nonstandard name or the concept strongly requires a different naming convention.

Do not rename existing or user-specified characters unless the user asks for edits. Manual/pre-existing names are allowed to be one-word or nonstandard.

For batches, shop stock, auction stock, job-board NPCs, and story-world stock,
use unique surnames unless characters are intentionally related. Do not reuse
surnames from player options, examples, templates, skill references, or
unrelated existing characters. If two characters share a surname, record the
relationship clearly in durable known facts; otherwise rename one before final
export.

## Proposal Format

When proposing original character options before final JSON, follow
`proposal_preferences`. If it is unanswered, use this compact neutral fallback:

```text
Name (species/variant)
Description.
```

Include the species/variant parenthetical only when the saved preference requests it or when it materially helps compare concepts. For humans, obey `human_race_detail_preference` rather than always forcing an ethnicity into the proposal.

## Personality

Use preference-file personality and boldness guidance. Make personalities durable and specific, not just current mood or a list of sexual behaviors. Boldness, aggression, and dominant/submissive dynamics are independent: a character may be extremely bold and submissive, quietly dominant, gentle and forward, or aggressive but romantically reserved.

For spicy originals, combine sexuality with identity: job, flaws, humor, fears, habits, principles, contradictions, and social style.

Avoid repetitive boilerplate unless the user explicitly asks for a uniform batch.

## Practical Body And Appearance Guidance

The field contract above defines the schema. This section adds creation guidance
for producing clean image prompts and should not introduce alternate field shapes.

- Body slots describe body only. Do not put clothing, personality, mood, job,
  relationship, pose, or sexual behavior in physical slots.
- Use integer 0–20 presets when they fit. Each body-scale field also accepts a
  nonempty custom description for the trait it represents. Put anatomy outside
  the scale fields' scope in the appropriate remainder field.
- `personality_description` owns personality, behavior, motivations,
  temperament, and durable social style only. Do not put body shape, clothing,
  hair, skin, tattoos, scars, horns, pose, or image-prompt visual text in it.
- `speech_style` owns how the character usually talks. Write one concise
  sentence covering rhythm, formality, bluntness, warmth, guardedness, profanity,
  humor, flirtation, or similar dialogue behavior. Do not put current emotions,
  story instructions, TTS/voice metadata, or visual traits in it.
- `species` owns the complete biological/source identity, including meaningful subtype, subgroup, ethnicity, or lineage qualifiers. Do not create `race` or `ancestry` fields.
- Keep hair length, style, and color in their respective fields. Use
  `appearance.fallback_hair` for genuine differences in the alternate
  presentation and let unspecified traits inherit. Match the character's
  setting, features, and visual identity in both presentations.
- `extra_description` owns concrete durable visual traits that do not fit another specific appearance field, including horns, claws, fangs, ordinary tails, wings, extra eyes, unusual ears, nonhuman hands, tattoos, scars, birthmarks, body paint, facial markings, body markings, or a concise species trait that cannot be expressed by one numeric field. Replacement nonhuman lower-body anatomy belongs in `extra_description_lower_body`, not here. It is a remainder field, not a second full-body description.
- Do not duplicate specific appearance fields inside `appearance.extra_description`. The game converts the eleven numeric body fields plus hair, eyes, and skin into image-prompt text. Remove duplicated height, shoulder width, chest size, upper-body build, abdominal build, hip width, butt/glute build, thigh/calf build, arm length, leg length, penis size, hair, skin, and eyes. After final assembly, clean both remainder fields again; if nothing unique remains, use `""`.
- Do not use filler `extra_description` prose such as `Attractive adult [species] with a distinctive silhouette`, `expressive face`, `design cues tied to her work as...`, or `[species] traits shaped around...`. Those phrases are not concrete visual traits and usually duplicate `species`, `role`, body fields, or personality. Write only specific durable visuals that the other fields cannot express, such as scars, tattoos, horns, tails, wings, markings, ports, unusual anatomy, or similar.
- Do not paste prose-first body-design notes into `extra_description`, mention the character by name, use narrative pronouns, describe posture or current state, or explain a visual trait through profession/history. Prefer a compact list of visible leftovers. Before export, preview the fully assembled image prompt and reject `extra_description` if it repeats structured prompt phrases or reads like a character-sheet paragraph.
- For exaggerated features, use direct graphic description language when needed for accurate image output.
- Manual characters may use the full valid 0-20 range when appropriate.
- When the preference file contains a numeric or calibrated body range, final character body fields must explicitly match that scale. Do not rely on vague words like "huge", "massive", or "defined" if the user has calibrated the scale with concrete anchors.
- For clothed characters, use the normal female chest phrase and append `fully covered by the described clothing` when structured upper-body clothing is present. Do not invent a separate clothed scale.
- If the user supplies a concrete anchor such as "8 equals full watermelon-sized per breast", use it to calibrate and select the numeric value `8`. Keep the final mapped body field numeric. Put genuinely additional unmapped anatomy in `extra_description`; do not repeat the mapped trait there.
- If the user prefers impossible anatomy, state it directly and visually, e.g. "more visible ab blocks than realistic human anatomy", rather than just "defined abs".
- Keep species/variant anatomy consistent and visually useful.

### Image Prompt Projection Contract

Character files store facts; EmberAdventures decides what is visible for each image request. Authors must keep the structured facts complete rather than pre-composing a final image prompt.

- Profile portraits are framed from the top of the head through the waist. They include `shoulder_width`, `chest`, `upper_body_build`, `midsection_build`, `arm_length`, durable upper-body traits, and the visible upper clothing subset. They omit `hip_width`, `butt_build`, `lower_body_build`, `leg_length`, `extra_description_lower_body`, and genital-placement wording.
- Normal/full-body and group prompts include `extra_description_lower_body` whenever it is authored and the selected framing includes the lower body. It may describe lower-only markings or unusual humanoid details while `nonhuman_lower_body` is false, or the complete replacement anatomy while the flag is true.
- When `nonhuman_lower_body` is true and ordinary humanoid lower-body traits do not apply, image prompts suppress `hip_width`, `butt_build`, `lower_body_build`, and `leg_length`. Other body fields and all authored clothing remain available.
- Adult NSFW prompts may describe anatomy at the humanoid-to-nonhuman body junction. Male and futa/futanari characters use penis wording; every other character uses vulva/feminine-contour wording. Covered prompts describe only a covered contour. Genital placement never dictates softness, erection, or arousal state.
- Futa/futanari identity must be represented by `gender: "futa"` or `gender: "futanari"`. Tags, kink tags, sexual preferences, role, and appearance prose never establish or override gender. Do not place exact futa/futanari metadata on a non-futanari definition because import and publish validation reject that contradiction.
- Age wording is deterministic: known ages 18 or older are described as `{age}-year-old adult`; known younger ages use the numeric age without `adult`; missing/invalid ages default to adult unless the definition is explicitly minor-marked, in which case image generation is forced SFW.
- Clothing prompt order is: `hat`, `hair_accessory`, `face`, `ears`, `neck`, `shoulders`, `undershirt`, `shirt`, `over_shirt`, `coat`, `bra`, `back`, `hands`, `right_wrist`, `left_wrist`, `right_fingers`, `left_fingers`, `waist`, `belt_accessory`, `pants`, `skirt`, `legwear`, `underwear`, `socks`, `feet`, `other_accessory`. A bra is rendered as `with {bra} underneath` when an `undershirt`, `shirt`, `over_shirt`, or `coat` exists. Underwear is rendered the same way when `pants`, `skirt`, or `legwear` exists. These decisions use structured slot occupancy only, never clothing-word searches.

## Practical Clothing And Items Guidance

The field contract above defines the schema. This section adds workflow and
image-prompt guidance without adding alternate clothing fields.

- Clothing slots are precise item slots. Do not write ambiguous values like "adventuring outfit or maid clothes depending on scene."
- Create one or more precise outfit presets according to the request and saved wardrobe preferences. Never collapse multiple requested looks into one ambiguous outfit.
- Treat clothing like inventory/equipment slots.
  Characters created for Codex-version stories, story shops, auction stock, job
  boards, or generated NPC pools still use the same outfit system; do not move
  removable garments into prose fields just because the character is embedded
  inside a Codex story packet.
- During preference intake, ask what default outfit guidance should be saved for original characters. Offer options such as:
  - `0. You decide how many outfits based on the character`
  - `1. Make 1 normal outfit only unless I ask for more`
  - `2. Make 10 outfits for every character`
  - `3. Make a fixed wardrobe pattern, such as 1 normal, 1 formal, 1 casual, 1 sexy, 1 swimsuit, 1 cosplay, and variants`
  - `4. Free answer`
- Save the answer in `clothing_and_style.outfit_count_guidance`, `default_outfit_plan`, `normal_outfit_count`, `sexual_outfit_count`, `required_outfit_types`, `disallowed_outfit_types`, and `sexual_outfit_notes` as applicable. Use those saved preferences when the user asks for original characters unless the current request overrides them.
- Clothing slots are only for worn/removable items. Do not put tattoos, scars,
  birthmarks, body paint, facial markings, horns, claws, fangs, tails, wings,
  skin color, hair, eyes, body shape, anatomy, or other physical traits in any
  clothing slot, including `other_accessory`.
- If a physical feature is visible because of the outfit, keep the outfit in
  `clothing` and place the physical feature in `appearance.extra_description`.
- Fill every garment the character actually wears in each preset, including
  ordinary underlayers. A coat-only, dress-only, armor-only, or shirt-and-pants
  definition is incomplete when the intended character also wears underwear,
  a bra, undershirt, socks, or other removable layers. Omit a layer only when
  the character intentionally is not wearing it in that outfit.
- Use `starting_inventory`, `starting_known_facts`, and `starting_held_items` to make the character concrete and usable in game. Keep image metadata blank.
- Clothing slots strongly influence EmberAdventures image generation. Do not put lingerie-coded items in `bra`, `underwear`, `shirt`, `skirt`, or `back` unless the intended outfit is skimpy.
- If the user wants a dressed character, avoid values like `thong`, `bikini`, `bra top`, `skirt panels`, `plunging bodice`, or `cape over lingerie`. Use full garments such as tunic, robe, coat, dress, armor, pants, shorts, bodysuit, mantle, apron, or layered wraps.
- Negative image prompt wording cannot reliably overcome skimpy clothing slots. Fix the clothing slots first.
- For sexy-but-dressed characters, show appeal through fit, silhouette, material tension, posture, and selective exposure rather than defaulting to near-nudity.
- EmberAdventures's prompt builder checks top and bottom clothing coverage separately. If a one-piece garment covers the groin, hips, or legs, it must have a normal top/body slot entry and also a bottom-slot coverage entry. Otherwise the generated prompt may infer a naked bottom. Do not duplicate the whole garment description in both slots; put the main garment in the top/body slot, then use the bottom slot for concise lower-body coverage, length, or continuation information.
  - Fishnet teddy example: `shirt`: `"one-piece black fishnet teddy bodysuit"` and `underwear`: `"same teddy covers her groin with a high-cut panty shape"`.
  - Dress example: `shirt`: `"cute wine-red wrap dress with a soft neckline and short flutter sleeves"` and `skirt`: `"same wrap dress falls to mid-thigh"`.
  - Catsuit example: `shirt`: `"one-piece black latex catsuit with a front zipper"` and `pants`: `"same catsuit continues over her hips and legs to the ankles"`.

## Reference body scales 0 20

# EmberAdventures 0–20 body-scale reference

These are the current effective normal EmberAdventures image-prompt phrases:
12 tables and 252 presets for the eleven numeric body fields. Chest has separate
male and female/non-male presentation tables. The tables describe what the
engine requests from the image model; they do not guarantee the resulting image.

## Selecting values

- Every body-scale field is required. Use an integer from 0 through 20 or a
  nonempty custom description when the scale does not fit. Preserve existing
  values when only the reference wording changes.
- Use each table directly. These are discrete presets, not percentages. Some
  build and chest scales decrease toward the minimum at 10 and increase with a
  different kind of shape afterward. A larger number is not universally larger.
- Select chest using the character's active presentation. Male and trans-male
  presentations use the male table; other presentations use the female/non-male
  table. The same stored number can describe different shapes after adaptation.
- Keep clothing, pose, personality and image style out of numeric body fields.
  Put only additional durable visual details in the appropriate remainder fields,
  without repeating traits already represented by the scales.
- When `nonhuman_lower_body` is true, all eleven scale fields remain required, but
  prompt projection omits `hip_width`, `butt_build`, `lower_body_build` and
  `leg_length`. Describe the replacement anatomy in
  `extra_description_lower_body`; clothing remains independent.
- The non-male chest phrase gains the exact suffix
  `, fully covered, with their size and shape visible beneath the described clothing` when the prompt's structured `chestCovered` flag is true.
  Authors should not copy that clothing-state suffix into appearance data.
- Genital wording is emitted only for an applicable male/futanari presentation
  when the image includes an uncovered lower body and the request is not forced
  SFW. The required `penis_size` field remains present for every character.

## Prompt defaults

These are image-prompt defaults, not permission to fill missing required export
fields. Authored values still require canonical character validation.

| Field | Prompt default |
|---|---:|
| `height` | 10 |
| `shoulder_width` | 10 |
| `chest` | 13 |
| `upper_body_build` | 8 |
| `midsection_build` | 8 |
| `hip_width` | 10 |
| `butt_build` | 8 |
| `lower_body_build` | 8 |
| `arm_length` | 10 |
| `leg_length` | 10 |
| `penis_size` | 10 |

## Height

Field: `appearance.height`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurdly tiny adult figure, about 2'6" / 76 cm tall |
| 1 | extraordinarily tiny adult figure, about 3'0" / 91 cm tall |
| 2 | exceptionally tiny adult figure, about 3'6" / 107 cm tall |
| 3 | extremely short adult figure, about 4'0" / 122 cm tall |
| 4 | unusually short adult figure, about 4'4" / 132 cm tall |
| 5 | very short adult figure, about 4'8" / 142 cm tall |
| 6 | short adult figure, about 5'0" / 152 cm tall |
| 7 | moderately short adult figure, about 5'2" / 157 cm tall |
| 8 | slightly short adult figure, about 5'4" / 163 cm tall |
| 9 | a little below average height, about 5'6" / 168 cm tall |
| 10 | average adult height, about 5'8" / 173 cm tall |
| 11 | a little above average height, about 5'10" / 178 cm tall |
| 12 | moderately tall adult figure, about 6'0" / 183 cm tall |
| 13 | tall adult figure, about 6'3" / 191 cm tall |
| 14 | very tall adult figure, about 6'6" / 198 cm tall |
| 15 | exceptionally tall adult figure, about 7'0" / 213 cm tall |
| 16 | giant-scale adult figure, about 7'6" / 229 cm tall |
| 17 | extremely tall fantasy figure, about 8'0" / 244 cm tall |
| 18 | enormous fantasy figure, about 9'0" / 274 cm tall |
| 19 | colossal fantasy figure, about 10'6" / 320 cm tall |
| 20 | absurd extreme-fantasy height, about 12'0" / 366 cm tall |

## Shoulder width

Field: `appearance.shoulder_width`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-fantasy narrow shoulder span, outer-shoulder to outer-shoulder width about 0.75 head-widths |
| 1 | extraordinarily narrow shoulder span, outer-shoulder to outer-shoulder width about 1 head-width |
| 2 | exceptionally narrow shoulder span, outer-shoulder to outer-shoulder width about 1.25 head-widths |
| 3 | extremely narrow shoulder span, outer-shoulder to outer-shoulder width about 1.5 head-widths |
| 4 | unusually narrow shoulder span, outer-shoulder to outer-shoulder width about 1.75 head-widths |
| 5 | very narrow shoulder span, outer-shoulder to outer-shoulder width about 1.9 head-widths |
| 6 | narrow shoulder span, outer-shoulder to outer-shoulder width about 2.05 head-widths |
| 7 | narrow shoulder span, outer-shoulder to outer-shoulder width about 2.15 head-widths |
| 8 | slightly narrow shoulder span, outer-shoulder to outer-shoulder width about 2.25 head-widths |
| 9 | slightly narrow shoulder span, outer-shoulder to outer-shoulder width about 2.35 head-widths |
| 10 | average shoulder span, outer-shoulder to outer-shoulder width about 2.5 head-widths |
| 11 | slightly wide shoulder span, outer-shoulder to outer-shoulder width about 2.65 head-widths |
| 12 | slightly wide shoulder span, outer-shoulder to outer-shoulder width about 2.85 head-widths |
| 13 | wide shoulder span, outer-shoulder to outer-shoulder width about 3.05 head-widths |
| 14 | wide shoulder span, outer-shoulder to outer-shoulder width about 3.3 head-widths |
| 15 | very wide shoulder span, outer-shoulder to outer-shoulder width about 3.6 head-widths |
| 16 | very wide shoulder span, outer-shoulder to outer-shoulder width about 4 head-widths |
| 17 | extreme fantasy-wide shoulder span, outer-shoulder to outer-shoulder width about 4.5 head-widths |
| 18 | extreme fantasy-wide shoulder span, outer-shoulder to outer-shoulder width about 5.1 head-widths |
| 19 | colossal fantasy shoulder span, outer-shoulder to outer-shoulder width about 6 head-widths |
| 20 | absurd extreme-fantasy shoulder span, outer-shoulder to outer-shoulder width about 7 head-widths |

## Chest (female / non-male presentation)

Field: `appearance.chest`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-scale soft breasts, each about 12 head-volumes, extremely heavy and pancake-like, resting substantially on the ground |
| 1 | extraordinarily huge soft breasts, each about 10 head-volumes, with extreme sagging and the lower portion resting on the ground |
| 2 | gigantic soft breasts, each about 8 head-volumes, hanging to around ankle level |
| 3 | extremely huge soft breasts, each about 6 head-volumes, hanging to around mid-shin |
| 4 | massively oversized soft breasts, each about 4 head-volumes, hanging to around knee level |
| 5 | enormous soft heavy breasts, each about 3 head-volumes, hanging to around mid-thigh |
| 6 | very large soft breasts, each about 2 head-volumes, hanging to the upper thighs |
| 7 | large soft breasts, each about 1.25 head-volumes, severely sagging to around the hip crease / top of pelvis |
| 8 | moderately sized soft breasts, each about 0.75 head-volume, extremely sagging to the lower abdomen below the navel |
| 9 | small soft breasts, each about 0.25 head-volume, but extremely elongated/sagging into the upper abdomen |
| 10 | minimum-volume breasts, each under 0.1 head-volume, with minimal projection |
| 11 | small breasts, each about 0.2 head-volume, rounded and modestly projected |
| 12 | modest breasts, each about 0.35 head-volume, rounded with clear projection |
| 13 | medium breasts, each about 0.55 head-volume, full and rounded |
| 14 | large breasts, each about 0.8 head-volume, prominently projected |
| 15 | very large breasts, each about 1.1 head-volumes, full and strongly projected |
| 16 | huge breasts, each about 1.5 head-volumes, very full and strongly projected |
| 17 | enormous breasts, each about 2 head-volumes, strongly rounded and projected |
| 18 | massive breasts, each about 4 head-volumes, extremely full and oversized |
| 19 | colossal breasts, each about 7 head-volumes, overwhelmingly large |
| 20 | absurd extreme-scale breasts, each more than 10 head-volumes, enormous enough for the lowest curves to reach the ground |

## Chest (male presentation)

Field: `appearance.chest`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme fat-dominant chest with enormous soft adipose pectoral pads spread broadly across the chest wall and hanging as wide flattened folds rather than rounded breast-shaped mounds; soft pectoral-region projection about 2 head-lengths forward from the chest wall |
| 1 | extremely fat-dominant chest with massive soft adipose pectoral pads, very heavy downward chest-fat volume, and broad flattened folds; soft pectoral-region projection about 1.7 head-lengths forward from the chest wall |
| 2 | severely fat-dominant chest with very thick soft pectoral-region adipose pads and pronounced flattened chest-wall fullness; soft pectoral-region projection about 1.4 head-lengths forward from the chest wall |
| 3 | very fat-dominant chest with large soft adipose pads across the pectoral region and clearly heavy flattened chest volume; soft pectoral-region projection about 1.15 head-lengths forward from the chest wall |
| 4 | fat-dominant chest with thick soft adipose pectoral fullness, broad and flattened rather than breast-shaped; soft pectoral-region projection about 0.9 head-lengths forward from the chest wall |
| 5 | clearly soft/heavy chest with substantial adipose padding across the pectoral region and modest downward fold; soft pectoral-region projection about 0.7 head-lengths forward from the chest wall |
| 6 | mildly soft chest with noticeable adipose pectoral padding and limited visible pectoral definition; soft pectoral-region projection about 0.5 head-lengths forward from the chest wall |
| 7 | soft pectoral area with moderate chest-fat fullness; soft pectoral-region projection about 0.35 head-lengths forward from the chest wall |
| 8 | slightly soft pectoral area with a small amount of chest-fat padding; soft pectoral-region projection about 0.2 head-lengths forward from the chest wall |
| 9 | very lean nearly flat pectoral area with only trace soft tissue and almost no projection; soft pectoral-region projection about 0.1 head-lengths forward from the chest wall |
| 10 | minimum-volume point: completely flat chest with essentially no adipose padding and almost no pectoral projection, about 0 head-lengths beyond the chest wall |
| 11 | extremely lean chest with slight pectoral definition; pectoral muscle projects about 0.08 head-lengths forward from the chest wall |
| 12 | lean chest with modest pectoral shape; pectoral muscle projects about 0.12 head-lengths forward from the chest wall |
| 13 | fit chest with clear pectoral definition; pectoral muscle projects about 0.18 head-lengths forward from the chest wall |
| 14 | athletic pectorals with visible thickness and firm projection; pectoral muscle projects about 0.26 head-lengths forward from the chest wall |
| 15 | muscular pectorals with substantial thickness and forward projection; pectoral muscle projects about 0.36 head-lengths forward from the chest wall |
| 16 | very muscular pectorals with large thick muscle mass and strong projection; pectoral muscle projects about 0.5 head-lengths forward from the chest wall |
| 17 | bodybuilder pectorals with very large deeply defined muscle volume; pectoral muscle projects about 0.7 head-lengths forward from the chest wall |
| 18 | extreme bodybuilder pectorals with enormous hypertrophied thickness and rounded muscular projection; pectoral muscle projects about 0.95 head-lengths forward from the chest wall |
| 19 | hyper-muscular fantasy pectorals with colossal forward-projecting muscle mass; pectoral muscle projects about 1.35 head-lengths forward from the chest wall |
| 20 | absurd extreme-fantasy pectorals with gigantic impossible muscular projection and volume; pectoral muscle projects about 2 head-lengths forward from the chest wall |

## Upper-body build

Field: `appearance.upper_body_build`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd fat-volume extreme: enormously thick soft upper arms plus overwhelming soft tissue across the upper back and side torso with deep folds; upper-arm diameter about 2.2 head-widths |
| 1 | extreme fat-volume upper body: massive soft upper arms plus very heavy softness across the upper back and side torso; upper-arm diameter about 1.9 head-widths |
| 2 | severe fat-volume upper body: very thick soft upper arms plus substantial soft tissue across the upper back and side torso; upper-arm diameter about 1.6 head-widths |
| 3 | very heavy soft upper body with large soft upper arms and pronounced upper-back/side-torso fullness; upper-arm diameter about 1.4 head-widths |
| 4 | heavy soft upper body with thick upper arms and clearly substantial upper-back/side-torso soft-tissue volume; upper-arm diameter about 1.2 head-widths |
| 5 | clearly overweight upper-body build with full soft arms and noticeable extra upper-back/side-torso mass; upper-arm diameter about 1 head-width |
| 6 | mildly overweight upper-body build with soft upper arms and modest extra upper-back/side-torso fullness; upper-arm diameter about 0.85 head-widths |
| 7 | naturally soft upper-body build with moderate arm softness and ordinary upper-back/side-torso fullness; upper-arm diameter about 0.7 head-widths |
| 8 | average-soft upper-body build with ordinary arm mass and normal upper-back/side-torso soft-tissue volume; upper-arm diameter about 0.58 head-widths |
| 9 | very thin upper-body build with slender arms, very little fat, and very little muscle bulk through the upper arms/back; upper-arm diameter about 0.38 head-widths |
| 10 | absurd emaciated extreme: stick-thin arms with virtually no visible fat or muscle mass through the upper arms/back and sharply visible collarbone structure; upper-arm diameter about 0.22 head-widths |
| 11 | extremely thin upper-body build with very slim arms and only trace visible upper-arm/back muscle tone; upper-arm diameter about 0.3 head-widths |
| 12 | lean upper-body build with slim lightly toned arms and subtle upper-back definition; upper-arm diameter about 0.4 head-widths |
| 13 | fit upper-body build with clearly toned arms and upper-back definition but modest muscle bulk; upper-arm diameter about 0.52 head-widths |
| 14 | athletic upper-body build with visibly developed biceps, triceps, deltoids, traps, and upper-back muscles; upper-arm diameter about 0.65 head-widths |
| 15 | muscular upper-body build with substantial arm muscles and strongly developed deltoids, traps, and upper back; upper-arm diameter about 0.8 head-widths |
| 16 | very muscular upper-body build with large biceps/triceps and thick, strongly developed deltoids, traps, and upper-back musculature; upper-arm diameter about 1 head-width |
| 17 | bodybuilder upper-body build with very large deeply defined arms, deltoids, traps, and upper-back muscles; upper-arm diameter about 1.25 head-widths |
| 18 | extreme bodybuilder upper-body build with enormous rounded arm muscles and heavily hypertrophied deltoids, traps, and upper back; upper-arm diameter about 1.55 head-widths |
| 19 | hyper-muscular fantasy upper-body build with colossal bulging arm, deltoid, trap, and upper-back muscle mass; upper-arm diameter about 1.9 head-widths |
| 20 | absurd extreme-fantasy muscular upper-body build with gigantic impossible arm, deltoid, trap, and upper-back muscle mass; upper-arm diameter about 2.3 head-widths |

## Midsection build

Field: `appearance.midsection_build`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd fat-volume extreme: front abdominal projection about 3 head-lengths beyond the ribcage line; deep overhang reaching roughly knee level |
| 1 | fat/soft midsection: front abdominal projection about 2.5 head-lengths beyond the ribcage line; heavy overhang reaching around mid-thigh |
| 2 | fat/soft midsection: front abdominal projection about 2.1 head-lengths beyond the ribcage line; substantial overhang reaching the upper-mid thigh |
| 3 | fat/soft midsection: front abdominal projection about 1.7 head-lengths beyond the ribcage line; large overhang reaching the upper thigh |
| 4 | fat/soft midsection: front abdominal projection about 1.4 head-lengths beyond the ribcage line; pronounced overhang reaching around the groin/hip crease |
| 5 | fat/soft midsection: front abdominal projection about 1.1 head-lengths beyond the ribcage line; full rounded belly hanging several inches below the waistline |
| 6 | fat/soft midsection: front abdominal projection about 0.8 head-lengths beyond the ribcage line; soft belly with a modest overhang over the waistline |
| 7 | fat/soft midsection: front abdominal projection about 0.55 head-lengths beyond the ribcage line; rounded soft belly without a heavy overhang |
| 8 | fat/soft midsection: front abdominal projection about 0.3 head-lengths beyond the ribcage line; average-soft abdomen with mild natural fullness |
| 9 | fat/soft midsection: front abdominal projection about 0.12 head-lengths beyond the ribcage line; very thin nearly flat abdomen with very little body fat |
| 10 | absurd emaciated extreme: deeply sunken abdomen with virtually no fat or abdominal muscle, hollowed through the stomach, with faint ribs and minimal side definition |
| 11 | extremely lean flat abdomen with barely visible natural abdominal lines, a light central groove, very faint upper-ab structure, and minimal oblique definition |
| 12 | lean flat abdomen with a faint 2-pack, a subtle central groove, slight upper-ab definition, and light natural oblique lines |
| 13 | fit flat abdomen with a clear 2-pack, light horizontal separations, a visible central groove, gentle oblique definition, and the beginning of a subtle V-cut |
| 14 | athletic tight abdomen with a clear 4-pack, visible obliques, a defined central groove, moderate horizontal separations, and a noticeable V-cut / Adonis belt |
| 15 | muscular tight abdomen with a distinct 6-pack, strong obliques, clear horizontal and central grooves, a pronounced V-cut / Adonis belt, and light serratus definition beneath the ribs |
| 16 | very muscular abdomen with a deep 6-pack, thick sharply sculpted ab blocks, pronounced obliques, visible serratus muscles beneath the ribs, and a deep clearly carved V-cut |
| 17 | bodybuilder abdomen with a highly visible 8-pack, thick rounded ab blocks, deep central and horizontal grooves, prominent obliques, strong saw-toothed serratus definition, and a sharply defined V-cut |
| 18 | extreme bodybuilder abdomen with a thick sharply defined 8-pack, very deep abdominal segmentation, heavily developed obliques, pronounced serratus, a very deep V-cut / Adonis belt, and tightly contracted, sharply defined abdominal musculature |
| 19 | hyper-muscular fantasy abdomen with an exaggerated 10-pack formed by five clear rows of paired ab blocks, each block thick, dense, and sharply sculpted, with extremely deep grooves, colossal obliques, exaggerated serratus, and an extreme carved V-cut |
| 20 | absurd extreme-fantasy abdominal musculature with an impossible 12-pack formed by exactly six clearly visible horizontal rows of paired rectus-abdominis blocks, with no additional central ab rows; each row is thick, dense, rounded, and sharply sculpted, with extremely deep central and horizontal grooves; the lateral abdominal musculature follows the same overall row rhythm through thick diagonally angled oblique ridges that wrap outward from the central abs; exaggerated serratus muscles form sharp saw-toothed diagonal bands beneath the ribs and interlock visually with the upper abdominal rows; colossal external obliques create layered angled side-ab definition through the lower torso; an extremely deep sharply carved V-cut / Adonis belt frames the lower abdomen; the entire midsection has substantially more abdominal segmentation and muscular definition than anatomically possible |

## Hip width

Field: `appearance.hip_width`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-fantasy narrow hip span, lateral outer-hip width about 0.75 head-widths |
| 1 | extraordinarily narrow hip span, lateral outer-hip width about 1 head-width |
| 2 | exceptionally narrow hip span, lateral outer-hip width about 1.2 head-widths |
| 3 | extremely narrow hip span, lateral outer-hip width about 1.4 head-widths |
| 4 | unusually narrow hip span, lateral outer-hip width about 1.6 head-widths |
| 5 | very narrow hip span, lateral outer-hip width about 1.75 head-widths |
| 6 | narrow hip span, lateral outer-hip width about 1.85 head-widths |
| 7 | narrow hip span, lateral outer-hip width about 1.95 head-widths |
| 8 | slightly narrow hip span, lateral outer-hip width about 2.05 head-widths |
| 9 | slightly narrow hip span, lateral outer-hip width about 2.15 head-widths |
| 10 | average hip span, lateral outer-hip width about 2.25 head-widths |
| 11 | slightly wide hip span, lateral outer-hip width about 2.4 head-widths |
| 12 | slightly wide hip span, lateral outer-hip width about 2.6 head-widths |
| 13 | wide hip span, lateral outer-hip width about 2.8 head-widths |
| 14 | wide hip span, lateral outer-hip width about 3.05 head-widths |
| 15 | very wide hip span, lateral outer-hip width about 3.35 head-widths |
| 16 | very wide hip span, lateral outer-hip width about 3.7 head-widths |
| 17 | extreme fantasy-wide hip span, lateral outer-hip width about 4.1 head-widths |
| 18 | extreme fantasy-wide hip span, lateral outer-hip width about 4.6 head-widths |
| 19 | colossal fantasy hip span, lateral outer-hip width about 5.2 head-widths |
| 20 | absurd extreme-fantasy hip span, lateral outer-hip width about 6 head-widths |

## Butt / glute build

Field: `appearance.butt_build`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-fantasy soft/fat butt with enormously oversized plush glute volume, extreme roundness, and overwhelming glute projection; glute depth outward from the pelvis line about 3 head-lengths |
| 1 | extremely huge soft fat butt with massive plush glute volume and enormous rounded projection; glute depth outward from the pelvis line about 2.6 head-lengths |
| 2 | gigantic soft fat butt with very large plush glute volume and substantial rounded projection; glute depth outward from the pelvis line about 2.3 head-lengths |
| 3 | enormous soft fat butt with large rounded cheeks and pronounced glute volume; glute depth outward from the pelvis line about 2 head-lengths |
| 4 | very large soft fat butt with thick plush volume, strong roundness, and substantial projection; glute depth outward from the pelvis line about 1.7 head-lengths |
| 5 | large soft fat butt with noticeably full rounded cheeks and generous projection; glute depth outward from the pelvis line about 1.4 head-lengths |
| 6 | full soft butt with abundant natural fat volume and clear rounded projection; glute depth outward from the pelvis line about 1.15 head-lengths |
| 7 | nicely full soft butt with noticeable plush volume and natural roundness; glute depth outward from the pelvis line about 0.9 head-lengths |
| 8 | moderately full soft butt with gentle roundness and natural projection; glute depth outward from the pelvis line about 0.65 head-lengths |
| 9 | small lean butt with little soft volume and limited glute projection; glute depth outward from the pelvis line about 0.3 head-lengths |
| 10 | completely and totally flat butt with virtually no visible glute volume or outward projection; glute depth outward from the pelvis line is effectively 0 head-lengths |
| 11 | extremely small lean glutes with only slight muscular shape and minimal projection; glute depth outward from the pelvis line about 0.2 head-lengths |
| 12 | lean lightly toned glutes with modest muscular shape and little projection; glute depth outward from the pelvis line about 0.35 head-lengths |
| 13 | fit glutes with clear muscular shape and moderate projection; glute depth outward from the pelvis line about 0.5 head-lengths |
| 14 | athletic glutes with visibly developed muscle and firm rounded projection; glute depth outward from the pelvis line about 0.7 head-lengths |
| 15 | muscular glutes with substantial muscle volume, strong roundness, and pronounced projection; glute depth outward from the pelvis line about 0.9 head-lengths |
| 16 | very muscular glutes with large thick muscle mass and powerful rounded projection; glute depth outward from the pelvis line about 1.15 head-lengths |
| 17 | bodybuilder glutes with very large deeply developed muscular volume and strong separation; glute depth outward from the pelvis line about 1.45 head-lengths |
| 18 | extreme bodybuilder glutes with enormous hypertrophied muscle mass and exaggerated muscular projection; glute depth outward from the pelvis line about 1.8 head-lengths |
| 19 | hyper-muscular fantasy glutes with colossal bulging muscle volume and extreme projection; glute depth outward from the pelvis line about 2.3 head-lengths |
| 20 | absurd extreme-fantasy muscular glutes with gigantic impossible muscle volume and overwhelming glute projection; glute depth outward from the pelvis line about 3 head-lengths |

## Lower-body build

Field: `appearance.lower_body_build`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd fat-volume extreme with enormously thick soft thighs and calves, deep soft folds, and overwhelming lower-leg mass; thigh diameter about 3 head-widths and calf diameter about 2 head-widths |
| 1 | extreme fat-volume lower body with massive soft thighs and very thick soft calves; thigh diameter about 2.6 head-widths and calf diameter about 1.75 head-widths |
| 2 | severe fat-volume lower body with very large soft thighs and substantially thickened calves; thigh diameter about 2.3 head-widths and calf diameter about 1.55 head-widths |
| 3 | very heavy soft lower body with large thighs and noticeably heavy calves; thigh diameter about 2 head-widths and calf diameter about 1.35 head-widths |
| 4 | heavy soft lower body with clearly thick thighs and substantial calf softness; thigh diameter about 1.7 head-widths and calf diameter about 1.15 head-widths |
| 5 | clearly overweight lower body with full thighs and calves but still reasonably proportional; thigh diameter about 1.45 head-widths and calf diameter about 1 head-width |
| 6 | mildly overweight lower body with soft full thighs and modestly thick calves; thigh diameter about 1.25 head-widths and calf diameter about 0.85 head-widths |
| 7 | naturally soft lower body with moderate thigh/calf fullness; thigh diameter about 1.1 head-widths and calf diameter about 0.72 head-widths |
| 8 | average-soft lower body with ordinary thigh and calf mass; thigh diameter about 0.95 head-widths and calf diameter about 0.6 head-widths |
| 9 | very thin lower body with slender thighs/calves and very little fat or muscle; thigh diameter about 0.6 head-widths and calf diameter about 0.4 head-widths |
| 10 | absurd emaciated extreme with stick-thin thighs/calves and virtually no visible fat or muscle mass; thigh diameter about 0.35 head-widths and calf diameter about 0.25 head-widths |
| 11 | extremely thin lower body with very slim thighs/calves and only trace muscle tone; thigh diameter about 0.45 head-widths and calf diameter about 0.3 head-widths |
| 12 | lean lower body with slim lightly toned thighs/calves; thigh diameter about 0.6 head-widths and calf diameter about 0.4 head-widths |
| 13 | fit lower body with clearly toned thighs/calves but modest muscle bulk; thigh diameter about 0.8 head-widths and calf diameter about 0.5 head-widths |
| 14 | athletic lower body with visibly developed quadriceps, hamstrings, and calves; thigh diameter about 1 head-width and calf diameter about 0.65 head-widths |
| 15 | muscular lower body with substantial quadriceps, hamstrings, and calf development; thigh diameter about 1.25 head-widths and calf diameter about 0.8 head-widths |
| 16 | very muscular lower body with large thighs and heavily developed calves; thigh diameter about 1.5 head-widths and calf diameter about 1 head-width |
| 17 | bodybuilder lower body with very large deeply defined quadriceps, hamstrings, and calves; thigh diameter about 1.8 head-widths and calf diameter about 1.2 head-widths |
| 18 | extreme bodybuilder lower body with enormous rounded quadriceps/hamstrings and heavily hypertrophied calves; thigh diameter about 2.15 head-widths and calf diameter about 1.45 head-widths |
| 19 | hyper-muscular fantasy lower body with colossal bulging thigh and calf muscles; thigh diameter about 2.55 head-widths and calf diameter about 1.7 head-widths |
| 20 | absurd extreme-fantasy muscular lower body with gigantic impossible quadriceps, hamstrings, and calves; thigh diameter about 3 head-widths and calf diameter about 2 head-widths |

## Arm length

Field: `appearance.arm_length`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-fantasy short arms: shoulder-to-fingertip length about 15% of standing height; each hand is visibly longer than the entire shortened shoulder-to-wrist arm |
| 1 | impossibly short arms: shoulder-to-fingertip length about 18% of standing height; each hand is about as long as the shortened shoulder-to-wrist arm |
| 2 | extraordinarily short arms: shoulder-to-fingertip length about 22% of standing height |
| 3 | extremely short arms: shoulder-to-fingertip length about 26% of standing height |
| 4 | exceptionally short arms: shoulder-to-fingertip length about 29% of standing height |
| 5 | very short arms: shoulder-to-fingertip length about 32% of standing height |
| 6 | short arms: shoulder-to-fingertip length about 34% of standing height |
| 7 | moderately short arms: shoulder-to-fingertip length about 36% of standing height |
| 8 | slightly short arms: shoulder-to-fingertip length about 37% of standing height |
| 9 | a little below-average arm length: shoulder-to-fingertip length about 39% of standing height |
| 10 | average proportional arm length: shoulder-to-fingertip length about 41% of standing height |
| 11 | a little above-average arm length: shoulder-to-fingertip length about 43% of standing height |
| 12 | slightly long arms: shoulder-to-fingertip length about 45% of standing height |
| 13 | long arms: shoulder-to-fingertip length about 48% of standing height |
| 14 | noticeably long arms: shoulder-to-fingertip length about 52% of standing height |
| 15 | very long arms: shoulder-to-fingertip length about 57% of standing height |
| 16 | exceptionally long arms: shoulder-to-fingertip length about 63% of standing height |
| 17 | extremely long arms: shoulder-to-fingertip length about 70% of standing height |
| 18 | exaggerated fantasy-long arms: shoulder-to-fingertip length about 80% of standing height |
| 19 | extreme fantasy-long arms: shoulder-to-fingertip length about 115% of standing height; the upper-arm segment itself is long enough that the elbows hang close to the lower shins when standing upright |
| 20 | absurd extreme-fantasy arm length: shoulder-to-fingertip length about 160% of standing height; the upper-arm segment alone is about 85% of standing height, allowing the elbows to touch the ground while standing upright, with forearms and hands extending far beyond them |

## Leg length

Field: `appearance.leg_length`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | absurd extreme-fantasy short legs; hip-to-ground leg length about 18% of total standing height, with the hips only a short distance above the ankles |
| 1 | impossibly short legs; hip-to-ground leg length about 22% of total standing height |
| 2 | extraordinarily short legs; hip-to-ground leg length about 27% of total standing height |
| 3 | extremely short legs; hip-to-ground leg length about 32% of total standing height |
| 4 | exceptionally short legs; hip-to-ground leg length about 36% of total standing height |
| 5 | very short legs; hip-to-ground leg length about 40% of total standing height |
| 6 | short legs; hip-to-ground leg length about 43% of total standing height |
| 7 | short legs; hip-to-ground leg length about 46% of total standing height |
| 8 | slightly short legs; hip-to-ground leg length about 48% of total standing height |
| 9 | slightly short legs; hip-to-ground leg length about 50% of total standing height |
| 10 | average proportional leg length; hip-to-ground leg length about 52% of total standing height |
| 11 | slightly long legs; hip-to-ground leg length about 54% of total standing height |
| 12 | slightly long legs; hip-to-ground leg length about 56% of total standing height |
| 13 | long legs; hip-to-ground leg length about 59% of total standing height |
| 14 | long legs; hip-to-ground leg length about 62% of total standing height |
| 15 | very long legs; hip-to-ground leg length about 66% of total standing height |
| 16 | very long legs; hip-to-ground leg length about 70% of total standing height |
| 17 | extreme fantasy-long legs; hip-to-ground leg length about 75% of total standing height |
| 18 | extreme fantasy-long legs; hip-to-ground leg length about 82% of total standing height, with leg length overwhelmingly dominating torso length |
| 19 | colossal fantasy-long legs; hip-to-ground leg length about 88% of total standing height, leaving only a very small upper-body portion above the hips |
| 20 | absurd extreme-fantasy leg length; hip-to-ground leg length about 94% of total standing height, leaving a proportionally tiny torso above the extremely high-set hips |

## Penis size

Field: `appearance.penis_size`.

| Value | Image-prompt phrase |
|---:|---|
| 0 | almost no external projection penis, about 0.25 in / 0.6 cm long and about 0.25 in / 0.6 cm wide |
| 1 | extremely tiny penis, about 0.5 in / 1.3 cm long and about 0.35 in / 0.9 cm wide |
| 2 | extraordinarily tiny penis, about 0.75 in / 1.9 cm long and about 0.45 in / 1.1 cm wide |
| 3 | micropenis-scale penis, about 1 in / 2.5 cm long and about 0.6 in / 1.5 cm wide |
| 4 | exceptionally tiny penis, about 1.5 in / 3.8 cm long and about 0.7 in / 1.8 cm wide |
| 5 | tiny penis, about 2 in / 5.1 cm long and about 0.8 in / 2.0 cm wide |
| 6 | very small penis, about 2.5 in / 6.4 cm long and about 0.9 in / 2.3 cm wide |
| 7 | very small penis, about 3 in / 7.6 cm long and about 1 in / 2.5 cm wide |
| 8 | small penis, about 4.5 in / 11.4 cm long and about 1.2 in / 3.0 cm wide |
| 9 | moderately small penis, about 5.25 in / 13.3 cm long and about 1.3 in / 3.3 cm wide |
| 10 | average-sized penis, about 6 in / 15.2 cm long and about 1.35 in / 3.4 cm wide |
| 11 | large penis, about 7 in / 17.8 cm long and about 1.5 in / 3.8 cm wide |
| 12 | very large penis, about 8 in / 20.3 cm long and about 1.6 in / 4.1 cm wide |
| 13 | extremely large and thick penis, about 9 in / 22.9 cm long and about 1.75 in / 4.4 cm wide |
| 14 | massive fantasy-sized penis, about 12 in / 30.5 cm long and about 2 in / 5.1 cm wide |
| 15 | enormous fantasy-sized penis, about 15 in / 38.1 cm long and about 2.4 in / 6.1 cm wide |
| 16 | gigantic fantasy-sized penis, about 18 in / 45.7 cm long and about 2.75 in / 7.0 cm wide |
| 17 | colossal fantasy-sized penis, about 24 in / 61.0 cm long and about 3.5 in / 8.9 cm wide |
| 18 | absurd extreme-fantasy-scale penis, about 36 in / 91.4 cm long and about 5 in / 12.7 cm wide |
| 19 | surreal extreme-fantasy-scale penis, about 60 in / 152.4 cm long and about 8 in / 20.3 cm wide |
| 20 | absolute extreme-fantasy maximum penis, about 96 in / 243.8 cm long and about 12 in / 30.5 cm wide |

## Reference maintenance

The tables are generated from `bodyStatPhraseFromNumber`, including its chest
override, and `BODY_STAT_DEFAULTS` in a normal EmberAdventures checkout. They
replace the historical design/migration worksheet. This reference supplies no
automatic legacy conversion and must not be used to rewrite existing characters.

The editable maintainer workspace owns the scale-checking utilities. After updating the tables, validate the inline references and rebuild the ZIP.

## Reference character contract

# Character contract

Use [reference-character.json](#reference-reference-character) for a complete validated export.
`field-sets.json` snapshots the current canonical field names; the game validator remains authoritative.

## Character Schema And Rules

This skill must be shareable as a standalone skill. Do not depend on any shared EmberAdventures reference files at runtime. The only external file this skill should require is the optional private preference file described in this skill.

Follow the preference-gathering rules at the start of this file. Offer a private preferences file only when the creator wants to save reusable preferences.

### Required Metadata

Every standalone character-library definition must include non-null `source`,
`creation_tool`, approved `genres`, boolean `nsfw`, boolean `loli`, and boolean
`can_die`. Original characters use `source: "Original"`; `creation_tool` records
the actual tool/model/reasoning label. `genres` belongs on standalone library
exports, not story-embedded definitions. `kink_tags` is optional searchable
metadata only for standalone library definitions; story-embedded definitions,
future-cast shells, and future-cast `full_character` definitions must omit it.
Use `can_die: false` by default for standalone definitions. The field
contract below is authoritative for meanings, allowed shapes, and runtime-field
exclusions. Do not emit `creator` or `creator_id`; EmberAdventures assigns
creator ownership during import. This is an internal maintenance rule: never
add creator fields back to this skill, never show them in examples, and never
ask the user for a creator name or alias during preference intake.

### Character Export Shape

The field contract below is authoritative. Keep the example and contract synchronized; there are no exception rules for older examples.

Use `character_definition` as the single immutable/default character object. Do
not use other top level fields. Story/runtime placement decides whether this
definition becomes a player, party character, future character, or inspected NPC.
For creating batches of characters, use a characters array as shown below, or make a separate file for each character. Do not add any other top level fields to the export. Ask the user if they want seperate files or 1 file with all characters in it when creating multiple at once. The game is capable of importing either, but for batches, it will import all of them, so a batch file should only be created if it's intended to import all of them into the game together.
```json
{
  "characters": [
    {
      "character_definition": {
        ...
      }
    }
  ]
}
```

Before final export, run a field-purpose and process-leakage pass. For every
field, ask what the field is for, how EmberAdventures uses/displays it, whether the
value serves that purpose, and whether it can be clearer or or match the intended use better.
Character information should never mention how the character will be or how it will change in
the future. Character definitions are meant to be a snapshot of a character in a specific
point in time. You should describe them exactly as they are at that moment, and you can also
include include the backstory/history of that character. The only future related information
that is allowed is future asperations, desires, and goals.

Before final export, run a character-depth pass. A final character definition
must be useful in EmberAdventures, not just technically valid. Characters should have
concrete `starting_known_facts` covering identity, role, personality under pressure,
combat/usefulness or social usefulness, household/social role when relevant, quirks/preferences,
and relationship dynamics.

Before final export, run the standalone release pass. Do not assume an
EmberAdventures maintainer or a later main thread will repair the character after
output. If schema fields are questionable, metadata is missing, durable facts
are generic, outfit slots are incomplete, or the character concept is underdeveloped,
fix it before final output or clearly ask the user for the missing decision.

If creating a batch of characters, or if there is a known library of existing characters, run a duplicate-name-and-id validation pass where you make sure that there are no exact matches for character names. If there is an exact name match, or if the newly created character has only a first name and it matches an existing first name, a new name should be chosen. If a last name matches an existing character, it should be changed unless the two characters sharing a last name (being related) is intended.

The timestamp strings in the example below are documentation placeholders
only. Replace them with real ISO 8601 timestamps in every final file.

```json
{
  "character_definition": {
    "version": 1,
    "id": "character-name",
    "name": "Character Name",
    "source": "Original",
    "creation_tool": "<Tool> <Model Number> (<Reasoning or Intelligence Level>)",
    "catalog_hook": "A concise, spoiler-free reason to start a game with this character.",
    "default_image_background": "a candlelit apothecary lined with dried herbs and glass bottles",
    "genres": ["fantasy"],
    "kink_tags": [],
    "nsfw": false,
    "loli": false,
    "can_die": false,
    "romanceable": true,
    "gender": "female",
    "fallback_name": "Fallback Name",
    "fallback_outfits": [
      {
        "id": "default",
        "name": "Default",
        "nsfw": false,
        "clothing": {
          "hat": "hat",
          "hair_accessory": "hair accessory",
          "face": "face",
          "ears": "ears",
          "neck": "neck",
          "shoulders": "shoulders",
          "bra": "bra",
          "undershirt": "undershirt",
          "shirt": "shirt",
          "over_shirt": "over shirt",
          "coat": "coat",
          "back": "back",
          "hands": "hands",
          "right_wrist": "right wrist",
          "left_wrist": "left wrist",
          "right_fingers": "right fingers",
          "left_fingers": "left fingers",
          "waist": "waist",
          "belt_accessory": "belt accessory",
          "underwear": "underwear",
          "pants": "pants",
          "skirt": "skirt",
          "legwear": "legwear",
          "socks": "socks",
          "feet": "feet",
          "other_accessory": "other accessory"
        }
      }
    ],
    "fallback_starting_outfit_id": "default",
    "age": 25,
    "role": "Short role",
    "personality_description": "Durable personality and behavior summary.",
    "speech_style": "Concise durable dialogue style.",
    "boldness": 5,
    "starting_relationship_to_player": "none",
    "starting_trust": 0,
    "starting_attraction": 0,
    "starting_affection": 0,
    "starting_arousal": 0,
    "starting_state_of_mind": "",
    "starting_physical_state": "",
    "starting_pose": "",
    "appearance": {
      "species": "complete species identity, including meaningful subtype or qualifier",
      "height": 10,
      "shoulder_width": 10,
      "chest": 13,
      "upper_body_build": 8,
      "midsection_build": 8,
      "hip_width": 10,
      "butt_build": 8,
      "lower_body_build": 8,
      "arm_length": 10,
      "leg_length": 10,
      "penis_size": 10,
      "skin_color": "",
      "eye_color": "",
      "hair_color": "",
      "hair_length": "",
      "hair_type": "",
      "extra_description": "",
      "extra_description_lower_body": "",
      "nonhuman_lower_body": false
    },
    "outfits": [
      {
        "id": "default",
        "name": "Default",
        "nsfw": false,
        "clothing": {
          "hat": "hat",
          "hair_accessory": "hair accessory",
          "face": "face",
          "ears": "ears",
          "neck": "neck",
          "shoulders": "shoulders",
          "bra": "bra",
          "undershirt": "undershirt",
          "shirt": "shirt",
          "over_shirt": "over shirt",
          "coat": "coat",
          "back": "back",
          "hands": "hands",
          "right_wrist": "right wrist",
          "left_wrist": "left wrist",
          "right_fingers": "right fingers",
          "left_fingers": "left fingers",
          "waist": "waist",
          "belt_accessory": "belt accessory",
          "underwear": "underwear",
          "pants": "pants",
          "skirt": "skirt",
          "legwear": "legwear",
          "socks": "socks",
          "feet": "feet",
          "other_accessory": "other accessory"
        }
      }
    ],
    "starting_outfit_id": "default",
    "starting_held_items": {
      "right_hand": null,
      "left_hand": null
    },
    "starting_inventory": [],
    "starting_known_facts": [],
    "starting_nsfw_known_facts": [],
    "chat_story": "",
    "chat_opening_message": "",
    "chat_starting_location": {
      "label": "",
      "place": "",
      "activity": ""
    },
    "chat_story_template": null,
    "default_seed": 0,
    "image_prompt_config": {
      "seed_enabled": true,
      "seed": 0,
      "style": "",
      "profile_style": "",
      "negative": "",
      "negative_prompt": ""
    },
    "default_profile_image": {
      "url": "",
      "local_image_id": "",
      "source": "none",
      "seed": null,
      "prompt": "",
      "negative_prompt": "",
      "note": "",
      "male": false
    },
    "profile_image_presentations": {
      "male": {
        "url": "",
        "local_image_id": "",
        "source": "none",
        "seed": null,
        "prompt": "",
        "negative_prompt": "",
        "note": "",
        "male": true
      },
      "non_male": {
        "url": "",
        "local_image_id": "",
        "source": "none",
        "seed": null,
        "prompt": "",
        "negative_prompt": "",
        "note": "",
        "male": false
      }
    },
    "profile_images": {
      "active_image_id": "",
      "image_ids": []
    },
    "images": {
      "active_image_id": "",
      "image_ids": []
    },
    "voice": null,
    "created_at": "<actual ISO 8601 creation timestamp>",
    "updated_at": "<actual ISO 8601 update timestamp>"
  }
}
```

Keep all image and voice fields blank exactly as shown. The application supplies image
styles, generated image records, ownership ids, voices, and active-image metadata after
import. All of these top level fields should be exactly the same as the example above:
"default_seed",
"image_prompt_config",
"default_profile_image",
"profile_image_presentations",
"profile_images",
"images",
"voice"

### Character Definition Field Contract

Use this contract when creating EmberAdventures character definitions. Do not add
fields that are absent from the example and field rules. Standalone library
characters and characters embedded in stories intentionally use different
subsets of this contract.

#### Standalone And Story-Embedded Fields

The complete export example is a standalone character-library definition.
Standalone definitions own their public discovery metadata and optional
character-launcher experiences.

The following fields are standalone-only and must be omitted from every
story-embedded character definition, including players, party characters, NPC
shells and `full_character` definitions, and future-cast shells and
`full_character` definitions:

- `catalog_hook`
- `default_image_background`
- `genres`
- `kink_tags`
- `chat_story`
- `chat_opening_message`
- `chat_starting_location`
- `chat_story_template`

Story-embedded characters inherit discovery and classification from the story.
A story uses its own title, description, opening, state, and objectives; it
never carries a nested standalone Chat launcher on one of its characters. This
also prevents recursive stories inside stories. All other approved authored
character fields follow their normal rules in both contexts unless a later rule
explicitly says otherwise. Runtime-only fields remain forbidden in both.

#### Field Purpose And Process-Leakage Standard

For every character field, ask:

1. What is this field for in EmberAdventures?
2. How does EmberAdventures use or display it?
3. Does this value serve that purpose?
4. Could it be shorter, clearer, or less like process text?

Do not copy instructions meant for Codex/the character creator into character
fields. Examples of forbidden process leakage:

- `source-faithful`, `current app compatible`, `clean export`;
- `should not appear before X`, `introduce after objective Y`;
- `future party member`, `will become romance partner`, `unlock reward`;
- `do not spoil`, `hide this from the player`, `use in prompt only`;
- field explanations such as `this is the active outfit` or `used by image gen`.

Apply those instructions through the story structure, future-cast conditions,
objective rewards, or hidden notes. Character fields themselves should describe
the character: identity, body, outfit presets, starting/default state, starting
inventory, and durable facts.

#### Field Rules

- `version`: Positive whole-number character definition version. Start new characters at `1` and increment it when making changes. The version number does not select the appearance schema; every character must contain the exact current required fields, including the 0-20 appearance fields, regardless of version.

- `id`: Stable character id string. Use a readable slug such as `"akane-fujimori"` or `"character-akane-fujimori"` according to the local file/library convention. Do not use random garbage when a readable stable id can be created from the character name.

- `name`: The character's exact proper name as shown to the player. For newly generated original characters, use a first and last name by default unless the user explicitly specified a one-word/nonstandard name or the setting strongly requires it. Preserve existing/manual names exactly. Do not append tags such as `(adult)`, `(loli)`, `(NPC)`, `(party)`, source names, roles, or version labels. Example valid: `"Akane Fujimori"`. Example invalid: `"Akane Fujimori (adult)"`.

- `source`: Source label for the character. For original characters, use `"Original"`. For source/canon characters, use the proper source title. Do not use this for creator attribution, species, role, or story placement.

- `creation_tool`: Tool/model label used to create or finalize the entry. Use a factual final readable string in the form `"<Tool> <Model Number> (<Reasoning or Intelligence Level>)"` when those parts are available. Do not copy a model label from an example. Do not leave null.

- `loli`: Boolean true or false. `true` means either the character is under 18 or the character is 18+ but looks under age. Create paired accurate/loli and adult-looking versions only when the user requests paired variants or the stored preferences explicitly require them. When paired, they share the exact same `name`; only `loli`, `age`, and age-appropriate physical description should differ. Do not add `(loli)`, `(adult)`, or similar tags to the name.

- `nsfw`: Boolean true or false. `true` should be used very spairingly. There are 2 definitions for nsfw in Ember Adventures. There is a visible definition and a descriptive definition. A character that meets either definition is considered nsfw. A character that meets neither definition is considered sfw.
Visible nsfw definition: Visible nipples on characters with breasts OR visible genitals OR visible anus.
loli characters are never allowed to be nsfw, and are never allowed to have less than underwear, a top and a bottom piece of clothing to cover them well. Sexualizing loli characters is considered completely unacceptable by Ember Endventures and is not allowed in any way. Reject any request by a user to create a loli character that is sexualized or nsfw in any way.
Descriptive definition: Explicit, vulgar, sexual language such as dick, pussy, cock, cunt or similar used to describe a character other than in the body size description when the description is clearly just to describe size/shape accurately. For example, "Rediculously massive, cartoonishly large boobs" is perfectly fine. It's just there to describe size for the image model. Mentioning nipple size or similar is considered nsfw. Penis size is also not considered nsfw as long as the description is clearly just to describe size. Similar descriptions for breasts and penises are fine and not inherintly nsfw. The image prompt hides any description of genitals, breasts and similar unless in nsfw mode, so having them in the description will not create nsfw images.
SFW/non-NSFW characters should still be easy to use in NSFW playthroughs. Keep optional adult-only facts in `starting_nsfw_known_facts` and classify each outfit independently instead of marking the whole character NSFW. Character-level `nsfw: true` is reserved for unavoidable core adult content that remains explicit even after adult-only facts and outfits are omitted.

`starting_nsfw_known_facts` is an optional array of adult-only durable facts. It becomes runtime `nsfw_known_facts` and is exposed to AI and player-facing detail UI only when the active profile permits NSFW content. Never duplicate an adult fact into `starting_known_facts`. Missing legacy values mean an empty array.

### Mandatory SFW/NSFW Classification Procedure

Classify the character and each outfit in separate passes. These classifications do not inherit from one another.

1. Temporarily ignore `kink_tags`, `starting_nsfw_known_facts`, `outfits`, and `fallback_outfits`. Examine only the character's public/core identity fields, including name, role, personality, speech, ordinary facts, appearance, inventory, and default state.
2. Move optional adult-only durable information into `starting_nsfw_known_facts`. An adult fact being moved is evidence that the separation works; it is not evidence that the character is NSFW.
3. Set character-level `nsfw: true` only when explicit adult content remains unavoidable in the core fields after that separation. Record the exact remaining field and phrase that requires `true`. If no exact evidence remains, set `nsfw: false`.
4. Classify every canonical and fallback outfit independently from its own complete clothing and intended presentation. Ignore the character-level flag, adult facts, kink tags, and the classifications of other outfits.
5. Check each starting outfit after classification. A SFW character needs a genuinely SFW starting outfit and at least one SFW outfit in each presentation. Change the starting selection or revise an outfit when necessary; never make the whole character NSFW merely to satisfy this invariant.

The following facts never make a character NSFW by themselves:

- the character has one or many NSFW outfits;
- the character has `starting_nsfw_known_facts` or sexual `kink_tags`;
- the character is flirtatious, seductive, sensual, romantic, attractive, confident, dominant, submissive, a succubus/incubus, or an adult romance option;
- the character has large breasts, a penis-size value, exaggerated body proportions, or other neutral body-shape data;
- the character can participate in NSFW play when an adult profile is active.

Character-level SFW examples include a flirtatious ember demon with optional adult power-dynamic facts, a seductive vampire with lingerie presets, a werewolf whose adult arousal response is isolated in `starting_nsfw_known_facts`, and a shapeshifter with optional voyeurism facts. Character-level NSFW examples include a character whose unavoidable public role or personality explicitly describes sex acts, whose ordinary public facts contain explicit genital or sex-act prose that cannot be separated without changing the concept, or whose core concept requires visible nipples, genitals, or anus outside an optional outfit. When a coherent SFW core remains after adult facts and outfits are hidden, the character is SFW.

Do not manufacture an adult fact merely to populate `starting_nsfw_known_facts`. An empty array is valid. Do not copy one generic adult fact across unrelated characters during a batch.

### Outfit Purpose Test And Borderline Examples

Judge the complete outfit, not isolated keywords. Ask: "Is this primarily clothing for travel, work, combat, ceremony, fashion, swimming, lounging, or sleeping, or is its primary purpose sexual display/fetish presentation?" Attractive styling does not change an ordinary outfit's purpose.

Normally SFW:

- fitted suits, uniforms, armor, workwear, travel clothes, formal gowns, fitted dresses, and fashionable fantasy clothing;
- an open-collar or partially open shirt, including a male bare upper chest;
- ordinary crop tops, miniskirts, high slits, low necklines, corset tops, thigh-high stockings, or garters when the complete outfit is fashion rather than sexual display;
- ordinary opaque bikinis, one-piece swimsuits, swim briefs, sports bras, gym clothing, pajamas, robes, and normal sleepwear;
- sheer sleeves, lace trim, mesh panels, or isolated cutouts that do not expose nipples, genitals, or anus and do not make sexual display the outfit's purpose;
- practical chest/body harnesses used as armor, climbing equipment, weapon support, ritual equipment, or fantasy adventuring gear.

Normally NSFW:

- lingerie intended as erotic display, fishnet teddies, fetishwear, bondage gear, rope harness sets, and sexual latex outfits;
- g-strings, c-strings, minimal chain sets, strategically placed ribbons, or garments designed to cover only nipples/genitals;
- transparent or sheer torso/lower-body garments that expose nipples, genitals, or anus;
- open garments with no meaningful underlayer when the presentation is designed around exposing breasts or genitals;
- hypersexualized cosplay, extreme sling dresses, micro garments, or cutout outfits whose primary purpose is showing as much body as possible;
- a decorative strap harness presented as intimate/fetishwear rather than functional equipment.

Borderline decisions:

- `bikini` is SFW by default; `micro bikini designed to expose as much as possible` is NSFW.
- `black corset dress with a low neckline` can be SFW; `open-cup corset exposing nipples` is NSFW.
- `sheer sleeves over an opaque bodice` is SFW; `transparent bodice exposing breasts` is NSFW.
- `leather battle harness supporting armor` is SFW; `minimal leather fetish harness with garters and no ordinary coverage` is NSFW.
- `nightshirt`, `pajamas`, or an ordinary opaque nightgown is SFW; an erotic negligÃ©e or lingerie sleep set is NSFW.
- A bra and underwear listed underneath ordinary outer clothing never make the outfit NSFW. An underwear-only outfit may be SFW when it is ordinary nonsexual changing-room, medical, athletic, or similar presentation; erotic lingerie presentation is NSFW.

Words such as `open`, `fitted`, `short`, `slit`, `sheer`, `corset`, `harness`, `bikini`, `stockings`, `garter`, `lounge`, `sleepwear`, `formal`, `armor`, and `battle` are not automatic classifications. Use the full clothing composition and purpose.

For equivalent canonical/fallback outfits, classifications should normally match because presentation gender does not change purpose. A mismatch requires a concrete clothing difference, such as one version being opaque and the other exposing anatomy. Never classify one presentation as NSFW merely because it contains a bra, skirt, breasts, or feminine construction.

For batch creation, migration, or review, inspect every character and outfit individually. Before finalizing, audit every `nsfw: true` value:

- Character `true`: identify the exact unavoidable core field and phrase.
- Outfit `true`: identify the exact clothing combination or presentation purpose.
- If the explanation is only "the character has adult content," "the outfit is revealing," or a single keyword, the classification is unsupported and must be reconsidered.
- If ordinary formalwear, armor, workwear, travel clothes, swimwear, or sleepwear are broadly becoming NSFW across the batch, stop and redo the outfit-purpose review instead of accepting the pattern.

Every outfit must include `nsfw: true` or `nsfw: false`. Mark an outfit NSFW when its purpose is sexual display, fetish presentation, or exposing as much as possible even if nipples, genitals, and anus remain narrowly covered. Ordinary attractive, fitted, fashionable, swimsuit, or revealing clothing can remain SFW when sexual display is not its primary purpose. A character with `nsfw: false` must have an SFW starting outfit and at least one SFW outfit in both canonical and fallback presentations. Missing outfit classification is a hard import error; never infer it from the character or another outfit.

Loli or under-18 characters must have `nsfw: false`, an empty `starting_nsfw_known_facts`, and only SFW outfits. Reject any request that violates this rule.

- `can_die`: Boolean internal plot armor. Always set this to false for standalone characters.
- Optional `shop_owner_category` records explicitly authored trade conduct. Use
  `good` for honest/fair trade, `bad` for deliberate trade misconduct, and
  `neutral` for mixed or self-interested conduct. Omit it when unassigned.
  The category is independent of personality warmth and relationship meters.
  Ordinary AI generation and state updates cannot assign it.


### Gender flexibility system
Every character is required to have 2 gender presentations. One male and one non-male (usually female). That means that each character has 2 sets of gender related fields. This is the full list of fields that have associated fallbacks for gender swapping:
name -> fallback_name
outfits -> fallback_outfits
starting_outfit_id -> fallback_starting_outfit_id
The character's gender is whatever default gender the character is supposed to be. The point being for someone who is attracted to all genders, the default genders will be shown. For someone who is only attracted to women, all characters will become women by women not changing and all others being gender swapped to female.
`romanceable` determines if the character's gender should match the player's preferred gender(s). There is also a setting that will force all characters to swap to the player's preferred gender(s) regardless of `romanceable`. That is why all characters must have both a male and non-male presentation. Non-binary genders are treated no different as female. trans-male is also considered male. All other genders are considered non-male. When choosing the default gender for a character, it is perfectly acceptable to use a non-binary gender, just make sure you understand what the fallback gender will be (male for all non-binary genders except trans-male). This means that if the character presents as male, it's generally best to use male or trans-male as the gender instead of something like non-binary to prevent confusion.

//TODO: Move to story skill
The goal is for there to be a 40% male, 40% female, 20% futanari split between the DEFAULT genders. This does not mean that you need to designed characters as the default gender. For instance, you can designed 100% of the cast as female, then at the end, swap the default gender and swapping the name, outfits, and starting outfit id with the fallback ones of 60% of the characters to match the desired split without changing anything else about the characters. The point of this is to allow gender flexibility for everyone and to give a good spread of genders for people that are attracted to multiple genders. Futanari characters have an extra field for fallback gender so that they swap to male or female if someone likes male and female but not futanari. To accomplish an even split of 50% male and 50% female when this happens, half of the futanari default gender characters should have a fallback gender of male and the other half female. When making a story, it is probably best to first ignore the 40/40/20 split and apply the split at the very end of story creation only as a gender swap, not modifying the character's identity, personality, appearance, or anything else. It is also perfectly acceptable to have a story ignore the split. Ask the story creator which they want, and explain what they are actually being asked to decide. They are deciding if the genders should be split evenly for people that like multiple genders to have a good balance without affecting the character's identity, personality, appearance, or anything else. The split is only for the default gender and any player who excludes genders would have the character's genders swapped. It is especially important to do this for games that have all 1 gender so that players who like multiple genders can have a spread of genders, not all just one. The default gender should never be swapped for standalone characters (including if the player has story characters duplicated as standalone characters) because the default gender is the character's identity. The split is only for stories, not individual characters. If you were to make a story with 100% women, then do the 40/40/20 split at the end and have all characters as standalone characters, all of the standalone characters should be women.

- `romanceable`: Required boolean. All standalone characters should have romanceable set to true.

//TODO: Move this part of the description to the story skill.
This field's name is slightly less descriptive than what it is used for. Ember Adventures requires all characters to be able to swap genders to whatever gender the player wants. This only affects the character's name, images, and outfits. Everything else stays the same. Male characters us the male presentation. All other genders use the female presentation. `romanceable` is used to determine if this character's gender should be swapped to a gender the player is attracted to. The reason all characters must have both a male and female presentation is that there is a setting to force all characters to swap to a perfered gender, not just the romanceable characters. So `romanceable` is which ones should always swap even if that setting is off. In general, if the character is intended to be a potential romantic/intimate/sexual partner, `romanceable` should be true. But you should probably have at least a few that aren't so that there are some of the other gender in the game so not every single character is one gender. It is used to determine if this character  Use `true` when the character is an intended potential romantic or sexual interest. Use `false` intentionally for plot-only officials, incidental contacts, antagonists, or other characters who should not normally adapt to the player's preferred romantic genders. Most recurring AI-created characters should be romanceable unless their story function gives a concrete reason not to be. Player characters are never gender-adapted from this field.

- `fallback_name`, `fallback_outfits`, and `fallback_starting_outfit_id`: Required atomic opposite male/non-male presentation group for the same character. See "Gender flexibility system" above. Prefer a fallback name that retains at least the first letter, and preferably the first two letters, of the canonical name so the character remains recognizable. A natural, setting-appropriate authored name is more important than preserving letters when that would make the result strained. Fallback outfits must be nonempty and remain recognizable equivalents: preserve each outfit's purpose, colors, equipment, status, and general visual identity while changing only gendered construction, underwear, fit, and similar presentation details unless a larger change is specifically justified. `fallback_starting_outfit_id` must reference one of those outfits. Personality, facts, relationships, and shared appearance stay consistent. Use `appearance.fallback_hair` for authored hair differences. Local import and public publishing both reject the character until this group is complete.

- `fallback_gender`: Only required on futanari characters. Use exactly `"male"` or `"female"` to decide which presentation is used when the player's selected preferences include male and female but not futanari. Omit it for non-futanari characters.

//TODO: Move this to story skill
Across a generated cast, split futanari fallback genders evenly so a 40% male / 40% female / 20% futanari base distribution becomes 50/50 when only male and female are preferred.

//TODO: Move this to story skill
When migrating an existing cast into gender-flexible definitions, preserve identity instead of rewriting the character. If an existing female character becomes canonical male, move her original name to `fallback_name`, her original outfits to `fallback_outfits`, and her original starting outfit id to `fallback_starting_outfit_id`; then author a natural canonical male name and equivalent male outfits. If she remains canonical female, preserve her current name and outfits and add the male fallback. If she becomes canonical futanari, preserve the current non-male name and outfits as canonical, add a male fallback name and equivalent outfit set, and distribute `fallback_gender` evenly across the futanari cast. When reversing the canonical presentation, move any presentation-specific hair with its presentation. Preserve personality, facts, role, stats, relationships, inventory, and shared appearance.

- `genres`: Approved broad genre/search tags for standalone character-library definitions. Approved values are `anime`, `fantasy`, `sci-fi`, `modern`, `historical`, `romance`, `adventure`, `action`, `comedy`, `drama`, `mystery`, `thriller`, `horror`, `dark`, `cozy`, `slice of life`, `superpower`, `isekai`, `school`, `workplace`, `political`, `war`, `crime`, `mythology`, `supernatural`, `post-apocalyptic`, `western`, `cyberpunk`, `steampunk`, and `harem`.

//TODO: Move this to story skill
Do not store `genres` on characters embedded inside story templates; embedded story characters inherit the story's `genres`.

- `kink_tags`: Required for nsfw characters. Optional for SFW characters. Some tags are not appropriate for SFW characters. Use the nsfw descriptions in the nsfw section. This is a closed vocabulary and is separate from player sexual preferences. Every value must exactly match one of the canonical lowercase strings below; these are the only valid options. Do not invent, combine, pluralize, reword, or add tags. Interpret every kink tag from the player's perspective: `dominance` means the player acts dominant, `submission` means the player acts submissive, `owning partners` means the player owns partners, and `being owned` means the player is owned. A character's behavior or preference alone does not justify the opposite player-perspective tag. Use only tags intrinsic to the interaction this standalone character definition supports, and use `[]` when none apply. Do not use vanilla kissing, oral sex, vaginal sex, ordinary romance, tone, body appearance, or broad genres as kink tags.
  - **Power Exchange:** `dominance`, `submission`, `switching`, `owning partners`, `being owned`, `serving partners`, `being served`, `disciplining partners`, `being disciplined`, `punishing partners`, `being punished`, `training partners`, `being trained`, `brat taming`, `being a brat`, `using partners freely`, `being freely used`, `taking control in cnc`, `being overpowered in cnc`, `hypnotizing partners`, `being hypnotized`, `mind controlling partners`, `being mind controlled`, `corrupting partners`, `being corrupted`, `financial domination`, `financial submission`.
  - **Bondage And Restraint:** `bondage`, `binding partners`, `being bound`, `collaring partners`, `wearing a collar`, `leashing partners`, `being leashed`, `gagging partners`, `being gagged`, `blindfolding partners`, `being blindfolded`, `sensory depriving partners`, `being sensory deprived`, `enforcing chastity`, `wearing chastity`, `denying partners orgasms`, `being denied orgasm`, `forcing partners to orgasm`, `being forced to orgasm`.
  - **Impact And Pain:** `spanking partners`, `being spanked`, `slapping partners`, `being slapped`, `whipping partners`, `being whipped`, `flogging partners`, `being flogged`, `paddling partners`, `being paddled`, `caning partners`, `being caned`, `pulling hair`, `having hair pulled`, `biting partners`, `being bitten`, `scratching partners`, `being scratched`, `choking partners`, `being choked`, `sadism`, `masochism`.
  - **Sensation And Edge Play:** `wax play`, `temperature play`, `electrostimulation`, `tickling`, `needle play`, `knife play`, `blood play`.
  - **Psychological And Verbal:** `humiliating partners`, `being humiliated`, `degrading partners`, `being degraded`, `objectifying partners`, `being objectified`, `writing on partners`, `being written on`, `feminizing partners`, `being feminized`, `bimbofying partners`, `being bimbofied`, `praising partners`, `being praised`, `making partners beg`, `being made to beg`, `worshipping partners`, `being worshipped`, `dirty talk`.
  - **Roleplay:** `authority figure roleplay`, `subordinate roleplay`, `medical roleplay`, `pet owner`, `being a pet`, `primal predator`, `primal prey`, `uniforms`, `crossdressing`.
  - **Exposure And Multiple Participants:** `exhibitionism`, `voyeurism`, `public sex`, `group sex`, `participating in gangbangs`, `being gangbanged`, `sharing partners`, `being shared`, `watching partners with others`, `being watched with others`, `cuckolding partners`, `being cuckolded`, `swinging`, `double penetration`.
  - **Sexual Activities:** `penetrating partners anally`, `receiving anal`, `masturbation`, `using toys on partners`, `partners using toys`, `fisting partners`, `being fisted`, `pegging partners`, `being pegged`, `rimming partners`, `being rimmed`, `sitting on partners' faces`, `being facesat`, `giving titjobs`, `receiving titjobs`, `giving thighjobs`, `receiving thighjobs`, `giving creampies`, `receiving creampies`, `cum play`, `squirting`, `lactation`, `breeding partners`, `being bred`, `impregnating partners`, `being impregnated`, `being rough with partners`, `partners being rough`, `clothed sex`.
  - **Fantasy:** `using tentacles`, `receiving tentacles`, `futanari`, `transforming partners`, `being transformed`, `oviposition giving`, `oviposition receiving`.
  - **Fantasy Partners:** `angels`, `demons`, `succubi and incubi`, `vampires`, `werewolves`, `demi-humans`, `anthropomorphic characters`, `monsters`, `aliens`, `androids`, `robots`, `elves`, `dark elves`, `orcs`, `goblins`, `dragons`, `fairies`, `merfolk`, `centaurs`, `minotaurs`, `lamias`, `harpies`, `arachne`, `ghosts`, `undead`, `shapeshifters`, `living dolls`, `golems`, `elementals`, `deities`.
  - **Materials And Clothing:** `latex`, `leather`, `lingerie`.
  - **Fluids And Functions:** `watersports`, `scat`, `spit`, `sweat`, `food play`.

//TODO: Move this to story skill
Do not store `kink_tags` on characters inside story files; embedded story characters inherit the story's `kink_tags`.

- `age`: Age in number of years as an integer. Do not use ranges, words, unknown, approximate text, or decimals. If the character is not marked as loli, it must be 18 or older, no exceptions. All characters under 18 must be marked as loli.

- `gender`: The default gender of the character. Some genders are recognized as exact strings. If the character is one of these recognized genders, write their gender exactly as it appears in this list: `"male"`, `"trans-male"`, `"trans male"`, `"futanari"`, `"futa"`, `"female"`. `"trans-male"` and `"trans male"` are treated identically. `"futanari"` and `"futa"` are treated identically. `"male"` and `"trans-male"` are the only male presenting genders. If the character is intended to be male presenting, you must use one of those two. If the character's gender falls outside the list, use any string that makes sense to describe the gender. It will be treated as female (non-male) by the game engine and it will use gemale presenting language such as breasts. `"futa"` and `"futanari"` identify futanari characters; they use the female mechanics except that they have a penis. Every other value, including female, non-binary, trans female, trans non-binary, and free-text identities, uses the female mechanics bucket. Do not infer gender from `kink_tags`, `tags`, `sexual_preferences`, appearance prose, role, or any other field. Import and publish validation reject exact futa/futanari metadata on a character whose `gender` is not futa or futanari. Do not use this field for voice names or relationship roles.

- `appearance.penis_size`: Required 0–20 integer or nonempty custom description on every character regardless of gender in case runtime adaptation changes the presentation to male or futanari. Do not set it to 0 merely because the canonical presentation is non-male. Runtime ignores it unless the active presentation is male or futanari. Use the locked mapping in [references/body-scales-0-20.md](#reference-body-scales-0-20).

- `role`: Required short occupational/social label, title, rank, or specialty. Maximum 40 characters, including spaces and punctuation. Do not put responsibilities or background here; put those in `starting_known_facts`. Examples: `"Guild Registrar"`, `"Healer"`, `"Queen"`, `"Assassin"`.

- `personality_description`: Durable personality and behavior summary. Describe how the character tends to think, act, flirt, fight, negotiate, or handle pressure. This is meant as permanent guidance for the player's personality, not temporary mood or state. This field is used by the ai to determine how this character acts and speaks.

- `speech_style`: Durable description of how the character speaks. Describe how the character usually speaks. Do not use this for TTS/voice metadata. This field is used by the ai to determine how this character speaks.

- `boldness`: Required integer from 1 through 10 or a nonempty custom behavioral description. Numeric values must be whole numbers in range; invalid authored values are rejected, not defaulted. Prefer the numeric scale when it fits: profile boldness adjustments apply to numbers. Custom descriptions are used directly and remain unchanged by profile adjustments. Do not include numeric score annotations in custom text or encode a number as a string. Use the same scale for every gender; gender adaptation never changes personality.
  - `1`: very reserved; almost never initiates romance or intimacy and waits for unmistakable mutual interest.
  - `2`: reserved; expresses interest subtly and waits for clear encouragement before initiating.
  - `3`: cautious; may initiate small compliments or mild flirting, then pauses to judge the response.
  - `4`: mildly forward; comfortably initiates light flirting or closeness when the context supports it.
  - `5`: balanced; can initiate direct interest, flirting, invitations, or welcomed physical closeness.
  - `6`: confident; readily initiates romantic tension, invitations, and physical closeness when attraction supports it.
  - `7`: very forward; states attraction directly and actively proposes escalation while watching for a clear response.
  - `8`: highly forward; readily initiates explicit flirting, intimate invitations, or consensual exposure when appropriate.
  - `9`: extremely forward; clearly proposes sexual escalation and communicates desire directly, while waiting for consent before meaningful escalation.
  - `10`: maximum initiative; openly states exactly what they want and proactively creates clear opportunities for consensual escalation, immediately respecting refusal or hesitation.

- `starting_relationship_to_player`: Starting relationship text copied into runtime when a new game/import begins. Examples: `"self"`, `"none"`, `"trusted companion"`, `"professional handler"`, `"rival"`, `"romantic partner"`.

Character, common title and pronoun references: When any text field needs to mention the character definition's own name, pronouns, or the gender specific titles listed below, use the ID-less references below instead of hardcoding the resulting word(s). The enclosing character definition supplies the identity, finalized name, and gender presentation. References may appear only in JSON values, never in JSON keys.

Reference types:

Names:
- Full name: `|[character]|`
  - Example result: `Akane Fujimori`
- First name: `|[character_first]|`
  - Example result: `Akane`

Pronouns:
- Subject pronoun: `|[character_subject_pronoun]|`
  - Male: `he`
  - Non-male: `she`
- Subject-pronoun shorthand: `|[character_pronoun]|`
  - Male: `he`
  - Non-male: `she`
- Object pronoun: `|[character_object_pronoun]|`
  - Male: `him`
  - Non-male: `her`
- Possessive determiner: `|[character_possessive_pronoun]|`
  - Male: `his`
  - Non-male: `her`
  - Use this before a noun, such as `his sword` or `her sword`.
- Independent possessive pronoun: `|[character_independent_possessive_pronoun]|`
  - Male: `his`
  - Non-male: `hers`
  - Use this without a following noun, such as `The sword is his` or `The sword is hers`.
- Reflexive pronoun: `|[character_reflexive_pronoun]|`
  - Male: `himself`
  - Non-male: `herself`

Gendered nouns and titles:
- Person term: `|[character_person_term]|`
  - Male: `man`
  - Non-male: `woman`
- Honorific: `|[character_honorific]|`
  - Male: `Mr.`
  - Non-male: `Ms.`
- Formal address: `|[character_formal_address]|`
  - Male: `sir`
  - Non-male: `ma'am`
- Monarch title: `|[character_monarch_title]|`
  - Male: `king`
  - Non-male: `queen`
- Royal-heir title: `|[character_royal_heir_title]|`
  - Male: `prince`
  - Non-male: `princess`
- Noble title: `|[character_noble_title]|`
  - Male: `lord`
  - Non-male: `lady`
- Spouse term: `|[character_spouse_term]|`
  - Male: `husband`
  - Non-male: `wife`
- Parent term: `|[character_parent_term]|`
  - Male: `father`
  - Non-male: `mother`
- Child term: `|[character_child_term]|`
  - Male: `son`
  - Non-male: `daughter`
- Sibling term: `|[character_sibling_term]|`
  - Male: `brother`
  - Non-male: `sister`
- Uncle/aunt term: `|[character_uncle_aunt_term]|`
  - Male: `uncle`
  - Non-male: `aunt`
- Nephew/niece term: `|[character_nephew_niece_term]|`
  - Male: `nephew`
  - Non-male: `niece`

Capitalization:
- References do not infer capitalization from their position in a sentence.
- Pronouns and gendered terms return lowercase text by default.
- Add `_cap` to the reference name when the resolved word must begin with a capital letter.
- Examples:
  - `|[character_subject_pronoun]|` becomes `he` or `she`.
  - `|[character_subject_pronoun_cap]|` becomes `He` or `She`.
  - `|[character_monarch_title]|` becomes `king` or `queen`.
  - `|[character_monarch_title_cap]|` becomes `King` or `Queen`.
- Full-name and first-name references already preserve the character name's proper capitalization and do not need `_cap`.
- Honorific references already return conventionally capitalized forms such as `Mr.` and `Ms.`.

Presentation-dependent text about another character must be self-contained. Use
`|[M|male text|female text]|`, where `M` or `F` is the default presentation,
the second part is the exact male text, and the third part is the exact
female/non-male text. Example:
`|[M|her brother Aurek Emberlash|her sister Aurelia Emberlash]|`.
If the player's preferences allow only one presentation, use that branch. If
both or neither are selected, use the declared default. The token must contain
exactly two internal `|` separators; both text branches must be non-empty and
must not contain `|`, `|[`, or `]|`.

Player references:
- Player full name: `|[player_name]|`
- Player first name: `|[player_first_name]|`
- Player subject pronoun: `|[player_subject_pronoun]|`
- Player subject-pronoun shorthand: `|[player_pronoun]|`
- Player object pronoun: `|[player_object_pronoun]|`
- Player possessive determiner: `|[player_possessive_pronoun]|`
- Player independent possessive pronoun: `|[player_independent_possessive_pronoun]|`
- Player reflexive pronoun: `|[player_reflexive_pronoun]|`

Player pronoun and gendered-term references follow the same `_cap` rule. For example, `|[player_subject_pronoun_cap]|` becomes `He` or `She`.

- `starting_trust`: Starting trust from 0 to 10. Use a number. `0` means no trust; `10` means complete trust at start.

- `starting_attraction`: Starting attraction from 0 to 10. Use a number. This is initial attraction toward the player/protagonist. It is not an attractiveness score.

- `starting_affection`: Starting affection from 0 to 10. Use a number. This is initial emotional warmth/bond, not current romance progress after play.

- `starting_arousal`: Starting arousal from 0 to 10 for characters/stories where arousal defaults are relevant. Use `null` or omit only for characters where arousal does not apply. Do not store post-play arousal here.

- `starting_state_of_mind`: Initial mood/mental state copied into runtime. Examples: `""`, `"curious"`, `"guarded"`, `"amused"`, `"panicked but focused"`. Used only for text generation.

- `starting_physical_state`: Initial physical condition copied into runtime. Examples: `""`, `"tired"`, `"wounded shoulder"`, `"covered in slime but unharmed"`. Do not use this for clothing or pose. Used for both image and text generation.

- `starting_pose`: Initial body posture or position. Examples: `"standing behind the counter"`, `"leaning against the bar"`, `"kneeling beside a broken crate"`, `"wrists bound together"`. Used for both image and text generation.

#### Appearance

Appearance and outfit fields primarily build image prompts. Describe each body
trait and garment precisely enough to help image generation, including concise
fit, coverage, or worn-appearance details when useful. Keep those descriptions
short, and do not duplicate the same visual information across appearance
fields, outfit slots, pose, or location. Leave a field blank rather than repeat
information that the prompt builder will already include elsewhere.

`appearance` describes the body and persistent visual traits only. Do not put clothing, current pose, current mood, relationship, inventory, or sexual behavior here.

- `species`: The complete concise species identity. Include the base species and every meaningful subtype, subgroup, visual qualifier, or heritage descriptor needed to identify the character, in one field. Examples: `"human"`, `"Black human"`, `"High Elf"`, `"Iron Coast Dwarf"`, and `"Cosmic Ghost"`. Character definitions have no separate race or ancestry fields; do not split one identity across multiple fields. Do not include gender in `species`.

- The body-scale portion of `appearance` contains exactly `height`, `shoulder_width`, `chest`, `upper_body_build`, `midsection_build`, `hip_width`, `butt_build`, `lower_body_build`, `arm_length`, `leg_length`, and `penis_size`. Every field requires an integer from 0 to 20 or a nonempty custom description. Use numeric presets when they fit. `chest` uses the presentation-specific male or non-male mapping; the other ten fields use one mapping for every presentation. Read [references/body-scales-0-20.md](#reference-body-scales-0-20) before selecting or validating body values.

- Legacy appearance fields `muscular`, `shoulders`, `stomach`, `hips`, `waist`, `legs`, and `arms` are invalid. Clothing slots with names such as `shoulders` and `waist` are separate garment keys and remain valid.

- `skin_color`, `eye_color`, `hair_color`, `hair_length`, and `hair_type` describe the character's default appearance. Keep length and color in their own fields, and describe texture, cut, or a signature hairstyle in `hair_type`. Use the outfit's `hair_accessory` slot for arrangements and accessories specific to that outfit.
- `appearance.fallback_hair` is optional and follows the same opposite male/non-male presentation as `fallback_name` and `fallback_outfits`. Its only allowed keys are `hair_length`, `hair_type`, and `hair_color`. Omitted or blank keys share the canonical value. Use `null` to clear a named trait on the alternate presentation. Omit the whole block when all hair traits are shared. For example, `"fallback_hair": { "hair_length": "ear length", "hair_type": "thick swept-back curls" }` changes the hairstyle and keeps the character's color. The game sends the active hair to narration and new image requests. Existing portraits keep their original artwork.
- `skin_color`: Bare color phrase only, for example `"warm medium-deep brown"`. Do not include the word "skin," sentences, cultural context, conditional wording, or unrelated appearance details.

- `extra_description`: Optional remainder field for concrete, durable visual traits that do not fit another appearance field. Examples include `"scar across left collarbone"`, `"transparent mint-green slime body"`, or `"filed canines"`, `"butterfly tatoo on right cheek"`. It is not a general physical-description field. Do not include temporary dirt, arousal, clothing damage, scene effects, personality, mood, pose, health, role, backstory, or explanations of how the character acquired a body type. Do not repeat details already represented by the other appearance fields. For details that are only on the lower body, do not include them here such as `"tatoo on right ancle"`. All lower body specific descriptions belong in `extra_description_lower_body`. Use `""` when there is no distinct extra description needed.

- `male_only_extra_description` and `non_male_only_extra_description`: Optional, narrow appearance-only fields. Missing or `null` means no additional prompt text. Use them only for an important visual feature that genuinely differs between male and non-male presentations and is not represented by another field, primarily optional facial hair for male presentation. Do not use them for a general character description; most appearance belongs in shared fields. Breasts, pecs/chest, genitals, and any other anatomy owned by structured fields are forbidden here. Do not put clothing, pose, scene state, personality, sexual behavior, or instructions in these fields. The engine selects only the field matching the active presentation.

- `nonhuman_lower_body`: Boolean. Use `true` only when ordinary humanoid hips, buttocks, thighs/calves, and legs are replaced by an integrated lower body such as a serpent tail, arachnid body, centaur body, or merfolk tail. Hooves, digitigrade humanoid legs, unusual feet, an ordinary tail, or extra limbs alongside otherwise humanoid legs do not qualify. All eleven numeric body fields remain required for structural validity, but prompt projection suppresses `hip_width`, `butt_build`, `lower_body_build`, and `leg_length` when those traits do not apply. Never invent ordinary legs or glutes to justify the stored numbers.

- `extra_description_lower_body`: Follow the same remainder-field rules as `extra_description`, but include only durable lower-body-specific information. Do not duplicate `extra_description`. When `nonhuman_lower_body` is false, use it only for lower-body markings or unusual details not represented elsewhere. When `nonhuman_lower_body` is true, it owns the complete replacement anatomy and must describe the integrated lower-body structure without referring to suppressed numeric fields. It appears in normal/full-body and group prompts but not profile portraits. Use `""` when no distinct lower-body detail is needed.

When `nonhuman_lower_body` is true, still author every garment the character actually wears. Clothing is independent from body-scale applicability and must not be deleted merely because the anatomy is nonhuman. Put each garment in the most reasonable existing clothing slot.

##### Extra Description Deduplication

This section aplies to infromation in both `extra_description` and `extra_description_lower_body`. Each time it talks about `extra_description`, it also applies to `extra_description_lower_body`.

`extra_description` is only for visual traits that are not already captured elsewhere. Numeric body fields are converted into image-prompt phrases by the game, so repeating those same ideas in `extra_description` creates duplicated prompts and over-emphasized bodies.

When writing `extra_description`:

- First choose/fill the specific appearance fields.
- Then write `extra_description` only for leftover durable visual information that no other field can express.
- Never paste a prose-first body-design summary or complete silhouette description into `extra_description`. Planning prose must be translated into the dedicated fields and then discarded.
- Compare each `extra_description` phrase against every specific appearance field.
- Remove or rewrite phrases that duplicate numeric body fields, including breast size, bust silhouette, abs/stomach definition, shoulder width, arm muscle, hip width, leg length, height, and overall muscularity.
- Remove or rewrite phrases that duplicate skin, eye, hair, or notable-feature fields.
- Remove filler phrases such as `Attractive adult [species] with a distinctive silhouette`, `expressive face`, `design cues tied to her work as...`, or `[species] traits shaped around...`. These are not concrete visual traits and usually duplicate `species`, `role`, or personality.
- Do not write narrative prose using the character's name or pronouns. Do not explain traits with phrases such as `built from years of carrying armor`, `giving her an athletic silhouette`, or `showing the life of a veteran`. Record only the visible result when it is not represented elsewhere.
- Prefer a compact comma-separated list or one short sentence. Length is not a substitute for specificity.
- Keep genuinely additional integrated traits, species anatomy, scars/features not listed elsewhere, unusual proportions that are not represented by one numeric field, or source-faithful visual notes that cannot fit a specific field.
- At the end of character creation, perform a final pass over the whole appearance object and clean `extra_description` again after all numeric/string fields are final. Then assemble or mentally project the complete image prompt and remove any duplicated or prose-heavy fragment before export.

Bad `extra_description` when the specific fields already contain those traits:

```text
Athletic, rugged, and curvy with very broad shoulders, large breasts, deeply defined abs, wide hips, strong thighs, and powerful mechanic arms.
```

If `shoulder_width`, `chest`, `upper_body_build`, `midsection_build`, `hip_width`, `butt_build`, `lower_body_build`, `arm_length`, and `leg_length` already encode those traits, keep only concrete unmapped traits, for example:

```text
Callused palms, old welding burns across both forearms, and a crescent scar below the left eye.
```

If nothing meaningful remains after deduplication, use `""` for `extra_description`.

#### Outfits And Starting Equipment

Outfits are immutable clothing presets stored on the character definition. When starting a game, the active outfit referenced by `starting_outfit_id` is copied into the character's runtime clothing.

- `outfits`: Array of outfit objects. Every character must have at least one outfit. A one-outfit character still needs `outfits: [{ "id": "default", "name": "Default", "clothing": { ... } }]` and `starting_outfit_id: "default"`. Do not replace `outfits` with a single `clothing` object. Do not leave it empty. Animal, monster, spirit, slime, natural-form, or otherwise unclothed characters still need at least one concrete outfit entry. If a character is intentionally naked, include only the underwear slots and have them empty strings, `""`. For non-human or demi-human characters, you can use natural clothing in slots such as a turtle shell for a turtle-human character if desired. Do not invent slots such as `full_body`; unsupported slots will throw an error. Never use `{}` as the clothing object.

- `outfits[]`: Each outfit object is a reusable preset. It should describe one coherent outfit the character can wear, such as travel clothes, a guild uniform, armor, sleepwear, formalwear, casual clothes, work clothes, battle gear, a disguise, or another kind of outfit. Do not create vague outfits like `"whatever fits the scene"` or `"armor or dress depending on mood"`. Do not use non-deterministic wording such as `"White or Black"` or `"could"` or `"roughly"` or `"maybe"`. If a character needs multiple looks, create separate concrete outfit entries. Outfits should include all layers that would actually be in the outfit, not just the outer layer. Underwear shuold be included unless the outfit is intended to not have underwear.

//---Left Off Here---//

- `outfits[].id`: Stable short string id for the outfit inside this character definition. Valid examples: `"default"`, `"travel"`, `"formal"`, `"combat"`, `"guild_uniform"`, `"sleepwear"`, `"festival"`, `"disguise"`. Use lowercase snake_case or another stable simple string. Do not use a full sentence, display-only prose, user-facing description, random generated id, or the outfit's entire clothing list. This id is used by `starting_outfit_id` and runtime outfit switching.

- `outfits[].name`: Player-facing outfit name. Valid examples: `"Default"`, `"Travel Gear"`, `"Guild Uniform"`, `"Formal Dress"`, `"Combat Armor"`, `"Sleepwear"`. This should be readable in UI. Do not put mechanical notes, AI instructions, source spoilers, or conditional logic in the name.

- `outfits[].nsfw`: Required boolean on every newly authored outfit. Use the outfit-purpose test above. This flag controls SFW UI visibility, AI context, equipping, shops, rewards, and image generation; it does not replace character-level `nsfw`.

- Character profile images cannot be uploaded by users. EmberAdventures generates them from the structured definition. Generation is NSFW for an inherently NSFW character; otherwise it follows the exact selected outfit's `nsfw` value. Generated image classification is immutable, and NSFW profile images are unavailable behind a local placeholder in SFW mode.

- `outfits[].clothing`: Object using EmberAdventures clothing slots. Values are item descriptions or `null`. This object should describe the full preset as clearly as possible. Use precise garments/equipment, not broad vibes. Good examples: `"faded navy linen travel shirt"`, `"black leather corset"`, `"silver-gray steel breastplate"`, `"brown knee-high buckle boots"`, `"silver serpent hairpin"`. Bad examples: `"sexy clothes"`, `"normal outfit"`, `"varies"`, `"whatever she wants"`, `"revealing but tasteful"`, `"armor or maid dress"`.

- Clothing slot keys should be stable equipment/body-wear slots. Canonical slots are `hat`, `hair_accessory`, `face`, `ears`, `neck`, `shoulders`, `bra`, `undershirt`, `shirt`, `over_shirt`, `coat`, `back`, `hands`, `right_wrist`, `left_wrist`, `right_fingers`, `left_fingers`, `waist`, `belt_accessory`, `underwear`, `pants`, `skirt`, `legwear`, `socks`, `feet`, and `other_accessory`. Use only slots that make sense. Do not author the legacy `hair` alias; use `hair_accessory`. A missing slot or `null` means nothing is defined for that outfit slot.
- State a specific color in the description of each worn item, including inner layers, footwear, jewelry, armor and other accessories. Use a recognizable color name, such as navy or charcoal gray, and record the colors of each item when a slot describes multiple pieces. Apply this to all standard and fallback outfits. Hairstyle-only descriptions and natural body coverings follow their own appearance guidance.
- `hair_accessory` is the head/hair presentation slot for hairstyles as well as hair accessories. It does not have to describe a clothing item or physical accessory: `"hair gathered into a loose braid"` is valid. Describe the hairstyle for this outfit unconditionally. Use `hat` for headwear; do not invent a `head`, `hair`, or `hairstyle` field.

- Every outfit must describe the complete set of clothing the character actually wears in that preset, including ordinary inner layers such as underwear, a bra, undershirt, socks, or other garments when appropriate. Do not define only the most visible outer garment. The runtime can remove clothing one piece at a time, so omitted inner layers can make a character become accidentally naked after removing one outer layer. Deliberately minimal, nude, or underwear-only outfits are valid only when that is the actual intended preset.

- Authored `bra` and `underwear` values are intentionally included in image prompts even beneath outer clothing. Do not omit them because they are mostly covered; models can correctly show realistic partial visibility such as a bra strap or waistband. When torso or lower outerwear exists, EmberAdventures lists the outer garments first and describes the corresponding bra or underwear as underneath. When no covering garment exists, the bra or underwear is described as visible clothing. SFW image generation may project a basic opaque bra or underwear only when the corresponding authored slot is empty, and that fallback never changes the saved outfit.

- Use `null` intentionally. `null` means this outfit does not define an item in that clothing slot. It does not mean a character permanently lost that item during play. Temporary removal during spicy scenes belongs to runtime clothing/inventory restore logic, not the outfit definition.

- Do not use outfit definitions to represent nudity caused by current scene action. If a character has an intentionally nude/default nude outfit, that can be a real outfit only when it is a deliberate reusable preset. Otherwise, clothing removed during a scene should be runtime state and should be restorable.

- Keep each outfit internally coherent. If the shirt is formal, the shoes, accessories, and lower-body clothing should usually match. Do not mix unrelated pieces unless the character concept intentionally calls for mismatched clothing and the description makes that clear.

- Keep outfits visually useful for image generation. Clothing fields strongly affect profile and scene images. Put the actual visible garments in the correct slots. Negative prompts cannot reliably fix bad clothing-slot values. If the character should be dressed, avoid accidentally lingerie-coded slots like `"thong"`, `"micro bikini"`, `"bra top"`, `"skirt panels"`, or `"cape over lingerie"` unless that is truly the intended outfit.

- For sexy-but-dressed characters, show appeal through fit, silhouette, material, tailoring, selective exposure, and posture-compatible clothing rather than defaulting to near-nudity. Example valid: `"fitted crimson corset over a white off-shoulder blouse"` plus `"high-waisted black leather breeches"`. Example invalid for a dressed tavern owner: `"black lace bra"` as the visible main top with no shirt unless intentionally dressed that way.

- Multiple outfits should be easy for the player or AI to swap between. If a character has multiple common contexts, add clear outfit presets such as `"default"`, `"combat"`, `"casual"`, `"formal"`, and `"sleepwear"`. Do not create many barely different outfits unless the differences matter. Do not create an outfit that depends on hidden future story knowledge unless the story prompt projection will keep it hidden until relevant.

- `starting_outfit_id`: Outfit id that should be active when the character is first created/imported. It must exactly match one `outfits[].id`. Do not use an outfit name here unless the name and id are identical. Do not leave it blank when `outfits` has entries. If there is only one outfit, `starting_outfit_id` should usually be `"default"`.

- Outfit definitions can be used by AI/runtime outfit swapping later, but the AI should change the active runtime outfit id or runtime clothing, not rewrite the immutable definition. If the AI invents a temporary outfit change in play, that belongs to runtime state unless the player explicitly saves it as a new reusable outfit.

- `starting_held_items`: Exactly `right_hand` and `left_hand`. Each value is a nonempty item description or `null`; an empty hand must use `null`, never an empty string. Do not put inventory lists here.

- `starting_inventory`: Array of starting inventory item strings or structured item objects if the item needs metadata. Use examples like `"Coin pouch"` or `{ "name": "Silver key", "note": "Opens the guild side door" }`. Do not store items gained during play here.

- `starting_known_facts`: Array of facts copied into mutable runtime `known_facts` when a new playthrough starts. Use concise strings. This is definition data, not chat history, current scene memory, or a field that changes during play. Avoid future spoilers unless the prompt projection system will hide them until relevant. For public/standalone character definitions, prefer facts safe for library/editor display; put story-only secrets in hidden story objectives, future cast notes, or private prompt projections instead.

- `starting_nsfw_known_facts`: Optional array of adult-only facts copied into runtime `nsfw_known_facts`. Keep it separate from `starting_known_facts`; EmberAdventures exposes it only when the active profile permits NSFW content. Use `[]` when there are no adult-only facts.

- `catalog_hook`: Optional concise, spoiler-free player-facing pitch for the
  standalone character in catalog and discovery UI. Explain why someone would
  want to start a game with this character, usually in one or two sentences.
  Keep it accurate without revealing hidden routes, twists, transformations, or
  endings. It is display metadata, not personality guidance, AI instructions,
  chat context, or a substitute for `chat_story` or
  `chat_story_template.description`. Use `""` when no distinct hook is needed.
  A SFW character's hook must itself be SFW. Omit it from every story-embedded
  character definition.

- `default_image_background`: Optional standalone-character image-setting
  guidance. When present, use a trimmed, nonempty string describing only the
  environment or background that normally suits this character, such as
  `"a candlelit apothecary lined with dried herbs and glass bottles"`. Do not
  put pose, camera, action, anatomy, clothing, or character-description prose
  in this field. EmberAdventures may use it for profile images and other solo
  standalone-character images when no story, scene, location, or explicit user
  setting is authoritative. It never overrides an explicit setting and does
  not apply to multi-character scene images. Omit the field when the normal
  genre-derived/default background is preferable; do not emit a blank string.
  Omit it from every story-embedded character definition.

#### Standalone Character Chat Scenario

Standalone characters may include a lightweight authored starting scenario for the
character library's Chat action. These fields are optional. Use blank strings and a
blank location object when no authored scenario is needed. They do not create
objectives, branches, rewards, shops, or other full-story systems.

- `chat_story`: Inspectable setup context for a new game started through this
  character's Chat action. Describe the immediate premise, relevant history, current
  situation, and durable constraints that the AI needs to continue the interaction.
  Keep it self-contained and focused on this character and the player. The player can
  inspect this text before starting and may replace it with their own opening guidance,
  so do not store secrets that must remain hidden from the player. This field is not a
  transcript and must not prescribe the player's dialogue, thoughts, feelings, or
  important decisions.
- `chat_opening_message`: Exact first visible message for the authored Chat scenario.
  Write finished in-game prose and dialogue rather than an instruction to generate a
  message. Establish an actionable moment and leave control of the player to the
  player. Use supported runtime tokens such as `|[player_name]|` when the text needs
  the selected player's identity. Leave this blank when the AI should generate the
  opening from `chat_story` instead.
- `chat_starting_location`: Exact object with only `label`, `place`, and `activity`.
  `label` is a short player-facing location name. `place` concretely describes where
  the scene occurs. `activity` describes what the character and player are presently
  doing and should work as scene/image context. Either provide all three nonblank
  strings or leave all three blank. Do not add coordinates, world-map topology, NPC
  lists, objectives, or runtime location ids.

Authored Chat fields are defaults, not commands the player must accept. The game tells
the player when authored content exists, lets them inspect it, and lets them override
the location or opening guidance before creating the save. Author these fields so the
scenario still makes sense when the player chooses a different valid location or
direction. Once a Chat game begins, the chosen authored or overridden setup is copied
into that save; later edits to the library character must not retroactively change an
existing game. Importing this character into a normal story does not start or inject
the Chat scenario.

- `chat_story_template`: Optional complete EmberAdventures `storyTemplate` object for
  players who want a full authored story with this character instead of an open-ended
  chat. Use `null` when no full story is included. Never hand-author, summarize,
  partially copy, or invent fields inside this object using the Character skill. Load
  and follow the EmberAdventures Story skill, create the story there, and place only
  its complete inner `storyTemplate` object in this field, never the outer export
  wrapper or any non-story data. The lightweight Chat fields may remain filled when a
  full story exists: they define the separately selectable Just Chat opening and do
  not override, merge into, or replace the full story. The inner story must set
  `allow_any_player: true`. Do not duplicate the surrounding standalone character
  in `state.player`, `state.players`, `state.characters`, NPC entries, or
  `future_cast`. The engine automatically registers the authoritative surrounding
  character under its stable standalone id before validating and launching the
  attached story. The story may reference that stable id in supported character
  references; a second embedded definition with the same id is invalid.

- `stats`: Optional object of game-specific numeric stats. Keys are authored,
  readable stable identifiers such as `strength`, `agility`, `mana`,
  `capacity_cost`, or `pack_share`; EmberAdventures does not prescribe a fixed
  stat list for ordinary custom mechanics. Values normally must be JavaScript
  safe integers. Negative, zero, and positive custom integers are valid; numeric
  strings, booleans, null and unsafe values are invalid. A complete optional
  [fixed combat profile](#reference-combat-stats) has built-in decimal precision and
  health bounds, including in reusable library characters. Omit `stats` when the
  character does not participate in an authored numeric system. Do not add
  generic RPG stats merely to fill the field. Stats are shown with full
  character information and supplied to the AI for characters present in the
  scene, but omitted from reduced absent-character context.

  Story-embedded copies may use decimal stat values only when the containing
  story declares that custom stat key and its allowed 1-6 decimal places in
  `state.numeric_precision.character_stats`. Other standalone custom stats
  remain integer-only; the complete fixed combat profile is the documented
  exception and does not require story-specific precision metadata.

  Do not put unlock timing, objective requirements, creator instructions, or
  scheduling notes here. Bad: `Should not appear before Harz politics become
  relevant.` Good: `Serves House Harz as a cautious noble contact.`

  Important characters need enough facts to be useful in play. Main party
  members usually need 6-10 specific facts. Major NPCs usually need 4-6. Cover
  identity, role, personality under pressure, combat/usefulness or social
  usefulness, household/social role when relevant, quirks/preferences,
  relationship dynamics, and story/concept-specific complications or arcs. One
  generic fact is draft quality except for truly minor one-scene utility
  characters.

#### Player-Facing Visibility

Character definitions may be shown in public libraries, local libraries, editor
views, character definition panels, and story setup screens. Before exporting,
audit fields that can be visible to players: `name`, `source`, `genres`,
`kink_tags`, `nsfw`, `loli`, `gender`, `age`, `role`,
`personality_description`, `speech_style`, appearance, outfits, starting state, inventory,
durable known facts, voice metadata, and default image metadata.

Visible character fields must not reveal hidden story objectives, future party
roles, future relationship outcomes, private AI instructions, source twists, or
story-specific secrets unless the character entry is intentionally published as
spoiler-heavy and appropriate for that context.

If the character is intended to be used as a player character, visible fields
should establish who they are at the start while preserving the user's future
agency.

#### Image Defaults

- Character-creation AIs do not have the application-owned image records needed to assign image metadata correctly. Always emit blank image defaults. Do not invent, infer, copy, promote, or attach image ids, URLs, prompts, styles, seeds from generated images, or ownership history. The application manages real image metadata after import.

- `default_seed`: Use `0`.

- `image_prompt_config`: Emit the blank object shape from the canonical example.

- `image_prompt_config.seed_enabled`: Use `true` in the blank authored shape.

- `image_prompt_config.seed`: Use `0`.

- `image_prompt_config.style`: Use `""`.

- `image_prompt_config.profile_style`: Use `""`.

- `image_prompt_config`: Use exactly the blank fields shown in the canonical example. The current EmberAdventures exporter emits `negative` and `negative_prompt`, so include both as `""` for round-trip schema consistency. Never put generated or inferred image guidance in them.

- `default_profile_image`: Emit the complete blank object shown in the canonical example, including blank `local_image_id`.

- `default_profile_image.url`: Use `""`.

- `default_profile_image.local_image_id`: Use `""`.

- `default_profile_image.source`: Use `"none"`.

- `default_profile_image.seed`: Use `null`.

- `default_profile_image.prompt`: Use `""`.

- `default_profile_image.negative_prompt`: Use `""`.

- `default_profile_image.note`: Use `""`.

- `default_profile_image.male`: Required boolean profile-presentation metadata. Use `true` only for a male or trans-male presentation. Use `false` for female, futanari, non-binary, and every other non-male presentation. Female and futanari profile images intentionally share the non-male bucket. For a blank authored slot, initialize this from the canonical character presentation. For a configured image, describe the presentation actually shown by that image, even when it is the character's fallback rather than canonical presentation. Never infer this value later from the character's current gender.

- `profile_image_presentations`: Application-managed pair of default profile-image slots named `male` and `non_male`. Each slot uses the same shape as `default_profile_image`; `male.male` must be `true` and `non_male.male` must be `false` when a real image slot is populated. Character-creation AIs emit both keys with blank/null image values and never invent real URLs, local ids, prompts, seeds, data URLs, transparent images, or placeholder image objects. Leave image values blank for EmberAdventures to fill when real images are generated or selected.

A character may be locally drafted or imported with empty profile-image slots, but public publishing requires one real resolving hosted profile image for the male presentation and one real resolving hosted profile image for the female/futanari presentation. Both `profile_image_presentations.male.url` and `profile_image_presentations.non_male.url` must resolve as real images before public upload, and the character must also have the required alternate name/outfit group. Do not use fake image data to satisfy this requirement. `default_profile_image` remains the canonical/default presentation slot and should be null/blank until it can match one of the two real presentation slots. At runtime, a profile image is eligible only when its `male` value matches the character's active male/female presentation; never display the opposite bucket as a fallback. This metadata applies only to profile images. Normal/full-body, group, story, item, outfit, title-card, and other images must not receive a `male` field.

- `created_at`: Required ISO 8601 timestamp for when this definition was first created. Use the actual creation time for new entries; never leave it blank or use an empty placeholder. Preserve it unchanged when editing an existing definition.

- `updated_at`: Required ISO 8601 timestamp for the most recent definition change. Set it to the actual edit time for a new or modified entry. When reviewing without changing the definition, preserve the existing value.

- `profile_images`: Always emit `{ "active_image_id": "", "image_ids": [] }`.

- `images`: Always emit `{ "active_image_id": "", "image_ids": [] }`.

#### Voice

- `voice`: Always use `null`. Character-creation AIs do not have the installed TTS/screen-reader voice information needed to populate this correctly. Do not infer a voice bucket, assign a character name, use a voice actor, or ask the user for voice metadata during normal character creation.

#### Forbidden Definition Fields

Do not include these in `character_definition`: `kind`, `entity_kind`, duplicate name fields, `creator`, `creator_id`, `short_description`, `creator_notes`, `character_version`, `power`, `consent_state`, current `relationship_to_player`, current `trust`, current `attraction`, current `affection`, current `arousal`, current `state_of_mind`, current `physical_state`, current `pose`, `active_outfit_id`, active/current `clothing`, current `held_items`, current `inventory`, current `known_facts`, `profile_image_id`, `profile_images_list`, current location, scene lists, inspected status, invite status, party membership, NPC status, death state, or image inclusion state. `starting_outfit_id` is allowed because it identifies the immutable default preset; `active_outfit_id` is runtime state and is forbidden.


### Physical Attribute Phrase List

The current effective image-prompt mappings and presentation rules are in [references/body-scales-0-20.md](#reference-body-scales-0-20). Read that reference when selecting or reviewing character appearance values. It describes existing engine behavior and supplies no automatic legacy conversion.

Starting relationship stats `starting_trust`, `starting_attraction`, `starting_affection`, and `starting_arousal` are also base-10 values from 0 to 10. Do not use legacy 0-100 values for those fields.

`bodyStatKeys`: `height`, `shoulder_width`, `chest`, `upper_body_build`, `midsection_build`, `hip_width`, `butt_build`, `lower_body_build`, `arm_length`, `leg_length`, `penis_size`.

All eleven keys must exist exactly once. Each accepts an integer from 0 to 20 or a nonempty custom description. The old appearance keys `muscular`, `shoulders`, `stomach`, `hips`, `waist`, `legs`, and `arms` must not appear. Do not automatically rescale existing values or repair older exports from this phrase reference. Handle an explicitly requested file repair separately under the canonical character contract.

## Reference combat stats

# Optional fixed combat profile

Characters may carry the complete six-value profile in `stats`. This snippet
illustrates the numeric fields; it is not a complete character export:

```json
{
  "stats": {
    "health": 200,
    "max_health": 200,
    "physical_attack": 100,
    "magical_attack": 60,
    "physical_defense": 700,
    "magical_defense": 180
  }
}
```

These are example values, not universal character defaults or a rebalance of
an existing cast. Author a coherent scale based on the character's established
capabilities. Preserve existing numbers unless a deliberate change is requested.

All six values use at most two decimal places. These complete-profile rules are
built into the character validator; other custom stat keys retain their normal
integer contract. Values must be finite safe numbers; only current health may
be negative, from minus maximum through maximum. Maximum health is positive.

Physical and magical Attack are effectiveness ratings, not damage amounts.
Per-hit Strength is BASE damage chosen from the technique, weapon, force and
intent. The engine computes ceil(Strength * 2 * Attack / (Attack + Defense)),
using physical_attack/physical_defense or magical_attack/magical_defense.
Attack zero always deals zero, including both ratings zero. Final damage is an
integer, rounded up once. No susceptibility multiplier or alternate equation.

A magical Attack rating does not grant a
new spell; describe actual learned abilities and restrictions in existing
character fields. Descriptive speed/reflexes belong in descriptions or facts,
not unsupported string-valued numeric stats.

Zero and negative HP above minus maximum mean conscious, speech permitted and
slow crawling only; no fighting, standing, walking or weapon use. At minus maximum
can_die true means dead, otherwise unconscious. Explicit nonlethal damage stops
at zero and cannot worsen negative HP. Stopping combat does not restore HP or
consciousness. There is no universal passive healing, mana or stamina pool.
Initial adjudication cannot invent death/permanent wounds; final narration follows
actual engine results. Full definitions still require their boolean can_die.
An uninspected shell's omitted optional flag follows native storage's false policy.
An uninspected NPC may already have current combat stats; completing their
definition by inspection preserves those existing values, including current HP.
Existing authored injuries, species traits and abilities remain part of the
character; do not erase them or add regeneration merely to fill this profile.

Combat stats are optional character data. Do not add generic RPG stats to a
character unless relevant to the requested design. Full character schema,
outfits, identity and quality requirements remain unchanged.

## Author a story for Character Chat

Use the inner \`storyTemplate\` object as \`chat_story_template\`. It has its own opening.

- Use the validated story example. The outer app is "EmberAdventures" and exportType is "story-template". Inside storyTemplate, app is "EmberAdventures" and templateType is "story". Both editions use these values. Put authored metadata, the opening and state inside storyTemplate.
- A story with selectable library protagonists uses allow_any_player. An optional any_player_starting_state can apply authored starting-story data when requested by the creator. Leave the example's null value when no overlay is needed. Avoid overwriting a player outfit by accident. Author all starting options with the same depth and coherence. Use exact stable IDs and player references.
- Place the default player in state.player, alternate authored players in state.players, starting companions in state.characters, local NPC records in state.npc_directory, and unrevealed cast in state.future_cast. The NPC directory associates named identities with locations. Physical scene membership is separate from stored location and party membership. Only present actors belong in the opening scene and image targets. Put future identities only where the current story can safely withhold them.
- The initial world map and location should agree with scene, time, named NPC rooms, and opening. Place authored locations on their appropriate hex layers, keeping believable travel distances and meaningful unexplored space. Do not invent map field aliases or put unvisited locations into starting player knowledge. Put actual story currency, supplies, equipment and starting resources in their respective fields. An economy needs its currency named in story metadata and a matching inventory record. Keep process notes and engine session values out of story definitions.

## Objective and reward flow

- Author a clear opening objective with a visible summary and an exact private completion condition. Explain what counts as concrete progress. Give normal narration only information the relevant scene can know. Put actions after completion in the correct completion or transition fields, rather than asking the narrator to simulate state effects.
- Use player control for a player action, AI control for a plot event the narrator may initiate, and choice control for explicit options. Use evidence requirements and meaningful alternate outcomes when an action can legitimately fail or be refused. Complete solely when supported by the action or scene. Avoid forced lockstep progression unless the intended experience needs it.
- Use numeric requirements for real mechanical thresholds, authored rewards for mutations, ordered authored output IDs for branching, and the supported ending fields for conclusions. Reuse IDs consistently across state graph, routes, rewards, and journal references. Check for unintentional loops, dangling routes and single unreachable branches.
- Include one concrete payoff early, a clear next opportunity, and a coherent resolution or explicit freeplay handoff. For a sandbox, authored state gives the narrator enough to respond well even when the player ignores the tracked objective.
- Optional systems include jobs, timed events, maps, character schedules, property, combat, and stat sharing. Start with the schema for the selected edition. Use optional fields only for systems the creator wants. For a complicated feature whose type or layout is unclear, ask for a current game export that already uses that feature before adding it. Preserve unrelated authored systems and save identity when editing an existing story.

## Embedded characters

Apply the character rules and exact embedded field sets below to every humanoid and animal, including future cast and alternate players. Characters should have their own immediate goals, knowledge, clothing, speech, and reactions. Resolve gender tokens against their chosen presentations. Names and IDs in NPC directory, party, effects, opening text and map data must refer to the intended individual.

## Private character preferences

In a local Codex workflow, read the private file at `\${CODEX_HOME}/private/emberadventures-character-preferences.json` (or `~/.codex/private/emberadventures-character-preferences.json`). Ask only the next relevant missing preference. Save general preferences there when the creator wants them remembered. Saved tastes apply to the current task unless the creator says otherwise. In chat, use preferences already supplied, and provide a separate preference JSON only if requested.

For Full, if you need to establish whether explicit character content is wanted, ask that as its own question. For a first-time global preference setup, ask “Before we start, do you want to be able to make NSFW characters?” Omit explicit topics when the answer is no. Use the current model and reasoning mode for factual creation metadata and ask about it separately only if you need the information and cannot verify it.

Track answered and skipped preferences by stable ID. Ask questions about a character's role and relationship on separate turns if both matter. Once the creator skips a question, choose a sensible default. The following question bank and JSON shape are internal storage guidance.

### Optional Groups

Maintain optional groups as internal coverage tracking, not as a mandatory questionnaire. When presenting optional setup, include group counts only if the user asks what remains or explicitly wants setup/audit mode. In normal character creation, ask only the missing optional questions that matter for the requested character.

Suggested groups:

- Looks and body
- Genders and attraction
- Species/races
- Personality and boldness
- Jobs/concepts
- Relationship dynamics
- Clothing/style
- Names
- Sexual/NSFW preferences if allowed
- Limits and icks
- Batch uniqueness and similarity to existing characters

### Stable Question Bank

Use the stable ids below for `answered_questions`, `skipped_questions`, batch
tracking, and remaining counts. The ids are internal; continue labeling the
internal preference tracking. Ask only relevant unanswered ids and
generate concise multiple-choice options plus a free-answer option. Filter all
`nsfw.*` questions when `allow_nsfw` is false. Compute remaining group counts
from unanswered applicable ids instead of copying hardcoded totals.

```text
required_setup (not included in optional group counts)
setup.allow_nsfw -> general.allow_nsfw -> whether NSFW character creation is allowed
setup.creation_tool -> general.default_creation_tool and default_creation_tool_parts -> current tool, model, and reasoning/intelligence label
setup.spice_mode -> general.default_spice_mode -> normal, sexy, explicit, or ask/infer default when NSFW is allowed

looks_and_body (12)
looks.height -> body_preferences.height_range -> preferred height range
looks.shoulder_width -> body_preferences.shoulder_width_range -> preferred shoulder-width range
looks.chest -> body_preferences.chest_range -> preferred chest range
looks.upper_body_build -> body_preferences.upper_body_build_range -> preferred upper-body build range
looks.midsection_build -> body_preferences.midsection_build_range -> preferred midsection build range
looks.hip_width -> body_preferences.hip_width_range -> preferred hip-width range
looks.butt_build -> body_preferences.butt_build_range -> preferred butt/glute build range
looks.lower_body_build -> body_preferences.lower_body_build_range -> preferred lower-body build range
looks.arm_length -> body_preferences.arm_length_range -> preferred arm-length range
looks.leg_length -> body_preferences.leg_length_range -> preferred leg-length range
looks.penis_size -> body_preferences.penis_size_range -> preferred penis-size range when relevant
looks.custom_anatomy -> body_preferences.custom_body_notes -> recurring anatomy or body details not covered by scales

genders_and_attraction (4)
gender.targets -> genders_and_attraction.target_genders -> genders the user wants created
gender.focus -> genders_and_attraction.gender_focus -> default gender focus or ask/infer behavior
gender.body_by_gender -> genders_and_attraction.body_type_focus_by_gender -> body preferences that differ by gender
gender.variation -> genders_and_attraction.variation_preference -> desired gender variation across batches

species_and_races (6)
species.likes -> species_and_race.liked_species -> liked species/races
species.dislikes -> species_and_race.disliked_species -> disliked species/races
species.human_detail -> species_and_race.human_race_detail_preference -> whether human ethnicity/visual ancestry should be specific, varied, inferred, or omitted
species.diversity -> species_and_race.diversity_expectation -> desired species/race diversity in batches
species.anatomy -> species_and_race.nonhuman_anatomy_preferences -> recurring nonhuman anatomy preferences
species.horror -> species_and_race.horror_appearance_tolerance -> tolerance for genuinely disturbing or horror-like designs

personality_and_boldness (7)
personality.boldness -> personality.boldness_range -> preferred numeric 1-10 boldness range or text guidance
personality.likes -> personality.liked_traits -> liked personality traits
personality.dislikes -> personality.disliked_traits -> disliked personality traits
personality.subversion -> personality.mismatch_or_subversion_preference -> preference for archetype subversion or mismatched traits
personality.aggression -> personality.aggression_preference -> aggression preference independent of boldness
personality.power_dynamic -> personality.power_dynamic_preference -> dominant, submissive, switch, neutral, varied, or ask/infer behavior
personality.tone -> personality.humor_and_tone_preference -> preferred humor, seriousness, warmth, darkness, or tonal mix

jobs_and_concepts (5)
concept.likes -> jobs_and_concepts.liked_jobs -> liked jobs, roles, and concepts
concept.dislikes -> jobs_and_concepts.disliked_jobs -> disliked jobs, roles, and concepts
concept.priority -> jobs_and_concepts.concept_priority -> whether job, archetype, appearance, personality, or another hook should lead design
concept.power -> jobs_and_concepts.overpowered_preference -> desired power level
concept.role_style -> jobs_and_concepts.role_style_preference -> ordinary, fantastical, setting-grounded, origin-driven, or varied role style

relationship_dynamics (5)
relationship.character_type -> relationship_defaults.default_character_type -> player character, party member, NPC, or ask/infer
relationship.default -> relationship_defaults.default_relationship_to_player -> default relationship to player
relationship.allowed -> relationship_defaults.allowed_relationship_types -> allowed relationship types
relationship.none -> relationship_defaults.allow_no_relationship -> whether no player relationship must remain available
relationship.special -> relationship_defaults.special_relationship_dynamics -> optional romance, ownership, oath, rival, family, erotic, or other special dynamics; omit NSFW options when NSFW is disabled

clothing_style (5)
clothing.likes -> clothing_and_style.liked_styles -> liked clothing styles
clothing.dislikes -> clothing_and_style.disliked_styles -> disliked clothing styles
clothing.count -> clothing_and_style.outfit_count_guidance -> how many outfits to create
clothing.plan -> clothing_and_style.default_outfit_plan -> recurring wardrobe composition
clothing.special -> clothing_and_style.special_outfit_notes -> special outfit requirements, including sexual outfit guidance only when NSFW is enabled

names (4)
names.likes -> names.name_style_likes -> liked naming styles
names.dislikes -> names.name_style_dislikes -> disliked naming styles
names.theming -> names.over_themed_name_tolerance -> tolerance for concept-themed names
names.length -> names.word_count_preference -> preferred name length and structure

sexual_nsfw_preferences (8; NSFW only)
nsfw.level -> nsfw_preferences.spice_level -> desired explicitness
nsfw.frequency -> nsfw_preferences.spice_frequency -> desired frequency of sexual characterization
nsfw.kinks -> nsfw_preferences.liked_kinks -> liked kinks and dynamics
nsfw.limits -> nsfw_preferences.limits -> sexual hard limits
nsfw.forwardness -> nsfw_preferences.default_sexual_forwardness -> default sexual forwardness
nsfw.anatomy -> nsfw_preferences.anatomy_preferences -> sexual anatomy preferences
nsfw.role -> nsfw_preferences.role_preferences -> preferred sexual roles or power dynamics
nsfw.clothing -> nsfw_preferences.clothing_preferences -> explicit clothing and exposure preferences

limits_and_icks (3)
limits.hard -> limits_and_icks.hard_limits -> content or traits never to create
limits.soft -> limits_and_icks.soft_avoids -> content or traits generally to avoid
limits.context -> limits_and_icks.contextual_limits -> content allowed only in specific contexts or when explicitly requested

batch_uniqueness (3)
batch.priority -> batch_uniqueness.uniqueness_priority -> desired uniqueness level
batch.compare -> batch_uniqueness.compare_against_existing_characters -> whether to compare against existing libraries
batch.similarity -> batch_uniqueness.similarity_to_existing_characters -> whether new characters should fit with or differ from existing characters
```

Most questions should be multiple choice with an explicit free-answer option. The user can skip any question or stop setup at any time.

When the user says they are done, happy enough, wants to stop questions, wants to skip setup, or wants to return to the character request, record that state in the preference file and proceed using the answered preferences plus reasonable defaults.

If optional counters or `answered_questions` disagree with populated preference fields, trust the populated fields, repair the counters, and avoid re-asking the same topic.

Use a shape like:

"Setup is saved.

There are 11 preference groups with unanswered questions:
- Looks and body: 10 questions
- Genders and attraction: 4 questions
- Species/races: 6 questions
- Personality and boldness: 7 questions
- Jobs/concepts: 5 questions
- Relationship dynamics: 5 questions
- Clothing/style: 5 questions
- Names: 4 questions
- Sexual/NSFW preferences: 8 questions
- Limits and icks: 3 questions
- Batch uniqueness and similarity: 3 questions

Which preference would you like to set next?"

If NSFW is disabled, omit NSFW-only groups/questions from the count and prompt.

## Preference Schema

Use a structured JSON preference file with one general section and otherwise specific question/answer slots.

Suggested shape:

```json
{
  "schema": "emberadventures-character-preferences-v1",
  "updated_at": "<actual ISO 8601 update timestamp>",
  "general": {
    "setup_complete": false,
    "minimum_setup_complete": false,
    "optional_setup_complete": false,
    "user_stopped_setup": false,
    "user_stopped_optional_setup": false,
    "intake_status": "in_progress",
    "allow_nsfw": null,
    "default_spice_mode": "ask_or_infer",
    "default_source": "Original",
    "default_creation_tool": "<actual tool/model> (<reasoning level>)",
    "default_creation_tool_parts": {
      "tool": "",
      "model": "",
      "intelligence": ""
    },
    "preferred_workflow": "ask_missing_propose_review_approve_make",
    "workflow_notes": "Default: ask only relevant missing preferences, infer the rest, propose a few options, let the user review/pick/request changes, then create. User may override with direct creation or another flow.",
    "compare_existing_library": "ask",
    "existing_library_paths": [],
    "last_question_batch": [],
    "unanswered_from_last_batch": [],
    "answered_questions": [],
    "skipped_questions": [],
    "question_plan": {
      "question_label_style": "plain",
      "answer_option_label_style": "numbers",
      "batch_size": 1,
      "stable_question_bank_version": 1,
      "priority_order": []
    },
    "remaining_required_questions": [
      "setup.allow_nsfw",
      "setup.creation_tool",
      "setup.spice_mode"
    ],
    "remaining_optional_groups": {
      "looks_and_body": 10,
      "genders_and_attraction": 4,
      "species_and_races": 6,
      "personality_and_boldness": 7,
      "jobs_and_concepts": 5,
      "relationship_dynamics": 5,
      "clothing_style": 5,
      "names": 4,
      "sexual_nsfw_preferences": 8,
      "limits_and_icks": 3,
      "batch_uniqueness": 3
    }
  },
  "genders_and_attraction": {
    "target_genders": [],
    "gender_focus": "ask",
    "body_type_focus_by_gender": {},
    "variation_preference": "ask"
  },
  "body_preferences": {
    "height_range": null,
    "shoulder_width_range": null,
    "chest_range": null,
    "upper_body_build_range": null,
    "midsection_build_range": null,
    "hip_width_range": null,
    "butt_build_range": null,
    "lower_body_build_range": null,
    "arm_length_range": null,
    "leg_length_range": null,
    "penis_size_range": null,
    "custom_body_notes": ""
  },
  "species_and_race": {
    "liked_species": [],
    "disliked_species": [],
    "human_race_detail_preference": "ask",
    "diversity_expectation": "ask",
    "nonhuman_anatomy_preferences": [],
    "horror_appearance_tolerance": "ask"
  },
  "personality": {
    "boldness_range": null,
    "liked_traits": [],
    "disliked_traits": [],
    "mismatch_or_subversion_preference": "ask",
    "aggression_preference": "ask",
    "power_dynamic_preference": "ask",
    "humor_and_tone_preference": "ask"
  },
  "jobs_and_concepts": {
    "liked_jobs": [],
    "disliked_jobs": [],
    "concept_priority": "ask",
    "overpowered_preference": "ask",
    "role_style_preference": "ask"
  },
  "relationship_defaults": {
    "default_character_type": "ask",
    "default_relationship_to_player": "ask",
    "allow_no_relationship": true,
    "allowed_relationship_types": [],
    "slave_by_choice_default": "ask",
    "special_relationship_dynamics": []
  },
  "clothing_and_style": {
    "liked_styles": [],
    "disliked_styles": [],
    "ambiguity_rule": "pick_one_precise_outfit",
    "outfit_count_guidance": "ask",
    "default_outfit_plan": "ask",
    "normal_outfit_count": null,
    "sexual_outfit_count": null,
    "required_outfit_types": [],
    "disallowed_outfit_types": [],
    "sexual_outfit_notes": "",
    "special_outfit_notes": ""
  },
  "names": {
    "name_style_likes": [],
    "name_style_dislikes": [],
    "over_themed_name_tolerance": "ask",
    "word_count_preference": "ask"
  },
  "proposal_preferences": {
    "format": "ask",
    "detail_level": "ask",
    "include_race_parenthetical": "ask"
  },
  "nsfw_preferences": {
    "spice_level": null,
    "spice_frequency": null,
    "liked_kinks": [],
    "limits": [],
    "default_sexual_forwardness": "ask",
    "anatomy_preferences": [],
    "role_preferences": [],
    "clothing_preferences": []
  },
  "limits_and_icks": {
    "hard_limits": [],
    "soft_avoids": [],
    "contextual_limits": []
  },
  "batch_uniqueness": {
    "uniqueness_priority": "ask",
    "compare_against_existing_characters": "ask",
    "similarity_to_existing_characters": "ask"
  },
  "observed_acceptance_patterns": [],
  "preference_mismatches_to_discuss": []
}
```

If the user accepts/rejects characters in a way that conflicts with recorded preferences, tell them the mismatch you observe and work with them to update preferences or explain why your inference was wrong.

When feedback includes a calibration correction, ask or infer whether it is general or character-specific. Save general calibrations in the relevant preference slot. Examples:

- "This image is a 6, not an 8" -> save as body-scale calibration.
- "Spider women should have spider legs from the back, not a realistic abdomen" -> save as monster-girl anatomy guidance if general.
- "This outfit reads like lingerie" -> save clothing-slot and prompt guidance if general.

<a id="reference-reference-character"></a>

## Validated character example

<!-- resource:reference-character.json -->
```json
{
  "character_definition": {
    "version": 1,
    "id": "character-aren-valehart",
    "name": "Aren Valehart",
    "source": "Original",
    "creation_tool": "Codex",
    "genres": [
      "fantasy",
      "adventure",
      "romance"
    ],
    "can_die": false,
    "romanceable": true,
    "gender": "male",
    "fallback_name": "Arenna Valehart",
    "fallback_outfits": [
      {
        "id": "travel",
        "name": "Trail Tracker Gear",
        "clothing": {
          "hat": null,
          "hair_accessory": null,
          "face": null,
          "ears": null,
          "neck": "carved amber animal-trail pendant",
          "shoulders": null,
          "bra": null,
          "undershirt": "soft gray undershirt",
          "shirt": "forest-green field shirt",
          "over_shirt": null,
          "coat": "brown weatherproof tracker coat",
          "back": null,
          "hands": null,
          "right_wrist": null,
          "left_wrist": null,
          "right_fingers": null,
          "left_fingers": null,
          "waist": "dark brown leather tracking belt",
          "belt_accessory": null,
          "underwear": null,
          "pants": "reinforced charcoal trail trousers",
          "skirt": null,
          "legwear": null,
          "socks": "thick gray wool socks",
          "feet": "mud-caked brown hiking boots",
          "other_accessory": null
        },
        "nsfw": false
      },
      {
        "id": "town",
        "name": "Quiet Ranger Clothes",
        "clothing": {
          "hat": null,
          "hair_accessory": null,
          "face": null,
          "ears": null,
          "neck": "small bronze trail marker pendant",
          "shoulders": null,
          "bra": null,
          "undershirt": null,
          "shirt": "cream rolled-sleeve blouse",
          "over_shirt": null,
          "coat": "deep green long vest",
          "back": null,
          "hands": "dark brown fingerless field gloves",
          "right_wrist": null,
          "left_wrist": null,
          "right_fingers": null,
          "left_fingers": null,
          "waist": null,
          "belt_accessory": null,
          "underwear": null,
          "pants": null,
          "skirt": "opaque ankle-length brown walking skirt",
          "legwear": "opaque charcoal leggings",
          "socks": null,
          "feet": "clean black leather boots",
          "other_accessory": null
        },
        "nsfw": false
      }
    ],
    "fallback_starting_outfit_id": "travel",
    "age": 32,
    "role": "Monster tracker and conflict mediator",
    "personality_description": "|[character]| is a rugged human monster tracker who prefers resolving conflicts without killing misunderstood creatures. |[character_subject_pronoun_cap]| is quiet and observant, with a dry sense of humor that appears at unexpected moments. |[character_subject_pronoun_cap]| studies tracks, habits, and motives before drawing a weapon, but once |[character]| decides someone is in danger, |[character_subject_pronoun]| becomes difficult to move. |[character_subject_pronoun_cap]| worries that mercy can look like weakness to frightened communities and wants proof that patient protection can hold a town together.",
    "speech_style": "Sparse and grounded, with long pauses for observation, understated jokes, and plain language when a decision matters.",
    "boldness": 4,
    "starting_relationship_to_player": "not yet met",
    "starting_trust": 0,
    "starting_attraction": 0,
    "starting_affection": 0,
    "starting_state_of_mind": "quietly assessing tracks and listening for movement beyond the road",
    "starting_physical_state": "healthy adult human with the ordinary wear of a long trail",
    "starting_pose": "crouched beside a set of tracks, looking up only after finishing an observation",
    "appearance": {
      "species": "highland human",
      "height": 11,
      "skin_color": "weathered medium-brown skin",
      "eye_color": "gray-green",
      "hair_color": "dark brown",
      "hair_length": "neck length",
      "hair_type": "straight and wind-tossed",
      "fallback_hair": {
        "hair_length": "shoulder length"
      },
      "extra_description": "A broad, capable adult with a broken-nose profile, a neatly trimmed beard, and a patient gaze that misses very little.",
      "extra_description_lower_body": "",
      "nonhuman_lower_body": false,
      "shoulder_width": 13,
      "chest": 14,
      "upper_body_build": 14,
      "midsection_build": 13,
      "hip_width": 11,
      "butt_build": 13,
      "lower_body_build": 14,
      "arm_length": 10,
      "leg_length": 11,
      "penis_size": 10
    },
    "outfits": [
      {
        "id": "travel",
        "name": "Trail Tracker Gear",
        "clothing": {
          "hat": null,
          "hair_accessory": null,
          "face": null,
          "ears": null,
          "neck": "carved amber animal-trail pendant",
          "shoulders": null,
          "bra": null,
          "undershirt": "soft gray undershirt",
          "shirt": "forest-green field shirt",
          "over_shirt": null,
          "coat": "brown weatherproof tracker coat",
          "back": null,
          "hands": null,
          "right_wrist": null,
          "left_wrist": null,
          "right_fingers": null,
          "left_fingers": null,
          "waist": "dark brown leather tracking belt",
          "belt_accessory": null,
          "underwear": null,
          "pants": "reinforced charcoal trail trousers",
          "skirt": null,
          "legwear": null,
          "socks": "thick gray wool socks",
          "feet": "mud-caked brown hiking boots",
          "other_accessory": null
        },
        "nsfw": false
      },
      {
        "id": "town",
        "name": "Quiet Ranger Clothes",
        "clothing": {
          "hat": null,
          "hair_accessory": null,
          "face": null,
          "ears": null,
          "neck": "small bronze trail marker pendant",
          "shoulders": null,
          "bra": null,
          "undershirt": "soft cream undershirt",
          "shirt": "cream rolled-sleeve shirt",
          "over_shirt": null,
          "coat": "deep green long vest",
          "back": null,
          "hands": "dark brown fingerless field gloves",
          "right_wrist": null,
          "left_wrist": null,
          "right_fingers": null,
          "left_fingers": null,
          "waist": null,
          "belt_accessory": null,
          "underwear": null,
          "pants": "brown walking trousers",
          "skirt": null,
          "legwear": null,
          "socks": "opaque charcoal leggings",
          "feet": "clean black leather boots",
          "other_accessory": null
        },
        "nsfw": false
      }
    ],
    "starting_outfit_id": "travel",
    "starting_held_items": {
      "right_hand": null,
      "left_hand": null
    },
    "starting_inventory": [
      "tracker's notebook",
      "scent-masking herbs",
      "folding camp saw"
    ],
    "starting_known_facts": [
      "Aren tracks dangerous creatures and looks for peaceful solutions before recommending a hunt.",
      "Aren has earned the trust of several misunderstood creatures but remains cautious about promises made by frightened people."
    ],
    "stats": {},
    "default_seed": 0,
    "image_prompt_config": {
      "seed_enabled": true,
      "seed": 0,
      "style": "",
      "profile_style": "",
      "negative": "",
      "negative_prompt": ""
    },
    "default_profile_image": {
      "url": "",
      "local_image_id": "",
      "source": "none",
      "seed": null,
      "prompt": "",
      "negative_prompt": "",
      "note": "",
      "male": true,
      "nsfw": false
    },
    "profile_image_presentations": {
      "male": {
        "url": "",
        "local_image_id": "",
        "source": "none",
        "seed": null,
        "prompt": "general-audience portrait of Aren Valehart, a human monster tracker with dark brown wind-tossed hair and a short beard, brown weatherproof coat over a field shirt, crouched beside animal tracks with a notebook, thoughtful steady expression, quiet woodland trail, no text, no logo",
        "negative_prompt": "extra people, text, logo, watermark",
        "note": "Male presentation: tracker coat, notebook, and grounded pose establish his role.",
        "male": true,
        "nsfw": false
      },
      "non_male": {
        "url": "",
        "local_image_id": "",
        "source": "none",
        "seed": null,
        "prompt": "general-audience portrait of Arenna Valehart, a human monster tracker with dark brown wind-tossed hair tied back, brown weatherproof coat over a field shirt, crouched beside animal tracks with a notebook, thoughtful steady expression, quiet woodland trail, no text, no logo",
        "negative_prompt": "extra people, text, logo, watermark",
        "note": "Non-male presentation: tracker coat, notebook, and grounded pose establish the same character role.",
        "male": false,
        "nsfw": false
      }
    },
    "profile_images": {
      "active_image_id": "",
      "image_ids": []
    },
    "images": {
      "active_image_id": "",
      "image_ids": []
    },
    "voice": null,
    "created_at": "2026-08-31T00:00:00.000Z",
    "updated_at": "2026-09-03T06:16:19.219Z",
    "nsfw": false,
    "loli": false,
    "starting_arousal": 0,
    "starting_nsfw_known_facts": [],
    "kink_tags": []
  }
}
```

## Reference field sets

<!-- resource:character-field-sets.json -->
```json
{
  "CHARACTER_SHOP_COST_TEMPLATE_FIELDS": [
    "type",
    "costs",
    "effects"
  ],
  "CHARACTER_SHOP_COST_FIELDS": [
    "label",
    "available_expression",
    "op",
    "required_stat"
  ],
  "CHARACTER_SHOP_EFFECT_FIELDS": [
    "label",
    "operation",
    "field_path",
    "value_stat"
  ],
  "CHARACTER_DEFINITION_FIELDS": [
    "version",
    "id",
    "name",
    "source",
    "creation_tool",
    "catalog_hook",
    "genres",
    "kink_tags",
    "nsfw",
    "loli",
    "can_die",
    "romanceable",
    "shop_owner_category",
    "gender",
    "fallback_gender",
    "fallback_name",
    "fallback_outfits",
    "fallback_starting_outfit_id",
    "age",
    "role",
    "personality_description",
    "speech_style",
    "boldness",
    "starting_relationship_to_player",
    "starting_trust",
    "starting_attraction",
    "starting_affection",
    "starting_arousal",
    "starting_state_of_mind",
    "starting_physical_state",
    "starting_pose",
    "appearance",
    "outfits",
    "starting_outfit_id",
    "starting_held_items",
    "starting_inventory",
    "starting_known_facts",
    "starting_nsfw_known_facts",
    "chat_story",
    "chat_opening_message",
    "chat_starting_location",
    "chat_story_template",
    "stats",
    "default_seed",
    "default_image_background",
    "image_prompt_config",
    "default_profile_image",
    "profile_image_presentations",
    "profile_images",
    "images",
    "voice",
    "created_at",
    "updated_at"
  ],
  "CHARACTER_REQUIRED_FIELDS": [
    "version",
    "id",
    "name",
    "source",
    "creation_tool",
    "genres",
    "nsfw",
    "loli",
    "can_die",
    "romanceable",
    "gender",
    "fallback_name",
    "fallback_outfits",
    "fallback_starting_outfit_id",
    "age",
    "role",
    "personality_description",
    "speech_style",
    "boldness",
    "starting_relationship_to_player",
    "starting_trust",
    "starting_attraction",
    "starting_affection",
    "starting_arousal",
    "starting_state_of_mind",
    "starting_physical_state",
    "starting_pose",
    "appearance",
    "outfits",
    "starting_outfit_id",
    "starting_held_items",
    "starting_inventory",
    "starting_known_facts",
    "default_seed",
    "image_prompt_config",
    "default_profile_image",
    "profile_image_presentations",
    "profile_images",
    "images",
    "voice",
    "created_at",
    "updated_at"
  ],
  "ANIMAL_DEFINITION_FIELDS": [
    "version",
    "id",
    "name",
    "source",
    "creation_tool",
    "can_die",
    "gender",
    "shop_owner_category",
    "age",
    "role",
    "species",
    "physical_description",
    "personality_description",
    "communication_style",
    "starting_relationship_to_player",
    "starting_trust",
    "starting_affection",
    "starting_state_of_mind",
    "starting_physical_state",
    "starting_pose",
    "starting_known_facts",
    "stats",
    "default_seed",
    "image_prompt_config",
    "default_profile_image",
    "profile_image_presentations",
    "profile_images",
    "images",
    "voice",
    "created_at",
    "updated_at"
  ],
  "ANIMAL_DEFINITION_REQUIRED_FIELDS": [
    "version",
    "id",
    "name",
    "source",
    "creation_tool",
    "can_die",
    "gender",
    "age",
    "role",
    "species",
    "physical_description",
    "personality_description",
    "communication_style",
    "starting_relationship_to_player",
    "starting_trust",
    "starting_affection",
    "starting_state_of_mind",
    "starting_physical_state",
    "starting_pose",
    "starting_known_facts",
    "created_at",
    "updated_at"
  ],
  "CHARACTER_APPEARANCE_SCALE_FIELDS": [
    "height",
    "shoulder_width",
    "chest",
    "upper_body_build",
    "midsection_build",
    "hip_width",
    "butt_build",
    "lower_body_build",
    "arm_length",
    "leg_length",
    "penis_size"
  ],
  "CHARACTER_APPEARANCE_FIELDS": [
    "species",
    "height",
    "shoulder_width",
    "chest",
    "upper_body_build",
    "midsection_build",
    "hip_width",
    "butt_build",
    "lower_body_build",
    "arm_length",
    "leg_length",
    "penis_size",
    "skin_color",
    "eye_color",
    "hair_color",
    "hair_length",
    "hair_type",
    "fallback_hair",
    "extra_description",
    "extra_description_lower_body",
    "male_only_extra_description",
    "non_male_only_extra_description",
    "nonhuman_lower_body"
  ],
  "CHARACTER_APPEARANCE_REQUIRED_FIELDS": [
    "species",
    "height",
    "shoulder_width",
    "chest",
    "upper_body_build",
    "midsection_build",
    "hip_width",
    "butt_build",
    "lower_body_build",
    "arm_length",
    "leg_length",
    "penis_size",
    "skin_color",
    "eye_color",
    "hair_color",
    "hair_length",
    "hair_type",
    "extra_description",
    "extra_description_lower_body",
    "nonhuman_lower_body"
  ],
  "CHARACTER_OUTFIT_FIELDS": [
    "id",
    "name",
    "nsfw",
    "clothing"
  ],
  "CHARACTER_CLOTHING_FIELDS": [
    "hat",
    "hair_accessory",
    "face",
    "ears",
    "neck",
    "shoulders",
    "bra",
    "undershirt",
    "shirt",
    "over_shirt",
    "coat",
    "back",
    "hands",
    "right_wrist",
    "left_wrist",
    "right_fingers",
    "left_fingers",
    "waist",
    "belt_accessory",
    "underwear",
    "pants",
    "skirt",
    "legwear",
    "socks",
    "feet",
    "other_accessory"
  ],
  "CHARACTER_HELD_ITEM_FIELDS": [
    "right_hand",
    "left_hand"
  ],
  "CHARACTER_CHAT_STARTING_LOCATION_FIELDS": [
    "label",
    "place",
    "activity"
  ],
  "CHARACTER_IMAGE_PROMPT_FIELDS": [
    "seed_enabled",
    "seed",
    "style",
    "profile_style",
    "negative",
    "negative_prompt"
  ],
  "CHARACTER_PROFILE_IMAGE_SLOT_FIELDS": [
    "url",
    "local_image_id",
    "source",
    "seed",
    "prompt",
    "negative_prompt",
    "note",
    "male",
    "nsfw"
  ],
  "CHARACTER_PROFILE_IMAGE_SLOT_REQUIRED_FIELDS": [
    "url",
    "local_image_id",
    "source",
    "seed",
    "prompt",
    "negative_prompt",
    "note",
    "male"
  ],
  "CHARACTER_PROFILE_PRESENTATION_FIELDS": [
    "male",
    "non_male"
  ],
  "CHARACTER_IMAGE_COLLECTION_FIELDS": [
    "active_image_id",
    "image_ids"
  ],
  "CHARACTER_STARTING_INVENTORY_ITEM_FIELDS": [
    "id",
    "name",
    "note",
    "description",
    "type",
    "quantity",
    "value",
    "sellable",
    "quest_item",
    "image_prompt",
    "image_id",
    "image"
  ],
  "RUNTIME_OUTFIT_FIELDS": [
    "id",
    "name",
    "nsfw",
    "formality",
    "revealing",
    "origin",
    "memory",
    "source_shop_id",
    "source_outfit_id",
    "image_prompt",
    "image_id",
    "image",
    "contexts",
    "clothing",
    "held_items"
  ],
  "CHARACTER_LIBRARY_RECORD_FIELDS": [
    "id",
    "name",
    "source",
    "creator",
    "creator_id",
    "creation_tool",
    "loli",
    "nsfw",
    "role",
    "character",
    "active_profile_image_ids",
    "public_library_item_id",
    "public_library_owner_user_id",
    "public_library_version_id",
    "preferred_voice_name",
    "created_at",
    "updated_at"
  ],
  "CHARACTER_LIBRARY_RECORD_REQUIRED_FIELDS": [
    "id",
    "name",
    "source",
    "creator",
    "creator_id",
    "creation_tool",
    "loli",
    "nsfw",
    "role",
    "character",
    "active_profile_image_ids",
    "public_library_item_id",
    "public_library_owner_user_id",
    "public_library_version_id",
    "created_at",
    "updated_at"
  ],
  "CHARACTER_LIBRARY_ACTIVE_PROFILE_IMAGE_ID_FIELDS": [
    "male",
    "non_male"
  ]
}
```

## Validated story example

For Character Chat, copy the inner storyTemplate object.

<!-- resource:reference-story.json -->
```json
{
  "app": "EmberAdventures",
  "exportType": "story-template",
  "storyTemplate": {
    "id": "lantern-road",
    "title": "The Lantern Road",
    "description": "Help a village bridgekeeper restore the light for the spring festival.",
    "source": "Original",
    "creation_tool": "Codex",
    "genres": [
      "fantasy"
    ],
    "createdAt": "2026-10-21T23:00:17.617Z",
    "updatedAt": "2026-10-21T23:00:17.617Z",
    "allow_any_player": true,
    "any_player_starting_state": {
      "role": "A visitor helping the bridgekeeper"
    },
    "app": "EmberAdventures",
    "templateType": "story",
    "default_image_model": "fantasy-rpg",
    "title_card_subjects": [
      "A lantern on a stone village bridge"
    ],
    "title_card_image": {
      "id": "bramble-bridge-title-card",
      "title": "The Lantern Road title card",
      "prompt": "A small stone footbridge over a shallow stream, village festival bunting and an empty iron lantern hook, soft amber dusk, illustrated fantasy landscape, no lettering.",
      "negativePrompt": "text, logo, watermark",
      "seed": 0,
      "model": "fantasy-rpg",
      "source": "hosted",
      "url": "",
      "hosted_url": "",
      "html": "",
      "favorite": false,
      "nsfw": false
    },
    "state": {
      "meta": {
        "app": "EmberAdventures",
        "genres": [
          "fantasy"
        ],
        "story_guidance": "Tell a short, cozy fantasy adventure. Respect the player’s chosen method. Mira offers practical help without solving tasks for the player. Keep responses concise and leave room for dialogue. The missing lantern is an ordinary accident, not a hidden villain or supernatural crisis.",
        "story_source": {
          "mode": "original",
          "title": "The Lantern Road",
          "description": "Help a village bridgekeeper restore the light for the spring festival.",
          "modifications": []
        },
        "default_image_model": "fantasy-rpg",
        "loli": false,
        "kink_tags": []
      },
      "player": {
        "version": 1,
        "id": "bramble-rowan-reed",
        "name": "Rowan Reed",
        "source": "Original",
        "creation_tool": "Codex",
        "can_die": false,
        "romanceable": false,
        "gender": "male",
        "fallback_name": "Rowan Reed",
        "fallback_outfits": [
          {
            "id": "fallback-default",
            "name": "Everyday work clothes",
            "clothing": {
              "hat": null,
              "hair_accessory": null,
              "face": null,
              "ears": null,
              "neck": null,
              "shoulders": null,
              "bra": null,
              "undershirt": null,
              "shirt": "opaque long-sleeved blue wool tunic",
              "over_shirt": null,
              "coat": null,
              "back": "weatherproof courier satchel",
              "hands": null,
              "right_wrist": null,
              "left_wrist": null,
              "right_fingers": null,
              "left_fingers": null,
              "waist": "plain leather belt",
              "belt_accessory": null,
              "underwear": null,
              "pants": "full-length brown canvas trousers",
              "skirt": null,
              "legwear": null,
              "socks": "gray wool socks",
              "feet": "sturdy brown walking boots",
              "other_accessory": null
            },
            "nsfw": false
          }
        ],
        "fallback_starting_outfit_id": "fallback-default",
        "age": 29,
        "role": "Village courier",
        "personality_description": "Patient and curious, Rowan remembers promises and notices practical details. He can mend a strap but is no expert craftsperson. He worries about disappointing neighbors and sometimes takes on too many errands.",
        "speech_style": "Warm, plain-spoken sentences with occasional understated humor.",
        "boldness": 5,
        "starting_relationship_to_player": "self",
        "starting_trust": 4,
        "starting_attraction": 0,
        "starting_affection": 1,
        "starting_state_of_mind": "Concerned about the missing bridge lantern, but ready to help.",
        "starting_physical_state": "Healthy and uninjured.",
        "starting_pose": "Standing by the bridge railing.",
        "appearance": {
          "species": "human",
          "height": "5 feet 9 inches tall",
          "skin_color": "warm brown",
          "eye_color": "hazel",
          "hair_color": "black",
          "hair_length": "short",
          "hair_type": "curly",
          "extra_description": "A small pale scar at the left temple.",
          "extra_description_lower_body": "",
          "nonhuman_lower_body": false,
          "shoulder_width": 10,
          "chest": 12,
          "upper_body_build": 12,
          "midsection_build": 12,
          "hip_width": 9,
          "butt_build": 11,
          "lower_body_build": 13,
          "arm_length": 10,
          "leg_length": 11,
          "penis_size": 10
        },
        "outfits": [
          {
            "id": "default",
            "name": "Everyday work clothes",
            "clothing": {
              "hat": null,
              "hair_accessory": null,
              "face": null,
              "ears": null,
              "neck": null,
              "shoulders": null,
              "bra": null,
              "undershirt": null,
              "shirt": "opaque long-sleeved blue wool tunic",
              "over_shirt": null,
              "coat": null,
              "back": "weatherproof courier satchel",
              "hands": null,
              "right_wrist": null,
              "left_wrist": null,
              "right_fingers": null,
              "left_fingers": null,
              "waist": "plain leather belt",
              "belt_accessory": null,
              "underwear": null,
              "pants": "full-length brown canvas trousers",
              "skirt": null,
              "legwear": null,
              "socks": "gray wool socks",
              "feet": "sturdy brown walking boots",
              "other_accessory": null
            },
            "nsfw": false
          }
        ],
        "starting_outfit_id": "default",
        "starting_held_items": {
          "right_hand": null,
          "left_hand": null
        },
        "starting_inventory": [
          "A folded route map",
          "A length of spare twine"
        ],
        "starting_known_facts": [
          "Rowan carries messages between Bramble village and nearby farms.",
          "Rowan grew up in Bramble and knows bridgekeeper Mira Bellweather.",
          "Rowan promised to deliver the festival invitations before dusk."
        ],
        "default_seed": 0,
        "image_prompt_config": {
          "seed_enabled": true,
          "seed": 0,
          "style": "high detail fantasy RPG character art, cinematic lighting",
          "profile_style": "",
          "negative": "",
          "negative_prompt": ""
        },
        "default_profile_image": {
          "url": "",
          "local_image_id": "",
          "source": "none",
          "seed": null,
          "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
          "negative_prompt": "",
          "note": "",
          "male": false,
          "nsfw": false
        },
        "profile_image_presentations": {
          "male": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
            "seed": null,
            "negative_prompt": "",
            "note": "",
            "male": true,
            "nsfw": false
          },
          "non_male": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
            "seed": null,
            "negative_prompt": "",
            "note": "",
            "male": false,
            "nsfw": false
          }
        },
        "profile_images": {
          "active_image_id": "",
          "image_ids": []
        },
        "images": {
          "active_image_id": "",
          "image_ids": []
        },
        "voice": null,
        "created_at": "2026-10-21T23:00:17.617Z",
        "updated_at": "2026-10-21T23:00:17.617Z",
        "nsfw": false,
        "loli": false,
        "starting_arousal": 0,
        "starting_nsfw_known_facts": []
      },
      "players": [
        {
          "version": 1,
          "id": "bramble-rowan-reed",
          "name": "Rowan Reed",
          "source": "Original",
          "creation_tool": "Codex",
          "can_die": false,
          "romanceable": false,
          "gender": "male",
          "fallback_name": "Rowan Reed",
          "fallback_outfits": [
            {
              "id": "fallback-default",
              "name": "Everyday work clothes",
              "clothing": {
                "hat": null,
                "hair_accessory": null,
                "face": null,
                "ears": null,
                "neck": null,
                "shoulders": null,
                "bra": null,
                "undershirt": null,
                "shirt": "opaque long-sleeved blue wool tunic",
                "over_shirt": null,
                "coat": null,
                "back": "weatherproof courier satchel",
                "hands": null,
                "right_wrist": null,
                "left_wrist": null,
                "right_fingers": null,
                "left_fingers": null,
                "waist": "plain leather belt",
                "belt_accessory": null,
                "underwear": null,
                "pants": "full-length brown canvas trousers",
                "skirt": null,
                "legwear": null,
                "socks": "gray wool socks",
                "feet": "sturdy brown walking boots",
                "other_accessory": null
              },
              "nsfw": false
            }
          ],
          "fallback_starting_outfit_id": "fallback-default",
          "age": 29,
          "role": "Village courier",
          "personality_description": "Patient and curious, Rowan remembers promises and notices practical details. He can mend a strap but is no expert craftsperson. He worries about disappointing neighbors and sometimes takes on too many errands.",
          "speech_style": "Warm, plain-spoken sentences with occasional understated humor.",
          "boldness": 5,
          "starting_relationship_to_player": "self",
          "starting_trust": 4,
          "starting_attraction": 0,
          "starting_affection": 1,
          "starting_state_of_mind": "Concerned about the missing bridge lantern, but ready to help.",
          "starting_physical_state": "Healthy and uninjured.",
          "starting_pose": "Standing by the bridge railing.",
          "appearance": {
            "species": "human",
            "height": "5 feet 9 inches tall",
            "skin_color": "warm brown",
            "eye_color": "hazel",
            "hair_color": "black",
            "hair_length": "short",
            "hair_type": "curly",
            "extra_description": "A small pale scar at the left temple.",
            "extra_description_lower_body": "",
            "nonhuman_lower_body": false,
            "shoulder_width": 10,
            "chest": 12,
            "upper_body_build": 12,
            "midsection_build": 12,
            "hip_width": 9,
            "butt_build": 11,
            "lower_body_build": 13,
            "arm_length": 10,
            "leg_length": 11,
            "penis_size": 10
          },
          "outfits": [
            {
              "id": "default",
              "name": "Everyday work clothes",
              "clothing": {
                "hat": null,
                "hair_accessory": null,
                "face": null,
                "ears": null,
                "neck": null,
                "shoulders": null,
                "bra": null,
                "undershirt": null,
                "shirt": "opaque long-sleeved blue wool tunic",
                "over_shirt": null,
                "coat": null,
                "back": "weatherproof courier satchel",
                "hands": null,
                "right_wrist": null,
                "left_wrist": null,
                "right_fingers": null,
                "left_fingers": null,
                "waist": "plain leather belt",
                "belt_accessory": null,
                "underwear": null,
                "pants": "full-length brown canvas trousers",
                "skirt": null,
                "legwear": null,
                "socks": "gray wool socks",
                "feet": "sturdy brown walking boots",
                "other_accessory": null
              },
              "nsfw": false
            }
          ],
          "starting_outfit_id": "default",
          "starting_held_items": {
            "right_hand": null,
            "left_hand": null
          },
          "starting_inventory": [
            "A folded route map",
            "A length of spare twine"
          ],
          "starting_known_facts": [
            "Rowan carries messages between Bramble village and nearby farms.",
            "Rowan grew up in Bramble and knows bridgekeeper Mira Bellweather.",
            "Rowan promised to deliver the festival invitations before dusk."
          ],
          "default_seed": 0,
          "image_prompt_config": {
            "seed_enabled": true,
            "seed": 0,
            "style": "high detail fantasy RPG character art, cinematic lighting",
            "profile_style": "",
            "negative": "",
            "negative_prompt": ""
          },
          "default_profile_image": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "seed": null,
            "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
            "negative_prompt": "",
            "note": "",
            "male": false,
            "nsfw": false
          },
          "profile_image_presentations": {
            "male": {
              "url": "",
              "local_image_id": "",
              "source": "none",
              "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
              "seed": null,
              "negative_prompt": "",
              "note": "",
              "male": true,
              "nsfw": false
            },
            "non_male": {
              "url": "",
              "local_image_id": "",
              "source": "none",
              "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
              "seed": null,
              "negative_prompt": "",
              "note": "",
              "male": false,
              "nsfw": false
            }
          },
          "profile_images": {
            "active_image_id": "",
            "image_ids": []
          },
          "images": {
            "active_image_id": "",
            "image_ids": []
          },
          "voice": null,
          "created_at": "2026-10-21T23:00:17.617Z",
          "updated_at": "2026-10-21T23:00:17.617Z",
          "nsfw": false,
          "loli": false,
          "starting_arousal": 0,
          "starting_nsfw_known_facts": []
        }
      ],
      "characters": {},
      "future_cast": {
        "enabled": false,
        "items": {}
      },
      "location": {
        "universe": "Bramble Tales",
        "world": "Alder",
        "continent": "Westreach",
        "region": "Willow Vale",
        "settlement_type": "village",
        "settlement_name": "Bramble",
        "district": "Riverside",
        "specific_place": "Bramble Bridge",
        "npc_location_id": "bramble-bridge"
      },
      "npc_directory": {
        "locations": {
          "bramble-bridge": {
            "label": "Bramble Bridge",
            "characters": {
              "Mira Bellweather": {
                "id": "bramble-mira-bellweather",
                "name": "Mira Bellweather",
                "gender": "female",
                "age": 46,
                "role": "Bridgekeeper and lantern maker",
                "relationship": "acquaintance",
                "note": "Bridgekeeper and lantern maker; knows Rowan from village deliveries.",
                "current_appearance": "Standing beside the empty lantern hook with a canvas tool roll.",
                "inspected": true,
                "voice": null,
                "full_character": {
                  "version": 1,
                  "id": "bramble-mira-bellweather",
                  "name": "Mira Bellweather",
                  "source": "Original",
                  "creation_tool": "Codex",
                  "can_die": false,
                  "romanceable": false,
                  "gender": "female",
                  "fallback_name": "Mira Bellweather",
                  "fallback_outfits": [
                    {
                      "id": "fallback-default",
                      "name": "Everyday work clothes",
                      "clothing": {
                        "hat": null,
                        "hair_accessory": "simple wooden hair clasp",
                        "face": null,
                        "ears": null,
                        "neck": null,
                        "shoulders": null,
                        "bra": null,
                        "undershirt": null,
                        "shirt": "opaque long-sleeved rust-red linen shirt",
                        "over_shirt": "heavy full-front canvas work apron",
                        "coat": null,
                        "back": null,
                        "hands": null,
                        "right_wrist": null,
                        "left_wrist": null,
                        "right_fingers": null,
                        "left_fingers": null,
                        "waist": null,
                        "belt_accessory": null,
                        "underwear": null,
                        "pants": "full-length dark green work trousers",
                        "skirt": null,
                        "legwear": null,
                        "socks": "cream wool socks",
                        "feet": "black leather work boots",
                        "other_accessory": null
                      },
                      "nsfw": false
                    }
                  ],
                  "fallback_starting_outfit_id": "fallback-default",
                  "age": 46,
                  "role": "Bridgekeeper and lantern maker",
                  "personality_description": "Methodical, kind, and quietly stubborn. Mira takes pride in maintaining public things that others overlook. She taps a thumb against her tool roll when thinking. Her patience frays when people treat every old object as disposable; she admits when she needs help.",
                  "speech_style": "Brief, concrete explanations, dry humor, and a reassuring tone when someone struggles.",
                  "boldness": 5,
                  "starting_relationship_to_player": "acquaintance",
                  "starting_trust": 4,
                  "starting_attraction": 0,
                  "starting_affection": 1,
                  "starting_state_of_mind": "Concerned about the missing bridge lantern, but ready to help.",
                  "starting_physical_state": "Healthy and uninjured.",
                  "starting_pose": "Standing by the bridge railing.",
                  "appearance": {
                    "species": "human",
                    "height": "5 feet 4 inches tall",
                    "skin_color": "light brown",
                    "eye_color": "green",
                    "hair_color": "silver-gray",
                    "hair_length": "shoulder length",
                    "hair_type": "wavy",
                    "extra_description": "A scattering of freckles across her nose.",
                    "extra_description_lower_body": "",
                    "nonhuman_lower_body": false,
                    "shoulder_width": 12,
                    "chest": 13,
                    "upper_body_build": 8,
                    "midsection_build": 6,
                    "hip_width": 12,
                    "butt_build": 7,
                    "lower_body_build": 9,
                    "arm_length": 10,
                    "leg_length": 10,
                    "penis_size": 10
                  },
                  "outfits": [
                    {
                      "id": "default",
                      "name": "Everyday work clothes",
                      "clothing": {
                        "hat": null,
                        "hair_accessory": "simple wooden hair clasp",
                        "face": null,
                        "ears": null,
                        "neck": null,
                        "shoulders": null,
                        "bra": null,
                        "undershirt": null,
                        "shirt": "opaque long-sleeved rust-red linen shirt",
                        "over_shirt": "heavy full-front canvas work apron",
                        "coat": null,
                        "back": null,
                        "hands": null,
                        "right_wrist": null,
                        "left_wrist": null,
                        "right_fingers": null,
                        "left_fingers": null,
                        "waist": null,
                        "belt_accessory": null,
                        "underwear": null,
                        "pants": "full-length dark green work trousers",
                        "skirt": null,
                        "legwear": null,
                        "socks": "cream wool socks",
                        "feet": "black leather work boots",
                        "other_accessory": null
                      },
                      "nsfw": false
                    }
                  ],
                  "starting_outfit_id": "default",
                  "starting_held_items": {
                    "right_hand": "A folded canvas tool roll",
                    "left_hand": null
                  },
                  "starting_inventory": [
                    "A small brass workshop key",
                    "A clean polishing cloth"
                  ],
                  "starting_known_facts": [
                    "Mira has maintained Bramble Bridge for sixteen years.",
                    "Mira made the bridge lantern with her father and repairs it each spring.",
                    "Mira keeps a spare lantern frame and amber glass in her workshop."
                  ],
                  "default_seed": 0,
                  "image_prompt_config": {
                    "seed_enabled": true,
                    "seed": 0,
                    "style": "high detail fantasy RPG character art, cinematic lighting",
                    "profile_style": "",
                    "negative": "",
                    "negative_prompt": ""
                  },
                  "default_profile_image": {
                    "url": "",
                    "local_image_id": "",
                    "source": "none",
                    "seed": null,
                    "prompt": "Mira Bellweather, A stocky, sturdy build with a relaxed, practical bearing. opaque long-sleeved rust-red linen shirt, full-length dark green work trousers, black leather work boots. Warm illustrated fantasy village portrait.",
                    "negative_prompt": "",
                    "note": "",
                    "male": false,
                    "nsfw": false
                  },
                  "profile_image_presentations": {
                    "male": {
                      "url": "",
                      "local_image_id": "",
                      "source": "none",
                      "prompt": "Mira Bellweather, A stocky, sturdy build with a relaxed, practical bearing. opaque long-sleeved rust-red linen shirt, full-length dark green work trousers, black leather work boots. Warm illustrated fantasy village portrait.",
                      "seed": null,
                      "negative_prompt": "",
                      "note": "",
                      "male": true,
                      "nsfw": false
                    },
                    "non_male": {
                      "url": "",
                      "local_image_id": "",
                      "source": "none",
                      "prompt": "Mira Bellweather, A stocky, sturdy build with a relaxed, practical bearing. opaque long-sleeved rust-red linen shirt, full-length dark green work trousers, black leather work boots. Warm illustrated fantasy village portrait.",
                      "seed": null,
                      "negative_prompt": "",
                      "note": "",
                      "male": false,
                      "nsfw": false
                    }
                  },
                  "profile_images": {
                    "active_image_id": "",
                    "image_ids": []
                  },
                  "images": {
                    "active_image_id": "",
                    "image_ids": []
                  },
                  "voice": null,
                  "created_at": "2026-10-21T23:00:17.617Z",
                  "updated_at": "2026-10-21T23:00:17.617Z",
                  "nsfw": false,
                  "loli": false,
                  "starting_arousal": 0,
                  "starting_nsfw_known_facts": []
                }
              }
            }
          }
        }
      },
      "scene": {
        "summary": "Mira waits at the bridge with a repaired lantern ready to light.",
        "party_members_present": [],
        "image_characters": [
          "Mira Bellweather"
        ],
        "npcs_present": [
          "Mira Bellweather"
        ],
        "image_action": "Holding a repaired lantern beside the bridge hook.",
        "intimacy_level": 0,
        "spicy_mode": "off",
        "sex_position": "",
        "ai_sex_position": "",
        "sex_acts": []
      },
      "story_rules": [
        {
          "id": "safe-recovery",
          "text": "No one is in immediate danger. The stream is shallow; any recovery can be done safely from the bank with the available rake."
        },
        {
          "id": "patient-festival",
          "text": "The festival waits for the bridge light; there is no hidden countdown or forced failure."
        }
      ],
      "story_inventory": {
        "items": []
      },
      "world_map": {
        "current_location_id": "bramble-bridge",
        "focus_location_id": "bramble-bridge",
        "travel_history": [
          "bramble-bridge"
        ],
        "locations": {
          "bramble-bridge": {
            "id": "bramble-bridge",
            "name": "Bramble Bridge",
            "type": "place",
            "scale": "site",
            "parent_id": "",
            "x": 0,
            "y": 0,
            "discovered": true,
            "travel_enabled": true,
            "summary": "A stone footbridge with festival ribbons and an empty lantern hook.",
            "detail": {},
            "connections": [
              "willow-bank",
              "lantern-workshop"
            ],
            "npcs": [
              "Mira Bellweather"
            ]
          },
          "willow-bank": {
            "id": "willow-bank",
            "name": "Willow Bank",
            "type": "place",
            "scale": "site",
            "parent_id": "",
            "x": 1,
            "y": 0,
            "discovered": true,
            "travel_enabled": true,
            "summary": "A shallow, muddy bank below the bridge; a long-handled rake rests by the steps.",
            "detail": {},
            "connections": [
              "bramble-bridge"
            ],
            "npcs": []
          },
          "lantern-workshop": {
            "id": "lantern-workshop",
            "name": "Mira’s Workshop",
            "type": "place",
            "scale": "site",
            "parent_id": "",
            "x": -1,
            "y": 0,
            "discovered": true,
            "travel_enabled": true,
            "summary": "A tidy workshop beside the bridge, stocked with spare lantern parts.",
            "detail": {},
            "connections": [
              "bramble-bridge"
            ],
            "npcs": []
          }
        }
      },
      "objectives": {
        "active_id": "light-the-crossing",
        "no_current": false,
        "items": [
          {
            "id": "light-the-crossing",
            "title": "Light the crossing",
            "type": "story",
            "status": "active",
            "summary": "A working lantern is ready. Mira has a candle and taper; the repaired hook waits on the bridge.",
            "while_active_guidance": "Let the player act at their own pace. Do not complete the next task in the same response.",
            "completion_control": "ai",
            "completion_criteria": "The player lights and hangs the usable lantern on Bramble Bridge.",
            "next_objectives": [
              {
                "id": "bridge-lit",
                "completion_instruction": "Describe the amber light reaching the bridge stones and the first festival visitors crossing. Mira thanks the player in her reserved, sincere way. Leave the evening open for conversation or exploring the festival.",
                "rewards": [],
                "ending_type": "freeplay",
                "ending_title": "A light for everyone",
                "ending_message": "The crossing glows again. Music carries across the water, and the festival evening is yours to enjoy."
              }
            ]
          }
        ]
      },
      "time": {
        "year": 1,
        "month": 5,
        "day": 12,
        "hour": 18,
        "minute": 0
      },
      "story_memory": {
        "world_notes": [
          "Bramble celebrates its spring festival this evening.",
          "Mira’s workshop stands next to Bramble Bridge."
        ],
        "unresolved_threads": [],
        "relationship_notes": [
          "Mira knows the default courier Rowan through village deliveries. Other player characters begin as visitors."
        ],
        "rules_and_constraints": [],
        "ai_private_notes": []
      },
      "recent_changes": [],
      "story_clock": {
        "elapsed_minutes": 0,
        "label": "Day 1, 6:00 PM"
      },
      "story_pacing": {
        "mode": "player_controlled",
        "pending_event_id": "",
        "timeline": {}
      },
      "timed_events": {}
    },
    "messages": [
      {
        "role": "assistant",
        "speaker": "Narrator",
        "at": "2026-10-21T23:00:17.617Z",
        "text": "The repaired lantern rests on Bramble Bridge. Mira places a fresh candle beside it. “Ready when you are,” she says, holding out a taper. Music drifts from the village square."
      }
    ],
    "nsfw": false,
    "loli": false,
    "kink_tags": []
  },
  "exportedAt": "2026-10-21T23:00:17.617Z"
}
```

## Exact story field lists

<!-- resource:story-field-sets.json -->
```json
{
  "STORY_EXPORT_FIELDS": [
    "app",
    "exportType",
    "storyTemplate",
    "exportedAt"
  ],
  "STORY_TEMPLATE_FIELDS": [
    "id",
    "title",
    "description",
    "createdAt",
    "updatedAt",
    "allow_any_player",
    "any_player_starting_state",
    "state",
    "messages",
    "source",
    "app",
    "templateType",
    "creation_tool",
    "genres",
    "kink_tags",
    "nsfw",
    "loli",
    "default_image_model",
    "editor_data",
    "title_card_subjects",
    "title_card_image"
  ],
  "STORY_TEMPLATE_REQUIRED_FIELDS": [
    "id",
    "title",
    "description",
    "createdAt",
    "updatedAt",
    "allow_any_player",
    "any_player_starting_state",
    "state",
    "messages",
    "source",
    "app",
    "templateType",
    "creation_tool",
    "genres",
    "kink_tags",
    "nsfw",
    "loli",
    "default_image_model",
    "title_card_subjects",
    "title_card_image"
  ],
  "STORY_STATE_FIELDS": [
    "meta",
    "location",
    "world_map",
    "time",
    "scene",
    "player",
    "players",
    "characters",
    "npc_directory",
    "future_cast",
    "objectives",
    "story_inventory",
    "story_shops",
    "story_job_offers",
    "story_job_offer_history",
    "active_generated_jobs",
    "story_generated_npc_pool",
    "story_rules",
    "story_memory",
    "recent_changes",
    "story_clock",
    "story_pacing",
    "timed_events",
    "progression",
    "numeric_precision",
    "reward_templates",
    "reward_bundles",
    "character_shop_cost_templates",
    "player_home",
    "combat",
    "character_schedules",
    "spoken_abilities"
  ],
  "STORY_STATE_REQUIRED_FIELDS": [
    "meta",
    "location",
    "world_map",
    "time",
    "scene",
    "player",
    "characters",
    "npc_directory",
    "objectives",
    "future_cast",
    "story_rules",
    "story_memory",
    "recent_changes",
    "story_clock",
    "story_pacing",
    "timed_events"
  ],
  "STORY_META_FIELDS": [
    "app",
    "story_guidance",
    "story_source",
    "genres",
    "kink_tags",
    "loli",
    "default_image_model",
    "stat_display",
    "player_stat_display",
    "currency"
  ],
  "STORY_META_REQUIRED_FIELDS": [
    "app",
    "story_guidance",
    "story_source",
    "genres",
    "kink_tags",
    "loli"
  ],
  "STORY_SOURCE_FIELDS": [
    "mode",
    "title",
    "description",
    "modifications"
  ],
  "STORY_LOCATION_FIELDS": [
    "universe",
    "world",
    "continent",
    "region",
    "settlement_type",
    "settlement_name",
    "district",
    "specific_place",
    "npc_location_id"
  ],
  "STORY_WORLD_MAP_FIELDS": [
    "current_location_id",
    "focus_location_id",
    "travel_history",
    "locations",
    "hex_layout"
  ],
  "STORY_WORLD_LOCATION_FIELDS": [
    "id",
    "name",
    "type",
    "scale",
    "parent_id",
    "x",
    "y",
    "discovered",
    "travel_enabled",
    "summary",
    "detail",
    "connections",
    "npcs",
    "hidden_description"
  ],
  "STORY_TIME_FIELDS": [
    "year",
    "month",
    "day",
    "hour",
    "minute"
  ],
  "STORY_SCENE_FIELDS": [
    "summary",
    "intimacy_level",
    "spicy_mode",
    "party_members_present",
    "image_characters",
    "npcs_present",
    "speak_targets",
    "image_action",
    "sex_position",
    "ai_sex_position",
    "sex_acts"
  ],
  "STORY_SCENE_REQUIRED_FIELDS": [
    "summary",
    "intimacy_level",
    "spicy_mode",
    "party_members_present",
    "image_characters",
    "npcs_present",
    "image_action",
    "sex_position",
    "ai_sex_position",
    "sex_acts"
  ],
  "STORY_OBJECTIVE_STATE_FIELDS": [
    "active_id",
    "no_current",
    "items"
  ],
  "STORY_MESSAGE_FIELDS": [
    "role",
    "speaker",
    "text",
    "nsfwMode",
    "at"
  ],
  "STORY_TITLE_CARD_IMAGE_FIELDS": [
    "id",
    "title",
    "prompt",
    "negativePrompt",
    "seed",
    "model",
    "source",
    "url",
    "hosted_url",
    "html",
    "favorite",
    "nsfw",
    "upload_attestation_classification",
    "upload_attested_by",
    "upload_attested_at",
    "upload_attestation_policy_version"
  ],
  "STORY_TITLE_CARD_IMAGE_OPTIONAL_FIELDS": [
    "nsfw",
    "upload_attestation_classification",
    "upload_attested_by",
    "upload_attested_at",
    "upload_attestation_policy_version"
  ],
  "STORY_EDITOR_DATA_FIELDS": [
    "story_tree"
  ],
  "STORY_EDITOR_TREE_FIELDS": [
    "positions",
    "viewport",
    "output_modes"
  ],
  "STORY_EDITOR_TREE_REQUIRED_FIELDS": [
    "positions",
    "viewport"
  ],
  "STORY_EDITOR_VIEWPORT_FIELDS": [
    "x",
    "y",
    "zoom"
  ],
  "STORY_MEMORY_FIELDS": [
    "world_notes",
    "unresolved_threads",
    "relationship_notes",
    "rules_and_constraints",
    "ai_private_notes"
  ],
  "STORY_CLOCK_FIELDS": [
    "elapsed_minutes",
    "label"
  ],
  "STORY_PACING_FIELDS": [
    "mode",
    "pending_event_id",
    "timeline",
    "interruptions",
    "abandonments"
  ],
  "STORY_TIMELINE_EVENT_FIELDS": [
    "id",
    "title",
    "status",
    "objective_id",
    "trigger",
    "prompt",
    "accept",
    "decline",
    "missed_due_to_conflict",
    "on_ready",
    "auto_start",
    "queued_order"
  ],
  "STORY_TIMELINE_TRIGGER_FIELDS": [
    "at_elapsed_minutes",
    "objective_id"
  ],
  "STORY_TIMELINE_PROMPT_FIELDS": [
    "message",
    "accept_label",
    "decline_label"
  ],
  "STORY_TIMELINE_ACTION_FIELDS": [
    "objective_id",
    "message",
    "rewards",
    "travel_to_location_id"
  ],
  "STORY_TIMED_EVENT_FIELDS": [
    "id",
    "title",
    "status",
    "visibility",
    "trigger",
    "time_limit",
    "cancel_objective_id",
    "message",
    "stages",
    "rewards"
  ],
  "STORY_TIMED_EVENT_TRIGGER_FIELDS": [
    "objective_id",
    "immediately"
  ],
  "STORY_DURATION_FIELDS": [
    "days",
    "hours",
    "minutes"
  ],
  "STORY_TIMED_EVENT_STAGE_FIELDS": [
    "id",
    "after",
    "visibility",
    "message",
    "rewards"
  ],
  "STORY_FUTURE_CAST_FIELDS": [
    "enabled",
    "items"
  ],
  "STORY_FUTURE_CAST_ITEM_FIELDS": [
    "id",
    "name",
    "status",
    "canonical_order",
    "introduce_as",
    "can_die",
    "npc_location_id",
    "location_hint",
    "scene_presence",
    "role",
    "relationship",
    "note",
    "personality_description",
    "greeting",
    "full_character",
    "animal_definition",
    "meet_condition",
    "join_condition",
    "on_unlock",
    "unlocked_by",
    "last_triggered_reason",
    "on_purchase_objective",
    "fallback_name",
    "outfits",
    "fallback_outfits",
    "starting_outfit_id",
    "fallback_starting_outfit_id"
  ],
  "STORY_FUTURE_CAST_ON_UNLOCK_FIELDS": [
    "greeting",
    "image"
  ],
  "STORY_FUTURE_CAST_UNLOCK_IMAGE_FIELDS": [
    "id",
    "title",
    "prompt",
    "negative_prompt",
    "seed",
    "model",
    "source",
    "url",
    "favorite"
  ],
  "STORY_NPC_DIRECTORY_FIELDS": [
    "locations"
  ],
  "STORY_NPC_LOCATION_FIELDS": [
    "label",
    "characters"
  ],
  "STORY_NPC_FIELDS": [
    "id",
    "name",
    "gender",
    "age",
    "role",
    "relationship",
    "note",
    "current_appearance",
    "inspected",
    "voice",
    "full_character",
    "animal_definition",
    "status",
    "death_note",
    "killed_by_player",
    "killed_by",
    "player_known_name",
    "player_facing_label",
    "can_die",
    "stats"
  ],
  "STORY_RULE_FIELDS": [
    "id",
    "text"
  ],
  "STORY_OBJECTIVE_FIELDS": [
    "id",
    "title",
    "type",
    "status",
    "summary",
    "while_active_guidance",
    "completion_control",
    "completion_criteria",
    "completion_instruction",
    "dialogue_lines",
    "requires",
    "completion_requirements",
    "next_objectives",
    "choices",
    "choice_response_mode",
    "route_control",
    "unresolved_route_behavior",
    "outcome_routes",
    "evaluate_ai_on_activation",
    "requirement_check_only",
    "exclusive_group",
    "selectable",
    "locked_until_complete",
    "time_window_minutes",
    "available_now",
    "blocked_reason",
    "notes",
    "completion_message",
    "travel_location_id",
    "travel_location_name",
    "rewards",
    "abandonment"
  ],
  "STORY_NEXT_OUTPUT_FIELDS": [
    "id",
    "objective_id",
    "target_input_group_id",
    "completion_instruction",
    "dialogue_lines",
    "requirements",
    "rewards",
    "travel_location_id",
    "travel_location_name",
    "fallback",
    "ending_type",
    "ending_title",
    "ending_message"
  ],
  "STORY_CHOICE_OUTPUT_FIELDS": [
    "id",
    "title",
    "summary",
    "player_text",
    "next_objective_id",
    "target_input_group_id",
    "completion_instruction",
    "dialogue_lines",
    "requirements",
    "rewards",
    "travel_location_id",
    "travel_location_name",
    "effects",
    "open_shop_id",
    "defer",
    "ending_type",
    "ending_title",
    "ending_message"
  ],
  "STORY_ROUTE_OUTPUT_FIELDS": [
    "id",
    "criteria",
    "automatic",
    "fallback",
    "default_mode",
    "next_objective_id",
    "target_input_group_id",
    "completion_instruction",
    "dialogue_lines",
    "requirements",
    "rewards",
    "travel_location_id",
    "travel_location_name",
    "ending_type",
    "ending_title",
    "ending_message"
  ],
  "STORY_SHOP_COMMON_FIELDS": [
    "id",
    "title",
    "type",
    "subtype",
    "description",
    "summary",
    "unlocked",
    "currency",
    "location",
    "npc_location_id",
    "owner_npc_id",
    "visible_count",
    "generic_jobs_enabled",
    "items",
    "owner_generator"
  ],
  "STORY_SHOP_BUYING_FIELDS": [
    "enabled",
    "quest_items_rejected"
  ],
  "STORY_EMBEDDED_CHARACTER_FIELDS": [
    "version",
    "id",
    "name",
    "source",
    "creation_tool",
    "nsfw",
    "loli",
    "can_die",
    "romanceable",
    "shop_owner_category",
    "gender",
    "fallback_gender",
    "fallback_name",
    "fallback_outfits",
    "fallback_starting_outfit_id",
    "age",
    "role",
    "personality_description",
    "speech_style",
    "boldness",
    "starting_relationship_to_player",
    "starting_trust",
    "starting_attraction",
    "starting_affection",
    "starting_arousal",
    "starting_state_of_mind",
    "starting_physical_state",
    "starting_pose",
    "appearance",
    "outfits",
    "starting_outfit_id",
    "starting_held_items",
    "starting_inventory",
    "starting_known_facts",
    "starting_nsfw_known_facts",
    "stats",
    "default_seed",
    "image_prompt_config",
    "default_profile_image",
    "profile_image_presentations",
    "profile_images",
    "images",
    "voice",
    "created_at",
    "updated_at"
  ],
  "STORY_EMBEDDED_CHARACTER_REQUIRED_FIELDS": [
    "version",
    "id",
    "name",
    "source",
    "creation_tool",
    "nsfw",
    "loli",
    "can_die",
    "romanceable",
    "gender",
    "fallback_name",
    "fallback_outfits",
    "fallback_starting_outfit_id",
    "age",
    "role",
    "personality_description",
    "speech_style",
    "boldness",
    "starting_relationship_to_player",
    "starting_trust",
    "starting_attraction",
    "starting_affection",
    "starting_arousal",
    "starting_state_of_mind",
    "starting_physical_state",
    "starting_pose",
    "appearance",
    "outfits",
    "starting_outfit_id",
    "starting_held_items",
    "starting_inventory",
    "starting_known_facts",
    "default_seed",
    "image_prompt_config",
    "default_profile_image",
    "profile_image_presentations",
    "profile_images",
    "images",
    "voice",
    "created_at",
    "updated_at"
  ],
  "STORY_INVENTORY_ITEM_FIELDS": [
    "id",
    "name",
    "type",
    "quantity",
    "value",
    "sellable",
    "quest_item",
    "description",
    "image_prompt",
    "image_id",
    "image"
  ],
  "STORY_TITLE_CARD_STORE_FIELDS": [
    "id",
    "at",
    "source",
    "reason",
    "title",
    "prompt",
    "negativePrompt",
    "seed",
    "model",
    "html",
    "url",
    "hosted_url",
    "favorite",
    "pending",
    "error",
    "forceSfw",
    "nsfwMode",
    "smoke_test_artifact",
    "story_key",
    "story_id",
    "story_title",
    "story_source",
    "upload_attestation_classification",
    "upload_attested_by",
    "upload_attested_at",
    "upload_attestation_policy_version"
  ],
  "STORY_TITLE_CARD_STORE_REQUIRED_FIELDS": [
    "id",
    "at",
    "source",
    "reason",
    "title",
    "prompt",
    "negativePrompt",
    "seed",
    "model",
    "html",
    "url",
    "hosted_url",
    "favorite",
    "pending",
    "error",
    "forceSfw",
    "nsfwMode",
    "smoke_test_artifact",
    "story_key",
    "story_id",
    "story_title",
    "story_source"
  ],
  "MAIN_PLOT_POINT_FIELDS": [
    "id",
    "title",
    "kind",
    "order",
    "status",
    "objective_id",
    "trigger",
    "rewards",
    "unlock_notice_shown",
    "last_readiness_message_id"
  ],
  "MAIN_PLOT_POINT_TRIGGER_FIELDS": [
    "at_elapsed_minutes",
    "objective_id",
    "readiness_guidance"
  ]
}
```
