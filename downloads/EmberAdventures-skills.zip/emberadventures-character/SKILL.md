---
name: emberadventures-character
description: Authoritative base skill for EmberAdventures character definitions. Use directly for characters, preference intake, proposals, character JSON creation, review, repair, and library maintenance.
---

# EmberAdventures Character

This package preserves the character workflow and contract with linked resources.

## Required references

- Before creating or repairing JSON, read [character-contract.md](references/character-contract.md).
  The complete validated export is [reference-character.json](references/reference-character.json).
- For design, proposals or library review, read [authoring-guide.md](references/authoring-guide.md).
- For preference intake or an existing private preference file, read [preferences.md](references/preferences.md).
- For numerical appearance wording, use [body-scales-0-20.md](references/body-scales-0-20.md).
- Story placement and differences belong to the Story skill; retain that skill's authority.

The package is self-contained. Its optional validator invokes a local normal
EmberAdventures checkout; ordinary authoring does not require cloning game source.

## Skill Maintenance

This section is for guidance on maintaining/updating this skill, and is not applicable when just using the skill.

This skill is for only character information. Do not mention anything that is only related to character definitions when they are in story files. All differences between this skill (standalone characters) and story-embedded characters must be described in the story file.  Do not talk about it at all in this skill. This skill is for creating standalone characters. Story embeded characters are created with this skill as well, but then need to be modified to fit into the story.  The story file is the authoritative source for story-embedded characters, and this skill is the authoritative source for standalone characters.

## Version and Update Check

Current skill version: `1.0.36`.

The complete public distribution is the [EmberAdventures skills ZIP](https://github.com/andro951/ember-adventures-tools/raw/refs/heads/main/downloads/EmberAdventures-skills.zip).
Version information is inside each SKILL.md and the bundle manifest.json.
Before using this skill, compare the installed version with the same skill's
version in the archive manifest. If the installed version is older, ask for
permission to download the new version unless the user has already authorized
updating. Continue with the older version only if the user chooses to use it.
Recommend updating before creating or editing characters because a stale
contract can produce invalid exports. Keep private preferences when updating.

## Model Quality Recommendation

Before working on the character json file, if the current model and
reasoning/intelligence/effort level are known to be below 5.6 Terra Medium, tell the
creator that 5.6 Terra Medium or higher is recommended and will likely produce a better
character. 5.6 Sol High is likely the best option for the highest quality results. Going
higher than High effort is unlikely to produce significantly better results, and is waistful
for the user's paid usage. If higher than High effort, strongly suggest to reduce to High
effort. This is a quality recommendation, not a hard gate; character creation should still
work on lower models unless the output is visibly invalid.

## Workflow Modes

Default workflow:

- Read preferences.
- Ask only missing or ambiguous preferences relevant to the request.
- Infer the rest from preferences and the prompt.
- Propose a few suitable options.
- Let the user review, select, request changes, or request more options.
- Create the final character after approval/selection.
- After user feedback, distinguish general preference updates from character-specific revisions.

Do not ask a standalone workflow-mode question during initial setup. Explain the default proposal-review-approval workflow in the main setup message and tell the user they can propose a different workflow if they dislike it. Save any user-provided override to preferences and obey it; direct creation is valid when the saved preference or current request asks for it.

If the user asks for proposed changes before editing, list exact planned changes with old value -> new value and wait for approval before editing.

## Final Deterministic Validation

Before returning any character file, validate every entry in the batch using
this checklist. Do not call an entry finished until all checks pass:

1. The export wrapper is correct: one definition uses `character_definition`; a
   batch uses `characters[]` containing those wrappers; no app/type/export
   marker fields are present.
2. Required metadata exists and is valid: `source` is non-null, original
   entries use `"Original"`, `creation_tool` is factual rather than copied from
   an example, `genres` is approved where required, and `nsfw`, `loli`, and
   `can_die` are booleans.
3. `version` is numeric, `id` is stable, `name` is a proper display name, and
   `age` is an integer. Paired loli/adult entries are created only when
   requested or required by saved preferences, and both keep the same plain
   name without variant suffixes.
4. `boldness` is either a number from 1 to 10 or a non-empty descriptive
   string. Numeric `0` and all other out-of-range numeric values are rejected.
   Text boldness contains behavior only and does not contain score annotations.
5. `voice` is exactly `null`; no inferred or invented TTS metadata is present.
6. `created_at` and `updated_at` are real ISO 8601 timestamps. Existing
   `created_at` is preserved; `updated_at` changes only when the definition
   changes.
7. `outfits` is a non-empty array, every outfit has a unique stable `id` and
   coherent clothing object and explicit boolean `nsfw`, and
   `starting_outfit_id` matches an outfit id. SFW characters have SFW starting
   outfits and at least one SFW outfit in both presentations.
   Every outfit includes all intended visible and inner clothing layers.
   Animal or natural-form outfits use concrete body-covering slot values and
   never use `{}` as placeholder clothing.
   `active_outfit_id` and other runtime clothing fields are absent.
8. Body fields contain body information only, `extra_description` contains
   only additional durable visuals, and no appearance fact is duplicated across
   body, hair/skin/eye, extra-description, personality, or clothing fields. The
   final assembled image prompt has been reviewed, and `extra_description` is a
   concise remainder rather than copied body-design prose or narrative text.
   `nonhuman_lower_body` is a real boolean; when true,
   `extra_description_lower_body` contains a concise concrete replacement-body
   description and does not repeat numeric hips or legs. When false, the lower
   description is either blank or contains only a concrete humanoid lower-body
   detail that does not belong in another structured field.
9. All image metadata is blank exactly as shown in the canonical example:
   no image ids, URLs, prompts, styles, ownership, or invented image data is
   present; `default_profile_image.source` is `"none"`; `seed_enabled` is
   `true`; and both exported `negative` fields are present but empty.
10. Reusable definitions contain no current relationship/state/location,
   active outfit, current inventory, current known facts, scene membership,
   inspection, invite, death, or image-inclusion fields.
11. The entry contains no hidden process instructions, future unlock notes,
    story spoilers, or creator workflow text in player-visible character fields.
12. Batch names, ids, surnames, jobs, facts, personality wording, body language,
    inventory, and outfits are checked against the relevant existing library
    and against all entries in the current batch for accidental repetition.
13. The body-scale portion of `appearance` contains exactly the eleven current
    keys, each as an integer from 0 through 20. The seven legacy appearance keys
    are absent. Chest uses the correct canonical presentation table. Replacement
    nonhuman lower bodies retain all required numbers but suppress only the four
    inapplicable lower-body traits during prompt projection.
14. `creator`, `creator_id`, `short_description`, `creator_notes`,
    `character_version`, `consent_state`, and all other forbidden or obsolete
    fields are absent.
15. `starting_nsfw_known_facts` is an array, contains only adult-only durable
    facts, and duplicates none of `starting_known_facts`. Loli and under-18
    characters have no NSFW facts or outfits.
16. `catalog_hook` is a string containing an accurate, spoiler-free standalone
    catalog pitch, or `""`. It is omitted from story-embedded characters.
17. `default_image_background`, when present, is a trimmed nonempty string that
    describes only a suitable environment for solo standalone-character images.
    It is omitted rather than blank when unused, never overrides an explicit
    story/scene/location/user setting, and is omitted from story-embedded characters.
18. Optional Chat scenario fields use their exact shapes: `chat_story` and
    `chat_opening_message` are strings; `chat_starting_location` contains only
    `label`, `place`, and `activity`, which are either all nonblank or all blank.
    The opening never controls the player, the scenario is safe for player inspection,
    and the three fields describe one coherent starting situation.
    `chat_story_template` is either `null` or only a complete inner `storyTemplate`
    object created and validated under the EmberAdventures Story skill. It may coexist
    with the lightweight fields because Full Story and Just Chat are separate launch
    choices.

## Library Maintenance

When asked to maintain an original character library, support:

- metadata repair
- schema validation
- duplicate detection
- repetitive phrasing cleanup
- source/creation_tool/genres/nsfw/loli/can_die backfill
- style consistency
- species/variant balance review
- relationship/default-state consistency
- moving rejected entries aside without deleting unless asked


## Story Shop / Job Board Characters

When this skill is used to create characters for an EmberAdventures story shop, job
board, slave market, companion shop, auction, guild counter, or generated-job
role pool, create full normal character definitions. Do not output placeholder
labels such as `shopkeeper`, `worried baker`, `guild clerk`, or `slave girl`.
Owners, clients, witnesses, rivals, purchasable characters, and talkable shop
characters need real names, roles, personalities, speech styles, outfits,
appearance, and durable facts. The story skill should reference these
definitions from `future_cast`/NPC placement instead of duplicating them inside
shop item records.

For large-shop-stock mode, distinguish depth tiers:

- major/fixed story companions and important shop owners need full character
  depth, usually 6-10 concrete durable facts;
- ordinary purchasable/talkable stock characters should be compact but
  playable, usually 3-5 concrete durable facts plus a specific role, species or
  species/variant, appearance, outfit, personality, speech style, intended shop/stock
  category, unlock requirement when known, and a post-purchase or
  post-introduction hook;
- generated job-role NPCs such as recurring bakers, clerks, witnesses, or
  rivals can be shorter, but still need a proper name, real appearance, outfit,
  personality, speech style, and one reusable job-scene hook.

Do not make hundreds of stock characters main-character-length, but also do not
make them anonymous archetypes. They must be distinct enough that the player can
inspect, talk to, buy/recruit, remember, and use them in scenes.


## Optional canonical validation

`node scripts/validate-content.cjs <absolute-normal-EA-repository> <export.json> [...]`

This reports the game's real validation result without repairing or modifying files.
Without a checkout, use the references and test the export through the game import UI.

## Distribution and maintenance

Publish user-facing skill updates only as the complete ZIP bundle. Keep editable
skill folders locally; do not publish loose skill files or separate version files.
After any change, update the installed copies, validate the affected references and
scripts, rebuild the ZIP and its manifest, update archive links, and push the ZIP.
The package includes maintainer/package_skills.py for rebuilding both bundles.
Never include private preferences, personal data, tokens, caches or test output.
