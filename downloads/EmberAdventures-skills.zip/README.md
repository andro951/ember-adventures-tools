# EmberAdventures authoring skills

Extract this archive before use. Install the two named skill folders into your
Codex skills directory, or provide their instructions and required references
to an assistant as ordinary files. Start with each SKILL.md and follow its links.
For stories, load both character and story skills.

The references include full JSON examples and canonical field snapshots.
The optional character scripts/validate-content.cjs helper accepts the matching
local game checkout and one or more exported JSON files; it never repairs them.
The archive is not a game build and contains no personal preferences.

Public distribution is ZIP-only. After skill maintenance, validate resources,
update installed copies, rebuild using maintainer/package_skills.py, replace the
matching archive under downloads/ in ember-adventures-tools and skills/ in the
game repository, then push. Do not publish extracted folders or version files.
For a single extracted bundle, use --source <extracted-root> --kind normal.
Use --help for explicit source, destination and optional validation/install paths.

Versions:
- emberadventures-character: 1.0.40
- emberadventures-story: 1.0.75