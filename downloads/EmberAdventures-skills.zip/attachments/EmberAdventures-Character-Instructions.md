# EmberAdventures character instructions

Target EmberAdventures Full. Use this file as your complete authoring instructions.

Use the Full field lists below. Set the exact content classification fields based on the actual content. Match the creator's requested boundaries and retain required defaults from the example where appropriate. Omit the legacy lite marker.

## EmberAdventures character authoring

Produce an importable character definition after the player approves the concept. Start with intended role, personality, species, age, gender, and story hook. Ask only for details that change the result. For an original character use "Original" as source. Give the real generation tool as creation_tool. Keep process notes, rejected alternatives, private player preferences, and setup instructions outside JSON.

## Character intake

If you need the creator to choose a character's gender, ask “What gender is the character?” or “What gender is [name]?” Skip the question if the creator already specified the gender or left it for you to choose. Use the gender they give you as the character's authored gender. Handle any required alternate names, appearance, outfits, and engine fields yourself according to the edition and the creator's stated constraints. Keep terms such as “presentation,” “non-male,” and “fallback gender” out of intake questions and proposals.

## Definition

- A single export is an object containing character_definition. A batch is an object containing characters, an array of those same single-export wrappers. Use the exact case-sensitive keys listed below and one of the validated examples as your structural baseline.
- Give each record a stable unique ID and a believable name. Distinguish what they want, what they fear losing, a boundary, how they talk, and why a player would want to interact. Keep the catalog hook short. Role and appearance are visible facts. Personality and knowledge belong in their own fields. Use zero for relationship meters when strangers have no existing bond. The starting_* fields initialize play. Avoid runtime fields such as clothing at the definition root, current meters, timestamps from someone's save, or speaker and scene state.
- Use an exact whole-number age. For editable personality sliders such as boldness, use the scale required by the example or a specific custom description where allowed. Appearance uses the named 0–20 scales or a concise custom descriptor as allowed by the engine. Ten is the midpoint. Choose a coherent build and preserve the numeric values during conversion. Use the structured fields for anatomy and describe only additional visible features in prose.
- Set a primary and an alternate presentation when the character supports both. Supply a suitable name and outfit for each. Use gender tokens in story text for a character whose presentation can change. Keep the specified canonical presentation for a fixed character. Prefer structured hair color, length and texture, and the supported alternate hairstyle fields. Keep face and defining details recognizable across presentations.
- Specify a color for every visible clothing item, in both presentations. Choose clearly wearable outer clothes and footwear suitable for the environment. Use concise garment names, cut and fabric. Model layers using the exact clothing slots. Use null for an unused slot when filling a complete clothing object. Keep held objects in the hand fields. Define outfit IDs once and point the starting outfit fields to valid outfit IDs.
- Inventory items and stats must follow the canonical structures. Give the character possessions with a reason to exist. Keep appearance, props, clothes, and action separate for predictable images. Use the example's empty profile-image slots for generated or missing portraits. Include an actual image URL only when supplied or verified. Never invent an image URL, portrait ID or storage pointer.
- For Character Chat, write a single opening message with someone or something to react to. If there is an embedded playable story, use the story template object in chat_story_template. It contains its own opening, starting cast, and objectives. Character Chat and Play Story use different opening fields.
- For an animal definition use definition_type "animal", its own exact field set, a species, and physical_description. Use its species-appropriate behavior, communication and basic state. Leave humanoid appearance and wardrobe fields out of animal definitions.
- Story-embedded humanoids use the embedded-character field list instead of the standalone public catalog fields. Give them the same depth and a distinct role. Write all identities and references consistently.

## Validation

Before handing off, parse the exact resulting JSON and check required fields, permitted keys, legal enums, age, stable IDs, wardrobe references, wrapper shape, and edition. Validate in the target game where available, fix the source file, and validate again. Report which checks actually ran. A JSON parser checks syntax. A game import tests the actual content contract.

## EmberAdventures story authoring

Build a playable story around a clear player role, a promise, an immediate situation, and choices with consequences. For a larger story, capture the creator's intent, scope, working location, and playable outcomes before producing JSON. For a small scenario with an explicit premise, resolve only genuinely missing decisions. Provide a story JSON file with exact case-sensitive fields and share concrete validation results separately.

## Opening and agency

- Write an opening as one assistant message. Put the player in a comprehensible place, give them something concrete to notice or react to, and leave at least two genuinely different actions available. A quiet opening can give the player a warm encounter or a specific invitation. Avoid choosing the player's actions or feelings. Make the first few turns deliver the promise of the library card. A sandbox objective may stay open while the player explores other viable leads.
- Start with a playable problem, opportunity, or relationship. Supply facts the player can act on, especially spatial facts for exploration and tactical roles. The player should be deciding what to do with the information. Keep explanations short and layer in history when it becomes relevant.
- Use |[player_name]| or |[player_first_name]| to address the selected player and |[character:stable-character-id]| for an NPC whose name can vary. Keep IDs stable across presentations. Keep content visible to the player free of spoiler notes, branch mechanics, and future cast metadata.

## Envelope and starting state

- Use the validated story example. The outer app is "EmberAdventures" and exportType is "story-template". Inside storyTemplate, app is "EmberAdventures" and templateType is "story". Both editions use these values. Put authored metadata, the opening and state inside storyTemplate.
- A story with selectable library protagonists uses allow_any_player. An optional any_player_starting_state can apply authored starting-story data when requested by the creator. Leave the example's null value when no overlay is needed. Avoid overwriting a player outfit by accident. Author all starting options with the same depth and coherence. Use exact stable IDs and player references.
- Place the default player in state.player, alternate authored players in state.players, starting companions in state.characters, local NPC records in state.npc_directory, and unrevealed cast in state.future_cast. The NPC directory associates named identities with locations. Physical scene membership is separate from stored location and party membership. Only present actors belong in the opening scene and image targets. Put future identities only where the current story can safely withhold them.
- The initial world map and location should agree with scene, time, named NPC rooms, and opening. Place authored locations on their appropriate hex layers, keeping believable travel distances and meaningful unexplored space. Do not invent map field aliases or put unvisited locations into starting player knowledge. Put actual story currency, supplies, equipment and starting resources in their respective fields. An economy needs its currency named in story metadata and a matching inventory record. Keep process notes and engine session values out of story definitions.

## Objective and reward flow

- Author a clear opening objective with a visible summary and an exact private completion condition. Explain what counts as concrete progress. Give normal narration only information the relevant scene can know. Put actions after completion in the correct completion or transition fields, rather than asking the narrator to simulate state effects.
- Use player control for a player action, AI control for a plot event the narrator may initiate, and choice control for explicit options. Use evidence requirements and meaningful alternate outcomes when an action can legitimately fail or be refused. Complete solely when supported by the action or scene. Avoid forced lockstep progression unless the intended experience needs it.
- Use numeric requirements for real mechanical thresholds, authored rewards for mutations, ordered authored output IDs for branching, and the supported ending fields for conclusions. Reuse IDs consistently across state graph, routes, rewards, and journal references. Check for unintentional loops, dangling routes and single unreachable branches.
- Include one concrete payoff early, a clear next opportunity, and a coherent resolution or explicit freeplay handoff. For a sandbox, authored state gives the narrator enough to respond well even when the player ignores the tracked objective.
- Optional systems include jobs, timed events, maps, character schedules, property, combat, and stat sharing. Start with the schema for the selected edition. Use optional fields only for systems the creator wants. For a complicated feature whose type or layout is unclear, ask for a current game export that already uses that feature before adding it. Preserve unrelated authored systems and save identity when editing an existing story.

## Embedded characters

Apply the character rules and exact embedded field sets below to every humanoid and animal, including future cast and alternate players. Characters should have their own immediate goals, knowledge, clothing, speech, and reactions. Resolve gender tokens against their chosen presentations. Names and IDs in NPC directory, party, effects, opening text and map data must refer to the intended individual.

## Validation

Parse the resulting JSON and check exact fields, IDs, types, references, time, cast visibility, openings, objective transitions and endings. Verify actual import and story start when available. Check the natural first action and a reasonable alternative against what the objective accepts. Report each completed check accurately.

## Exact character field lists

Use only keys in the list for the object you are authoring. A list of allowed keys does not make all of its keys required.

- CHARACTER_SHOP_COST_TEMPLATE_FIELDS
  type, costs, effects

- CHARACTER_SHOP_COST_FIELDS
  label, available_expression, op, required_stat

- CHARACTER_SHOP_EFFECT_FIELDS
  label, operation, field_path, value_stat

- CHARACTER_DEFINITION_FIELDS
  version, id, name, source, creation_tool, catalog_hook, genres, kink_tags, nsfw, loli, can_die, romanceable, shop_owner_category, gender, fallback_gender, fallback_name, fallback_outfits, fallback_starting_outfit_id, age, role, personality_description, speech_style, boldness, starting_relationship_to_player, starting_trust, starting_attraction, starting_affection, starting_arousal, starting_state_of_mind, starting_physical_state, starting_pose, appearance, outfits, starting_outfit_id, starting_held_items, starting_inventory, starting_known_facts, starting_nsfw_known_facts, chat_story, chat_opening_message, chat_starting_location, chat_story_template, stats, default_seed, default_image_background, image_prompt_config, default_profile_image, profile_image_presentations, profile_images, images, voice, created_at, updated_at

- CHARACTER_REQUIRED_FIELDS
  version, id, name, source, creation_tool, genres, nsfw, loli, can_die, romanceable, gender, fallback_name, fallback_outfits, fallback_starting_outfit_id, age, role, personality_description, speech_style, boldness, starting_relationship_to_player, starting_trust, starting_attraction, starting_affection, starting_arousal, starting_state_of_mind, starting_physical_state, starting_pose, appearance, outfits, starting_outfit_id, starting_held_items, starting_inventory, starting_known_facts, default_seed, image_prompt_config, default_profile_image, profile_image_presentations, profile_images, images, voice, created_at, updated_at

- ANIMAL_DEFINITION_FIELDS
  version, id, name, source, creation_tool, can_die, gender, shop_owner_category, age, role, species, physical_description, personality_description, communication_style, starting_relationship_to_player, starting_trust, starting_affection, starting_state_of_mind, starting_physical_state, starting_pose, starting_known_facts, stats, default_seed, image_prompt_config, default_profile_image, profile_image_presentations, profile_images, images, voice, created_at, updated_at

- ANIMAL_DEFINITION_REQUIRED_FIELDS
  version, id, name, source, creation_tool, can_die, gender, age, role, species, physical_description, personality_description, communication_style, starting_relationship_to_player, starting_trust, starting_affection, starting_state_of_mind, starting_physical_state, starting_pose, starting_known_facts, created_at, updated_at

- CHARACTER_APPEARANCE_SCALE_FIELDS
  height, shoulder_width, chest, upper_body_build, midsection_build, hip_width, butt_build, lower_body_build, arm_length, leg_length, penis_size

- CHARACTER_APPEARANCE_FIELDS
  species, height, shoulder_width, chest, upper_body_build, midsection_build, hip_width, butt_build, lower_body_build, arm_length, leg_length, penis_size, skin_color, eye_color, hair_color, hair_length, hair_type, fallback_hair, extra_description, extra_description_lower_body, male_only_extra_description, non_male_only_extra_description, nonhuman_lower_body

- CHARACTER_APPEARANCE_REQUIRED_FIELDS
  species, height, shoulder_width, chest, upper_body_build, midsection_build, hip_width, butt_build, lower_body_build, arm_length, leg_length, penis_size, skin_color, eye_color, hair_color, hair_length, hair_type, extra_description, extra_description_lower_body, nonhuman_lower_body

- CHARACTER_OUTFIT_FIELDS
  id, name, nsfw, clothing

- CHARACTER_CLOTHING_FIELDS
  hat, hair_accessory, face, ears, neck, shoulders, bra, undershirt, shirt, over_shirt, coat, back, hands, right_wrist, left_wrist, right_fingers, left_fingers, waist, belt_accessory, underwear, pants, skirt, legwear, socks, feet, other_accessory

- CHARACTER_HELD_ITEM_FIELDS
  right_hand, left_hand

- CHARACTER_CHAT_STARTING_LOCATION_FIELDS
  label, place, activity

- CHARACTER_IMAGE_PROMPT_FIELDS
  seed_enabled, seed, style, profile_style, negative, negative_prompt

- CHARACTER_PROFILE_IMAGE_SLOT_FIELDS
  url, local_image_id, source, seed, prompt, negative_prompt, note, male, nsfw

- CHARACTER_PROFILE_IMAGE_SLOT_REQUIRED_FIELDS
  url, local_image_id, source, seed, prompt, negative_prompt, note, male

- CHARACTER_PROFILE_PRESENTATION_FIELDS
  male, non_male

- CHARACTER_IMAGE_COLLECTION_FIELDS
  active_image_id, image_ids

- CHARACTER_STARTING_INVENTORY_ITEM_FIELDS
  id, name, note, description, type, quantity, value, sellable, quest_item, image_prompt, image_id, image

## Exact story field lists

Use only keys in the list for the object you are authoring. A list of allowed keys does not make all of its keys required.

- STORY_EXPORT_FIELDS
  app, exportType, storyTemplate, exportedAt

- STORY_TEMPLATE_FIELDS
  id, title, description, createdAt, updatedAt, allow_any_player, any_player_starting_state, state, messages, source, app, templateType, creation_tool, genres, kink_tags, nsfw, loli, default_image_model, editor_data, title_card_subjects, title_card_image

- STORY_TEMPLATE_REQUIRED_FIELDS
  id, title, description, createdAt, updatedAt, allow_any_player, any_player_starting_state, state, messages, source, app, templateType, creation_tool, genres, kink_tags, nsfw, loli, default_image_model, title_card_subjects, title_card_image

- STORY_STATE_FIELDS
  meta, location, world_map, time, scene, player, players, characters, npc_directory, future_cast, objectives, story_inventory, story_shops, story_job_offers, story_job_offer_history, active_generated_jobs, story_generated_npc_pool, story_rules, story_memory, recent_changes, story_clock, story_pacing, timed_events, progression, numeric_precision, reward_templates, reward_bundles, character_shop_cost_templates, player_home, combat, character_schedules, spoken_abilities

- STORY_STATE_REQUIRED_FIELDS
  meta, location, world_map, time, scene, player, characters, npc_directory, objectives, future_cast, story_rules, story_memory, recent_changes, story_clock, story_pacing, timed_events

- STORY_META_FIELDS
  app, story_guidance, story_source, genres, kink_tags, loli, default_image_model, stat_display, player_stat_display, currency

- STORY_META_REQUIRED_FIELDS
  app, story_guidance, story_source, genres, kink_tags, loli

- STORY_SOURCE_FIELDS
  mode, title, description, modifications

- STORY_LOCATION_FIELDS
  universe, world, continent, region, settlement_type, settlement_name, district, specific_place, npc_location_id

- STORY_WORLD_MAP_FIELDS
  current_location_id, focus_location_id, travel_history, locations, hex_layout

- STORY_WORLD_LOCATION_FIELDS
  id, name, type, scale, parent_id, x, y, discovered, travel_enabled, summary, detail, connections, npcs, hidden_description

- STORY_TIME_FIELDS
  year, month, day, hour, minute

- STORY_SCENE_FIELDS
  summary, intimacy_level, spicy_mode, party_members_present, image_characters, npcs_present, speak_targets, image_action, sex_position, ai_sex_position, sex_acts

- STORY_SCENE_REQUIRED_FIELDS
  summary, intimacy_level, spicy_mode, party_members_present, image_characters, npcs_present, image_action, sex_position, ai_sex_position, sex_acts

- STORY_OBJECTIVE_STATE_FIELDS
  active_id, no_current, items

- STORY_MESSAGE_FIELDS
  role, speaker, text, nsfwMode, at

- STORY_TITLE_CARD_IMAGE_FIELDS
  id, title, prompt, negativePrompt, seed, model, source, url, hosted_url, html, favorite, nsfw, upload_attestation_classification, upload_attested_by, upload_attested_at, upload_attestation_policy_version

- STORY_TITLE_CARD_IMAGE_OPTIONAL_FIELDS
  nsfw, upload_attestation_classification, upload_attested_by, upload_attested_at, upload_attestation_policy_version

- STORY_EDITOR_DATA_FIELDS
  story_tree

- STORY_EDITOR_TREE_FIELDS
  positions, viewport, output_modes

- STORY_EDITOR_TREE_REQUIRED_FIELDS
  positions, viewport

- STORY_EDITOR_VIEWPORT_FIELDS
  x, y, zoom

- STORY_MEMORY_FIELDS
  world_notes, unresolved_threads, relationship_notes, rules_and_constraints, ai_private_notes

- STORY_CLOCK_FIELDS
  elapsed_minutes, label

- STORY_PACING_FIELDS
  mode, pending_event_id, timeline, interruptions, abandonments

- STORY_TIMELINE_EVENT_FIELDS
  id, title, status, objective_id, trigger, prompt, accept, decline, missed_due_to_conflict, on_ready, auto_start, queued_order

- STORY_TIMELINE_TRIGGER_FIELDS
  at_elapsed_minutes, objective_id

- STORY_TIMELINE_PROMPT_FIELDS
  message, accept_label, decline_label

- STORY_TIMELINE_ACTION_FIELDS
  objective_id, message, rewards, travel_to_location_id

- STORY_TIMED_EVENT_FIELDS
  id, title, status, visibility, trigger, time_limit, cancel_objective_id, message, stages, rewards

- STORY_TIMED_EVENT_TRIGGER_FIELDS
  objective_id, immediately

- STORY_DURATION_FIELDS
  days, hours, minutes

- STORY_TIMED_EVENT_STAGE_FIELDS
  id, after, visibility, message, rewards

- STORY_FUTURE_CAST_FIELDS
  enabled, items

- STORY_FUTURE_CAST_ITEM_FIELDS
  id, name, status, canonical_order, introduce_as, can_die, npc_location_id, location_hint, scene_presence, role, relationship, note, personality_description, greeting, full_character, animal_definition, meet_condition, join_condition, on_unlock, unlocked_by, last_triggered_reason, on_purchase_objective, fallback_name, outfits, fallback_outfits, starting_outfit_id, fallback_starting_outfit_id

- STORY_FUTURE_CAST_ON_UNLOCK_FIELDS
  greeting, image

- STORY_FUTURE_CAST_UNLOCK_IMAGE_FIELDS
  id, title, prompt, negative_prompt, seed, model, source, url, favorite

- STORY_NPC_DIRECTORY_FIELDS
  locations

- STORY_NPC_LOCATION_FIELDS
  label, characters

- STORY_NPC_FIELDS
  id, name, gender, age, role, relationship, note, current_appearance, inspected, voice, full_character, animal_definition, status, death_note, killed_by_player, killed_by, player_known_name, player_facing_label, can_die, stats

- STORY_RULE_FIELDS
  id, text

- STORY_OBJECTIVE_FIELDS
  id, title, type, status, summary, while_active_guidance, completion_control, completion_criteria, completion_instruction, dialogue_lines, requires, completion_requirements, next_objectives, choices, choice_response_mode, route_control, unresolved_route_behavior, outcome_routes, evaluate_ai_on_activation, requirement_check_only, exclusive_group, selectable, locked_until_complete, time_window_minutes, available_now, blocked_reason, notes, completion_message, travel_location_id, travel_location_name, rewards, abandonment

- STORY_NEXT_OUTPUT_FIELDS
  id, objective_id, target_input_group_id, completion_instruction, dialogue_lines, requirements, rewards, travel_location_id, travel_location_name, fallback, ending_type, ending_title, ending_message

- STORY_CHOICE_OUTPUT_FIELDS
  id, title, summary, player_text, next_objective_id, target_input_group_id, completion_instruction, dialogue_lines, requirements, rewards, travel_location_id, travel_location_name, effects, open_shop_id, defer, ending_type, ending_title, ending_message

- STORY_ROUTE_OUTPUT_FIELDS
  id, criteria, automatic, fallback, default_mode, next_objective_id, target_input_group_id, completion_instruction, dialogue_lines, requirements, rewards, travel_location_id, travel_location_name, ending_type, ending_title, ending_message

- STORY_SHOP_COMMON_FIELDS
  id, title, type, subtype, description, summary, unlocked, currency, location, npc_location_id, owner_npc_id, visible_count, generic_jobs_enabled, items, owner_generator

- STORY_SHOP_BUYING_FIELDS
  enabled, quest_items_rejected

- STORY_EMBEDDED_CHARACTER_FIELDS
  version, id, name, source, creation_tool, nsfw, loli, can_die, romanceable, shop_owner_category, gender, fallback_gender, fallback_name, fallback_outfits, fallback_starting_outfit_id, age, role, personality_description, speech_style, boldness, starting_relationship_to_player, starting_trust, starting_attraction, starting_affection, starting_arousal, starting_state_of_mind, starting_physical_state, starting_pose, appearance, outfits, starting_outfit_id, starting_held_items, starting_inventory, starting_known_facts, starting_nsfw_known_facts, stats, default_seed, image_prompt_config, default_profile_image, profile_image_presentations, profile_images, images, voice, created_at, updated_at

- STORY_EMBEDDED_CHARACTER_REQUIRED_FIELDS
  version, id, name, source, creation_tool, nsfw, loli, can_die, romanceable, gender, fallback_name, fallback_outfits, fallback_starting_outfit_id, age, role, personality_description, speech_style, boldness, starting_relationship_to_player, starting_trust, starting_attraction, starting_affection, starting_arousal, starting_state_of_mind, starting_physical_state, starting_pose, appearance, outfits, starting_outfit_id, starting_held_items, starting_inventory, starting_known_facts, default_seed, image_prompt_config, default_profile_image, profile_image_presentations, profile_images, images, voice, created_at, updated_at

- STORY_INVENTORY_ITEM_FIELDS
  id, name, type, quantity, value, sellable, quest_item, description, image_prompt, image_id, image

- MAIN_PLOT_POINT_FIELDS
  id, title, kind, order, status, objective_id, trigger, rewards, unlock_notice_shown, last_readiness_message_id

- MAIN_PLOT_POINT_TRIGGER_FIELDS
  at_elapsed_minutes, objective_id, readiness_guidance

## Validated character example

```json
{
  "character_definition": {
    "version": 1,
    "id": "character-aren-valehart",
    "name": "Aren Valehart",
    "source": "Original",
    "creation_tool": "Codex",
    "genres": [
      "fantasy",
      "adventure",
      "romance"
    ],
    "can_die": false,
    "romanceable": true,
    "gender": "male",
    "fallback_name": "Arenna Valehart",
    "fallback_outfits": [
      {
        "id": "travel",
        "name": "Trail Tracker Gear",
        "clothing": {
          "hat": null,
          "hair_accessory": null,
          "face": null,
          "ears": null,
          "neck": "carved amber animal-trail pendant",
          "shoulders": null,
          "bra": null,
          "undershirt": "soft gray undershirt",
          "shirt": "forest-green field shirt",
          "over_shirt": null,
          "coat": "brown weatherproof tracker coat",
          "back": null,
          "hands": null,
          "right_wrist": null,
          "left_wrist": null,
          "right_fingers": null,
          "left_fingers": null,
          "waist": "dark brown leather tracking belt",
          "belt_accessory": null,
          "underwear": null,
          "pants": "reinforced charcoal trail trousers",
          "skirt": null,
          "legwear": null,
          "socks": "thick gray wool socks",
          "feet": "mud-caked brown hiking boots",
          "other_accessory": null
        },
        "nsfw": false
      },
      {
        "id": "town",
        "name": "Quiet Ranger Clothes",
        "clothing": {
          "hat": null,
          "hair_accessory": null,
          "face": null,
          "ears": null,
          "neck": "small bronze trail marker pendant",
          "shoulders": null,
          "bra": null,
          "undershirt": null,
          "shirt": "cream rolled-sleeve blouse",
          "over_shirt": null,
          "coat": "deep green long vest",
          "back": null,
          "hands": "dark brown fingerless field gloves",
          "right_wrist": null,
          "left_wrist": null,
          "right_fingers": null,
          "left_fingers": null,
          "waist": null,
          "belt_accessory": null,
          "underwear": null,
          "pants": null,
          "skirt": "opaque ankle-length brown walking skirt",
          "legwear": "opaque charcoal leggings",
          "socks": null,
          "feet": "clean black leather boots",
          "other_accessory": null
        },
        "nsfw": false
      }
    ],
    "fallback_starting_outfit_id": "travel",
    "age": 32,
    "role": "Monster tracker and conflict mediator",
    "personality_description": "|[character]| is a rugged human monster tracker who prefers resolving conflicts without killing misunderstood creatures. |[character_subject_pronoun_cap]| is quiet and observant, with a dry sense of humor that appears at unexpected moments. |[character_subject_pronoun_cap]| studies tracks, habits, and motives before drawing a weapon, but once |[character]| decides someone is in danger, |[character_subject_pronoun]| becomes difficult to move. |[character_subject_pronoun_cap]| worries that mercy can look like weakness to frightened communities and wants proof that patient protection can hold a town together.",
    "speech_style": "Sparse and grounded, with long pauses for observation, understated jokes, and plain language when a decision matters.",
    "boldness": 4,
    "starting_relationship_to_player": "not yet met",
    "starting_trust": 0,
    "starting_attraction": 0,
    "starting_affection": 0,
    "starting_state_of_mind": "quietly assessing tracks and listening for movement beyond the road",
    "starting_physical_state": "healthy adult human with the ordinary wear of a long trail",
    "starting_pose": "crouched beside a set of tracks, looking up only after finishing an observation",
    "appearance": {
      "species": "highland human",
      "height": 11,
      "skin_color": "weathered medium-brown skin",
      "eye_color": "gray-green",
      "hair_color": "dark brown",
      "hair_length": "neck length",
      "hair_type": "straight and wind-tossed",
      "fallback_hair": {
        "hair_length": "shoulder length"
      },
      "extra_description": "A broad, capable adult with a broken-nose profile, a neatly trimmed beard, and a patient gaze that misses very little.",
      "extra_description_lower_body": "",
      "nonhuman_lower_body": false,
      "shoulder_width": 13,
      "chest": 14,
      "upper_body_build": 14,
      "midsection_build": 13,
      "hip_width": 11,
      "butt_build": 13,
      "lower_body_build": 14,
      "arm_length": 10,
      "leg_length": 11,
      "penis_size": 10
    },
    "outfits": [
      {
        "id": "travel",
        "name": "Trail Tracker Gear",
        "clothing": {
          "hat": null,
          "hair_accessory": null,
          "face": null,
          "ears": null,
          "neck": "carved amber animal-trail pendant",
          "shoulders": null,
          "bra": null,
          "undershirt": "soft gray undershirt",
          "shirt": "forest-green field shirt",
          "over_shirt": null,
          "coat": "brown weatherproof tracker coat",
          "back": null,
          "hands": null,
          "right_wrist": null,
          "left_wrist": null,
          "right_fingers": null,
          "left_fingers": null,
          "waist": "dark brown leather tracking belt",
          "belt_accessory": null,
          "underwear": null,
          "pants": "reinforced charcoal trail trousers",
          "skirt": null,
          "legwear": null,
          "socks": "thick gray wool socks",
          "feet": "mud-caked brown hiking boots",
          "other_accessory": null
        },
        "nsfw": false
      },
      {
        "id": "town",
        "name": "Quiet Ranger Clothes",
        "clothing": {
          "hat": null,
          "hair_accessory": null,
          "face": null,
          "ears": null,
          "neck": "small bronze trail marker pendant",
          "shoulders": null,
          "bra": null,
          "undershirt": "soft cream undershirt",
          "shirt": "cream rolled-sleeve shirt",
          "over_shirt": null,
          "coat": "deep green long vest",
          "back": null,
          "hands": "dark brown fingerless field gloves",
          "right_wrist": null,
          "left_wrist": null,
          "right_fingers": null,
          "left_fingers": null,
          "waist": null,
          "belt_accessory": null,
          "underwear": null,
          "pants": "brown walking trousers",
          "skirt": null,
          "legwear": null,
          "socks": "opaque charcoal leggings",
          "feet": "clean black leather boots",
          "other_accessory": null
        },
        "nsfw": false
      }
    ],
    "starting_outfit_id": "travel",
    "starting_held_items": {
      "right_hand": null,
      "left_hand": null
    },
    "starting_inventory": [
      "tracker's notebook",
      "scent-masking herbs",
      "folding camp saw"
    ],
    "starting_known_facts": [
      "Aren tracks dangerous creatures and looks for peaceful solutions before recommending a hunt.",
      "Aren has earned the trust of several misunderstood creatures but remains cautious about promises made by frightened people."
    ],
    "stats": {},
    "default_seed": 0,
    "image_prompt_config": {
      "seed_enabled": true,
      "seed": 0,
      "style": "",
      "profile_style": "",
      "negative": "",
      "negative_prompt": ""
    },
    "default_profile_image": {
      "url": "",
      "local_image_id": "",
      "source": "none",
      "seed": null,
      "prompt": "",
      "negative_prompt": "",
      "note": "",
      "male": true,
      "nsfw": false
    },
    "profile_image_presentations": {
      "male": {
        "url": "",
        "local_image_id": "",
        "source": "none",
        "seed": null,
        "prompt": "general-audience portrait of Aren Valehart, a human monster tracker with dark brown wind-tossed hair and a short beard, brown weatherproof coat over a field shirt, crouched beside animal tracks with a notebook, thoughtful steady expression, quiet woodland trail, no text, no logo",
        "negative_prompt": "extra people, text, logo, watermark",
        "note": "Male presentation: tracker coat, notebook, and grounded pose establish his role.",
        "male": true,
        "nsfw": false
      },
      "non_male": {
        "url": "",
        "local_image_id": "",
        "source": "none",
        "seed": null,
        "prompt": "general-audience portrait of Arenna Valehart, a human monster tracker with dark brown wind-tossed hair tied back, brown weatherproof coat over a field shirt, crouched beside animal tracks with a notebook, thoughtful steady expression, quiet woodland trail, no text, no logo",
        "negative_prompt": "extra people, text, logo, watermark",
        "note": "Non-male presentation: tracker coat, notebook, and grounded pose establish the same character role.",
        "male": false,
        "nsfw": false
      }
    },
    "profile_images": {
      "active_image_id": "",
      "image_ids": []
    },
    "images": {
      "active_image_id": "",
      "image_ids": []
    },
    "voice": null,
    "created_at": "2026-08-31T00:00:00.000Z",
    "updated_at": "2026-09-03T06:16:19.219Z",
    "nsfw": false,
    "loli": false,
    "starting_arousal": 0,
    "starting_nsfw_known_facts": [],
    "kink_tags": []
  }
}
```

## Validated story example

For an embedded character story, use the inner storyTemplate object of this example as chat_story_template.

```json
{
  "app": "EmberAdventures",
  "exportType": "story-template",
  "storyTemplate": {
    "id": "lantern-road",
    "title": "The Lantern Road",
    "description": "Help a village bridgekeeper restore the light for the spring festival.",
    "source": "Original",
    "creation_tool": "Codex",
    "genres": [
      "fantasy"
    ],
    "createdAt": "2026-10-21T23:00:17.617Z",
    "updatedAt": "2026-10-21T23:00:17.617Z",
    "allow_any_player": true,
    "any_player_starting_state": {
      "role": "A visitor helping the bridgekeeper"
    },
    "app": "EmberAdventures",
    "templateType": "story",
    "default_image_model": "fantasy-rpg",
    "title_card_subjects": [
      "A lantern on a stone village bridge"
    ],
    "title_card_image": {
      "id": "bramble-bridge-title-card",
      "title": "The Lantern Road title card",
      "prompt": "A small stone footbridge over a shallow stream, village festival bunting and an empty iron lantern hook, soft amber dusk, illustrated fantasy landscape, no lettering.",
      "negativePrompt": "text, logo, watermark",
      "seed": 0,
      "model": "fantasy-rpg",
      "source": "hosted",
      "url": "",
      "hosted_url": "",
      "html": "",
      "favorite": false,
      "nsfw": false
    },
    "state": {
      "meta": {
        "app": "EmberAdventures",
        "genres": [
          "fantasy"
        ],
        "story_guidance": "Tell a short, cozy fantasy adventure. Respect the player’s chosen method. Mira offers practical help without solving tasks for the player. Keep responses concise and leave room for dialogue. The missing lantern is an ordinary accident, not a hidden villain or supernatural crisis.",
        "story_source": {
          "mode": "original",
          "title": "The Lantern Road",
          "description": "Help a village bridgekeeper restore the light for the spring festival.",
          "modifications": []
        },
        "default_image_model": "fantasy-rpg",
        "loli": false,
        "kink_tags": []
      },
      "player": {
        "version": 1,
        "id": "bramble-rowan-reed",
        "name": "Rowan Reed",
        "source": "Original",
        "creation_tool": "Codex",
        "can_die": false,
        "romanceable": false,
        "gender": "male",
        "fallback_name": "Rowan Reed",
        "fallback_outfits": [
          {
            "id": "fallback-default",
            "name": "Everyday work clothes",
            "clothing": {
              "hat": null,
              "hair_accessory": null,
              "face": null,
              "ears": null,
              "neck": null,
              "shoulders": null,
              "bra": null,
              "undershirt": null,
              "shirt": "opaque long-sleeved blue wool tunic",
              "over_shirt": null,
              "coat": null,
              "back": "weatherproof courier satchel",
              "hands": null,
              "right_wrist": null,
              "left_wrist": null,
              "right_fingers": null,
              "left_fingers": null,
              "waist": "plain leather belt",
              "belt_accessory": null,
              "underwear": null,
              "pants": "full-length brown canvas trousers",
              "skirt": null,
              "legwear": null,
              "socks": "gray wool socks",
              "feet": "sturdy brown walking boots",
              "other_accessory": null
            },
            "nsfw": false
          }
        ],
        "fallback_starting_outfit_id": "fallback-default",
        "age": 29,
        "role": "Village courier",
        "personality_description": "Patient and curious, Rowan remembers promises and notices practical details. He can mend a strap but is no expert craftsperson. He worries about disappointing neighbors and sometimes takes on too many errands.",
        "speech_style": "Warm, plain-spoken sentences with occasional understated humor.",
        "boldness": 5,
        "starting_relationship_to_player": "self",
        "starting_trust": 4,
        "starting_attraction": 0,
        "starting_affection": 1,
        "starting_state_of_mind": "Concerned about the missing bridge lantern, but ready to help.",
        "starting_physical_state": "Healthy and uninjured.",
        "starting_pose": "Standing by the bridge railing.",
        "appearance": {
          "species": "human",
          "height": "5 feet 9 inches tall",
          "skin_color": "warm brown",
          "eye_color": "hazel",
          "hair_color": "black",
          "hair_length": "short",
          "hair_type": "curly",
          "extra_description": "A small pale scar at the left temple.",
          "extra_description_lower_body": "",
          "nonhuman_lower_body": false,
          "shoulder_width": 10,
          "chest": 12,
          "upper_body_build": 12,
          "midsection_build": 12,
          "hip_width": 9,
          "butt_build": 11,
          "lower_body_build": 13,
          "arm_length": 10,
          "leg_length": 11,
          "penis_size": 10
        },
        "outfits": [
          {
            "id": "default",
            "name": "Everyday work clothes",
            "clothing": {
              "hat": null,
              "hair_accessory": null,
              "face": null,
              "ears": null,
              "neck": null,
              "shoulders": null,
              "bra": null,
              "undershirt": null,
              "shirt": "opaque long-sleeved blue wool tunic",
              "over_shirt": null,
              "coat": null,
              "back": "weatherproof courier satchel",
              "hands": null,
              "right_wrist": null,
              "left_wrist": null,
              "right_fingers": null,
              "left_fingers": null,
              "waist": "plain leather belt",
              "belt_accessory": null,
              "underwear": null,
              "pants": "full-length brown canvas trousers",
              "skirt": null,
              "legwear": null,
              "socks": "gray wool socks",
              "feet": "sturdy brown walking boots",
              "other_accessory": null
            },
            "nsfw": false
          }
        ],
        "starting_outfit_id": "default",
        "starting_held_items": {
          "right_hand": null,
          "left_hand": null
        },
        "starting_inventory": [
          "A folded route map",
          "A length of spare twine"
        ],
        "starting_known_facts": [
          "Rowan carries messages between Bramble village and nearby farms.",
          "Rowan grew up in Bramble and knows bridgekeeper Mira Bellweather.",
          "Rowan promised to deliver the festival invitations before dusk."
        ],
        "default_seed": 0,
        "image_prompt_config": {
          "seed_enabled": true,
          "seed": 0,
          "style": "high detail fantasy RPG character art, cinematic lighting",
          "profile_style": "",
          "negative": "",
          "negative_prompt": ""
        },
        "default_profile_image": {
          "url": "",
          "local_image_id": "",
          "source": "none",
          "seed": null,
          "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
          "negative_prompt": "",
          "note": "",
          "male": false,
          "nsfw": false
        },
        "profile_image_presentations": {
          "male": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
            "seed": null,
            "negative_prompt": "",
            "note": "",
            "male": true,
            "nsfw": false
          },
          "non_male": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
            "seed": null,
            "negative_prompt": "",
            "note": "",
            "male": false,
            "nsfw": false
          }
        },
        "profile_images": {
          "active_image_id": "",
          "image_ids": []
        },
        "images": {
          "active_image_id": "",
          "image_ids": []
        },
        "voice": null,
        "created_at": "2026-10-21T23:00:17.617Z",
        "updated_at": "2026-10-21T23:00:17.617Z",
        "nsfw": false,
        "loli": false,
        "starting_arousal": 0,
        "starting_nsfw_known_facts": []
      },
      "players": [
        {
          "version": 1,
          "id": "bramble-rowan-reed",
          "name": "Rowan Reed",
          "source": "Original",
          "creation_tool": "Codex",
          "can_die": false,
          "romanceable": false,
          "gender": "male",
          "fallback_name": "Rowan Reed",
          "fallback_outfits": [
            {
              "id": "fallback-default",
              "name": "Everyday work clothes",
              "clothing": {
                "hat": null,
                "hair_accessory": null,
                "face": null,
                "ears": null,
                "neck": null,
                "shoulders": null,
                "bra": null,
                "undershirt": null,
                "shirt": "opaque long-sleeved blue wool tunic",
                "over_shirt": null,
                "coat": null,
                "back": "weatherproof courier satchel",
                "hands": null,
                "right_wrist": null,
                "left_wrist": null,
                "right_fingers": null,
                "left_fingers": null,
                "waist": "plain leather belt",
                "belt_accessory": null,
                "underwear": null,
                "pants": "full-length brown canvas trousers",
                "skirt": null,
                "legwear": null,
                "socks": "gray wool socks",
                "feet": "sturdy brown walking boots",
                "other_accessory": null
              },
              "nsfw": false
            }
          ],
          "fallback_starting_outfit_id": "fallback-default",
          "age": 29,
          "role": "Village courier",
          "personality_description": "Patient and curious, Rowan remembers promises and notices practical details. He can mend a strap but is no expert craftsperson. He worries about disappointing neighbors and sometimes takes on too many errands.",
          "speech_style": "Warm, plain-spoken sentences with occasional understated humor.",
          "boldness": 5,
          "starting_relationship_to_player": "self",
          "starting_trust": 4,
          "starting_attraction": 0,
          "starting_affection": 1,
          "starting_state_of_mind": "Concerned about the missing bridge lantern, but ready to help.",
          "starting_physical_state": "Healthy and uninjured.",
          "starting_pose": "Standing by the bridge railing.",
          "appearance": {
            "species": "human",
            "height": "5 feet 9 inches tall",
            "skin_color": "warm brown",
            "eye_color": "hazel",
            "hair_color": "black",
            "hair_length": "short",
            "hair_type": "curly",
            "extra_description": "A small pale scar at the left temple.",
            "extra_description_lower_body": "",
            "nonhuman_lower_body": false,
            "shoulder_width": 10,
            "chest": 12,
            "upper_body_build": 12,
            "midsection_build": 12,
            "hip_width": 9,
            "butt_build": 11,
            "lower_body_build": 13,
            "arm_length": 10,
            "leg_length": 11,
            "penis_size": 10
          },
          "outfits": [
            {
              "id": "default",
              "name": "Everyday work clothes",
              "clothing": {
                "hat": null,
                "hair_accessory": null,
                "face": null,
                "ears": null,
                "neck": null,
                "shoulders": null,
                "bra": null,
                "undershirt": null,
                "shirt": "opaque long-sleeved blue wool tunic",
                "over_shirt": null,
                "coat": null,
                "back": "weatherproof courier satchel",
                "hands": null,
                "right_wrist": null,
                "left_wrist": null,
                "right_fingers": null,
                "left_fingers": null,
                "waist": "plain leather belt",
                "belt_accessory": null,
                "underwear": null,
                "pants": "full-length brown canvas trousers",
                "skirt": null,
                "legwear": null,
                "socks": "gray wool socks",
                "feet": "sturdy brown walking boots",
                "other_accessory": null
              },
              "nsfw": false
            }
          ],
          "starting_outfit_id": "default",
          "starting_held_items": {
            "right_hand": null,
            "left_hand": null
          },
          "starting_inventory": [
            "A folded route map",
            "A length of spare twine"
          ],
          "starting_known_facts": [
            "Rowan carries messages between Bramble village and nearby farms.",
            "Rowan grew up in Bramble and knows bridgekeeper Mira Bellweather.",
            "Rowan promised to deliver the festival invitations before dusk."
          ],
          "default_seed": 0,
          "image_prompt_config": {
            "seed_enabled": true,
            "seed": 0,
            "style": "high detail fantasy RPG character art, cinematic lighting",
            "profile_style": "",
            "negative": "",
            "negative_prompt": ""
          },
          "default_profile_image": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "seed": null,
            "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
            "negative_prompt": "",
            "note": "",
            "male": false,
            "nsfw": false
          },
          "profile_image_presentations": {
            "male": {
              "url": "",
              "local_image_id": "",
              "source": "none",
              "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
              "seed": null,
              "negative_prompt": "",
              "note": "",
              "male": true,
              "nsfw": false
            },
            "non_male": {
              "url": "",
              "local_image_id": "",
              "source": "none",
              "prompt": "Rowan Reed, A lean, wiry build accustomed to walking long distances. opaque long-sleeved blue wool tunic, full-length brown canvas trousers, sturdy brown walking boots. Warm illustrated fantasy village portrait.",
              "seed": null,
              "negative_prompt": "",
              "note": "",
              "male": false,
              "nsfw": false
            }
          },
          "profile_images": {
            "active_image_id": "",
            "image_ids": []
          },
          "images": {
            "active_image_id": "",
            "image_ids": []
          },
          "voice": null,
          "created_at": "2026-10-21T23:00:17.617Z",
          "updated_at": "2026-10-21T23:00:17.617Z",
          "nsfw": false,
          "loli": false,
          "starting_arousal": 0,
          "starting_nsfw_known_facts": []
        }
      ],
      "characters": {},
      "future_cast": {
        "enabled": false,
        "items": {}
      },
      "location": {
        "universe": "Bramble Tales",
        "world": "Alder",
        "continent": "Westreach",
        "region": "Willow Vale",
        "settlement_type": "village",
        "settlement_name": "Bramble",
        "district": "Riverside",
        "specific_place": "Bramble Bridge",
        "npc_location_id": "bramble-bridge"
      },
      "npc_directory": {
        "locations": {
          "bramble-bridge": {
            "label": "Bramble Bridge",
            "characters": {
              "Mira Bellweather": {
                "id": "bramble-mira-bellweather",
                "name": "Mira Bellweather",
                "gender": "female",
                "age": 46,
                "role": "Bridgekeeper and lantern maker",
                "relationship": "acquaintance",
                "note": "Bridgekeeper and lantern maker; knows Rowan from village deliveries.",
                "current_appearance": "Standing beside the empty lantern hook with a canvas tool roll.",
                "inspected": true,
                "voice": null,
                "full_character": {
                  "version": 1,
                  "id": "bramble-mira-bellweather",
                  "name": "Mira Bellweather",
                  "source": "Original",
                  "creation_tool": "Codex",
                  "can_die": false,
                  "romanceable": false,
                  "gender": "female",
                  "fallback_name": "Mira Bellweather",
                  "fallback_outfits": [
                    {
                      "id": "fallback-default",
                      "name": "Everyday work clothes",
                      "clothing": {
                        "hat": null,
                        "hair_accessory": "simple wooden hair clasp",
                        "face": null,
                        "ears": null,
                        "neck": null,
                        "shoulders": null,
                        "bra": null,
                        "undershirt": null,
                        "shirt": "opaque long-sleeved rust-red linen shirt",
                        "over_shirt": "heavy full-front canvas work apron",
                        "coat": null,
                        "back": null,
                        "hands": null,
                        "right_wrist": null,
                        "left_wrist": null,
                        "right_fingers": null,
                        "left_fingers": null,
                        "waist": null,
                        "belt_accessory": null,
                        "underwear": null,
                        "pants": "full-length dark green work trousers",
                        "skirt": null,
                        "legwear": null,
                        "socks": "cream wool socks",
                        "feet": "black leather work boots",
                        "other_accessory": null
                      },
                      "nsfw": false
                    }
                  ],
                  "fallback_starting_outfit_id": "fallback-default",
                  "age": 46,
                  "role": "Bridgekeeper and lantern maker",
                  "personality_description": "Methodical, kind, and quietly stubborn. Mira takes pride in maintaining public things that others overlook. She taps a thumb against her tool roll when thinking. Her patience frays when people treat every old object as disposable; she admits when she needs help.",
                  "speech_style": "Brief, concrete explanations, dry humor, and a reassuring tone when someone struggles.",
                  "boldness": 5,
                  "starting_relationship_to_player": "acquaintance",
                  "starting_trust": 4,
                  "starting_attraction": 0,
                  "starting_affection": 1,
                  "starting_state_of_mind": "Concerned about the missing bridge lantern, but ready to help.",
                  "starting_physical_state": "Healthy and uninjured.",
                  "starting_pose": "Standing by the bridge railing.",
                  "appearance": {
                    "species": "human",
                    "height": "5 feet 4 inches tall",
                    "skin_color": "light brown",
                    "eye_color": "green",
                    "hair_color": "silver-gray",
                    "hair_length": "shoulder length",
                    "hair_type": "wavy",
                    "extra_description": "A scattering of freckles across her nose.",
                    "extra_description_lower_body": "",
                    "nonhuman_lower_body": false,
                    "shoulder_width": 12,
                    "chest": 13,
                    "upper_body_build": 8,
                    "midsection_build": 6,
                    "hip_width": 12,
                    "butt_build": 7,
                    "lower_body_build": 9,
                    "arm_length": 10,
                    "leg_length": 10,
                    "penis_size": 10
                  },
                  "outfits": [
                    {
                      "id": "default",
                      "name": "Everyday work clothes",
                      "clothing": {
                        "hat": null,
                        "hair_accessory": "simple wooden hair clasp",
                        "face": null,
                        "ears": null,
                        "neck": null,
                        "shoulders": null,
                        "bra": null,
                        "undershirt": null,
                        "shirt": "opaque long-sleeved rust-red linen shirt",
                        "over_shirt": "heavy full-front canvas work apron",
                        "coat": null,
                        "back": null,
                        "hands": null,
                        "right_wrist": null,
                        "left_wrist": null,
                        "right_fingers": null,
                        "left_fingers": null,
                        "waist": null,
                        "belt_accessory": null,
                        "underwear": null,
                        "pants": "full-length dark green work trousers",
                        "skirt": null,
                        "legwear": null,
                        "socks": "cream wool socks",
                        "feet": "black leather work boots",
                        "other_accessory": null
                      },
                      "nsfw": false
                    }
                  ],
                  "starting_outfit_id": "default",
                  "starting_held_items": {
                    "right_hand": "A folded canvas tool roll",
                    "left_hand": null
                  },
                  "starting_inventory": [
                    "A small brass workshop key",
                    "A clean polishing cloth"
                  ],
                  "starting_known_facts": [
                    "Mira has maintained Bramble Bridge for sixteen years.",
                    "Mira made the bridge lantern with her father and repairs it each spring.",
                    "Mira keeps a spare lantern frame and amber glass in her workshop."
                  ],
                  "default_seed": 0,
                  "image_prompt_config": {
                    "seed_enabled": true,
                    "seed": 0,
                    "style": "high detail fantasy RPG character art, cinematic lighting",
                    "profile_style": "",
                    "negative": "",
                    "negative_prompt": ""
                  },
                  "default_profile_image": {
                    "url": "",
                    "local_image_id": "",
                    "source": "none",
                    "seed": null,
                    "prompt": "Mira Bellweather, A stocky, sturdy build with a relaxed, practical bearing. opaque long-sleeved rust-red linen shirt, full-length dark green work trousers, black leather work boots. Warm illustrated fantasy village portrait.",
                    "negative_prompt": "",
                    "note": "",
                    "male": false,
                    "nsfw": false
                  },
                  "profile_image_presentations": {
                    "male": {
                      "url": "",
                      "local_image_id": "",
                      "source": "none",
                      "prompt": "Mira Bellweather, A stocky, sturdy build with a relaxed, practical bearing. opaque long-sleeved rust-red linen shirt, full-length dark green work trousers, black leather work boots. Warm illustrated fantasy village portrait.",
                      "seed": null,
                      "negative_prompt": "",
                      "note": "",
                      "male": true,
                      "nsfw": false
                    },
                    "non_male": {
                      "url": "",
                      "local_image_id": "",
                      "source": "none",
                      "prompt": "Mira Bellweather, A stocky, sturdy build with a relaxed, practical bearing. opaque long-sleeved rust-red linen shirt, full-length dark green work trousers, black leather work boots. Warm illustrated fantasy village portrait.",
                      "seed": null,
                      "negative_prompt": "",
                      "note": "",
                      "male": false,
                      "nsfw": false
                    }
                  },
                  "profile_images": {
                    "active_image_id": "",
                    "image_ids": []
                  },
                  "images": {
                    "active_image_id": "",
                    "image_ids": []
                  },
                  "voice": null,
                  "created_at": "2026-10-21T23:00:17.617Z",
                  "updated_at": "2026-10-21T23:00:17.617Z",
                  "nsfw": false,
                  "loli": false,
                  "starting_arousal": 0,
                  "starting_nsfw_known_facts": []
                }
              }
            }
          }
        }
      },
      "scene": {
        "summary": "Mira waits at the bridge with a repaired lantern ready to light.",
        "party_members_present": [],
        "image_characters": [
          "Mira Bellweather"
        ],
        "npcs_present": [
          "Mira Bellweather"
        ],
        "image_action": "Holding a repaired lantern beside the bridge hook.",
        "intimacy_level": 0,
        "spicy_mode": "off",
        "sex_position": "",
        "ai_sex_position": "",
        "sex_acts": []
      },
      "story_rules": [
        {
          "id": "safe-recovery",
          "text": "No one is in immediate danger. The stream is shallow; any recovery can be done safely from the bank with the available rake."
        },
        {
          "id": "patient-festival",
          "text": "The festival waits for the bridge light; there is no hidden countdown or forced failure."
        }
      ],
      "story_inventory": {
        "items": []
      },
      "world_map": {
        "current_location_id": "bramble-bridge",
        "focus_location_id": "bramble-bridge",
        "travel_history": [
          "bramble-bridge"
        ],
        "locations": {
          "bramble-bridge": {
            "id": "bramble-bridge",
            "name": "Bramble Bridge",
            "type": "place",
            "scale": "site",
            "parent_id": "",
            "x": 0,
            "y": 0,
            "discovered": true,
            "travel_enabled": true,
            "summary": "A stone footbridge with festival ribbons and an empty lantern hook.",
            "detail": {},
            "connections": [
              "willow-bank",
              "lantern-workshop"
            ],
            "npcs": [
              "Mira Bellweather"
            ]
          },
          "willow-bank": {
            "id": "willow-bank",
            "name": "Willow Bank",
            "type": "place",
            "scale": "site",
            "parent_id": "",
            "x": 1,
            "y": 0,
            "discovered": true,
            "travel_enabled": true,
            "summary": "A shallow, muddy bank below the bridge; a long-handled rake rests by the steps.",
            "detail": {},
            "connections": [
              "bramble-bridge"
            ],
            "npcs": []
          },
          "lantern-workshop": {
            "id": "lantern-workshop",
            "name": "Mira’s Workshop",
            "type": "place",
            "scale": "site",
            "parent_id": "",
            "x": -1,
            "y": 0,
            "discovered": true,
            "travel_enabled": true,
            "summary": "A tidy workshop beside the bridge, stocked with spare lantern parts.",
            "detail": {},
            "connections": [
              "bramble-bridge"
            ],
            "npcs": []
          }
        }
      },
      "objectives": {
        "active_id": "light-the-crossing",
        "no_current": false,
        "items": [
          {
            "id": "light-the-crossing",
            "title": "Light the crossing",
            "type": "story",
            "status": "active",
            "summary": "A working lantern is ready. Mira has a candle and taper; the repaired hook waits on the bridge.",
            "while_active_guidance": "Let the player act at their own pace. Do not complete the next task in the same response.",
            "completion_control": "ai",
            "completion_criteria": "The player lights and hangs the usable lantern on Bramble Bridge.",
            "next_objectives": [
              {
                "id": "bridge-lit",
                "completion_instruction": "Describe the amber light reaching the bridge stones and the first festival visitors crossing. Mira thanks the player in her reserved, sincere way. Leave the evening open for conversation or exploring the festival.",
                "rewards": [],
                "ending_type": "freeplay",
                "ending_title": "A light for everyone",
                "ending_message": "The crossing glows again. Music carries across the water, and the festival evening is yours to enjoy."
              }
            ]
          }
        ]
      },
      "time": {
        "year": 1,
        "month": 5,
        "day": 12,
        "hour": 18,
        "minute": 0
      },
      "story_memory": {
        "world_notes": [
          "Bramble celebrates its spring festival this evening.",
          "Mira’s workshop stands next to Bramble Bridge."
        ],
        "unresolved_threads": [],
        "relationship_notes": [
          "Mira knows the default courier Rowan through village deliveries. Other player characters begin as visitors."
        ],
        "rules_and_constraints": [],
        "ai_private_notes": []
      },
      "recent_changes": [],
      "story_clock": {
        "elapsed_minutes": 0,
        "label": "Day 1, 6:00 PM"
      },
      "story_pacing": {
        "mode": "player_controlled",
        "pending_event_id": "",
        "timeline": {}
      },
      "timed_events": {}
    },
    "messages": [
      {
        "role": "assistant",
        "speaker": "Narrator",
        "at": "2026-10-21T23:00:17.617Z",
        "text": "The repaired lantern rests on Bramble Bridge. Mira places a fresh candle beside it. “Ready when you are,” she says, holding out a taper. Music drifts from the village square."
      }
    ],
    "nsfw": false,
    "loli": false,
    "kink_tags": []
  },
  "exportedAt": "2026-10-21T23:00:17.617Z"
}
```
