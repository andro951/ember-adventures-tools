"use strict";

const fs = require("node:fs");
const path = require("node:path");

const [projectRoot, kind] = process.argv.slice(2);
const repo = path.resolve(projectRoot);
const edition = kind === "lite" ? "lite" : "full";
const {createProductionContext} = require(path.join(repo, "tools/lib/production-declarations.cjs"));
const {addSfwDefaults} = require(path.join(repo, "src/contracts/lite-import-format.js"));
const {toLite} = require(path.join(repo, "src/editions/lite/shared-library-format.js"));
const assert = require("node:assert/strict");
const skills = JSON.parse(fs.readFileSync(0, "utf8"));
const validator = createProductionContext(repo, {edition});
const full = edition === "lite" ? createProductionContext(repo, {edition: "full"}) : validator;
const checked = new Map();

for (const [name, text] of Object.entries(skills)) {
    assert(text.includes("one short question about one decision per message"), name);
    const resources = [...text.matchAll(/<!-- resource:([^>]+) -->\s*\x60\x60\x60json\r?\n([\s\S]*?)\r?\n\x60\x60\x60/g)];
    assert(resources.length > 0, "No inline reference data in " + name);
    for (const [, key, raw] of resources) {
        const item = JSON.parse(raw);
        if (checked.has(key)) {
            assert.deepEqual(item, checked.get(key), "Different copies of " + key);
            continue;
        }

        checked.set(key, item);
        if (key.endsWith("-field-sets.json") && edition === "full") {
            for (const [field, expected] of Object.entries(item)) {
                validator.load(field);
                assert.deepEqual([...validator.context[field]], expected, key + " " + field);
            }
            continue;
        }
        const method = item.storyTemplate ? "validateStoryExport" : item.character_definition ? "validateCharacterExport" : "";
        if (!method) continue;

        const result = validator.invoke(method, structuredClone(item));
        assert(result.ok, key + ": " + JSON.stringify(result.errors));
        if (edition === "lite") {
            const publication = addSfwDefaults(item);
            const hosted = full.invoke(method, structuredClone(publication));
            assert(hosted.ok, key + " published from Lite: " + JSON.stringify(hosted.errors));
            assert.deepEqual(toLite(publication), item, key + " Lite publication round trip");
        }
    }
}

console.log("Validated embedded " + edition + " references.");
