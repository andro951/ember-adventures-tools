# Story Quality Checklist

Use this before finalizing a story template.

## Playability

- Opening message creates an immediate situation.
- First objective can be acted on immediately.
- The first scene does not explain the entire plot.
- The player has a clear place, body/identity, inventory, and immediate conflict.
- The player can understand what is happening in the first 30 seconds.
- The opening establishes pressure and context without deciding the player's
  meaningful choices for them. Do not make the player agree, submit, attack,
  flirt, forgive, accept a role, or commit to a path before the user acts.
- The first objective matches the opening's final actionable prompt.
- The story hides future spoilers without making the opening confusing.
- Long stories include enough hidden objective detail to keep play advancing
  after the first scene.

## Creative Direction

- The story's core player fantasy is identifiable in one sentence.
- The intended emotional target is clear: danger, desire, power,
  vulnerability, discovery, belonging, guilt, temptation, triumph, dread, or
  another deliberate feeling.
- The world hook makes the premise more specific than a generic genre setup.
- The main relationship focus is clear when the story depends on romance,
  companions, rivals, court intrigue, harem, or NSFW payoff.
- The progression/building axis is clear when the premise supports it: party,
  home, workshop, guild, kingdom, reputation, resources, family, body repair,
  power growth, or another concrete axis.
- Serious stories have a compact outline before objective writing: premise,
  player fantasy, emotional targets, world hook, beginning, midpoint or
  reevaluation moment, climax, ending/postgame shape, relationship arcs, and
  structure mode.
- If several substantially different games could be built from the user's
  prompt, the skill asked clarifying story-juice questions or proposed
  directions before final JSON.
- The skill did not keep asking questions after the core playable story was
  clear. It either offered to complete the story or proceeded when the creator
  delegated unresolved details.
- The story template acts as the director. Objectives, rewards, story rules,
  state changes, choices, and routing enforce anticipation/payoff instead of
  leaving the live AI to invent the whole arc.

## Full-Story Structure

- Major milestones cover beginning, middle, and current/end frontier.
- The story structure mode was chosen intentionally: Telltale-style branching
  for choice-heavy/multiple-ending stories, or linear/mostly-linear for focused
  stories where fake menu choices would hurt pacing.
- Objectives map cleanly to milestones.
- Every Player Action, AI Scene, and Immediate AI objective has story-specific
  `completion_criteria`; none use generic
  title-repeat boilerplate such as `Return yes only when the player completes:
  {title}`, `Return yes only when the player completes or survives...`, or
  `Return yes only when the player clearly takes action toward this goal...`.
- Every output has a story-specific `completion_instruction`; none use generic
  title-repeat boilerplate such as `Resolve the immediate outcome of {title}
  and move to the next objective`.
- Every objective has non-empty, story-specific `while_active_guidance`; none
  omit it or use generic filler.
- Every objective with a `summary` field has a non-empty, story-specific,
  player-facing hint or context note that helps the player understand how to
  approach the objective without spoiling hidden outcomes.
- In `time_controlled` stories, every main story objective before final
  aftermath/freeplay is time-locked and locked until complete. Free time is
  represented as gaps between locked main objectives, not as unlocked main
  story objectives.
- AI-controlled objectives describe the resolved narrator/world state in
  `completion_criteria` and never say `player completes`.
- The template is not only a bare critical path unless the user explicitly
  requested that. It includes major/fun side stories, optional chains, or
  memorable one-off side objectives that fit the source/premise.
- Branching is used where it improves play: one unlock can open several paths,
  optional side objectives can branch from hubs/milestones, and multiple
  branches can be required before a later major milestone.
- Every main objective has an authored output through `next_objectives`,
  `choices`, or hidden `outcome_routes`. Each output either continues to another
  objective or uses `ending_type`, with any ending rewards on that output.
  The story does not rely on fallback objective picking as normal flow.
- Telltale-style stories include direct `completion_control: "choice"` owner
  objectives with `choices[]`, non-spoilery option titles, branch-specific
  rewards, hidden outcome logic, and distinct endings/failure paths when
  appropriate.
- Choice option `effects` contain only visible requirements or concrete
  mechanical deltas such as `credits -80`, `trust >= 6`, or `suspicion +1`.
  They do not expose route labels, ending labels, unlock labels, hidden
  recommendations, or outcome spoilers.
- Choice-heavy stories, including multiple-ending or Telltale-style requests,
  usually target about 30-40% choice objectives and normally stay under half.
- Linear/mostly-linear stories do not use forced choice menus unless the choice
  materially changes the story.
- Character introductions happen through objective rewards.
- Important permanent changes happen through deterministic objective rewards,
  not only through narrator prose.
- Truly mutually exclusive branches have branch-specific rewards,
  `exclusive_group` on the visible choice owner objective, and branch
  descendants reached only through their selected output transitions; they do
  not collapse back into the same state.
- Optional branches, parallel goals, and side content that can all be completed
  do not use `exclusive_group`.
- Immediate-merge choices record consequences in rewards before returning to a
  shared next objective.
- Optional-with-skip choices are used for optional romance/NSFW moments inside
  the main flow when separate side objectives are not desired.
- Multi-route convergence uses separate branches that all must be completed
  before the merge objective, not `exclusive_group`.
- Fail-forward branches continue play with consequences instead of accidental
  dead-ends.
- Delayed callback choices store explicit rules/state/rewards that later
  objectives or endings can check.
- Repeated deterministic effects are factored into `state.reward_bundles` or typed `state.reward_templates` instead of duplicated.
  There are zero repeated reward definitions across the objective tree. Inline
  rewards are used only for effects unique to one objective, route, choice, or
  event.
- Automatic Transitions are used only when the graph needs deterministic
  convergence, bookkeeping, state-based routing, or automatic rewards. They
  have a valid continuing or ending output and are not visible player
  objectives.
- Relationship-threshold choices show locked options and visible requirements;
  options are not hidden or rewritten based on secret thresholds.
- Resource-gated routes show visible requirements for resources, reputation, or
  relationship stats before the route can start.
- Standalone Player Action and AI Scene side tasks can finish without a
  successor. Verify that they restore the existing main selection, do not show
  an ending, and do not repeat rewards. Choices, AI routes, automatic
  transitions, and main objectives retain their explicit output requirements.
- Side objectives usually have useful consequences such as items, story rules,
  relationship/stat changes, location unlocks, hidden leads, image triggers, or
  scene/list changes.
- Major NPCs have their own goals, fears, loyalties, problems, or plans where
  the story depends on them feeling alive.
- The world has offscreen motion when the premise benefits from it: rivals,
  deadlines, jobs, shops, opportunities, threats, or consequences can advance
  without waiting for the player.
- Intentional failure, rejection, death, missed opportunities, arriving too
  late, or worse outcomes are represented when they would strengthen the story,
  especially in Telltale-style structures.
- Relationship, romance, court, mystery, and slow-burn stories include bridge
  objectives between major beats instead of jumping from chapter event to
  chapter event.
- Romance, dark romance, romantasy, harem, and relationship-first stories
  include multiple relationship-building objectives between major plot
  milestones, not only one token conversation.
- NSFW stories build context, anticipation, invitation, consent/refusal,
  ambiance, escalation, and aftermath around sexual scenes unless the user
  explicitly requested an immediate-sex premise.
- If the intended player is submissive, shy, or unlikely to initiate, romantic
  leads have objective/completion-instruction support to flirt, invite, tempt,
  court, or come onto the player while preserving explicit choice.
- Every full non-player character in every story container has a complete
  opposite male/non-male fallback presentation so both romanceable adaptation
  and profile-level swap-all remain coherent. If the creator selected the
  optional authored default-presentation balance, the entire romanceable cast
  uses the canonical 40% male / 40% female / 20% futanari mix with deterministic
  rounding and evenly distributed futanari fallbacks.
- No objective chain expects one player message to complete multiple
  consecutive objectives; EmberAdventures checks one selected objective at a time.
- Relationship progress that should be deterministic uses `adjust_relationship`
  rewards instead of relying only on narrator prose.
- Romance, dark romance, harem, court, companion, and relationship-driven
  stories have a counted relationship-mechanics pass: direct choice objective
  count, `adjust_relationship` reward count, and relationship bridge objective
  coverage for each major relationship lead. A zero count must be fixed or
  justified as a deliberate design exception.
- `story_rules` are used for active runtime constraints when the story needs
  hard gates such as locked intimacy, pursuit, repair boundaries, source/world
  rules, body-state restrictions, or temporary danger. They are not used as a
  lore dump.
- Future locations are present in map state when needed.
- Story memory gives durable guidance without bloating the prompt.
- `story_memory.ai_private_notes` contains only concise in-world continuity
  constraints if needed; it does not contain coverage tables, omission reports,
  self-critiques, audit notes, or story-creation instructions.
- Objective content has variety where the premise supports it: travel,
  conversation, investigation, combat, shopping, training, downtime, social or
  relationship scenes, discovery, problem solving, and character moments.
- Side objectives are memorable or useful, not just filler errands.

## Feature Utilization

For every serious story, explicitly consider these features before finalizing:

- `state.players` for real player select when the story does not require one
  locked protagonist.
- `future_cast` for important people who should exist before they are met.
- `world_map.locations` with hidden/unlocked future locations.
- `story_rules` for current runtime laws and gates.
- `exclusive_group` for true mutually exclusive branch choices only.
- `completion_control: "choice"` for direct menu decisions in Telltale-style or
  otherwise choice-driven stories.
- `set_state_field` for permanent character/world/relationship/body changes.
- `adjust_relationship` for trust, attraction, affection, and carefully chosen
  arousal changes from objective rewards.
- For relationship-driven stories, `adjust_relationship` is expected whenever
  trust, attraction, affection, suspicion, rivalry, or arousal should persist
  beyond one scene. Do not leave major relationship growth only in prose.
- `add_story_rule` and `remove_story_rule` for changing hard constraints.
- `story_inventory` for story-owned resources such as credits, parts,
  suspicion, reputation, evidence, or repair supplies that objective rewards
  control instead of the AI freely changing.
- `state.reward_bundles` or typed `state.reward_templates` for shared deterministic rewards that would otherwise
  be repeated in more than one branch, route, choice, or event.
- Automatic Transitions (`completion_control: "reward_only"` plus
  `requirement_check_only: true`) for hidden deterministic graph nodes that
  route without an AI call.
- `add_state_list_item` and `remove_state_list_item` for scene/list changes.
- `kill_character` for deterministic death outcomes, with `can_die` respected
  unless an objective intentionally overrides it.
- `generate_profile_image` for face/hair/arms/torso/chest/shoulder/silhouette
  changes.
- `generate_solo_normal_image` for major visible scene/body/outfit changes.
- `generate_story_image` for authored non-character visual beats such as
  important objects, locations, clues, symbols, horror reveals, or jump scares.

If a feature is omitted, the omission should be because it does not serve the
story, not because the skill forgot the feature exists.

## Character Integration

- Invented characters come from `EmberAdventures Character`. If canon
  characters are required, keep this base story skill active and also load
  `Source EmberAdventures Story` plus `Source EmberAdventures Character`.
- Standalone and story-embedded humanoid character definitions use the same
  body-scale schema. Every embedded full character definition, including player
  options, active characters, inspected NPC `full_character`, and future-cast
  `full_character`, contains exactly `height`, `shoulder_width`, `chest`, `upper_body_build`,
  `midsection_build`, `hip_width`, `butt_build`, `lower_body_build`,
  `arm_length`, `leg_length`, and `penis_size`. Each accepts a 0–20 integer or a
  nonempty custom description. Legacy appearance keys `muscular`, `shoulders`, `stomach`, `hips`, `waist`,
  `legs`, and `arms` are invalid in both standalone and embedded definitions.
  Clothing slots with names such as `shoulders` and `waist` remain valid.
- Apply the base Character skill's `nonhuman_lower_body` contract unchanged in
  stories. Keep all eleven scale fields present, preserve complete
  replacement anatomy in `extra_description_lower_body`, and suppress only the
  four inapplicable lower-body traits during prompt projection.
- Future cast entries have full payloads when they will become active later.
- Embedded player, party, NPC, and future-cast definitions are built to support
  play. Durable facts include how the character affects objectives, what they
  can do in scenes, what relationship tensions matter, and what future rewards
  or gates may change about them.
- Character relationships and personalities remain consistent with the
  original premise unless the user requests changes.
- Clothing slots are precise item slots, not ambiguous scene-dependent descriptions.
- Every newly authored normal, fallback, shop, reward, override, and generated
  humanoid outfit has explicit boolean `nsfw`. Use the Character skill's outfit
  purpose test. A SFW character has an SFW starting outfit and at least one SFW
  outfit in both presentations. Missing outfit classification is a hard import
  error and must never be inferred from the character or story.
- Keep optional adult character facts in `starting_nsfw_known_facts`, not
  `starting_known_facts`. Loli and under-18 characters have no adult facts or
  NSFW outfits. A SFW story may contain optional gated adult facts/outfits, but
  its required premise, starting state, objectives, and visible path remain SFW.
- Player-character definitions describe starting identity/tendencies without
  scripting future choices, consent, morality, dialogue, or relationship paths.
- Public/standalone character definitions do not expose story-specific spoilers
  unless the entry is intentionally spoiler-heavy and safe to publish that way.

## Player-Visible Field Audit

Before final export, scan every field the player may see in a library card,
story-definition UI, map, objective list, opening chat, character card, or
read-only definition view.

Visible fields must not reveal hidden future cast, future party roles, future
locations, source twists, objective rewards, private AI instructions, locked
relationship outcomes, or implementation notes.

Audit these fields at minimum:

- story title and description;
- public source/genre/kink/SFW/NSFW metadata;
- opening messages;
- location and world-map names, summaries, details, and NPC lists;
- scene summary;
- objective titles and summaries;
- current NPC names, roles, relationships, and notes;
- character roles, personality descriptions, appearance, outfits, and durable
  known facts whenever they can appear in library/editor UIs.

Public-library cards may show counts and tags, but not hidden future-cast names,
hidden objective titles, future location names, or locked side-arc spoilers.

SFW-safe browsing text should not include explicit kink prose. Kink tags are
metadata for NSFW-capable filtering and should only surface in adult-appropriate
contexts.

## Creator-Instruction Leakage Audit

Before final export, search the story text for creator/process language that was
intended for Codex, not for the story file. Remove or rewrite it.

Do not leave terms like these in player-visible fields, story memory, world
flags, objective titles/summaries, character facts, or completion messages:

- `source-faithful`, `current app compatibility`, `story template`;
- `fake ending`, `current frontier`, `follow canon`, `hide spoilers`;
- `future hooks`, `objective rewards`, `without introducing future characters`;
- `should not appear before`, `has just been introduced by an objective reward`;
- `future engine`, `future shop`, `future quest`, `should later`,
  `convert these`, `until those systems exist`;
- `linked objective`, `authored objective`, `objective chain` when used as
  schema/process commentary instead of natural story wording;
- any explanation of how EmberAdventures objectives, publishing, SFW/NSFW policy, or
  prompt projection works.

If the concept is still needed, put it into the correct behavior:

- hidden future cast/objectives for spoilers;
- concise hidden runtime constraints for continuity;
- concrete player-facing objective titles for goals;
- blank/default fields when no story content belongs there.

For every field that feels questionable, ask: what is this field for, how is it
used by EmberAdventures, does this value serve that use, and could it be improved?

`story_guidance` / player guidance must be blank unless the creator explicitly
asks to populate that exact field or approves exact text for it.

## Originality And Hidden-Information Pass

- For source-free work, confirm the result remains source-free. If it has
  drifted into a recognizable adaptation, pause original-story work and load
  `Source EmberAdventures Story` before continuing under an explicit source
  scope.
- Visible text contains only what the protagonist/player could know at the
  starting point.
- Future names appear only in hidden future cast, hidden objectives, or rewards
  until introduced.
- Visible objectives do not leak locked future role labels.
- Map summaries do not reveal undiscovered enemies, places, allies, twists, or
  future relationships.

## Schema

- JSON parses.
- `future_cast.items` is an object.
- Every `future_cast.items` object key matches that entry's own `id`; do not
  use numeric/index keys for future cast.
- Every `future_cast.items[id]` contains exactly one of `full_character` and
  `animal_definition`. Humanoid shells and `full_character` values satisfy the
  complete humanoid contract, including outfits and fallback presentation.
  `animal_definition` values satisfy the lean animal contract and contain no
  humanoid appearance, outfit, clothing, held-item, romance, attraction,
  arousal, NSFW, or loli fields.
- `world_map.locations` is an object.
- Objective references resolve.
- No authored objectives, story rules, memory entries, scene participants,
  choices, rewards, map references, or other story content were silently
  truncated to satisfy an arbitrary count limit. If the target application
  cannot retain the complete authored data, report the incompatibility instead
  of presenting the shortened result as complete.
- Objective verifier criteria are concrete and specific enough for EmberAdventures to
  decide yes/no without guessing from the title alone.
- Objective completion instructions describe the immediate result, reveal,
  consequence, transition, or future-cast introduction for that exact beat.
- Future-cast reward ids resolve by exact `future_cast.items[character_id]`
  object key.
- Export metadata is current.
- `state.meta.story_source` does not include old planner-summary or
  source-outline fields.
- `nsfw` is true only when the story template itself contains required
  adult/NSFW premise, starting content, required objectives, required
  characters, or required storylines. It is false when the story is safe to play
  in SFW mode even if runtime settings can later allow spicy play.
- SFW stories do not use public-visible adult scene / NSFW / kink-facing prose,
  but they also do not block later NSFW conversion through runtime settings.
- `loli` is true only when at least one embedded character is actually marked
  `loli: true`; otherwise it is false, including adult/non-loli character
  variants.
- No stale revision labels.
- No mojibake apostrophes.
- Opening messages do not include runtime-only fields such as `streaming`,
  `stateSyncStatus`, `spicySyncStatus`, `voiceMeta`, `voiceSpeakers`, or
  `objectiveComplete`.
- Opening messages do not include exporter-discarded `id` or `entryId` fields.
- If pending main plot points are used, validate their explicit timeline variant,
  unique order and targets, hard triggers, private readiness guidance, and safe
  availability rewards. Manually check side/no-selection preservation, the short
  pending badge, once-only OK notices, and save/reload without repeated rewards.


---
