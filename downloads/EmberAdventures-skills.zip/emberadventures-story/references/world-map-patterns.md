# EmberAdventures World Map Patterns

Use `world_map.locations`, not old `visible_locations`, for stored story templates.

## Shape

```json
{
  "current_location_id": "loc-current",
  "focus_location_id": "loc-current",
  "travel_history": [],
  "locations": {
    "loc-current": {
      "id": "loc-current",
      "name": "Current Place",
      "type": "place",
      "scale": "site",
      "parent_id": "loc-settlement",
      "x": 50,
      "y": 50,
      "discovered": true,
      "travel_enabled": true,
      "summary": "Short map summary.",
      "detail": {
        "universe": "Story Title",
        "world": "World Name",
        "region": "Region Name",
        "settlement_name": "Settlement",
        "district": "District",
        "specific_place": "Specific place"
      },
      "connections": ["loc-settlement"],
      "npcs": []
    }
  }
}
```

## Hierarchy

Prefer stable parent chains:

world -> region -> settlement -> district/site

Opening site should be discovered. Nearby future places can exist but should often be `discovered: false` or `travel_enabled: false`.

Connections should be valid ids. Add bidirectional links when practical.

## NPC Pointers

`locations[id].npcs` can list proper names associated with that place, but full known NPC data belongs in `npc_directory`; future important characters usually belong in `future_cast`.

Do not put titles, jobs, groups, or generic descriptions in `locations[id].npcs`.
Invalid examples: `Gate Guard`, `Guild Clerk`, `travelers`, `cart drivers`,
`shopkeeper`, `villagers`. If the location needs a speakable or inspectable NPC,
create a named NPC such as `First Last` in `npc_directory` and list that
proper name here. Otherwise leave `npcs` empty.

## Optional hex exploration

For fixed-size settlements, road tiles and nested interiors, see [hex-exploration.md](hex-exploration.md) and the complete [courtyard example](hex-exploration-story.json). Add `hex_layout` only when choosing that system. In a hex area, existing location `x/y` hold exact axial q/r; explicit passages control travel, doors and duration. Hidden contents belong in optional `hidden_description`, never public `summary` or `detail`.
