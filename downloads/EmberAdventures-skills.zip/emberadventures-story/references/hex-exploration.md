# Bounded hex exploration

Use this optional system for freely explored settlements, roads and interiors.
Keep important plot developments in the objective graph. A room is a place;
entering it is not an objective completion, victory, injury or loot collection.

The complete [courtyard example](hex-exploration-story.json) demonstrates a
closed chest, separate opening/collection effects, retreat and explicit doors.
It uses the same character, inventory, requirement and reward contracts as other
stories. Do not create a second character or inventory system inside a map.

## Location records

Keep the normal `world_map` fields and location records. Add optional
`world_map.hex_layout` to opt in; omit it for an ordinary map. Existing files
do not need conversion.

For tiles in a hex area, location `x` is axial q and `y` is axial r. Both are
exact integers, including negative coordinates when the bounds permit them.
Each location's `parent_id` identifies the area's containing location. Tiles
cannot overlap or lie outside the declared bounds. Roads are ordinary tiles.

`summary` and optional `detail` remain player-known information. Optional
location `hidden_description` is exact narrator-only text. Put concealed
contents, unrevealed conditions and private guidance there, rather than in
`summary`, `detail` or a public NPC-name list. Narration still needs the actual
appropriate interaction before revealing concealed contents.

## Layout

`hex_layout` has exactly these required fields:

- `version`: integer `2`.
- `areas`: object keyed by exact area ID.
- `passages`: object keyed by exact passage ID.
- `visited_location_ids`: unique discovered location IDs in first-visit order.
- `notes`: object mapping location IDs to exact player-note strings.
- `moves`: object of engine-owned journey receipts; start with `{}`.

Optional fields are `interaction_ledger`, `generation_state` and
`dungeon_entry_checks`. Explicit null, false, aliases or additional fields
are invalid.
New stories normally start with the opening location visited, empty notes,
empty movement receipts and no generated batches.

Each area requires exactly `id`, `parent_location_id`, `kind`, `q_min`, `q_max`,
`r_min`, `r_max`, `allowed_place_types` and `generation_enabled`, with optional
`generation_rules`. `id` matches its key; the parent is an existing location,
and two areas cannot share the same parent. `kind` is `settlement`, `interior`
or `overworld`. Bounds are inclusive, ordered safe integers. Allowed types are
a nonempty unique string list, and every tile in the area uses one of them.
`generation_enabled` is an explicit boolean.

Each passage requires exactly `id`, `from_location_id`, `to_location_id`,
`kind`, `status`, `travel_minutes`, `description` and `hidden_description`.
Optional `door` is a boolean. Both descriptions are strings; empty is allowed.
IDs match their keys and reference existing distinct locations. No duplicate
pair of endpoints is allowed.

- `kind: "adjacent"` connects neighboring hexes in the same area.
- `kind: "entrance"` connects an area container to one of its child tiles.
- `status` is exactly `open`, `closed`, `locked` or `blocked`.
- `travel_minutes` is an exact nonnegative safe integer for one traversal.
- Only explicit `door: true` enables ordinary opening/closing. It cannot unlock
  or clear a blocked route. Adjacency and location `connections` never bypass
  the passage rules.

Clicks and conversational movement use the same validated journey. A blocked
later leg rejects the entire requested journey before any earlier leg applies.
Travel time is applied once, with separate new activity such as waiting added
after narration. A rejected or stationary movement-only turn records a zero-action,
zero-minute whole-turn receipt, with matching origin and destination. It records
no traversal or visit and cannot be retried into a successful movement under
the same message ID. A rejected request with additional activity leaves that
activity eligible for the ordinary time updater. Retreat and return visits preserve established changes.

## Dungeon room entry

A hex area with `kind: "interior"` whose parent location has `type: "dungeon"`
uses the dungeon room panel and Go action. First visits offer a short action
form. A blank form simply enters. A written approach can stop outside, and
a blocked passage never becomes traversable through narration. Longer routes
stop at the first room that needs an approach.
The story uses hex routing throughout its world map. This room behavior
does not switch an otherwise non-hex campaign to hybrid travel.

For an unresolved known hazard on revisits, optionally key
`world_map.hex_layout.dungeon_entry_checks` by the exact room ID. Each record
contains exactly these fields:

```json
{
  "known_flag": "tripwire_seen",
  "resolved_flag": "tripwire_disarmed",
  "warning": "The tripwire you spotted is still armed."
}
```

Both flags reference distinct existing booleans in `story_inventory`.
Only known=true and resolved=false shows the warning and reopens the approach
form. Use actual room interactions or objective effects to set them. Keep
concealed hazards in private room descriptions until observed. Visits,
observations, trap resolution, and loot grants are separate state changes.

## Authored passage status rewards

Objectives, choices and other canonical reward owners can change the status of
one existing hex passage:

```json
{"type":"set_hex_passage_status","passage_id":"mine-entry","status":"blocked"}
```

These are the only fields. `passage_id` must exactly reference an existing
passage in the story's opted-in hex layout. `status` must be exactly `open`,
`closed`, `locked` or `blocked`. This reward changes no geometry, position,
travel time, discovery, visit or history data. It participates in normal reward
transactions, persistence and source-message undo. Use it for an authored gate
closing after an assessment or opening after an established event. It does not
permit ordinary door actions or background AI updates to bypass barriers.
Do not imitate it with `set_state_field` into `world_map`; that path remains
forbidden. Room interactions retain the narrower reward whitelist below.

## Declared room outcomes

Optional `interaction_ledger` requires exactly `version: 1`, `definitions` and
`receipts`. Start `receipts` as `{}`. `definitions` is an object keyed by
location ID; each value is an object keyed by interaction ID.

Each interaction requires exactly `id`, `title`, `criteria`, `requirements`,
`rewards` and `repeatable`. IDs match their keys; title and criteria are
nonblank exact text; requirements and rewards use the canonical existing
contracts. Rewards must be nonempty. Current room effects permit
`add_story_item` and `set_state_field` for an already-authored boolean directly
under `story_inventory`. Other gameplay outcomes use their existing systems.

Opening a container and taking its contents should be separate interactions
when the player can do one without the other. Give collection an appropriate
requirement, and mark one-time outcomes `repeatable: false`. Do not require
selecting a quest merely to interact with a room. Completion checks use actual
finished narration, not an unfulfilled player intention. Ordered effects and
receipts apply atomically; retrying cannot grant the same item twice.

The engine owns receipt evidence, real source-message IDs and completed
interaction keys. Do not hand-author fake completion history. Undoing a turn
also rewinds its effects and receipts.

## Staged new-place generation

Authors decide bounds, reserved locations, allowed kinds, connection anchors
and guidance. Existing authored tiles, including undiscovered future places,
are reserved and cannot be overwritten. Begin with buildings inside a fixed
settlement rather than asking for an unconstrained new city.

An enabled area's `generation_rules` requires exactly:

```json
{
  "guidance": "Ordinary bookshops, public greens and repair workshops. Preserve the sealed storehouse.",
  "batch_size": 3,
  "passage_minutes": 2,
  "connection_anchor_ids": ["lantern-road"],
  "new_place_types": ["bookshop", "park", "workshop"],
  "scale_by_type": {"bookshop": "site", "park": "site", "workshop": "site"}
}
```

Guidance is nonblank text. Batch size is a positive safe integer; passage
minutes is a nonnegative safe integer. A batch uses the remaining empty capacity when fewer cells remain. Anchors are existing places in this
area. New types are a nonempty unique subset of its allowed types, and
`scale_by_type` has exactly those type keys with nonblank scale strings.

Also provide layout `generation_state` as
`{"version":1,"batches":{},"development":{}}`. The engine fills its receipts
and exact `pending`/`ready` statuses; authors do not invent generated IDs or
mark an undeveloped place ready.

Generation first designs names/purposes in prose, separately serializes those
proposals, then places the same proposals in bounds using explicit coordinates
and connections. Only the entered place receives detailed public/private text,
again with creative prose separated from serialization. Revisiting a ready
place reuses its recorded definition. Generation does not automatically grant
items, resolve encounters, recruit people or complete plot objectives.

## Author review

Validate the complete story with the normal game validator. Check every
opening/current/parent/passage reference, reserved tile, nested entrance,
reachable route and declared duration. Use the story builder's Opening panel
to edit the nested map fields; its structured editor preserves the complete
layout. Review private descriptions separately from public map text.

For acceptance, play a route by map and conversation, reject a closed/locked
route, retreat, revisit, collect an explicitly declared item, try again, save a
note, reopen and edit an earlier action. Confirm state, images and character
identities survive reopening and that undo removes only the affected outcomes.

## Shops in another city

Opening a shop whose authored nonempty `settlement_name` differs from the
current location first offers travel, naming its destination and exact valid
route duration. Declining changes no time, position, stock or funds. Acceptance
revalidates the route and uses the ordinary journey before opening the shop.
Transactions and job acceptance cannot happen remotely. Local shop entry keeps
its normal behavior.

The shop's `npc_location_id` must reference a mapped hex destination with a valid
timed route. A missing route cannot teleport the player or invent time/fees.
Detours and multi-day routes use their actual summed passage durations and the
normal calendar/once-only journey receipt; no extra activity-time charge applies.
If the quote or route changes before movement, the old quote cannot authorize
arrival. Ordinary unlocked objectives do not acquire hidden expiry dates merely
because travel took several days. Authors define actual timed events separately.
