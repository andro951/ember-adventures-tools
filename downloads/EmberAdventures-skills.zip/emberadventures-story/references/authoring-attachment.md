# EmberAdventures story authoring

Build a playable story around a clear player role, a promise, an immediate situation, and choices with consequences. For a larger story, capture the creator's intent, scope, working location, and playable outcomes before producing JSON. For a small scenario with an explicit premise, resolve only genuinely missing decisions. Provide a story JSON file with exact case-sensitive fields and share concrete validation results separately.

## Opening and agency

- Write an opening as one assistant message. Put the player in a comprehensible place, give them something concrete to notice or react to, and leave at least two genuinely different actions available. A quiet opening can give the player a warm encounter or a specific invitation. Avoid choosing the player's actions or feelings. Make the first few turns deliver the promise of the library card. A sandbox objective may stay open while the player explores other viable leads.
- Start with a playable problem, opportunity, or relationship. Supply facts the player can act on, especially spatial facts for exploration and tactical roles. The player should be deciding what to do with the information. Keep explanations short and layer in history when it becomes relevant.
- Use |[player_name]| or |[player_first_name]| to address the selected player and |[character:stable-character-id]| for an NPC whose name can vary. Keep IDs stable across presentations. Keep content visible to the player free of spoiler notes, branch mechanics, and future cast metadata.

## Envelope and starting state

- Use the validated story example. The outer app is "EmberAdventures" and exportType is "story-template". Inside storyTemplate, app is "EmberAdventures" and templateType is "story". Both editions use these values. Put authored metadata, the opening and state inside storyTemplate.
- A story with selectable library protagonists uses allow_any_player. An optional any_player_starting_state can apply authored starting-story data when requested by the creator. Leave the example's null value when no overlay is needed. Avoid overwriting a player outfit by accident. Author all starting options with the same depth and coherence. Use exact stable IDs and player references.
- Place the default player in state.player, alternate authored players in state.players, starting companions in state.characters, local NPC records in state.npc_directory, and unrevealed cast in state.future_cast. The NPC directory associates named identities with locations. Physical scene membership is separate from stored location and party membership. Only present actors belong in the opening scene and image targets. Put future identities only where the current story can safely withhold them.
- The initial world map and location should agree with scene, time, named NPC rooms, and opening. Place authored locations on their appropriate hex layers, keeping believable travel distances and meaningful unexplored space. Do not invent map field aliases or put unvisited locations into starting player knowledge. Put actual story currency, supplies, equipment and starting resources in their respective fields. An economy needs its currency named in story metadata and a matching inventory record. Keep process notes and engine session values out of story definitions.

## Objective and reward flow

- Author a clear opening objective with a visible summary and an exact private completion condition. Explain what counts as concrete progress. Give normal narration only information the relevant scene can know. Put actions after completion in the correct completion or transition fields, rather than asking the narrator to simulate state effects.
- Use player control for a player action, AI control for a plot event the narrator may initiate, and choice control for explicit options. Use evidence requirements and meaningful alternate outcomes when an action can legitimately fail or be refused. Complete solely when supported by the action or scene. Avoid forced lockstep progression unless the intended experience needs it.
- Use numeric requirements for real mechanical thresholds, authored rewards for mutations, ordered authored output IDs for branching, and the supported ending fields for conclusions. Reuse IDs consistently across state graph, routes, rewards, and journal references. Check for unintentional loops, dangling routes and single unreachable branches.
- Include one concrete payoff early, a clear next opportunity, and a coherent resolution or explicit freeplay handoff. For a sandbox, authored state gives the narrator enough to respond well even when the player ignores the tracked objective.
- Optional systems include jobs, timed events, maps, character schedules, property, combat, and stat sharing. Start with the schema for the selected edition. Use optional fields only for systems the creator wants. For a complicated feature whose type or layout is unclear, ask for a current game export that already uses that feature before adding it. Preserve unrelated authored systems and save identity when editing an existing story.

## Embedded characters

Apply the character rules and exact embedded field sets below to every humanoid and animal, including future cast and alternate players. Characters should have their own immediate goals, knowledge, clothing, speech, and reactions. Resolve gender tokens against their chosen presentations. Names and IDs in NPC directory, party, effects, opening text and map data must refer to the intended individual.

## Validation

Parse the resulting JSON and check exact fields, IDs, types, references, time, cast visibility, openings, objective transitions and endings. Verify actual import and story start when available. Check the natural first action and a reasonable alternative against what the objective accepts. Report each completed check accurately.
