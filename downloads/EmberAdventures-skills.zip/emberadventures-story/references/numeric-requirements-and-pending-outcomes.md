# Numeric eligibility and unresolved outcomes

These are normal EmberAdventures contracts, not permissions to change a
campaign's prices, capacities or balance. Examples below are partial sketches;
the complete validated example is [pending-agreement-story.json](pending-agreement-story.json).

## Exact numeric eligibility

Use type exactly numeric_expression with expression, op and value. The expression
uses the existing safe numeric-reward grammar: initial plus operations containing
operation and operand. Operations are add, subtract, multiply and divide.
Operands are finite numbers, {value:number}, or {path:[exact,path,parts]} with
optional character_id for a character-relative reference. These are structured
expressions, never executable JavaScript or a string formula.

For example, require at least8 currently available capacity:

```json
{
  "type": "numeric_expression",
  "expression": {
    "initial": { "path": ["story_inventory", "pact_capacity"] },
    "operations": [
      { "operation": "subtract", "operand": { "path": ["story_inventory", "pact_used"] } }
    ]
  },
  "op": ">=",
  "value": 8
}
```

Numeric comparisons are >, >=, <, <=, == and !=. value is a finite number, not
text. Missing/non-numeric references and undefined arithmetic refuse eligibility;
they never become zero or an enormous available balance. Comparisons use exact
rational arithmetic, not a cached free-capacity counter or an AI estimate.

Put an UPFRONT gate in completion_requirements, a player's choice.requirements,
or an AI outcome's requirements. Completion rechecks current eligibility before
its effects. A later capacity return cannot satisfy that earlier gate.
Deterministic next_objectives requirements retain their existing AFTER-reward
routing semantics; they are not an upfront-cost gate. Requirements check
eligibility but do not spend the resource: author the actual cost and return as
explicit rewards in the intended order. Existing once-only invocation and native
undo/reload rules still apply.

The guided requirement editor offers Calculated Numeric Amount. The narrator
receives calculated current amounts/eligibility; narration does not own the math.

## Leave an unclear outcome pending

An AI-routed objective may add exactly:

```json
{
  "route_control": "ai",
  "unresolved_route_behavior": "keep_pending_no_effects"
}
```

This property is optional, allowed only with AI outcome routing, and has only
that exact value. Omit it to retain the existing required unconditional fallback.
With it, do not author a fallback route. Each actual outcome needs explicit
criteria; undetermined is reserved for the AI's pending response, not a route ID.

The outcome classifier can return outcome: undetermined. Ambiguous evidence,
unusable responses after logged repairs, or no eligible outcome leaves this
objective pending without completing it, selecting a route, consuming rewards or
transitioning. One eligible route is still not an automatic choice. The ordinary
narrator asks the needed clarification without inventing a commitment.

This guarantees the objective transaction does not commit on an unresolved
result; it does not prove the model can never confidently misclassify a clearly
formatted answer. Write discriminating criteria and test ambiguous actions.
Unrelated actual gameplay remains actual gameplay: pending classification does
not undo movement, dialogue or earlier completed objectives.

For a side objective, an outcome can finish the task and return to the unfinished
main/interrupted quest without ending the whole story. Give the output its id,
criteria, completion_instruction and rewards array, and omit next_objective_id,
target_input_group_id and ending_type. Do not invent a self-loop or fake freeplay
ending. Main-objective outputs still need an actual successor or ending.

The guided AI-output inspector offers Keep pending when the outcome is unclear.
Changing output mode must not turn an explicitly pending one-route classifier
into automatic completion. New outcomes in this mode do not acquire a fallback.

These contracts do not add Abandon policies, conditional Home rates, new travel
fees or a new combat/healing system. Those have separate contracts/status.
