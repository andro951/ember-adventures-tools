# Player Home and lodging

Use optional `state.player_home` when the story should track the player's
accepted accommodation and collect agreed charges after actually used nights.
Omitting it disables Home processing; do not add it to unrelated stories.
It does not manage NPC housing or finances.

An initially unaccepted offer can use:

```json
{
  "version": 1,
  "current": null,
  "pricing_guidance": {
    "workshop": "Mira can offer the upstairs guestroom for two coins per actually used night, payable on waking. No advance payment or charge while away. Both parties must actually agree."
  },
  "nights": {},
  "pending_wakes": {}
}
```

Each pricing-guidance key must exactly identify a location in
`state.world_map.locations`. Guidance is hidden narrator context, not an agreed
tariff or automatic advertisement. Supply it at locations where an offer may be
discussed. Asking a price, visiting, inspecting a room, hearing an offer or
intending to rent it does not accept Home, spend money or start sleep.

For an established Home, `current` is exactly:

```json
{
  "id": "workshop-guestroom-agreement",
  "name": "Mira's upstairs guestroom",
  "location_id": "workshop",
  "counter_id": "coins",
  "nightly_cost": 2,
  "terms": "Two coins per actually used night, paid on waking. No charge while away."
}
```

All six fields are required. `id`, `name`, `location_id` and `terms` are nonempty
text. The location must exist. `nightly_cost` is a finite nonnegative number.
Paid accommodation requires the exact ID of an existing finite numeric
`state.story_inventory` counter. Free accommodation uses `nightly_cost: 0` and
`counter_id: ""`; do not invent a free currency counter. Free palace quarters,
a gifted home or a standing invitation can therefore begin established.
`agreement_source_id` is optional provenance text, normally written by the
engine when an actual dialogue agreement is established.

Leaving or sleeping elsewhere does not end the agreement. A different actual
agreement can replace it. This initial system bills used nights, not reservation
fees, skipped days, deposits, mortgages or NPC household accounts. Represent
other costs with existing explicit shops/rewards instead of pretending that
Home supports them. Keep terms consistent with this used-night policy.

The engine checks an actual wake and, only for relevant paid accommodation,
asks whether the player actually slept at that accepted Home. It freezes the
original source and accepted terms while that question is pending. No Home or
free accommodation receives a paid-night question. Uncertain evidence and
nights elsewhere authorize no deduction. Narrative payment claims do not create
funds, credit or a debt contract.

`nights` and `pending_wakes` are engine-owned identity maps; start both empty.
`last_check_message_id` is optional engine-owned processing provenance and is
omitted in a new story. Do not write fictional history into these maps. A night
identity is the literal JSON array string `[location_id,year,month,day]` for its
waking date; keep it intact. Renaming or renegotiating the same room cannot
rebill that night.

A pending record contains exactly `id`, `home` (the complete accepted snapshot),
`waking_date` (`year`, `month`, `day` whole numbers), `source_message_id` and the
full original `source_text`. A completed record adds `status` and `amount`:
`paid` requires exactly the agreed nightly cost, while `insufficient_funds`
requires zero. The same ID cannot be pending and completed. Insufficient funds
never create a negative balance or invented payment; the Home panel offers an
explicit later settlement if funds become available. Wallet and receipt persist
together, and replay/rollback restores their previous state together.
