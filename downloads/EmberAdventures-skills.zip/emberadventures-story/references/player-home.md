# Player Home and lodging

Use optional `state.player_home` when the story should track the player's
accepted accommodation and collect agreed charges after actually used nights.
Omitting it disables Home processing; do not add it to unrelated stories.
It does not manage NPC housing or finances.

An initially unaccepted offer can use:

```json
{
  "version": 1,
  "current": null,
  "pricing_guidance": {
    "workshop": "Mira can offer the upstairs guestroom for two coins per actually used night, payable on waking. No advance payment or charge while away. Both parties must actually agree."
  },
  "nights": {},
  "pending_wakes": {}
}
```

Each pricing-guidance key must exactly identify a location in
`state.world_map.locations`. Guidance is hidden narrator context, not an agreed
tariff or automatic advertisement. Supply it at locations where an offer may be
discussed. Asking a price, visiting, inspecting a room, hearing an offer or
intending to rent it does not accept Home, spend money or start sleep.

For an established Home, `current` is exactly:

```json
{
  "id": "workshop-guestroom-agreement",
  "name": "Mira's upstairs guestroom",
  "location_id": "workshop",
  "counter_id": "coins",
  "nightly_cost": 2,
  "terms": "Two coins per actually used night, paid on waking. No charge while away."
}
```

All six fields are required. `id`, `name`, `location_id` and `terms` are nonempty
text. The location must exist. `nightly_cost` is a finite nonnegative number.
Paid accommodation requires the exact ID of an existing finite numeric
`state.story_inventory` counter. Free accommodation uses `nightly_cost: 0` and
`counter_id: ""`; do not invent a free currency counter. Free palace quarters,
a gifted home or a standing invitation can therefore begin established.
`agreement_source_id` is optional provenance text, normally written by the
engine when an actual dialogue agreement is established.

Leaving or sleeping elsewhere does not end the agreement. A different actual
agreement can replace it. This initial system bills used nights, not reservation
fees, skipped days, deposits, mortgages or NPC household accounts. Represent
other costs with existing explicit shops/rewards instead of pretending that
Home supports them. Keep terms consistent with this used-night policy.

The engine checks an actual wake and, only for relevant paid accommodation,
asks whether the player actually slept at that accepted Home. It freezes the
original source and accepted terms while that question is pending. No Home or
free accommodation receives a paid-night question. Uncertain evidence and
nights elsewhere authorize no deduction. Narrative payment claims do not create
funds, credit or a debt contract.

`nights` and `pending_wakes` are engine-owned identity maps; start both empty.
`last_check_message_id` is optional engine-owned processing provenance and is
omitted in a new story. Do not write fictional history into these maps. A night
identity is the literal JSON array string `[location_id,year,month,day]` for its
waking date; keep it intact. Renaming or renegotiating the same room cannot
rebill that night.

A pending record contains exactly `id`, `home` (the complete accepted snapshot),
`waking_date` (`year`, `month`, `day` whole numbers), `source_message_id` and the
full original `source_text`. A completed record adds `status` and `amount`:
`paid` requires exactly the agreed nightly cost, while `insufficient_funds`
requires zero. The same ID cannot be pending and completed. Insufficient funds
never create a negative balance or invented payment; the Home panel offers an
explicit later settlement if funds become available. Wallet and receipt persist
together, and replay/rollback restores their previous state together.

## Conditional nightly pricing

Optional `price_modifiers` is a location identity map on `state.player_home`.
Each location has exactly `counter_id` (an existing finite numeric inventory
counter) and `modifiers` (an array). Every modifier has exactly a unique nonempty
`id`, nonempty `label`, finite signed `amount`, and canonical `requirements`.
Use the ordinary requirement contract, including numeric expressions when needed.
Optional `operation` is exactly `add` or `multiply`. Omission preserves the
existing additive meaning; it does not add a field to older clauses. For
`multiply`, `amount` is a finite nonnegative factor: `0.8` means twenty percent
off, `1.2` means twenty percent extra, and `0` means a full discount.

```json
{
  "workshop": {
    "counter_id": "coins",
    "modifiers": [
      {"id":"shortage","label":"Supply surcharge","amount":5,"requirements":[{"path":"world_flags.shortage","op":"==","value":true}]},
      {"id":"loyalty","label":"Agreed loyalty discount","amount":-2,"requirements":[{"path":"world_flags.discount_offered","op":"==","value":true}]}
    ]
  }
}
```

The agreed `current.nightly_cost` remains the BASE. When an actual wake is being
prepared, the engine adds all applicable additive amounts, then applies all
applicable multiplication factors, using exact decimal arithmetic. This order
does not depend on where clauses appear in the array. For example, a ten-coin
base plus an authored ten-coin blocked-route surcharge, then a twenty-percent
discount (`operation: "multiply", amount: 0.8`), costs sixteen. Neither the
surcharge nor the discount applies without its actual requirement being met.
There is no automatic blocked-route fee or universal loyalty discount.
A five-coin base plus five shortage coins costs ten; after the
shortage ends and an explicitly offered two-coin discount applies, it costs
three. The total must be finite and nonnegative; invalid negative prices fail,
they do not become refunds or silently clamp to zero. A free base can become
paid under an authored surcharge using the modifier book's currency. A paid
base and the book must use the same currency.
No implicit currency rounding is applied. A zero total is free and does not
prepare a paid-night check; existing receipts and base agreements are unchanged.

Require actual knowledge/offer conditions for benefits. Completing a quest does
not make a host omniscient or automatically grant a discount. Use a delivered
scene/reward to establish `discount_offered`, for example, after the host learns
what happened. The engine-calculated current quote is private narrator context;
it does not authorize payment before waking or retroactive repricing.

The pending/finished night optionally adds exact `pricing`:
`{"base_nightly_cost":5,"modifiers":[{"id":"shortage","label":"Supply surcharge","amount":5}]}`.
An explicitly supplied operation also appears on its frozen modifier, for example
`{"id":"loyalty","label":"Agreed twenty-percent discount","amount":0.8,"operation":"multiply"}`.
The components must calculate exactly to that night's frozen `home.nightly_cost`.
These components
persist with the original source. Later condition changes, retries, insufficient
funds and explicit settlement use the frozen amount, once. Earlier committed
nights remain unchanged. New stories leave all night maps empty.

## Before sleep

For an accepted Home or a story containing a `before_sleep` trigger, a small
plain-text yes/no check runs on an actual player message before narration.
Only a concrete attempt to sleep for the night qualifies; naps, hypothetical
plans and telling somebody else to sleep do not. This is separate from the
after-reply actual-wake/used-night check and never itself advances time or bills.
See [triggered quests](short-interruptions.md) to deliver an authored encounter
before sleep. After its entry beat is resolved, the player chooses whether to
sleep again; an uncompleted longer quest need not prohibit sleep forever.

Complete example: [Bramble lodging scenario](conditional-home-story.json).
