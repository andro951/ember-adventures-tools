# Objective Direction, Handoffs, And Iterative WIP Editing

## Choose Scene Mode Intentionally

Normal EmberAdventures stories may move in and out of two complementary modes.

- **Authored scene sequence:** Use a tight chain of linked objectives when the
  story needs deliberate pacing, a sequence of reveals, political procedure,
  investigation, training, negotiation, romance development, an emotional
  confrontation, a social ritual, a trial, a mission briefing, or any scene
  where each response should establish the next beat. A tight chain is not
  limited to the opening. Enter it whenever the author needs to tell a
  particular sequence of scenes, then return to broader player control when
  that sequence has delivered its purpose.
- **Open objective:** Use a larger objective when the player should control the
  method, order, tone, or amount of engagement: explore a city, earn access to
  a faction, investigate a mystery, prepare for a journey, pursue optional
  relationships, or solve a problem by any plausible approach. Do not create
  artificial micro-objectives merely to force the player through an otherwise
  open situation.

A strong story alternates deliberately. A broad objective can lead into a
political hearing; the hearing can use a tight sequence of authored objectives;
after the decision and consequences, the story can return to a broad objective.
Freeform relationship time can lead into a tightly authored confession,
argument, invitation, boundary, or shared crisis, then return to free play.

## Required Objective-Handoff Pass

For every objective in an authored scene sequence, validate this handoff:

`previous completion criteria -> previous completion instruction -> current
scene -> next title -> next summary`

Before writing or revising Objective N, inspect Objective N-1 and answer:

1. What exact player action or world result completes Objective N-1?
2. What does its one-time completion response show?
3. Where is the player after that response?
4. Who is physically present, and who is only known or expected elsewhere?
5. What does the player know, and what remains hidden?
6. What immediate action, choice, conversation, or freedom is now available?
7. Does Objective N's title clearly ask for that action?
8. Does Objective N's summary describe that exact live situation and why the
   action matters now?
9. Does Objective N-1's completion instruction stop before doing Objective N
   for the player?
10. Is Objective N's title still a pending action at activation, rather than a
    state or event Objective N-1 has already established? Reject it if its
    title would already be true as soon as the previous completion response
    ends.

Do this pass for each handoff in a tight sequence. For a broad/open objective,
validate only that its starting situation and completion criteria leave room for
multiple credible player approaches.

When the user builds objectives incrementally, begin the response by restating
the previous approved objective's completion condition and output instruction
before proposing the next objective. Do not jump ahead into unapproved future
content. Preserve stable ids and unrelated story data.

## Output Instructions Are One-Time Handoffs

An output's `completion_instruction` directs the immediate narrator response
when that result resolves. It is not permanent scene guidance, durable memory,
a replacement for deterministic rewards, or permission to complete the next
objective automatically.

Use it to do only the work needed to hand the story forward:

- show the immediate consequence;
- reveal one relevant fact;
- visibly introduce someone whose definition has been unlocked or made current;
- move the scene or advance time;
- establish the next actionable situation.

Then stop. An output instruction should hand the scene to the next objective,
not consume the next objective's playable content. A travel objective normally
establishes the destination and the next interaction; it does not perform the
entire conversation, lesson, negotiation, or conflict waiting there.

Do not use an output instruction as a container for authored exposition that
the player must receive. If a character must communicate particular facts,
terms, motives, warnings, findings, or a reveal, enable Dialogue on that output
and place the required wording in `dialogue_lines`. The instruction may direct
the delivery's tone, reaction, movement, or immediate consequence, but it must
not be the only place a required explanation lives.

## Dialogue Outputs

Dialogue is an output modifier, not a separate objective type or completion
system. Use ordinary `type: "story"` or `type: "side"`, choose the correct
completion family, and put `dialogue_lines` on the output that must deliver the
authored lines.

Use dialogue outputs for explanations, tutorials, magic rules, contract terms,
warnings, briefings, confessions, discoveries, announcements, twists, personal
reveals, memorable phrases, exact player responses, or any moment where
specific wording must reach the player. An objective can have dialogue on one,
several, or every output.

For AI-controlled outputs, `dialogue_lines` is a non-empty ordered array of
complete literal character lines. Every entry includes the intended speaker
tag in parentheses, quotation marks, and exact wording:

```json
{
  "id": "mentor-explanation-output",
  "objective_id": "respond-to-mentor",
  "target_input_group_id": "respond-to-mentor-input-1",
  "completion_instruction": "|[character_first:mentor-id]| speaks with patient precision and watches for the player's reaction.",
  "dialogue_lines": [
    "(|[character:mentor-id]|) \"First required line.\"",
    "(|[character:mentor-id]|) \"Second required line.\""
  ],
  "requirements": [],
  "rewards": []
}
```

Use normal runtime character-reference tokens so the line resolves to the
character's actual playthrough name. EmberAdventures gives the output's normal
`completion_instruction` to the narrator and requires every dialogue line
exactly once in authored order. The narrator may respond to the player's last
action first when necessary and may add narration, reactions, demonstrations,
or other dialogue between required lines, but must not paraphrase, merge, omit,
reorder, or alter them.

The output `completion_instruction` remains general guidance for the complete
response. It can direct tone, behavior, narration, demonstration, emotional
reaction, scene movement, or another appropriate beat. Do not create a second
dialogue-specific instruction field.

For player-controlled dialogue, use Player Choice with
`choice_response_mode: "exact_text"` and put the required player wording in the
selected output's `player_text`. Use `choice_response_mode: "optional_text"`
when the option should permit the player to add or omit their own response.
Do not put a character selector on player dialogue; the speaker is the player.

### Exposition Pattern

Dialogue outputs are the required tool when a story must deliver authored
exposition reliably. Do not list many facts in `completion_criteria` or
`completion_instruction` and hope the narrator covers them. Put the exact
information in output `dialogue_lines`.

For a character-led explanation, use a short chain of AI Scene Objectives with
Dialogue when the player should react between information groups. The first
objective can complete when the player directly speaks to the explaining
character:

```text
Return yes when the player speaks to |[character:mentor-id]|.
```

Later objectives can complete when the player responds, shows signs of
listening, asks a relevant follow-up, asks the character to continue, or
observes a demonstration:

```text
Return yes when the player responds to |[character:mentor-id]|, shows signs of
listening to the explanation, asks a relevant follow-up question, asks the
character to continue, or observes the demonstration. Do not complete when the
player changes the subject, leaves, or merely remains nearby without engaging.
```

The explaining character drives the explanation. Do not require the player to
guess which question unlocks the next fact or ask for information the
character has already been directed to deliver.

## Objective Summaries Describe The Live Situation

An objective summary is player-facing. It describes the immediate situation and
why the requested action is relevant now. Include current pressure, useful
context, available freedom, and who or what is waiting when that information
helps the player decide what to do. If an objective has a `summary` field, do
not leave it blank. The player usually opens the summary because they want help,
so give a minor non-spoilery hint about how to approach or complete the
objective: likely person, place, action, resource, topic, or constraint. It must
add meaningful context beyond the title without exposing hidden future outcomes,
route labels, endings, betrayals, or unearned consequences.

## One Objective, One Completion Beat

Every objective must require only one simple event, action, decision, result, or
scene-ending condition to complete. An objective is not a checklist. Do not put
an entire conversation, investigation, lesson, trip, relationship change, or
scene plan into one `completion_criteria`.

Treat these as strong warning signs that the objective is doing too much:

- the completion criterion contains a list of things that must all happen;
- the criterion joins separate required beats with `and`, `then`, `after`, or
  similar sequencing language;
- the title or summary names several distinct actions;
- completion requires the player to ask several questions, visit several
  places, receive several explanations, make several decisions, or produce
  several unrelated results;
- the narrator would need to track a hidden checklist before it could return
  yes.

When any warning sign appears, assume the objective is wrong and restructure it
unless every clause is merely another equivalent way to prove the same single
completion beat. An `or` list may describe equivalent evidence for one result;
it must not disguise several separate tasks.

Use one of these three normal structures when a scene needs many things:

1. **Sequential objective chain.** Create a chain in which each objective waits
   for one simple thing, completes, and hands off to the next objective. Use
   this for authored explanations, investigations with ordered discoveries,
   rituals, training, multi-stage travel, or any scene where several distinct
   beats must reliably occur.
2. **Open-ended scene with one player-controlled exit.** Put the optional
   topics, interactions, activities, and opportunities in the player-facing
   summary, but give the objective one unmistakable completion action such as
   leaving the room, going to sleep, ending the date, departing the camp, or
   explicitly concluding the meeting. Use this mainly for flexible,
   non-critical play such as dinner conversation, downtime, casual dates,
   socializing, or exploration where the listed activities do not all need to
   happen. Suggested content is not a hidden completion checklist.
3. **Objective tree.** Branch into separate objectives when different player
   actions, discoveries, choices, or outcomes should cause different events.
   Branches may converge on a later shared objective or remain permanently
   separate when the consequences should persist.

Do not solve an overloaded objective by making its criterion vaguer. Split the
required beats, make optional material genuinely optional behind one clear exit,
or model the alternatives as branches. During the final objective audit, inspect
every criterion containing a list or `and` statement and either restructure it
or confirm that it expresses only one completion beat.

## Reusable Objective Patterns

### Conversation, Teaching, And Briefing

Use an AI Scene Objective with Dialogue for any conversation in which a
character must deliver authored information to the player. Put every required
statement in the selected output's ordered `dialogue_lines`; do not bury facts
in a summary, completion condition, or completion instruction and hope the
narrator covers them. This is the required pattern for exposition, but it is
also useful for a confession, warning, instruction, finding, personal
disclosure, or any distinctive line that matters.

The objective title must name the playerâ€™s pending interaction, not the result
of that interaction. Good shapes include `Discuss the Port With the Guide`,
`Review the Assignment`, `Ask the Witness About the Fire`, and `Hear the
Companion's Proposal` when the proposal has not yet been delivered. Do not use
`Arrive in the Port` after the previous objective already established arrival,
or `Learn What the Companion Wants` when the companion still needs to explain
it. Name the actual live action instead.

Use a short chain of AI Scene Objectives with Dialogue when an explanation
needs room for player reaction. The first can use a minimal condition such as
`Return yes when the player speaks to |[character:guide-id]|.` Its output then
delivers the required lines. Later nodes can complete after the player
responds, listens, asks a follow-up, or observes a demonstration. The
explaining character pushes the information forward; the player should never
need to guess the exact question that unlocks it.

Use `completion_control: "ai"` when the scene or another character must decide
whether a flexible conversation, agreement, lesson, escort, or disclosure has
reached its actual result. Use `completion_control: "player"` when the
player's deliberate act itself should trigger the dialogue delivery. Either
control mode can place `dialogue_lines` on its output.

Do not make one objective require a chain such as meeting someone, receiving an
authored explanation, understanding it, and accepting or declining an offer.
Those are separate beats: an interaction or dialogue delivery, then a reaction
or choice when that decision matters. Omit output dialogue only
when the conversation is genuinely freeform and no authored information must be
reliably delivered before completion.

### Freeform Interlude

Use a broad or tightly bounded objective to provide freeform time before one
concrete advancement action: dinner before sleep, an inn evening before
departure, downtime before a briefing, exploration before leaving a building,
or companion conversation before a mission.

Make the eventual advancement action clear. Permit unrelated conversation,
exploration, visitors, or optional interaction first. Complete the objective
only when the player performs the actual advancement action. Do not assume
freeform dialogue creates durable facts or relationship changes; persist any
important result through supported state changes or rewards.

### Time Advancement

For sleep, rest, waiting until an event, or another time jump, make criteria
name the actual state-changing action and explicitly reject plausible
near-misses when useful. Entering a bedroom, lying down, or receiving a visitor
is not necessarily sleeping. The completion instruction may move the player,
advance the time fields, show the wake-up/event, and establish the next action.

### Bridge Objective

When location, time, social context, purpose, or the set of present characters
changes, ask whether that transition is itself a playable beat. Add a bridge
objective when the player needs to choose, travel, converse, prepare, or
otherwise take an action to enter the next scene. Do not jump from a reveal to
bedtime, from an introduction to training, or from an event to an unrelated
location without an authored handoff when the transition has playable value.

## Persistence And Knowledge

Anything later play must reliably know must be persisted in the correct
supported structure. Opening prose and completion instructions establish a
moment; they are not durable memory by themselves.

- Use a state field for an exact supported mechanical value.
- Use a story rule for a current hard runtime constraint or mechanic the
  narrator must obey, not ordinary lore or biography.
- Use story memory/world notes for durable continuity or lore when it does not
  need deterministic mechanical enforcement.
- Use a character/NPC field for identity, ability, durable facts, and other
  facts belonging to that person.
- Use an `adjust_relationship` reward for a persistent social change.
- Use location/map rewards and fields for discovery, availability, and travel.
- Use inventory fields and supported inventory rewards for controlled resources.

Do not invent undocumented nested state paths merely because a generic patch
could write them. Model a custom mechanic only in a documented supported
location. If the normal story schema lacks a suitable supported location,
identify that as an app/schema decision instead of silently inventing a new
persistent shape.

For every important reveal, maintain a knowledge partition: what the player
knows; what each present companion knows; what natives, officials, specialists,
and antagonists know; what is common knowledge; and who learns what during this
scene. Do not make all present characters react as though they share the same
information.

Narrate unfamiliar worlds through the player's knowledge lens. Distinguish what
the player directly perceives, what they can reasonably compare to familiar
media/history, what has been explicitly explained, and what remains unknown.
Do not turn author knowledge into player knowledge.

## Reveal Embargoes And Ensemble Scenes

For an important hidden class, identity, betrayal, secret power, appraisal,
relationship, or mystery, define the reveal objective and audit the embargoed
term/fact before it completes. Scan player-visible/current-context fields:

- title, description, public metadata, and `meta.story_source.description`;
- opening messages, current scene summary, current location text, and current
  NPC/character fields;
- visible objective titles and summaries;
- any current player fields shown in UI or included in ordinary prompts.

The hidden fact may appear in the revealing objective's completion instruction,
deterministic rewards, and later hidden objectives where appropriate. Do not
leak it through an early summary, metadata, current state, or image prompt.

Ensemble openings are valid when the premise requires a group event, summoning,
trial, team selection, family scene, crew introduction, or class ceremony. Keep
one immediate actionable focus, limit unnecessary speaking roles, avoid a cast
encyclopedia, and define every named speaker as a real current NPC or party
member before their voice tag appears. The player must never be placed in scene
speaker/presence lists.

For crowd reactions, do not write a crowd as one synchronized emotional organism
unless that unity is intentional. Differentiate nobles, officials, attendants,
servants, soldiers, and individuals through silence, alarm, whispers, pity,
disbelief, restrained ridicule, calculation, or conflicting reactions.

## Character Introduction And Map Timing

A visible introduction in an output `completion_instruction` is not a
substitute for a usable character definition. Predefine recurring or important
later characters in `future_cast` with full data. On the output where they
visibly arrive, use the applicable introduction/promotion/state rewards so
their identity, availability, and scene presence persist. Do not store a
character's identity only as a story rule.

Distinguish map existence, discovery, travel availability, current location, and
focus location. A location may exist in the template but remain hidden or
unavailable. Unlock it no later than the first objective where the player may
reasonably visit or use it. For a travel handoff, validate applicable updates to
current location, focus location, location detail, discovery/travel availability,
travel history, and valid map connections. Prefer a meaningful hierarchy such
as world -> region -> settlement -> district/building -> room/site rather than
using an unrelated room as the parent of every room in a building.

## Incremental WIP And Final-Release Modes

Use **incremental WIP mode** when the user is intentionally approving a story
one objective, scene, character, or change at a time.

1. Read the exact latest target file.
2. Detect normal story-template versus filesystem-backed Codex story shape
   before authoring. A normal story uses the wrapper documented by this skill
   and `storyTemplate.state.objectives`. It has no `story_engine` or
   `schema_version` discriminator. Route filesystem-backed Codex stories to
   `original-emberadventures-codex-story`.
3. Identify the approved frontier and previous handoff.
4. Propose or patch only the requested fields.
5. Preserve unrelated fields and stable ids.
6. Keep unfinished future routing only at the explicit WIP frontier.
7. Keep WIP/incomplete status outside player-visible story prose and metadata.

Use **final-release mode** only when the user asks for a finished/import-ready or
publish-ready story. Run the complete schema, handoff, visibility, routing,
character, map, and quality passes. No non-terminal main objective may remain
without an intentional route or an explicit scheduled continuation in final-release mode.

## Local File Update Verification

When Codex is asked to modify a local story file:

1. Read the exact source file and identify the requested target/version.
2. Preserve a backup or write a new numbered version when overwrite reliability
   is uncertain or the user asks to preserve prior drafts.
3. Apply only approved targeted changes.
4. Write the output.
5. Reopen the written output and parse it as JSON.
6. Verify exact expected values: objective count and ids, edited titles,
   summaries, criteria, instructions, completion requirements, output
   requirements, rewards, output destinations/input groups, location
   references, and any other requested values.
7. Report success only after that verification and give the exact output path.

Do not claim a write succeeded merely because an edit command was issued. This
procedure applies to Codex file edits; it does not assume a user working in an
external ChatGPT session has local filesystem access.

## Adjacent-Title Rhythm

Read objective titles in sequence as well as individually. Improve repetitive
adjacent title shapes when a clearer natural verb exists, but preserve clarity
and stable ids. Repetition is a soft quality concern, not a reason to replace
the clearest player-facing title.

# Integrated Reference Material

The following sections were formerly bundled reference files. They remain authoritative and are included here so this skill is fully self-contained.


---


# EmberAdventures Objective Patterns

Use objectives as the playable story engine.

## Objective Item

Recommended object:

```json
{
  "id": "stable-kebab-id",
  "title": "Short Action Title",
  "type": "story",
  "status": "hidden",
  "summary": "Player-facing context and a useful hint.",
  "while_active_guidance": "Keep the scene focused on the sealed door and do not reveal what is beyond it before the player opens it.",
  "completion_control": "player",
  "completion_criteria": "Return yes when the player opens the sealed door.",
  "completion_requirements": [],
  "next_objectives": [
    {
      "id": "stable-kebab-id-output-1",
      "objective_id": "next-stable-objective-id",
      "target_input_group_id": "next-stable-objective-input-1",
      "completion_instruction": "Show the door opening and reveal the room beyond.",
      "dialogue_lines": [],
      "requirements": [],
      "rewards": []
    }
  ]
}
```

Opening objective differences:

- `status`: `"active"`
- Its id is `state.objectives.active_id`.
- It has no incoming graph transition.

All other main objectives start `status: "hidden"` and are reached through
output transitions. Do not author empty/default optional fields merely to show
that they exist.

## Chain Design

For long original stories, make a milestone list first, then convert milestones into objectives.

Good objective granularity:

- One scene-scale task.
- One decision, encounter, purchase, reveal, or travel beat.
- Avoid giant objectives like "complete the entire city arc."

Use hidden main objectives for story order. Use hidden side objectives for optional intimacy, downtime, investigations, training, shopping, extra character focus, premise-specific side content, mechanically useful detours, comedy beats, and other memorable play.

Default to including meaningful side content in full story templates. A good
story usually has a main spine plus optional branches, not only a straight
line. Do not omit major side stories or fun one-off side objectives unless the
user asks for a minimal/critical-path-only template.

Side content can be:

- A single one-off objective.
- A short side chain.
- A side tree with a decision or reward choice.
- A major optional arc unlocked by a hub, cast member, location, or main-story
  milestone.

Branching main structure is also normal. One objective may unlock multiple
paths; several paths may all be required before a major later objective; or
optional branches may open alongside the next main objective. Use this when it
matches the source/story instead of forcing every campaign into one linear
chain.

## Story Direction Before Objectives

Before drafting objectives for a serious story, define the player fantasy,
emotional target, world hook, progression/building axis, major relationship
arcs, midpoint or reevaluation moment, climax, ending/postgame shape, and
structure mode. If those pieces are vague, the objective chain will usually
become a list of chores or chapter titles instead of a playable story.

Use the objective spine to enforce anticipation and payoff. The live AI can
write individual scenes, but objectives must decide when relationships soften,
when information is revealed, when intimacy becomes available, when an NPC's
attitude changes, when failure matters, and when the world reacts.

For relationship-driven stories, place bridge objectives between major plot
beats. Good bridge objectives can ask the player to spend time with someone,
learn something personal, earn a voluntary disclosure, prepare together,
survive a small mission, share downtime, recover after conflict, define a
boundary, accept or refuse temptation, or deal with jealousy/consequences. Do
not jump directly from introduction to attraction to sex or loyalty unless the
user explicitly requested that pacing.

For NSFW stories, design sexual content as part of the story arc. Use
objectives to create invitation, tension, consent/refusal, anticipation,
ambiance, escalation, and aftermath. Optional-with-skip choices are useful when
the story should offer intimacy without forcing it.

Give the world and major NPCs motion outside the player's immediate action.
Objectives may represent rivals acting, deadlines moving closer, shop/job
opportunities changing, NPCs pursuing their own plans, or the player arriving
too late. Failure, rejection, death, loss, and missed opportunities are valid
story outcomes when they are intentional and supported by rollback/choice flow.

## Story Structure Mode

Before drafting objectives, ask whether the story should be one of these modes
unless the user already specified the structure:

- Open adventure: a clear main direction with significant freedom, broad side
  objectives, exploration, jobs, shops, and AI-adapted connective play.
- Guided story: a strong main objective chain with open interludes and optional
  side arcs between authored story beats.
- Time-controlled story: main events are scheduled, time-locked, and separated
  by downtime gaps where the player may explore or pursue side content.
- Choice-heavy / Choices-like: direct player choice menus, mutually exclusive
  routes, hidden outcome logic, branch consequences, and multiple endings.
- Sandbox: world setup, systems, recurring loops, locations, jobs, shops, and
  emergent objectives with little or optional fixed plot.
- Relationship-focused: objectives primarily develop trust, affection, desire,
  rivalry, dependency, loyalty, betrayal, repair, or other character arcs.
- Telltale-style branching: direct player choice menus, mutually exclusive
  routes, hidden outcome logic, failure/death branches when appropriate, and
  multiple endings.
- Linear/mostly-linear: one strong objective spine with bridge objectives,
  side arcs, and occasional real choices only when they materially change play.

If the user does not know which mode they want, do not dump every option as a
blocking questionnaire. Ask a few story-intent questions, then recommend one to
three suitable modes with a short reason. The user may choose one, blend them,
or say "you decide"; if they delegate, choose the structure that best serves the
premise and explain the practical result briefly. Once those few questions give
enough direction, explicitly offer to complete the story instead of continuing
to ask more questions.

If interaction is unavailable or the user explicitly asked for no questions,
infer from the premise. Moral dilemmas, dark romance agency choices, faction
routes, survival mistakes, player-defined laws, bargains, and ending decisions
usually benefit from Telltale-style structure. Guided adventures, focused
relationship arcs, slice-of-life loops, and simple original adventures often work
better as linear/mostly-linear stories.

Do not encode the structure mode as visible story content or a JSON field. It
is an authoring choice.

### Internal Story-Structure Lenses

Use story theory as an internal planning tool, not as homework for the user.
After understanding the premise, quietly check whether any of these lenses
would improve pacing, objective order, or relationship payoff. Use one, blend
several, or ignore them when they do not fit. Tell the user the practical story
shape, not the theory label, unless the label helps discussion.

- Hero's journey: ordinary situation, call/displacement, mentor/allies, trials,
  midpoint revelation, major test/loss, transformation, final ordeal, aftermath.
- Three-act structure: setup, confrontation/escalation, resolution.
- Five-act escalation: setup, rising complications, midpoint turn, crisis,
  climax, aftermath.
- Mystery/investigation: hook, clue chains, suspects, false leads, reveals,
  confrontation, truth/consequence.
- Romance/relationship arc: first impression, friction, shared task, trust,
  vulnerability, rupture/test, repair/commitment or changed distance.
- Faction/political arc: factions, leverage, public events, private bargains,
  betrayals, reputation shifts, power change.
- Open-world hub-and-spoke: hub, optional spokes, gated main milestones, world
  state changes, return-to-hub consequences.
- Countdown/crisis: visible pressure, limited windows, tradeoffs, missed-event
  consequences, decisive intervention or failure.
- Corruption/temptation: offer, compromise, benefit, consequence, point of no
  return or resistance.
- Redemption: harm/guilt, denial, consequence, restitution, sacrifice, earned
  trust.
- Tournament/trial ladder: repeated tests, rival development, rising stakes,
  rule changes, final trial.
- Survival/escalation: scarcity, danger, adaptation, loss, escape/conquest.

### Structure-Specific Objective Patterns

These are helper patterns, not rules the story must obey. Objective trees should
be structured to follow the story's intent and make the experience feel the way
the creator wants. Use, modify, combine, or ignore these patterns when a better
objective tree fits the story.

For open adventure:

- Start with one clear main objective that gives direction without locking the
  player into a narrow path.
- Add broad side objectives, rumors, shops, jobs, locations, and NPC goals.
- Use discovery, travel, investigation, relationship, and resource objectives
  to let the player choose how to engage.
- Avoid too many locked objectives; use state, memories, story rules, and
  hidden outcome routes to adapt to the player's direction.

For guided story:

- Build a main objective chain with meaningful bridge objectives between major
  beats.
- Use tight objective clusters for authored scenes such as meetings, dinners,
  political sessions, discoveries, fights, or relationship development.
- Insert freeform interludes after tight clusters so the player can talk,
  explore, shop, train, rest, or pursue side content.
- Unlock side objectives and relationship scenes from main milestones.

For main-story availability that preserves side activities and player selection,
use the explicit `kind: "plot_point"` timeline variant described in
[main-plot-points.md](main-plot-points.md). Its private scheduled/readiness checks
do not use the strict locking/accept/decline behavior below.

For strict time-controlled stories:

- Put main story events in `story_pacing.timeline`.
- Make every main story objective before final aftermath/freeplay use
  `locked_until_complete: true`.
- Create downtime by spacing scheduled events or objective-triggered future
  events. This is the normal recommended form of time-controlled pacing because
  it lets players explore, shop, do jobs, rest, and pursue side objectives
  between main story events.
- Use wait prompts when the next event is ready but the player has not started
  it.
- Author missed-event consequences when overlapping events intentionally force
  the player to miss one.
- Use strict time-controlled pacing only for urgent arcs where side content
  should be unavailable, such as battles, escapes, trials, disasters, or
  consecutive endgame set pieces.

For choice-heavy / Choices-like stories:

- Use explicit `completion_control: "choice"` owner objectives for moments
  where the player knowingly chooses.
- Keep option titles and summaries non-spoilery; hide route labels and hidden
  outcomes.
- Apply durable consequences through relationship rewards, story rules,
  inventory/resources, future-cast changes, map changes, deaths, endings, or
  state-field updates.
- Use branch-and-bottleneck structure to prevent impossible content explosion:
  choices change state and later scenes, but major milestones may reconverge.

For sandbox stories:

- Prioritize locations, systems, recurring jobs, shops, social loops, rumors,
  factions, and reusable objectives.
- Keep the main plot light, optional, or generated from player action unless
  the user asks for a stronger spine.
- Use broad hub objectives and rotating/renewable side content.
- Let player behavior create new objectives through state changes and story
  memory instead of relying on a fixed chapter chain.

For relationship-focused stories:

- Build objective chains around shared tasks, private conversations, trust
  tests, vulnerability, jealousy, boundaries, conflict, repair, intimacy, or
  loyalty.
- Track durable relationship changes with deterministic rewards; do not rely
  only on narrator prose.
- Use tight clusters for emotional scenes, then open space afterward for
  player reaction and follow-up.
- Store promises, fears, avoided topics, favorite memories, and changed
  boundaries in durable state when they matter later.
- For relationship or conversation outcomes judged from natural play, default to
  a player-paced visible scene objective followed by a hidden automatic
  AI-routing objective. The detailed pattern appears under AI-adjudicated
  hidden-outcome objectives.

Useful objective purposes include discovery, travel, conversation/teaching,
trust-building, explicit choice, hidden AI route, training, shop/job/resource
loop, crisis, aftermath, hub/freeform interlude, faction move, relationship
repair, and ending/freeplay transition. Do not force these labels into JSON
unless the normal objective fields need them; they are planning aids.

For Telltale-style stories:

- Use several `completion_control: "choice"` clusters when the story scope
  supports them.
- If the user asks for multiple endings, many choice objectives, or a
  Telltale-style story, use roughly 30-40% choice objectives as a general target.
  Do not make more than half the objectives choices unless explicitly requested.
- Create one visible owner objective for each choice cluster. Set
  `completion_control: "choice"`, `selectable: true`, and use a `choices`
  array for the options.
- Give each branch deterministic consequences through story rules,
  relationship changes, state-field changes, map/location changes, image
  rewards, items, or death/failure endings.
- Keep major branch option UI non-spoilery. Choice titles should be the visible
  options; `summary` should clarify what the option means in the current scene
  when helpful, and `effects` should be empty unless it shows only visible
  requirements, visible costs, or story-inventory changes. Do not reveal
  death, failure, sale, romance, betrayal, ending, route labels, unlock labels,
  hidden recommendations, or hidden branch outcomes in player-facing choice
  text. Bad visible `effects` examples include `Bad ending route`, `Unlocks
  Mira treatment route`, `Hana affection route`, and `Best with first law:
  Truth or Freedom`. Good visible `effects` examples include `credits -80`,
  `trust >= 6`, `suspicion +1`, and `requires cellar key`.
- Make later branch objectives require the choice owner objective, and preserve
  the selected path through the chosen option's rewards: story rules,
  relationship changes, state changes, item/resource changes, or death/failure.
- Re-merge only after consequences are recorded, so the branches do not feel
  identical.

For romance, dark romance, harem, court-intrigue, companion, and
relationship-driven stories, audit choice mechanics even when the story is not
fully Telltale-style. Important choice clusters often include first trust,
first boundary, first bargain, choosing who to protect, defining a relationship,
choosing whether to escalate intimacy, choosing a faction/lover/rival stance,
and choosing an ending. If the story has none of these, verify that the premise
is intentionally linear and that player agency is still represented by bridge
objectives.

Use these branch shapes deliberately:

- Immediate merge: each choice output records relationship/stat/rule
  consequences, then all outputs link to the same shared objective through
  separate OR input groups. Use for short
  boundary, stance, flirt/refuse, mercy/cruelty, or tone choices.
- Optional with skip: a choice offers an optional scene and a skip option, such
  as `Knock on the Companion's Door` versus `Go to Bed`. Use this for optional romance
  or NSFW moments inside the main objective flow when the user does not want side
  objectives. Put only visible requirements/effects in player-facing option text.
- Multi-route convergence: separate route objectives/chains can all be completed
  before a larger event. The convergence input group requires every route's
  final transition. Do
  not use `exclusive_group` for these, because the routes are swappable and all
  valid.
- Fail-forward: a bad choice continues the story with debt, damage, distrust,
  lost resources, harder routes, or worse endings rather than accidentally
  ending play.
- Delayed callback: an early choice stores a rule, relationship change,
  state-field value, or story-inventory marker, and a later objective or ending
  reacts to that stored consequence.
- Conditional next routing: a completed objective can choose which next
  objective becomes active based on current story state, without showing a
  player choice menu. Use `next_objectives` on the completed objective for
  hidden consequence routing such as exposure, suspicion, reputation, money,
  injuries, relationship thresholds, or public/private outcomes. Entries are
  evaluated in order; the first matching entry wins. Use a final entry with no
  requirements as the default path when appropriate.
- Visible relationship-threshold fork: keep all relevant options visible in the
  choice list and show requirements such as `trust >= 6`, `attraction >= 8`, or
  `affection >= 5`. The game should show unmet options as locked/red; do not
  hide or rewrite the options based on hidden thresholds.
- Resource-gated route order: expose several route objectives/options, but make
  some require visible resources such as money, supplies, reputation, evidence,
  repair parts, or party trust before they can start.

For linear/mostly-linear stories, do not add fake choice menus. Use bridge
objectives to make pacing, relationships, world understanding, and intimacy
build naturally between major story beats.

For NSFW stories, optional adult side objectives are appropriate when they fit
the story and all characters involved are valid adult characters. For SFW
stories, side objectives should remain SFW. Do not hardcode any specific adult
side objective pattern; choose content that fits the premise.

Do not add legacy duplicate body fields such as `objective`, `steps`, `current_step_id`, or `selected_step`. The current app uses `summary` for player-facing objective text and the completion fields for verifier/narrator behavior.

Do not use the old nested completion-object shape:

```json
{
  "completion": {
    "type": "player_reaches_location",
    "location": "place-id"
  }
}
```

Convert that intent into the current flat fields instead:
`completion_control`, `completion_criteria`, and `completion_instruction`.

Every objective needs:

- `completion_control`: `"player"` when the player's deliberate action itself
  completes the goal or the player must control when the scene advances; `"ai"`
  when an NPC or the active scene must provide the result after the player
  engages or cooperates; `"choice"` when EmberAdventures should show a forced
  player choice menu, complete the owner objective immediately, and apply the
  selected option's rewards without AI verification; `"reward_only"` only for a
  hidden Automatic Transition with `requirement_check_only: true`; `"cutscene"`
  for one fixed authored beat delivered in the next completed narrator reply,
  with questions/protests changing reactions but not that beat's outcome.
- `evaluate_ai_on_activation`: Optional `true` only for an Immediate AI
  objective. It causes one activation-time AI decision and does not replace the
  ordinary AI Scene flow when that decision is no.
- `completion_requirements`: Optional structured requirements that must remain
  true before a reached objective can be selected, checked, routed, or
  completed.
- `completion_criteria`: One private verifier condition for Player Action, AI
  Scene, and Immediate AI objectives. Omit it for Player Choice, Automatic
  Transition and Interactive Cutscene.
- One output collection: `next_objectives` for deterministic Linear/Branch
  outputs, `choices` for Player Choice, or `outcome_routes` for AI-controlled
  hidden Branch outcomes.
- Every output needs a stable id, its own completion instruction, optional
  dialogue/rewards/travel/requirements, and either a valid destination plus
  `target_input_group_id` or an `ending_type`. Objectives never terminate by
  themselves; only individual outputs do. An ordinary terminal side errand or
  side cutscene may instead finish without a successor or whole-story ending.
  Terminal side choices and automatic tasks, empty automatic routers, and
  main objectives with an explicit scheduled continuation are also supported;
  see [objective-handoffs.md](objective-handoffs.md) for exact syntax and timing.

Interactive Cutscene requires a concrete nonempty `completion_instruction`, no
completion/output requirements, choices, AI outcome routing or activation check,
and at most one unconditional next output. Only completed narration commits its
progression/rewards; failed/canceled generation keeps the beat pending. See
[interactive-cutscenes.md](interactive-cutscenes.md) for the exact contract and
the distinction between guaranteed progression timing and AI prose quality.

Optional `state.meta.stat_display` maps exact character stat IDs to objects with
exactly `label` (nonempty text) and `color` (`#RRGGBB`). For example,
`{"health":{"label":"Health","color":"#d55964"}}`. It controls display only:
it adds no character stat or combat calculation. HP appears on character cards
and in the Stats panel; stories with no stats have no Stats button.

For additional player-only values calculated from current story state, use
optional `state.meta.player_stat_display`, documented in
[player-stat-displays.md](player-stat-displays.md). It displays live resources
without creating duplicate saved character stats or changing companion panels.

`completion_criteria` and `completion_instruction` must be authored content,
not generated boilerplate. Never write:

- `Return yes only when the player completes: {title}.`
- `Return yes only when the player completes or survives...`
- `Return yes only when the player completes, submits, or receives...`
- `Return yes only when the player clearly takes action toward this goal...`
- `Resolve the immediate outcome of {title} and move to the next objective.`
- `Continue naturally from completing this objective.`

For player-controlled objectives, criteria must name the exact player action,
attempt, commitment, self-directed travel, inspection, purchase, choice, or
player-timed advancement that finishes the objective. For standard AI-controlled
objectives, criteria must name the resolved narrator/world state that an NPC or
the active scene provides after the player engages, and must not say `player
completes`. For an activation-evaluated AI objective,
criteria must instead be decidable immediately from an already-finished scene,
recent messages, and current state; it must not require another player action or
narrator reply.

Every main objective must route intentionally. Use
`next_objectives` for deterministic outputs, `choices` for visible player
choices, or hidden `outcome_routes` when results depend on natural scene
context. An output may instead end through `ending_type`. An objective with no
output is invalid. Do not rely on fallback objective picking as normal story flow.

Do not design objectives so one player message should complete several
objectives at once. EmberAdventures checks one selected objective at a time. If one
message can reasonably finish multiple consecutive objectives, those objectives
are probably too small, duplicated, or poorly ordered. Merge them or rewrite the
chain so each objective represents one meaningful scene-scale beat.

For relationship, romance, court, trial, mystery, and slow-burn stories, use
bridge objectives between chapter-scale milestones. Bridge objectives should
build trust, suspicion, attraction, world understanding, private conversation,
or practical preparation before the next major event. Do not place large
chapter beats directly next to each other unless the story is deliberately fast.
For romance, dark romance, romantasy, harem, companion, and courtship-heavy
stories, use more relationship bridge objectives than ordinary adventure
stories. Major plot objectives should often be separated by chances to talk,
recover, flirt, refuse, test trust, define boundaries, or let a love interest
make a clear but optional advance. If the player/protagonist is submissive or
unlikely to initiate, build invitations and temptation into objective choices and
completion instructions so spicy/romantic content can happen without requiring
the player to chase it.

For each major romantic lead, companion lead, recurring temptation/rival, or
relationship-gated ally, include at least one objective that builds, tests,
defines, or damages that relationship. These objectives can be about boundaries,
refusal, trust, protection, apology, jealousy, vulnerability, privacy, distance,
or desire. Do not make relationship progression only implicit narrator prose
when the relationship affects future play.

### Romantic Advance Choice Pattern

For a `submissive` player-role story, give every intended romantic interest at
least one scene where that character initiates a meaningful romantic or sexual
advance. For a `switch` story, use this pattern for interests whose personality
is more dominant; do not force it onto deliberately submissive interests. A
`dominant` player-role story does not require NPC-initiated advance objectives.

Resolve the advance with a normal player choice objective. Adapt wording to the
scene while preserving these six functional reactions:

1. Enthusiastically reciprocate.
2. Accept and let them lead.
3. React with surprised interest.
4. Ask them to slow down.
5. Politely decline.
6. Reject the advance strongly.

The selected response applies only to the current advance. It is never blanket
consent for later escalation. Keep refusal routes playable and in character;
do not punish the player merely for declining intimacy.

For romance-first stories, audit every romanceable character's fallback
presentation. If the creator selected the optional authored 40/40/20 balance,
also audit that distribution. The runtime may adapt the whole romanceable cast
to one preferred gender, so no romantic route may depend on a character
remaining their canonical gender.

## Player-Facing Title And Control Rules

The player usually sees the objective title first and may not read the summary.
The title must therefore be a short playable command or clear direction by
itself. The summary should then provide optional help and context for players
who want a hint, not carry the whole objective by itself.

Treat title validity as a state-at-activation test. The title must describe a
specific action, interaction, decision, or discovery the player can still take
after the preceding completion response. It must not describe an arrival,
reveal, meeting, consequence, or other condition that has already happened.
For example, `Reach the Flooded Archive` is valid while travel is still pending;
`Arrive in the Flooded Archive` is invalid when the prior objective already
completed on arrival. In that situation, use the next pending action such as
`Discuss the Archive with the Guide`, `Inspect the Entrance`, or `Choose a
Route Through the Archive`.

Good title shapes:

- `Reach the Flooded Archive`
- `Recover the Missing Ledger`
- `Question the Harbor Witness`
- `Train With the Companion`
- `Repair the Signal Lantern`
- `Choose the Next Route`

Bad title shapes:

- `Hear the Village Alarm` when hearing it is automatic and the objective should
  instead direct the player to respond.
- `Arrive in Hearthcross` when the previous travel objective already completed
  on arrival. The player has already arrived; use the next interaction or
  decision instead.
- `Learn What the Companion Wants` when the companion must still disclose it.
  Use an AI Scene Objective with Dialogue such as
  `Talk with the Companion About Their Plans`.
- `Do Not Force a Fake Ending` because it is creator guidance, not gameplay.
- `Continue the Current Frontier` because it is vague/meta.
- `Choose the Current Frontier`, `Current Frontier`, `Pick the Next Arc`, or
  `Keep Following Canon` because these are story-author process labels, not
  playable in-world objectives.
- `Survive the Companion's Duel Thread` because `thread` is planning language.

Choose `completion_control` by asking who must provide the objective's actual
result, not merely who acts first:

- Use `"player"` when the player action or attempt itself completes the
  objective, or when the player must control when the scene advances. Common
  suggestions include using an object, attempting an action, deciding whether
  to accept or refuse a commitment, travelling under the player's own direction,
  buying or inspecting something, going to sleep, ending free time, or asking a
  question when asking it is the actual goal.
- Use `"ai"` when the player only needs to engage or cooperate and another
  character or the active scene must provide the required result. Common
  suggestions include receiving an explanation or lesson, learning information
  from someone, following an established guide to another room or place, being
  introduced to a group, attending a meeting that reaches a result, or waiting
  for a character/world response. An NPC merely being present is not enough:
  their explanation, agreement, response, escort, teaching, or decision must be
  necessary for completion.
- If the player says they will try, ask, follow, or cooperate but the objective
  still depends on another character's substantive response, normally use
  `"ai"`. If the objective intentionally ends at the player's attempt itself,
  normally use `"player"`.
- Do not write a player-controlled criterion that requires several later NPC
  results, such as "meet them, listen to the explanation, understand it, and
  decide." Use an AI Scene Objective with Dialogue and a minimal engagement
  criterion when the NPC should drive the authored explanation, then use
  another objective or a Player Choice for any later decision.
- Use `"choice"` when the story must force one mutually exclusive player
  decision from a list: choosing a law, ally, route, bargain, faction, romantic
  commitment, moral stance, or ending. Each option belongs in the owner
  objective's `choices[]` array; do not create one top-level objective per
  option.
- Use `"reward_only"` together with `requirement_check_only: true` only for an
  Automatic Transition, Automatic Router, or Automatic Finale. It resolves
  deterministic requirements, outputs, travel, dialogue-free instructions, and
  rewards without an AI call.

Do not split every attempt/outcome into two objectives. If `Defeat the Bandits`
is the player-facing goal, one AI-controlled objective is often correct: the
player knows what to try, and the narrator decides whether the attempt succeeds.

If an external event merely sets up the next action, usually fold that event
into the previous output's `completion_instruction` instead of making it a
separate passive objective. Example: after `Leave the Barn`, the output
instruction can reveal smoke, screaming, and bandits; its destination can be
`Defeat the Bandits`.

Never create meta/process objectives such as `Do Not Force a Fake Ending`,
`Keep Following Canon`, `Continue the Story`, `Choose the Current Frontier`,
`Current Frontier`, `Pick the Next Arc`, or `Maintain Source Fidelity`. Convert
those authoring instructions into concrete playable objectives or hidden
runtime constraints.

Visible `title` and `summary` must be written for the player and must not leak
future character names or imply a future character role before that character is
introduced by objective rewards. Avoid objectives like `Meet the Smith`, `Find a
Healer`, `Secure a Captain`, or `Hire a Guide` when a locked future-cast
character fills that role. Name the problem or situation instead, then use
the selected output's `completion_instruction` plus rewards to introduce the
predefined character.

`completion_instruction` is hidden narrator guidance for one specific output.
Do not paste broad boilerplate into it. Apply spoiler rules while writing it,
but do not store the spoiler rule itself. Good instructions describe that
output's actual immediate outcome, consequence, reveal, or transition.

Examples:

```json
{
  "title": "Question the Courier",
  "completion_control": "player",
  "completion_criteria": "Return yes only when the player asks the courier what happened, checks the letter, or clearly chooses to investigate the ambush.",
  "next_objectives": [
    {
      "id": "question-courier-output",
      "objective_id": "pursue-the-lead",
      "target_input_group_id": "pursue-the-lead-input-1",
      "completion_instruction": "Have the courier give one urgent lead, keep the ambush's deeper mastermind hidden, and point toward the next concrete clue.",
      "requirements": [],
      "rewards": []
    }
  ]
}
```

```json
{
  "title": "Defeat the Gate Raiders",
  "completion_control": "ai",
  "completion_criteria": "Return yes only when the narrator has resolved the gate fight and the raiders are defeated, routed, captured, or no longer an immediate threat.",
  "next_objectives": [
    {
      "id": "defeat-gate-raiders-output",
      "objective_id": "face-the-aftermath",
      "target_input_group_id": "face-the-aftermath-input-1",
      "completion_instruction": "Resolve the fight according to the player's approach and current allies, show the cost or consequence, and establish the aftermath.",
      "requirements": [],
      "rewards": []
    }
  ]
}
```

## Rewards

`rewards` must always be an array. Entries may be normal reward objects or
reward bundle references. A bundle reference may be a string bundle id such as
`"reward-pack-trust-earned"` or an object such as
`{ "type": "apply_reward_bundle", "bundle_id": "reward-pack-trust-earned" }`.
Do not use old reward bucket objects such as `rewards.unlock_locations`,
`rewards.introduce_future_characters`, or `rewards.story_rules`.

Use rewards as the deterministic story-progression layer. Important changes
should not rely only on narrator prose. When an objective changes what is true
about the world, the cast, the map, a relationship gate, a character's body, or
the scene, encode that change in rewards.

Use inline reward objects when the reward is unique to one objective, route, or
choice. Use `state.reward_bundles` when the same exact fixed reward or group of
rewards would otherwise appear in more than one place. Story trees generated by
this skill should have zero repeated reward definitions; repeated effects must
be factored into a named bundle and referenced from each location.

Use an Automatic Transition when the graph needs deterministic convergence,
bookkeeping, rewards, or a state-based route without an AI call. Do not add one
merely to deduplicate reward JSON; use `state.reward_bundles` for fixed
deduplication and `state.reward_templates` when repeated behavior needs typed
character-id or path parameters.

### Definition Fields Versus Runtime State

Character objects inside a story definition use immutable starting/default
fields. Starting a playthrough copies those values into separate mutable runtime
fields. Objective, choice, route, shop-purchase, reward-bundle, and reward-template
rewards must update the runtime fields. They must never rewrite the reusable
definition defaults.

The main character-field mappings are:

| Definition field | Mutable runtime field |
| --- | --- |
| `starting_relationship_to_player` | `relationship_to_player` |
| `starting_trust` | `trust` |
| `starting_attraction` | `attraction` |
| `starting_affection` | `affection` |
| `starting_arousal` | `arousal` |
| `starting_state_of_mind` | `state_of_mind` |
| `starting_physical_state` | `physical_state` |
| `starting_pose` | `pose` |
| `starting_held_items` | `held_items` |
| `starting_inventory` | `inventory` |
| `starting_known_facts` | `known_facts` |
| `starting_nsfw_known_facts` | `nsfw_known_facts` |
| `starting_outfit_id` plus `outfits` | `active_outfit_id` plus `clothing` |
| `default_seed`, `image_prompt_config`, `default_profile_image` | generated runtime image state |

`starting_known_facts` is only the reusable list copied into `known_facts` when
the game starts. Any fact learned, revealed, remembered, or changed during play
belongs in runtime `known_facts`. Use an `add_state_list_item` reward with
`field_path: ["player", "known_facts"]` for the player, or target a character and use
`field_path: ["known_facts"]`. Never target `starting_known_facts`.

`starting_nsfw_known_facts` is the separate reusable adult-only list copied
into mutable `nsfw_known_facts`. It is visible to AI and player-facing detail
UI only when the active profile permits NSFW content. Adult objectives may
mutate runtime `nsfw_known_facts`; never target
`starting_nsfw_known_facts`. Do not duplicate adult facts into normal known
facts as a workaround.

Generic state-path rewards use a positive runtime allowlist. A path is not valid
merely because that object or value exists in the authored starting state.
Import and public upload reject every path outside these approved mutable
runtime areas:

- `story_inventory`, `world_flags`, and authored `progression` values;
- mutable `player` fields: `appearance`, `can_die`, `clothing`, `held_items`,
  `inventory`, `known_facts`, `physical_state`, `pose`, `role`,
  `state_of_mind`, and `stats`;
- mutable resolved-character fields: `age`, `appearance`, `arousal`,
  `attraction`, `boldness`, `can_die`, `clothing`, `held_items`, `inventory`,
  `known_facts`, `personality_description`, `physical_state`, `pose`,
  `relationship_to_player`, `role`, `speech_style`, `state_of_mind`, `stats`,
  `trust`, and `affection`;
- `scene.party_members_present`, `scene.npcs_present`,
  `scene.image_characters`, `scene.summary`, and the documented intimacy mode
  fields;
- the documented `story_memory` lists;
- current `location` display fields and the current/focus/travel-history fields
  under `world_map`;
- `story_shops.<stable-shop-id>.unlocked`;
- the supported runtime status, relationship, and location-hint fields on an
  existing `future_cast.items.<stable-character-id>` entry.

List rewards require an existing array target. Numeric rewards require an
existing numeric target. Prefer dedicated rewards such as
`adjust_relationship`, `adjust_story_inventory`, `grant_outfit`,
`equip_outfit`, image rewards, and objective start/completion rewards whenever
one owns the operation. If a new mutable state domain is needed, add it to the
engine's validated allowlist first; do not assume arbitrary custom top-level
objects are writable.

Invalid reward targets include:

- every `starting_*` field;
- every `default_*` field;
- `state.players`, because it is the reusable player-option definition list;
- the removed `durable_known_facts` field;
- a definition's immutable `outfits` array when the intended action is granting
  or equipping runtime clothing;
- any missing path, non-list target used by a list reward, or nonnumeric target
  used by a numeric reward;
- any generic state path outside the engine's positive mutable-runtime
  allowlist, even when the path already exists in the story's starting state.

Story import and publication validation reject invalid reward paths. Runtime
reward application also preflights the complete reward transaction before any
reward is applied or logged. Do not depend on a later reward failure to undo an
earlier malformed reward; author every path against the live runtime shape.

For `add_state_list_item` and `remove_state_list_item`, prefer `field_path` for
ordinary state paths. Use `target` plus `field_path` only when the list belongs
to a resolved character/NPC rather than directly to story state. Story-owned
custom list reward targets should use flat array fields under
`story_inventory`, not nested custom object paths, unless the app validator is
explicitly updated to support nested list paths. The destination must already
exist as an array in the authored starting state before import; do not expect
the reward to create missing arrays. Good example:

```json
{
  "type": "add_state_list_item",
  "field_path": ["story_inventory", "gella_traits_absorbed"],
  "value": "trait name"
}
```

Do not use legacy `path`, top-level custom objects such as
`["progression", "gella_softmaw", "absorbed_traits"]`, or nested
`story_inventory` objects such as
`["story_inventory", "progression", "gella_softmaw", "absorbed_traits"]` for
story-owned custom list rewards. Upload validation can reject those nested
paths even when the arrays exist in the story JSON.

Reward bundle ids must be stable, descriptive slugs. Good examples:
`reward-pack-rescue-earned-trust`, `reward-pack-failed-city-defense`,
`reward-pack-choose-forest-route`. Avoid vague ids such as `reward-1` or
`shared`.

Useful reward types include:

- `introduce_future_character`
- `make_future_character_recruitable`
- `promote_future_character_to_party`
- `remove_character_shop_listing`
- `unlock_location`
- `lock_location` (close an existing ordinary destination while preserving discovery and exits)
- `set_hex_passage_status` (exact existing passage ID and status; see [hex exploration](hex-exploration.md#authored-passage-status-rewards))
- `add_item` / `grant_item`
- `add_story_item`
- `adjust_story_inventory`
- `advance_time`
- `complete_generated_job`
- `start_objective`
- `enable_triggered_objective` (arm a disabled event in the existing story-pacing registry; see [triggered quest trees](short-interruptions.md))
- `complete_objective`
- `add_story_rule`
- `remove_story_rule`
- `set_state_field`
- `set_combat_active` (opted-in fixed combat only; exact boolean `active`; see [combat.md](combat.md))
- `modify_integer`
- `adjust_relationship`
- `grant_outfit`
- `equip_outfit`
- `add_state_list_item`
- `remove_state_list_item`
- `kill_character`
- `generate_profile_image`
- `generate_solo_normal_image`
- `generate_story_image`
- `apply_reward_bundle`
- `modify_number`
- `apply_reward_template`

Story-inventory item grant:

```json
{
  "type": "add_story_item",
  "item": {
    "id": "signed-guild-writ",
    "name": "Signed Guild Writ",
    "type": "quest",
    "quantity": 1,
    "value": 0,
    "sellable": false,
    "quest_item": true,
    "description": "A writ proving the guild accepted the commission."
  }
}
```

Keep the reward discriminator in the outer `type` and the inventory item's own
category in `item.type`. Use this same shape inside objectives, reward bundles,
reward templates, and general-shop purchase rewards.

Time advancement:

```json
{
  "type": "advance_time",
  "hours": 3,
  "minutes": 30,
  "reason": "traveling through the ravine"
}
```

Use `advance_time` for jobs, travel, training, repairs, research, shopping,
resting, recovery, and chapter transitions. Do not use direct set-time rewards
in normal story content. EmberAdventures owns the actual clock and only story
content should request additive elapsed time.

The engine advances calendar time and elapsed story time together. The background
updater receives the exchange's starting clock and minutes already applied, so
authored rest/travel is not charged again. Do not add another reward to compensate
for the same interval. The relative story-clock label measures elapsed duration;
use the calendar for actual time of day.

Job ranks are exact: a job can be accepted only at the player's current
`story_inventory.adventurer_rank`, including authored jobs and cached generated
offers. Neither a lower rank nor the former one-rank-higher allowance qualifies.
NSFW eligibility remains a separate content check. Set each job's rank
deliberately; do not change XP awards or campaign stats to work around access.

Future-cast introduction:

```json
{
  "type": "introduce_future_character",
  "character_id": "future-cast-id",
  "scene_presence": "nearby",
  "reason": "Why this character appears now."
}
```

```json
{
  "type": "promote_future_character_to_party",
  "character_id": "future-cast-id"
}
```

Recruitment preserves an existing NPC's identity, current relationships, condition,
clothing, possessions, known facts and portraits. It also moves their scene presence
from NPC to present party member. A character not yet materialized uses the authored
future-cast definition; an existing uninspected shell retains its recorded current
identity and state while that definition supplies missing details. Do not add a
`preserve_existing_npc_state` flag: preservation is the default behavior.

Permanent state/body/relationship changes:

```json
{
  "type": "set_state_field",
  "target": "Character Name",
  "field_path": ["appearance", "extra_description"],
  "value": "left arm intact and strong; right arm rebuilt as a matching synthetic combat arm"
}
```

### Numeric Stats, Precision, And Reference Math

Character definitions may optionally include a `stats` object for authored,
game-specific numeric systems:

```json
"stats": {
  "strength": 7,
  "mana": 12,
  "capacity_cost": 5
}
```

Stat keys are arbitrary stable identifiers chosen by the story. Negative, zero,
and positive values are valid. Do not use numeric strings, null, booleans,
non-finite values, or values outside the safe numeric range. Do not add generic
stats unless the story actually uses them. Full information for a character
present in the scene includes `stats`; reduced context for an absent character
intentionally omits it.

Stats and top-level numeric `story_inventory` fields are integers by default.
When a story genuinely needs decimal values, declare the allowed final storage
precision in `state.numeric_precision`:

```json
"numeric_precision": {
  "story_inventory": {
    "pack_strength": 4,
    "pack_share_percent": 4
  },
  "character_stats": {
    "pack_share": 4,
    "growth_multiplier": 3
  }
}
```

Each map value is the allowed number of decimal places, from 1 through 6. A key
absent from the appropriate map is an integer. Declare only fields that really
need decimals. Authored initial values must already fit their declared
precision. A story-embedded character copy may use a decimal stat only when the
containing story declares that key under
`state.numeric_precision.character_stats`. Reusable character-library
definitions keep `stats` integer valued because decimal precision belongs to
the story that uses those stats.

Use `modify_integer` for deterministic integer arithmetic against existing
story state or character fields. It supports exactly `add`, `subtract`,
`multiply`, and integer `divide`. Division truncates toward zero. Rewards run in
listed order, so later rewards see earlier results.

Direct state target with a direct state operand:

```json
{
  "type": "modify_integer",
  "operation": "subtract",
  "field_path": ["story_inventory", "capacity_available"],
  "value_path": ["story_inventory", "capacity_reserved"]
}
```

Direct state target with a character-relative operand:

```json
{
  "type": "modify_integer",
  "operation": "subtract",
  "field_path": ["story_inventory", "capacity_available"],
  "value_character_id": "character-dessa",
  "value_path": ["stats", "capacity_cost"]
}
```

Character-relative target with a direct state operand:

```json
{
  "type": "modify_integer",
  "operation": "add",
  "character_id": "character-dessa",
  "field_path": ["stats", "strength"],
  "value_path": ["story_inventory", "training_bonus"]
}
```

Character-relative target and character-relative operand:

```json
{
  "type": "modify_integer",
  "operation": "add",
  "character_id": "character-dessa",
  "field_path": ["stats", "strength"],
  "value_character_id": "character-mara",
  "value_path": ["stats", "training_bonus"]
}
```

Literal operand:

```json
{
  "type": "modify_integer",
  "operation": "multiply",
  "character_id": "character-dessa",
  "field_path": ["stats", "strength"],
  "value": 2
}
```

`character_id` anchors `field_path` at the live character with that stable
definition id. Without it, `field_path` starts at story state.
`value_character_id` similarly anchors `value_path`; without it, `value_path`
starts at story state. The resolver covers players, party characters, inspected
NPCs, future cast, and story shop/job character containers while preferring the
current live entity when lifecycle mirrors exist.

Every `modify_integer` reward must obey all of these rules:

- Include exactly one of `value` or `value_path`.
- `value_character_id` is valid only with `value_path`.
- `field_path` and `value_path` must be non-empty arrays of non-empty strings.
- Every referenced character id must exist in the story definition.
- Every target and referenced path must already exist when the reward executes.
  Never depend on missing values becoming zero and never use this reward to
  create a path.
- Literal and referenced values, target values, and results are safe integers.
- A literal divide by zero is invalid and must be rejected during story import,
  story-builder validation, and publishing. A referenced divisor that resolves
  to zero produces `Number.MAX_SAFE_INTEGER` and logs a diagnostic warning.
- Overflow and underflow clamp to `Number.MAX_SAFE_INTEGER` and
  `Number.MIN_SAFE_INTEGER`. The runtime checks bounds before arithmetic so an
  unsafe intermediate result is never stored.
- Paths may never contain `__proto__`, `prototype`, or `constructor`.

Use ordinary unique inline rewards for one-off arithmetic. If the exact same
math reward is needed in multiple objectives/routes/choices, put it in one
named reward bundle and reference that bundle. Importing and publishing use the
same authoritative story validator, so do not rely on one path accepting math
that the other rejects.

Use `modify_number` when a reward needs decimals or chained calculations. Its
outer `operation` is still one of `add`, `subtract`, `multiply`, or `divide`.
It accepts exactly one of `value`, `value_path`, or `value_expression`.

```json
{
  "type": "modify_number",
  "operation": "add",
  "field_path": ["story_inventory", "pack_strength"],
  "value_expression": {
    "initial": {
      "character_id": "character-mara",
      "path": ["stats", "strength"]
    },
    "operations": [
      {
        "operation": "multiply",
        "operand": {
          "path": ["story_inventory", "pack_share_percent"]
        }
      }
    ]
  }
}
```

An expression `initial` value and each operation `operand` may be:

- A finite numeric literal.
- `{ "value": 1.25 }`.
- `{ "path": ["story_inventory", "field"] }` for direct state.
- `{ "character_id": "character-id", "path": ["stats", "field"] }`
  for a character-relative value.

Expression operations run in listed order using exact rational arithmetic.
There is no intermediate rounding, including after division. Only the final
assignment is rounded to the destination field's declared precision. Half
values round away from zero. An undeclared destination rounds to an integer.
Final values clamp before storage if their scaled integer would exceed the
JavaScript safe range. A hardcoded zero divisor anywhere in a reward is invalid.
A referenced divisor that resolves to zero clamps the result and records a
diagnostic warning.

Every target and source path must already exist when `modify_number` executes.
`modify_number` never creates missing state. It uses the same safe path rules,
character resolution, and import/publish validation as `modify_integer`.

### Parameterized Reward Templates

Use `state.reward_templates` only when repeated reward behavior needs different
structured character ids or paths. Use `state.reward_bundles` for fixed repeated
rewards. Keep one-off rewards inline. Never duplicate an identical reward in an
objective tree.

```json
"reward_templates": {
  "add-character-pack-share": {
    "parameters": {
      "character_id": { "type": "character_id" },
      "stat_path": { "type": "path" }
    },
    "rewards": [
      {
        "type": "modify_number",
        "operation": "add",
        "field_path": ["story_inventory", "pack_strength"],
        "value_expression": {
          "initial": {
            "character_id": { "parameter": "character_id" },
            "path": { "parameter": "stat_path" }
          },
          "operations": [
            {
              "operation": "multiply",
              "operand": {
                "path": ["story_inventory", "pack_share_percent"]
              }
            }
          ]
        }
      }
    ]
  }
}
```

Invoke it with concrete typed arguments:

```json
{
  "type": "apply_reward_template",
  "template_id": "add-character-pack-share",
  "arguments": {
    "character_id": "character-mara",
    "stat_path": ["stats", "strength"]
  }
}
```

Template parameters support only `character_id` and `path`. A placeholder must
be the entire structured value `{ "parameter": "parameter_name" }`. Never use
string interpolation, partial text replacement, or placeholders inside a path
segment. Every declared argument is required, unknown arguments are invalid,
character ids must exist in the story, paths must pass the normal safe-path
rules, and bundle/template recursion is invalid. Templates may contain normal
inline rewards, bundle references, or other non-recursive template references.

Relationship/stat changes:

```json
{
  "type": "adjust_relationship",
  "target": "Character Name",
  "stats": {
    "trust": 1,
    "affection": 1
  }
}
```

Count relationship rewards during review. If a romance/dark
romance/harem/court/companion story has no `adjust_relationship` rewards, add
them where the story needs persistent trust, attraction, affection, suspicion,
or arousal changes, or document why the relationship is intentionally not
tracked by objective rewards.

```json
{
  "type": "adjust_relationship",
  "target": "all_present",
  "preset": "all",
  "amount": 0.5
}
```

`preset: "all"` changes trust, attraction, and affection. It does not change
arousal. Use `preset: "all_and_arousal"` only when the story beat should also
raise temporary sexual readiness. Valid convenience targets include
`all_present`, `all_party_present`, and `all_npcs_present`.

```json
{
  "type": "set_state_field",
  "target": "Character Name",
  "field_path": ["trust"],
  "value": 3
}
```

Outfit rewards:

Use `grant_outfit` when story progression gives a player, party character, or
other authored character a new saved outfit. `character_id` must be the stable
id of a character definition in the story. A universal `outfit` uses the normal
character outfit schema with a stable `id`, human-readable `name`, and only
canonical clothing-slot keys. By default this adds the outfit without changing
what the character is currently wearing.

```json
{
  "type": "grant_outfit",
  "character_id": "mira-vale",
  "outfit": {
    "id": "guild-field-uniform",
    "name": "Guild Field Uniform",
    "nsfw": false,
    "contexts": ["field work", "guild duty"],
    "clothing": {
      "undershirt": "fitted linen undershirt",
      "shirt": "dark green guild field shirt",
      "pants": "reinforced black field trousers",
      "socks": "thick black socks",
      "feet": "weatherproof guild boots"
    }
  }
}
```

When an outfit is presentation-specific, omit `outfit` and provide
`male_outfit`, `non_male_outfit`, or both. The engine selects only the variant
matching the character's gender, which was finalized when the playthrough was
created. A nonmatching optional grant is an intentional no-op. This does not
change the character's gender.

```json
{
  "type": "grant_outfit",
  "character_id": "mira-vale",
  "male_outfit": {
    "id": "private-evening",
    "name": "Private Evening Outfit",
    "nsfw": false,
    "clothing": {
      "shirt": "fitted black evening shirt",
      "pants": "tailored black evening trousers"
    }
  },
  "non_male_outfit": {
    "id": "private-evening",
    "name": "Private Evening Outfit",
    "nsfw": false,
    "clothing": {
      "shirt": "fitted black evening blouse",
      "skirt": "long black evening skirt"
    }
  }
}
```

`male_outfit` and `non_male_outfit` must use the same stable outfit id when
both are present. Either variant may be omitted only when the grant is optional
and does not equip the outfit. If `equip: true`, both variants are required. If
the same objective contains an `equip_outfit` reward for that granted outfit
id, both variants are also required even when the grant itself has
`equip: false`.

Use `equip_outfit` when the character already owns the outfit and the objective
must immediately change what they are wearing. This atomically applies the
saved clothing snapshot and updates `active_outfit_id`; never imitate an outfit
swap with `set_state_field`.

```json
{
  "type": "equip_outfit",
  "character_id": "mira-vale",
  "outfit_id": "guild-field-uniform"
}
```

When receiving the outfit and immediately wearing it are one indivisible
reward, set `"equip": true` on `grant_outfit`. Do not also add a redundant
`equip_outfit` reward for the same action.

Use `delete_outfit` to permanently remove one owned runtime outfit. If it was
active, the character's active outfit id and current clothing are cleared.
Deleting an outfit the character does not own is an idempotent no-op.

```json
{
  "type": "delete_outfit",
  "character_id": "mira-vale",
  "outfit_id": "damaged-uniform"
}
```

Use `delete_all_outfits` only for a permanent wardrobe replacement, such as a
major transformation that makes every old outfit unusable. It removes every
owned runtime outfit and clears current clothing. Follow it in the same atomic
reward transaction with one or more `grant_outfit` rewards, equipping the new
default outfit as appropriate.

```json
{
  "type": "delete_all_outfits",
  "character_id": "mira-vale"
}
```

An `equip_outfit` failure is a warning rather than a failed reward transaction.
The warning explains the character and outfit the story attempted to use and
offers Export Both diagnostics. Import validation should still prevent every
statically detectable malformed outfit reward.

Story-rule gates and current constraints:

```json
{
  "type": "add_story_rule",
  "rule_id": "companion-intimacy-locked",
  "text": "The companion cannot willingly begin romance or sexual intimacy until the stated relationship condition is met."
}
```

```json
{
  "type": "remove_story_rule",
  "rule_id": "companion-intimacy-locked"
}
```

Scene/list updates:

For objectives that expect named characters to remain physically present, a
recommended pattern is to repeat the applicable idempotent add rewards on each
consecutive objective. Keep party members and NPCs in their respective lists.

```json
{
  "type": "remove_state_list_item",
  "field_path": ["scene", "npcs_present"],
  "value": "Character Name"
}
```

```json
{
  "type": "add_state_list_item",
  "field_path": ["scene", "npcs_present"],
  "value": "NPC Name"
}
```

Image triggers for visible changes:

```json
{
  "type": "generate_profile_image",
  "target": "Character Name",
  "reason": "The character's repaired arm changes their upper-body silhouette"
}
```

```json
{
  "type": "generate_solo_normal_image",
  "target": "Character Name",
  "reason": "The character's restored legs are now visible in the scene"
}
```

```json
{
  "type": "generate_story_image",
  "id": "cellar-door-first-look",
  "title": "Cellar Door",
  "prompt": "old rural house utility hallway, heavy cellar door wrapped in chains, one brass key lock and one six-letter combination lock, cold shadow under the door, cinematic horror lighting",
  "negative_prompt": "text, watermark, logo, signature"
}
```

Use `generate_profile_image` only when a change affects face, hair, arms,
torso, chest, shoulders, or the overall silhouette. Use
`generate_solo_normal_image` for major visible changes that should appear in
chat. Leg-only or lower-body-only changes should normally generate a solo
normal image, not a profile image.

Use `generate_story_image` for authored non-character images: story objects,
locations, clues, maps, symbols, ritual scenes, horror reveals, jump scares, or
other one-time visual beats. Keep a stable `id` so EmberAdventures can dedupe and
debug the image. The reward does not need a character target. All three image
reward types may carry the portable nested `image` slot. When that slot resolves
to a hosted image, EmberAdventures uses it immediately and does not call the
image generator. Without a real image reference, profile and solo rewards use
the target character to generate an image, while story-image rewards require a
prompt.

Branch consequences:

```json
{
  "type": "add_story_rule",
  "rule_id": "market-sale-moral-cost",
  "text": "The sale branch carries a visible moral cost; the companion was treated as property after refusing."
}
```

For future-character rewards, `character_id` must exactly match an object key in
`state.future_cast.items`, and that future-cast entry's own `id` must be the
same string. Do not use numeric/index keys for future cast and a different slug
inside the entry; the runtime reward lookup uses the object key.

Use `travel_location_id` and `travel_location_name` when completing the objective should move or reveal a location.

Use `exclusive_group` only for mutually exclusive branch-choice objectives where
one selected/completed path should permanently lock the others until the player
rolls back to an older state snapshot. Put the `exclusive_group` on the visible
choice owner objective, and connect each selected output only to its own branch
so losing-branch descendants stay hidden.
Do not use `exclusive_group` for optional branches, parallel tasks, side content,
or hub goals that can all be completed. Each exclusive branch should carry real
reward differences; a branch that only changes prose is likely to collapse back
into the same play path.

If several routes must all be completed before a larger event, model them as
parallel route chains whose terminal transitions share one destination input
group on an Automatic Transition. Do not mark those route chains exclusive.

For threshold-gated choices, requirements should be visible player-facing
requirements, not secret alternate objective text. If the option exists, show it
and let the game mark it unavailable until the requirement is met.

Player choice options and AI hidden routes use the same structured requirement
contract, but they resolve differently:

- Direct player choices are visible. Do not hide an option just because its
  requirements are unmet; the UI should show the locked option and its visible
  requirements. Every direct choice objective must include at least one option
  with no requirements so the player is never trapped.
- Hidden AI routes are private. Requirements filter which route ids the
  classifier is allowed to see. Ineligible route ids, criteria, rewards, and
  requirements must not be shown to the player.

For direct forced choices, create one visible owner objective with internal
options:

```json
{
  "id": "choose-first-law",
  "title": "Choose Your First Law",
  "type": "story",
  "status": "hidden",
  "summary": "Choose the first boundary your violet briar magic will defend.",
  "exclusive_group": "first-law-choice",
  "completion_control": "choice",
  "choice_response_mode": "optional_text",
  "choices": [
    {
      "id": "law-freedom",
      "title": "Defend Freedom",
      "summary": "Make freedom and agency the first principle.",
      "effects": [],
      "requirements": [],
      "completion_instruction": "Resolve only the law of freedom and show the court reacting to that choice.",
      "next_objective_id": "respond-to-first-law",
      "target_input_group_id": "respond-to-first-law-input-1",
      "rewards": [
        {
          "type": "add_story_rule",
          "rule_id": "first-law-freedom",
          "text": "The player's first law is freedom: the violet briars resist attempts to take away consent, agency, or choice."
        }
      ]
    },
    {
      "id": "law-vengeance",
      "title": "Answer Theft With Vengeance",
      "summary": "Make retaliation against theft the first principle.",
      "effects": [],
      "requirements": [],
      "completion_instruction": "Resolve only the law of vengeance and show the court reacting to that choice.",
      "next_objective_id": "respond-to-first-law",
      "target_input_group_id": "respond-to-first-law-input-2",
      "rewards": [
        {
          "type": "add_story_rule",
          "rule_id": "first-law-vengeance",
          "text": "The player's first law is vengeance: the violet briars punish those who take from the player."
        }
      ]
    }
  ]
}
```

Do not create one objective per option. Do not list choices only in summary
text. The owner objective names the decision; `choices[]` contains the options
and their rewards. Keep hidden outcomes in rewards and completion instructions,
not in player-facing `summary` or `effects`.

Use `story_inventory` for objective-owned resources that the AI should not
freely change, such as credits, parts, suspicion, reputation, evidence, or
repair supplies. For numeric resources such as coins, credits, XP, suspicion,
reputation, and parts, use `adjust_story_inventory` with a delta for rewards
and costs so the current value is not accidentally clobbered. When a story
needs percentage-style math, `adjust_story_inventory` may also use
`operation: "multiply"` or `operation: "divide"` with `amount`, or
`operation: "set"` for deliberate exact assignments. Reserve
`set_state_field` for deliberate absolute state assignments, such as setting a
mode, flag, location, body field, or exact story variable. Expose only concrete
visible requirements/effects such as `credits +500`, `credits >= 1200`, or
`Companion Name trust >= 6`.

For conditional hidden routing after an objective completes, use
`next_objectives` on that completed objective instead of a fake choice objective
or a separate branch node:

```json
{
  "id": "resolve-public-rescue",
  "title": "Help Without Being Seen",
  "summary": "Keep the rescue quiet while getting everyone out safely.",
  "completion_control": "ai",
  "completion_criteria": "Return yes when the rescue attempt has been resolved and the group is out of immediate danger.",
  "next_objectives": [
    {
      "id": "public-rescue-exposed-output",
      "objective_id": "agency-opens-a-file",
      "target_input_group_id": "agency-opens-a-file-input-1",
      "completion_instruction": "Show evidence that the rescue drew official attention.",
      "requirements": [
        { "path": "story_inventory.public_exposure", "op": ">=", "value": 5 }
      ],
      "rewards": []
    },
    {
      "id": "public-rescue-hidden-output",
      "objective_id": "stay-below-the-radar",
      "target_input_group_id": "stay-below-the-radar-input-1",
      "completion_instruction": "Show the group escaping without attracting official attention.",
      "requirements": [],
      "rewards": [],
      "fallback": true
    }
  ]
}
```

Do not duplicate these destination edges in `requires`. Do not show
deterministic branches in a choice menu unless the player is intentionally
choosing between them.

### AI-adjudicated hidden-outcome objectives

#### Default relationship/conversation routing pattern

When hidden AI routing judges relationship status, trust, loyalty, honesty,
attraction, compatibility, opinions, known interpersonal information, or other
conversation-derived outcomes, default to two objectives instead of asking one
AI-controlled objective to decide both when the scene ends and what it means:

1. Create a visible, player-paced scene objective that puts the player with the
   specific character or characters being evaluated. Its private criteria may
   identify the topics, attitudes, facts, and relationship evidence the scene
   should naturally explore, but topic coverage is not completion.
2. Give that visible objective a concrete, player-controllable scene-ending
   condition: the player leaves, explicitly concludes the exchange, accepts a
   clear ending, is dismissed or expelled, or an interruption definitively ends
   the interaction. Never complete it merely because enough subjects were
   discussed, enough evidence exists to classify the player, or the player is
   still participating normally within the scene.
3. Follow it with a non-selectable hidden AI-adjudicated objective with
   `completion_control: "ai"` and `evaluate_ai_on_activation: true`. Because the
   conversation has already ended, this second objective is evaluated immediately,
   selects one hidden route from the completed interaction and relevant durable
   state, applies its consequences, and advances. It must not replay, extend,
   narrate, or prematurely terminate the preceding conversation.

This separation is the default for meetings, negotiations, interviews,
interrogations, dates, trials, recruitment talks, political discussions,
relationship-defining scenes, and important private conversations. It gives the
player control over conversational pacing while preserving AI judgment of the
outcome. A direct AI-routed objective remains appropriate for clear externally
observable actions such as defeating a monster, escaping confinement, repairing
an object, or resolving a battle.

Example pair:

```json
[
  {
    "id": "attend-war-council",
    "title": "Take Part in the War Council",
    "type": "story",
    "status": "active",
    "summary": "Discuss the coming battle with the four heroes for as long as you need.",
    "completion_control": "player",
    "completion_criteria": "Complete only when the council has clearly ended because the player leaves or concludes it, the heroes dismiss or expel the player, or an interruption definitively ends the meeting. Do not complete merely because the planned strategy topics were discussed or enough evidence exists to judge the player. During the active meeting, let the heroes naturally raise the authored strategic disagreements and react to the player's opinions.",
    "next_objectives": [
      {
        "id": "attend-war-council-output",
        "objective_id": "judge-war-council",
        "target_input_group_id": "judge-war-council-input-1",
        "completion_instruction": "End the council without revealing hidden route labels, then proceed directly to private adjudication.",
        "requirements": [],
        "rewards": []
      }
    ]
  },
  {
    "id": "judge-war-council",
    "title": "Resolve the War Council",
    "type": "story",
    "status": "hidden",
    "completion_control": "ai",
    "evaluate_ai_on_activation": true,
    "completion_criteria": "The preceding war council has already ended. Complete immediately and judge the player's conduct, opinions, known facts, and current relationships from that completed interaction.",
    "route_control": "ai",
    "outcome_routes": [
      {
        "id": "earned-hero-trust",
        "criteria": "The player listened, contributed useful judgment, and treated the heroes as respected partners.",
        "requirements": [],
        "completion_instruction": "Apply the trusted result without replaying or extending the council.",
        "rewards": [],
        "next_objective_id": "prepare-trusted-plan",
        "target_input_group_id": "prepare-trusted-plan-input-1"
      },
      {
        "id": "strained-hero-alliance",
        "criteria": "The player remained involved but damaged cooperation through dismissal, hostility, manipulation, or reckless judgment.",
        "requirements": [],
        "completion_instruction": "Apply the strained result without replaying or extending the council.",
        "rewards": [],
        "next_objective_id": "prepare-strained-plan",
        "target_input_group_id": "prepare-strained-plan-input-1"
      },
      {
        "id": "uncertain-hero-alliance",
        "criteria": "The interaction ended without strong evidence for a more specific relationship outcome.",
        "requirements": [],
        "completion_instruction": "Apply the uncertain result without replaying or extending the council.",
        "rewards": [],
        "next_objective_id": "prepare-cautious-plan",
        "target_input_group_id": "prepare-cautious-plan-input-1",
        "fallback": true
      }
    ]
  }
]
```

Use this objective pattern when the story must branch according to what actually
happened in the scene, but presenting the possible outcomes to the player would
reveal hidden consequences or turn an organic result into an explicit choice.
This is not a fourth `completion_control` value. The objective uses
`completion_control: "ai"` to determine whether its scene is complete, then
`route_control: "ai"` to select exactly one hidden outcome.

The lifecycle is fixed:

1. The AI completion verifier decides whether the objective is complete.
2. If incomplete, it selects no outcome and the objective remains active.
3. If complete, it must select the single route that best matches the full
   scene, recent player behavior, narration, and relevant structured state.
4. The runtime applies the objective's base rewards once, applies the selected
   route's rewards once, records the selected route privately, and activates
   that route's next objective.

Author the objective in this shape:

```json
{
  "id": "resolve-mara-treatment",
  "title": "Resolve the Treatment",
  "completion_control": "ai",
  "completion_criteria": "The injury and treatment interaction has reached a clear resolution.",
  "route_control": "ai",
  "outcome_routes": [
    {
      "id": "showed-concern",
      "criteria": "The player sincerely noticed or considered the pain Mara experiences while healing them.",
      "requirements": [],
      "completion_instruction": "Resolve the concerned result without describing hidden relationship labels.",
      "rewards": [],
      "next_objective_id": "mara-softens",
      "target_input_group_id": "mara-softens-input-1"
    },
    {
      "id": "used-without-consideration",
      "criteria": "The player treated Mara's pain as irrelevant or treated her only as a reusable tool.",
      "requirements": [],
      "completion_instruction": "Resolve the inconsiderate result without describing hidden relationship labels.",
      "rewards": [],
      "next_objective_id": "mara-withdraws",
      "target_input_group_id": "mara-withdraws-input-1"
    },
    {
      "id": "accepted-assistance",
      "criteria": "The player accepted help pragmatically without meaningful concern or cruelty.",
      "requirements": [],
      "completion_instruction": "Resolve the neutral result without describing hidden relationship labels.",
      "rewards": [],
      "next_objective_id": "mara-neutral",
      "target_input_group_id": "mara-neutral-input-1",
      "fallback": true
    }
  ]
}
```

Use this for ally/neutral/hostile judgments, clean/costly/failed combat results,
concealed/partial/open revelations, recruitment states, and relationship
consequences inferred from natural play.

Route requirements use the same structured requirement contract as visible
choice/shop/job requirements. Use hard requirements only for facts that make a
route truly possible or impossible:

```json
{ "path": "story_inventory.adventurer_rank", "op": ">=", "value": 2 }
{ "type": "story_rule", "id": "mara-is-bound-by-first-law" }
{ "type": "known_fact", "target": "mara-venn", "id": "mara-trusts-player" }
{ "type": "party_member", "target": "mara-venn" }
{ "type": "character_alive", "target": "mara-venn" }
{ "type": "character_dead", "target": "bandit-captain" }
{ "type": "currency", "id": "coins", "op": ">=", "value": 120 }
```

Rules:

- If the player is knowingly choosing from clearly presented options, use a
  `completion_control: "choice"` objective instead. Hidden routing is for the
  result of play, not for concealing a decision the player should make.
- A completed objective must always produce one outcome. There is no
  valid response that leaves routing undecided. Prevent zero-eligible-route
  designs by giving the fallback route no requirements. EmberAdventures keeps
  the fallback route available as the zero-eligible safety route, so do not put
  meaningful locks on it.
- Route `requirements` are hard filters. Use them only for objective-owned
  state that truly makes a route possible or impossible, such as
  `story_inventory.adventurer_rank >= 2`, a required flag, or a required item.
  Use `criteria` for softer context judgments such as kindness, cruelty,
  deception, romance, caution, or tactical style.
- `criteria` must describe observable differences in behavior or outcome. Do
  not write circular criteria such as `Choose this route when route A applies`.
- Provide exactly one `fallback: true` route. It represents the closest neutral
  or ambiguous result and is used when no more specific criterion is a better
  match or when model output is unusable. It does not prevent a non-fallback
  route from winning whenever that route better fits the scene.
- If the route should be hidden unless every specific route is ineligible, use
  `fallback: true` with
  `default_mode: "only_if_no_other_eligible"`. This is useful for true
  zero-specific-match defaults, not for ordinary ambiguity between eligible
  routes.
- Outcome ids, criteria, requirements, route labels, and unchosen outcomes are
  private. Never expose them in objective titles, summaries, choice menus,
  narration, completion messages, hints, or visible reward descriptions.
- Each route must have a unique stable `id`, a non-empty `criteria` unless it is
  the fallback, a `completion_instruction`, a `rewards` array (empty is valid),
  and either an existing `next_objective_id` plus `target_input_group_id` or an
  `ending_type`.
- Do not combine `outcome_routes` with ordinary `next_objectives` on the same
  objective. Do not prefill runtime fields such as `selected_outcome_id`.
- Put `ending_type` directly on the specific outcome route that ends. Different
  routes from the same objective may continue or use different ending types.

## Validation

- `id` values are unique.
- Exactly one main objective is the story start. It is active; other unreached
  objectives are hidden.
- Every `requires` entry references an existing objective. All listed
  prerequisites must complete before the target can activate. A dependency is
  not duplicated as both `requires` and an output edge.
- Every continuing output across `next_objectives`, `choices`, and
  `outcome_routes` has a unique stable id, an existing destination, a valid
  `target_input_group_id`, a completion instruction, and a rewards array.
- Every non-starting main objective has at least one reachable incoming group.
  No group is empty or contains duplicate/missing output transitions.
- OR exists between input groups and AND exists inside a group. A transition is
  assigned to exactly one destination group.
- Every Completion Requirement and Output Requirement is structured, references
  existing data, and contains no circular objective-completion dependency.
- Player Choice has at least one option, valid visible option text, a supported
  response mode, and at least one continuation option with no requirements
  unless every outcome is intentionally unavailable/final.
- Player Choice with no output is rejected.
- Deterministic Branch outputs are priority ordered. Non-fallback outputs have
  requirements and the unrestricted fallback, when used, is last.
- Every AI outcome route has a unique id, private criteria, deterministic reward
  objects, and either an existing `next_objective_id` plus
  `target_input_group_id` or an `ending_type`. Exactly one
  route is the no-requirements fallback. AI-routed objectives do not
  also use `next_objectives`.
- Player Action, AI Scene, and Immediate AI use one simple completion
  condition. Player Choice and Automatic Transition omit it.
- Every objective has specific non-empty `while_active_guidance`, including
  Player Choice and Automatic Transition objectives.
- Immediate AI uses `completion_control: "ai"` and
  `evaluate_ai_on_activation: true`. Automatic Transition uses
  `completion_control: "reward_only"` and `requirement_check_only: true`.
- Automatic Transition contains no choice options, dialogue, AI route
  criteria, or completion condition.
- Every bounded-resource cost output has a matching eligibility requirement.
- Side tasks, including automatic tasks, may finish with no successor. A terminal
  side choice or AI outcome omits its destination and ending fields and returns
  through the existing quest context. Main tasks may have no output only when
  an existing timeline event explicitly owns the continuation. See
  [objective-handoffs.md](objective-handoffs.md); never invent a story ending.
- Every other output continues to a valid objective or sets `ending_type` to
  exactly `freeplay`, `ending`, or `game_over`.
- Cycles are intentional, reachable from outside the cycle, and cannot loop
  forever through unconditional Automatic Transitions.
- Relationship/conversation-based hidden routing normally uses the two-objective
  player-paced-scene then hidden-adjudication pattern. Verify that the visible
  objective cannot complete merely because the conversation is proceeding or
  enough classification evidence has accumulated.
- Every future-character reward references `future_cast.items[id]`, where
  `id` is the exact future-cast object key and the entry's own `id`.
- The active opening objective is actionable in the starting scene.
- Hidden objectives do not require facts the player cannot plausibly learn yet.
- Hidden objective titles/summaries do not expose locked future-character names
  or role labels that encourage the narrator to invent substitutes.
- Full story templates include major/fun side content unless the user requested
  a minimal main-spine-only version.
- Branching is used where it improves story flow: optional branches, parallel
  main branches, and multi-prerequisite gates are all valid.
- Optional NSFW/romance objectives remain gated behind adult characters and appropriate story state.
- Read every title alone and ask: would the player know the next intended
  action/direction?
- Check every objective for creator/process language masquerading as gameplay.
- Reject any objective whose `completion_criteria` is only the title repeated
  in a sentence.
- Reject any output whose `completion_instruction` is only the objective title
  repeated in a sentence.
- Reject any AI-controlled objective whose criteria says `player completes`.
- Forced branch choices use one `completion_control: "choice"` owner objective
  with a `choices[]` array. Each option has branch-specific rewards or story
  rules that downstream objectives can depend on.
- Relationship-heavy stories report or internally verify `choice` objective
  count and `adjust_relationship` reward count. Zero is a quality failure unless
  the story deliberately does not need that mechanic and the final notes say why.


---
