# Fixed opt-in combat

Normal EmberAdventures has one combat system. There are no story-defined damage
equations, alternative damage modes, initiative/dice configuration or custom
event processors. The AI decides plausible actions and BASE damage; the engine
applies Attack/Defense exactly once and owns health arithmetic and receipts.

## Enable a story

Optional `state.combat` has exactly these authored fields:

```json
{
  "enabled": true,
  "active": false,
  "rules": "Use established abilities. Decide per-hit Strength from the technique, weapon, force and intent, separately from Attack ratings. Explain weaker or stronger techniques in the private adjudication. This encounter uses restrained nonlethal strikes.",
  "rounds": {}
}
```

`enabled` permits the feature; `active` is current combat mode. Both are booleans.
Disabled combat cannot be active. Rules must be nonempty descriptive text; they
cannot change the fixed equation. Authors initialize rounds as an empty map.
Do not author the engine-owned optional `pending_opening`,
`last_checked_message_id`, `override_message_id` or populated round receipts.
Omit combat entirely for an ordinary story; it incurs no combat/checker calls.

When inactive, ordinary narration stops at an attempted attack before resolving
contact or injury. A separate post-response checker answers only yes/no and can
enable combat for the NEXT turn. The next adjudication receives the pending
opening intent; a later changed/canceled player instruction takes precedence.
The same small post-response check exits unscripted combat after it ends.

An inactive-mode opening classifier can instead identify a plausible surprise.
That resolves only its opening attacker before a target has an opportunity to
respond; no reciprocal hit is granted. An armed guard watching the player may
block or begin ordinary combat rather than permit surprise. Surprise is not an
in-combat stealth bonus. A clean surprise ordinarily suggests twice normal
Strength; exceptionally exposed targets can justify five/ten times. These are
contextual AI guidance, not engine multipliers or guaranteed hits. A surviving
target may fight, plead, surrender or flee. The post-response check starts
sustained combat only when appropriate and never queues a resolved opening again.

An objective may explicitly control mode:

```json
{ "type": "set_combat_active", "active": true }
```

Use false to stop combat. The guided reward editor exposes this as the
Combat active checkbox under Set combat active. The story must enable combat. Explicit objective
control takes precedence over that exchange's automatic checker. Mode alone
does not move characters, start an attack, grant powers or heal anyone.

## Character profiles

Use the character skill's complete definitions with these optional numeric stats:

| Exact stats key | Meaning | Precision |
|---|---|---|
| `health` | Current health, from minus maximum through maximum | At most 2 decimals |
| `max_health` | Positive maximum health | At most 2 decimals |
| `physical_attack` | Physical attack effectiveness rating | At most 2 decimals |
| `magical_attack` | Magical attack effectiveness rating | At most 2 decimals |
| `physical_defense` | Resistance rating against physical attacks | At most 2 decimals |
| `magical_defense` | Resistance rating against magical attacks | At most 2 decimals |

All six values must be finite safe numbers when a full profile is provided;
only health may be negative. Maximum health is positive. The fixed profile has
built-in precision; it does not need custom numeric_precision entries. Other
unrelated custom stats keep their existing precision contract. Susceptibility
fields are not part of this profile. No old-save migration or rule-version
compatibility system is provided before publication.

Prefer explicit profiles for important authored combatants, including a default
player. A magical attack value does not grant unknown spells. Describe learned
abilities, speed, reflexes and limitations in existing character descriptions
and facts; no new speed/reflexes/string-stat schema is introduced.

If a present character has no complete combat profile, entering active combat
may explicitly generate the missing profile through private creative prose and
a separate numerical extraction. Existing supplied combat values are preserved.
This is a gameplay creation step, not a load/import migration or silent default.
An invalid complete profile is rejected; it is not regenerated into validity.
An uninspected NPC can receive a profile without forcing full character inspection.
Ordinary directory updates preserve that profile, and later inspection carries
its existing values into the completed character without resetting health.

The reusable complete example is [combat-story.json](combat-story.json).

## Damage and outcomes

Applied damage is ceil(Strength * 2 * Attack / (Attack + Defense)). Physical
attacks use the attacker's physical_attack and target's physical_defense;
magic uses magical_attack and magical_defense. Strength is BASE damage for
that particular hit, not the Attack rating. The AI must not first multiply by
Attack or apply Defense. The engine rounds the exact final result up once to
an integer. Attack zero always deals zero, including Attack/Defense both zero.
Equal positive ratings give ceil(Strength); zero Defense doubles Strength before
final ceil. Misses/full blocks have no hit event; zero damage causes no new wound.

Weak spots, opportunity, preparation, weapons, force and restraint affect Strength.
Ordinary punches should not kill is AI guidance, not engine immunity; explicit
full force may be more dangerous. An explicitly nonlethal hit cannot push health
below zero or worsen existing negative health. In mixed orderless exchanges the
engine subtracts lethal damage, then caps nonlethal damage at remaining positive
health. Restraint never heals anyone and is not inferred from a weapon name.

All characters with positive health at the exchange's START may perform their
adjudicated attacks, even if incapacitated by another simultaneous hit. An
already-incapacitated character cannot attack. This is not chronological initiative.

Health cannot fall below minus max_health. At zero or negative above that floor,
a person is conscious, may speak and can only crawl slowly. They cannot stand,
walk, fight, grip weapons or perform other physical exertion. At minus maximum
they are dead if can_die is true; otherwise they are unconscious. The initial
adjudicator cannot decide death or permanent wounds. Final narration follows
the authoritative engine condition, including death only at the proper floor;
it cannot invent limb loss. Existing injuries remain. Explicit authored
kill_character/ending rewards retain their own semantics and can_die rules.
No mana/stamina or passive health regeneration exists. Ending combat restores
neither health nor consciousness; ordinary rest does not imply HP recovery.
Starting capabilities are explicit before adjudication. An actor already dead
or unconscious cannot actually attempt a voluntary action, struggle, speak or
perceive events merely because the player requests it. After the player loses
awareness, narration describes other characters externally rather than granting
the player a continuing sensory experience. A nonsexual combat condition pass
uses focused condition/HP data and preserves prior unresolved injuries while
replacing obsolete consciousness or posture; becoming unconscious does not heal.
Numeric healing, special regeneration and damage-transfer abilities are not
inferred from narration by the damage-only extractor. Author explicit valid
health rewards when needed; do not invent a new healing-extraction format.
Provide an authored recovery route or ending when incapacitation would otherwise
strand the player. Ending combat alone does not restore their ability to act.

## AI and persistence contract

The active exchange uses private natural-language adjudication, then damage-only
plain-text extraction, then final narration. The separate post-response mode
checker and ordinary existing state work are additional calls. New profiles
require their own one-time creation calls. Do not claim exactly three total
provider calls for every turn.

Damage extraction uses one block per decided hit, blank-line separated:

```text
attacker: exact present character ID
target: exact present character ID
type: physical
strength: 100
nonlethal: yes
```

Use `magical` for magic, or exactly `none` for no hits. The nonlethal line is
optional, accepts yes/no and must reflect an explicitly decided designation.
The internal raw_damage field stores this same Strength, not final damage.
No JSON, injuries,
conditions, deaths, new attacks or health recalculation belong in extraction.
The final narrator receives the FULL original adjudication and fixed results.
It cannot add a hit or choose a different outcome. Zero applied damage must not
be narrated as a damaging wound.

Health/result changes remain a private draft until final narration succeeds.
The engine then saves the health, buffered completed response and once-only
receipt together. A failed provider response before commit loses no health.
Repeated delivery of the same committed reply reuses its receipt; user-requested
message edit/regeneration first rewinds owned effects through normal snapshots.
Native save/reload preserves mode, health and complete receipts. Slow state AI
cannot write fixed combat stats or combat controls, preventing double damage.
Receipts capture each participant's explicit can_die policy. An uninspected
shell's omitted optional flag follows native storage's false policy without
inserting that field into canonical NPC data. Full characters require the flag.

AI judgment and extraction remain model-dependent. The fixed equation and
validated receipts guarantee the engine's arithmetic, not perfect tactics or
language on every generation. Inspect actual responses/retries when testing.
