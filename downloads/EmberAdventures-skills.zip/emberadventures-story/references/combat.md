# Fixed opt-in combat

Normal EmberAdventures has one combat system. There are no story-defined damage
equations, alternative damage modes, initiative/dice configuration or custom
event processors. The AI decides plausible actions and BASE damage; the engine
applies susceptibility exactly once and owns health arithmetic and receipts.

## Enable a story

Optional `state.combat` has exactly these authored fields:

```json
{
  "enabled": true,
  "active": false,
  "rules": "Use established abilities. An ordinary clean staff hit uses physical_attack; a known magical bolt uses magical_attack. Explain weaker or stronger techniques in the private adjudication. This encounter is nonlethal.",
  "rounds": {}
}
```

`enabled` permits the feature; `active` is current combat mode. Both are booleans.
Disabled combat cannot be active. Rules must be nonempty descriptive text; they
cannot change the fixed equation. Authors initialize rounds as an empty map.
Do not author the engine-owned optional `pending_opening`,
`last_checked_message_id`, `override_message_id` or populated round receipts.
Omit combat entirely for an ordinary story; it incurs no combat/checker calls.

When inactive, ordinary narration stops at an attempted attack before resolving
contact or injury. A separate post-response checker answers only yes/no and can
enable combat for the NEXT turn. The next adjudication receives the pending
opening intent; a later changed/canceled player instruction takes precedence.
The same small post-response check exits unscripted combat after it ends.

An objective may explicitly control mode:

```json
{ "type": "set_combat_active", "active": true }
```

Use false to stop combat. The guided reward editor exposes this as the
Combat active checkbox under Set combat active. The story must enable combat. Explicit objective
control takes precedence over that exchange's automatic checker. Mode alone
does not move characters, start an attack, grant powers or heal anyone.

## Character profiles

Use the character skill's complete definitions with these optional numeric stats:

| Exact stats key | Meaning | Precision |
|---|---|---|
| `health` | Current health, from zero through max_health | At most 2 decimals |
| `max_health` | Positive maximum health | At most 2 decimals |
| `physical_attack` | Ordinary clean physical hit's BASE damage | At most 2 decimals |
| `magical_attack` | Ordinary clean known magical attack's BASE damage | At most 2 decimals |
| `physical_susceptibility` | Fraction of physical raw damage taken | At most 6 decimals |
| `magical_susceptibility` | Fraction of magical raw damage taken | At most 6 decimals |

All six values must be finite, nonnegative safe numbers when a full profile is
provided. The fixed profile has built-in precision; it does not need custom
numeric_precision entries. Other unrelated custom stats keep their existing
precision contract. Fractions are literal: 0.25 takes 25%, 1 takes 100%, 0 is immune,
and values above 1 mean vulnerability. Do not author 25 for 25%.

Prefer explicit profiles for important authored combatants, including a default
player. A magical attack value does not grant unknown spells. Describe learned
abilities, speed, reflexes and limitations in existing character descriptions
and facts; no new speed/reflexes/string-stat schema is introduced.

If a present character has no complete combat profile, entering active combat
may explicitly generate the missing profile through private creative prose and
a separate numerical extraction. Existing supplied combat values are preserved.
This is a gameplay creation step, not a load/import migration or silent default.
An invalid complete profile is rejected; it is not regenerated into validity.
An uninspected NPC can receive a profile without forcing full character inspection.
Ordinary directory updates preserve that profile, and later inspection carries
its existing values into the completed character without resetting health.

The reusable complete example is [combat-story.json](combat-story.json).

## Damage and outcomes

Applied damage is raw physical damage times physical susceptibility, or raw
magical damage times magical susceptibility. Each hit rounds once to two
decimals, half upward. Sum all hits simultaneously and reduce health to a floor
of zero. Health lost cannot exceed starting health; an individual calculated
hit may contain overkill. Misses/full blocks have no damage event. Immunity
may have positive raw damage and zero applied damage.

All characters with positive health at the exchange's START may perform their
adjudicated attacks, even if incapacitated by another simultaneous hit. An
already-incapacitated character cannot attack. This is not chronological initiative.

Zero health means incapacitated, not automatic death/game over. Neither combat
AI call may declare deaths or permanent injuries such as lost limbs for anyone.
Existing injuries stay intact. Explicit authored kill_character/ending rewards
retain their own semantics and can_die rules. No mana/stamina or passive health
regeneration exists. Do not imply automatic HP recovery from ordinary rest.
Numeric healing, special regeneration and damage-transfer abilities are not
inferred from narration by the damage-only extractor. Author explicit valid
health rewards when needed; do not invent a new healing-extraction format.
Provide an authored recovery route or ending when incapacitation would otherwise
strand the player. Ending combat alone does not restore their ability to act.

## AI and persistence contract

The active exchange uses private natural-language adjudication, then damage-only
plain-text extraction, then final narration. The separate post-response mode
checker and ordinary existing state work are additional calls. New profiles
require their own one-time creation calls. Do not claim exactly three total
provider calls for every turn.

Damage extraction uses one block per decided hit, blank-line separated:

```text
attacker: exact present character ID
target: exact present character ID
type: physical
raw: 100
```

Use `magical` for magic, or exactly `none` for no hits. No JSON, injuries,
conditions, deaths, new attacks or health recalculation belong in extraction.
The final narrator receives the FULL original adjudication and fixed results.
It cannot add a hit or choose a different outcome. Zero applied damage must not
be narrated as a damaging wound.

Health/result changes remain a private draft until final narration succeeds.
The engine then saves the health, buffered completed response and once-only
receipt together. A failed provider response before commit loses no health.
Repeated delivery of the same committed reply reuses its receipt; user-requested
message edit/regeneration first rewinds owned effects through normal snapshots.
Native save/reload preserves mode, health and complete receipts. Slow state AI
cannot write fixed combat stats or combat controls, preventing double damage.

AI judgment and extraction remain model-dependent. The fixed equation and
validated receipts guarantee the engine's arithmetic, not perfect tactics or
language on every generation. Inspect actual responses/retries when testing.