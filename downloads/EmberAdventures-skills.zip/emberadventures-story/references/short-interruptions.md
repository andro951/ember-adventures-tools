# Short triggered interruptions

Use an optional `state.story_pacing.interruptions` container for short beats that
temporarily take objective focus and then return to the player's prior selection.
This is separate from a pending main plot point, which becomes available without
changing selection. Keep both the main objective graph and ordinary side tasks.

```json
{
  "events": {
    "a-weather": {
      "id": "a-weather",
      "title": "A weather notice",
      "objective_id": "hear-weather-notice",
      "trigger": {
        "readiness_guidance": "After the player actually returns the borrowed guide and its owner accepts it, at a conversational pause. An offer or intention is not a completed return."
      },
      "status": "waiting"
    }
  },
  "queue": [],
  "stack": []
}
```

The container requires exactly `events` (identity map), `queue` (array of event
IDs), and `stack` (resume frames). Omit the entire optional container when unused.
Fresh stories use empty queue/stack and waiting events. Event fields are exactly
`id`, `title`, `objective_id`, `trigger`, `status`, with optional engine-owned
`last_readiness_message_id` text. IDs use lowercase letters, numbers, hyphens or
underscores and must exactly match their map keys. Titles are nonempty text.

Each distinct target must be an existing non-repeating side objective, with no
selection lock and no `next_objectives`, `choices`, or `outcome_routes` outputs.
Use an empty `next_objectives` array and ordinary concrete completion criteria.
Require a nonempty `completion_instruction` on the target: it supplies the actual
beat content to the reply that resolves it after pre-narration completion.
`while_active_guidance` covers the ongoing interaction before resolution.
A title or completion criterion alone does not tell the resolving narrator
what to say. Initially hide it;
the interruption is its supported activation route, so no artificial graph edge
is needed. Keep hidden content out of ordinary narrator guidance and summaries.

Trigger fields are optional `objective_id` (a different completed-objective
prerequisite), `at_elapsed_minutes` (nonnegative whole elapsed story minutes),
and `readiness_guidance` (nonempty private text). At least one is required.
Hard prerequisites must all hold; guidance then asks the AI about established
events. Do not create cyclic interruption prerequisites. Readiness queues a beat:
it does not perform travel, accept an offer, grant rewards or finish the beat.

Ready events queue in ascending exact event-ID order. One runs at a time. Locked
scenes and pending objective choices defer the queue without consuming it.
Ordinary play completes the active objective; subsequent queued beats follow,
then the prior main/side/Stop Tracking selection returns. A player's explicit
manual selection takes precedence over restoring the old selection. An event
is consumed once and cannot restart on reload or another readiness check.

Engine status is `waiting`, `queued`, `active` or `complete`. Runtime stack frames
have exactly `event_id`, `selection`, `manual_override`; selection has exactly
`active_id`, `focus_id` (existing objective IDs or empty strings), `no_current`
(boolean). `manual_override` is boolean. Do not author gameplay history into a
fresh template. Queue/status/frame relationships are strictly validated, not
repaired. The full app validator also checks target references and restrictions.

Test actual eligibility, multiple simultaneous beats, selected side-task resume,
Stop Tracking, explicit manual override, reload while active, and ordinary
edit/regenerate rollback. Do not infer acceptance from parser tests alone.