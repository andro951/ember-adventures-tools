# Triggered side quest trees

Use optional `state.story_pacing.interruptions` for a triggered ordinary side
quest tree. It becomes selected when eligible, remembers the interrupted
questline, and returns when its selected path ends. The player can switch among
unfinished questlines. Pending main plot points remain a separate availability
feature and do not steal the selected side quest.

```json
{
  "events": {
    "parcel": {
      "id": "parcel",
      "title": "Pack a parcel",
      "objective_id": "parcel-choice",
      "trigger": {"objective_id": "return-book", "readiness_guidance": "The guide was actually returned and accepted, not merely offered."},
      "status": "disabled"
    }
  },
  "queue": [],
  "stack": []
}
```

The exact container fields remain `events`, `queue`, `stack`. The existing
`stack` name stores return-reference history; it is not a compulsory LIFO
execution stack. Fresh stories author empty queue/stack. An event requires
exactly `id`, `title`, `objective_id`, `trigger`, `status`, optionally the
engine-owned `last_readiness_message_id`. Event keys and matching IDs are
lowercase letters/numbers/hyphens/underscores. Titles are nonempty text.

## Ordinary graph ownership

`objective_id` names the entry side objective. Its tree is all side objectives
reachable through normal `next_objectives`, `choices` and `outcome_routes`
destination references. Author normal outputs, input groups, conditions,
completion instructions and rewards; do not duplicate the graph in an event
registry. Different event trees cannot share objectives or point into the main
story. A reward that starts an unrelated objective does not make it a child.
All members remain unavailable until this event fires. After firing, ordinary
selection, branch eligibility, progress, rewards and explicit objective locks
apply. There is no new per-instance progress or forced suspension engine.

End a path with an ordinary terminal side objective with no outgoing objective
references and a concrete `completion_instruction`. A title or completion
criterion alone does not tell the resolving narrator what to say. Branches can
converge on the same terminal. Do not use a whole-story `ending_type` merely to
return from a side quest: existing whole-story ending semantics still apply.
See [the complete workshop example](quest-tree-story.json).

## Arming and readiness

Start an event as `disabled` when an earned action must arm it:

```json
{"type":"enable_triggered_objective","event_id":"parcel"}
```

This exact reward accepts only `type` and `event_id`, referencing an existing
event here. It changes disabled to waiting, without firing, selecting anything,
completing an objective or awarding the event's own rewards. Enabling a waiting,
queued, active or completed event again has no further effect. Events fire once;
there is no repeating-instance or automatic-rearm system. Use `waiting` initially
when no separate arming step is wanted.

Trigger fields are optional `objective_id` (completed prerequisite),
`at_elapsed_minutes` (nonnegative integer) and `readiness_guidance` (private
nonempty text). At least one is required. Hard prerequisites must all hold;
guidance asks about established actual actions, not intentions. Do not create
cyclic event prerequisites. Existing checks run after completed AI responses
and state updates, never ahead of an already queued player response. Readiness
returns bare exact event IDs, one per line, or `none`; no `event:` prefix.

Ready events queue in ascending exact event-ID order. Explicit locked scenes
and pending objective choices defer activation. Another event may activate
while a quest is unfinished: it records that quest's current step as its return
reference. No priority system or compulsory suspension is imposed.

## Returns and persistence

Each fired event keeps one engine-owned return record in `stack` with required
`event_id`, `selection`, `manual_override`, and optional `current_objective_id`.
The current objective is a reference into the existing normal progress records;
it is not a second copy of branch progress. Without that optional reference the
entry is the current step. Selection contains exactly `active_id`, `focus_id`
(existing IDs or empty text) and `no_current` (boolean). `manual_override` records
whether the latest manual selection was outside this tree; returning manually
clears it. It does not permanently disable later automatic returns.

As normal objectives advance, update current steps and any saved return
references to those newer steps. Completing a selected terminal side objective
returns to the interrupted quest's current unfinished step. A background
completion preserves the player's actual current selection. Completed parent
trees are followed onward through their own return references, never reopened.
Keep completed return history because an unfinished child may still refer to
it. Reject return cycles and invalid references. Stop Tracking is a valid return
selection. An unresolved ordinary branch uses the normal objective chooser.

Statuses are exactly `disabled`, `waiting`, `queued`, `active`, `complete`.
Queue/status/return relationships, tree ownership and references are validated
through the app's canonical contract. Save/reload restores ordinary progress
and these references; it never replays rewards or fires completed events.
Normal message editing/rewind removes only source-owned effects.

Test a real choice, nested trigger, free switching, parent advancement, completed
parent skipping, background completion, once-only arming, native reopen and
source edit/undo. Automated checks support actual Perchance playtests.
