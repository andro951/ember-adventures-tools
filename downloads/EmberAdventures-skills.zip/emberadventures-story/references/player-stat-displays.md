# Live player stat displays

Optional `state.meta.player_stat_display` defines extra read-only values in the
player's Stats panel. Its keys are exact display IDs. Each entry requires exactly
`label` (nonempty text), `color` (`#RRGGBB`), and `value_expression`.

Use the existing safe numeric expression grammar: `initial` plus an `operations`
array of `operation` and `operand`. Do not use formula strings or JavaScript.
This is the same numeric expression contract used by numeric rewards and
[requirements](numeric-requirements-and-pending-outcomes.md).

```json
{
  "player_stat_display": {
    "command_total": {
      "label": "Total command capacity",
      "color": "#d4b768",
      "value_expression": {
        "initial": { "path": ["story_inventory", "command_capacity"] },
        "operations": []
      }
    },
    "command_available": {
      "label": "Available command capacity",
      "color": "#72bc8f",
      "value_expression": {
        "initial": { "path": ["story_inventory", "command_capacity"] },
        "operations": [
          { "operation": "subtract", "operand": { "path": ["story_inventory", "command_committed"] } }
        ]
      }
    }
  }
}
```

This snippet belongs inside `state.meta`. The numeric fields it references must
already exist in the story state. See the complete validated
[player-stat-display-story.json](player-stat-display-story.json) example,
including a separate used-capacity display.

These values are recalculated when opened and when their referenced state
changes. They survive save/reopen through the authored metadata and current
source values. Do not store or synchronize a second available-capacity counter.
Companion/NPC panels keep their own character stats and never receive these
player-only values. Ordinary `state.meta.stat_display` still permits only
`label` and `color`; do not put expressions there.

This contract changes display only: it does not spend resources, alter character
stats, implement bonding, or change rewards. Author those mechanics separately.
Unknown fields, missing/non-numeric references and undefined arithmetic are
errors; they never become zero. Runtime failures display Unavailable and report
the error. Nonintegral exact values are shown as fractions without silent
rounding. Keep future narrative readouts optional story content rather than a
requirement of this UI feature.
