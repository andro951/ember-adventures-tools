# Terminal side tasks, scheduled handoffs and automatic routers

Read when a side task should end without ending the story, a main step should
await an existing timeline event, or an automatic node only routes progress.

## Terminal side tasks and choices

An ordinary `type: "side"` task may finish with no next objective. This applies
to player, AI, cutscene and `reward_only` completion controls. A terminal direct
choice option, or an AI-routed side outcome, omits `next_objective_id`,
`target_input_group_id` and `ending_type`. Do not write null destinations or add
an ending merely to finish an errand. Choices still require a stable option ID,
title, completion instruction and reward array, including when empty.

```json
{
  "id": "take-receipt",
  "title": "Take the receipt",
  "completion_instruction": "The clerk hands over the receipt.",
  "requirements": [],
  "rewards": []
}
```

This option is valid on a side objective with `completion_control: "choice"`.
The player must select an eligible option; its effects and selected-output
receipt commit once. An unselected/canceled choice applies nothing. Completion
uses the existing quest return mechanism, including nested triggered quests and
the player's explicit selection changes. It does not request AI classification,
add an extra player action, advance the clock, or end the main story. Normal
narration of an actual player choice may still occur.

For an automatic terminal side task use `completion_control: "reward_only"`,
`requirement_check_only: true`, `type: "side"`, and `next_objectives: []`.
Its actual prerequisites/completion requirements still govern eligibility.
Do not use an AI-on-activation wrapper as a deterministic return operation.

## Main steps that await a timeline event

A main objective may have `next_objectives: []` if an existing ordinary
`state.story_pacing.timeline` event explicitly names it as the trigger prerequisite
and names a different successor objective. The pacing mode is `time_controlled`.
This is an intentional scheduled continuation, not an unfinished graph edge.

```json
{
  "id": "delivery-appointment",
  "title": "Delivery appointment",
  "status": "waiting",
  "objective_id": "attend-appointment",
  "trigger": {"objective_id": "deliver-parcel", "at_elapsed_minutes": 60},
  "auto_start": false,
  "prompt": {"message": "Your appointment is ready.", "accept_label": "Attend", "decline_label": "Decline"},
  "accept": {"objective_id": "attend-appointment", "rewards": []}
}
```

The time is absolute elapsed story minutes. Both the trigger prerequisite and
the deadline must be satisfied; the destination's authored prerequisites still
apply. Completing the source never unlocks the destination early through ordinary
dependency processing, selection, graph routing or a start-objective reward.
With `auto_start: false`, becoming ready preserves the invitation: availability
requires acceptance. `auto_start: true` retains the existing timed-event activation
behavior. Do not add an ordinary graph edge as a timer substitute. Save/load and
clock jumps retain the event's once-only status. A declined/missed event does not
become freely selectable through another path merely because time passed.

These ordinary timeline events retain their existing locked-scene/conflict
behavior. They are distinct from the softer `kind: "plot_point"` availability
system described in [main-plot-points.md](main-plot-points.md).

## Automatic routers with no gameplay reward

Use `completion_control: "reward_only"`, `requirement_check_only: true`,
`rewards: []` and ordered `next_objectives`. The first eligible ordinary output
wins; existing fallback semantics remain. No dummy currency, relationship,
inventory, clock, or flag reward is required. Completion and routing bookkeeping
still change, even when no gameplay reward does.

If no output qualifies, the router stays pending without completing or applying
effects. It is reconsidered through the existing objective/reward processing.
Never choose an ineligible branch to force progress. Automatic traversal cannot
replay a completed node; author graphs so their intended cycles require a real
player action or new authored work rather than relying on reward replay.

## Closing an ordinary map destination

```json
{"type": "lock_location", "location_id": "old-mine"}
```

The location ID must already exist. This reward sets its travel eligibility to
false, preserving discovery, history, connections, current position and other
locations. An actor already inside can leave through an existing eligible exit.
It neither teleports the player nor hides/deletes the destination. The existing
`unlock_location` reward reopens it. Do not write `travel_enabled` through
`set_state_field`; do not convert an ordinary map to hex mode to close one place.

For a hex passage use its separate explicit `set_hex_passage_status` contract.
See [objective-handoffs-story.json](objective-handoffs-story.json) for a complete
canonical example of these four behaviors.
