# Interactive cutscene beats

Use `completion_control: "cutscene"` for one short authored event that proceeds
with the next completed narrator reply, regardless of whether the player clicks
Continue, asks a question, protests, or supplies no substantive action. This is
different from an AI-controlled objective with an easy completion criterion.

Require a nonempty objective `completion_instruction` describing the fixed beat.
Omit `completion_criteria`. Use at most one unconditional `next_objectives` output
with normal exact output fields, rewards and target input group (or an ending).
Do not add choices, outcome routing, activation evaluation, completion requirements
or next-output requirements. Use an earlier ordinary objective for eligibility
before the cutscene begins. A terminal side cutscene may have no outgoing output
and return through the ordinary side-quest mechanism without ending the story.

The narrator is instructed to deliver that current beat while acknowledging the
player's reaction without inventing their agreement, thoughts or next action.
The reply must not deliver future beats. Sequence several cutscene objectives
with ordinary graph connections for a longer performance.

Progression and rewards occur only after a finished nonempty narrator reply to
that same still-current objective. Player submission, a streaming draft, canceled
or failed generation does not consume it. Completed-objective status and normal
reward receipts prevent duplicate effects. Native message edit/undo restores
the previous beat/effects and replay uses the normal delivery path. There is no
automatic chain of all cutscene beats in one turn.

This is prompt-directed prose delivery, as Isaac requested. The engine guarantees
the progression boundary; it cannot deterministically prove every semantic
detail appeared in an AI-written paragraph. Review real generated narration.
Keep cutscene events concrete and short, rather than packing an entire chapter
into one instruction.

See [the complete ferry-departure example](cutscene-ferry-story.json).
