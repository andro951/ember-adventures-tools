# Story contract

Use [reference-story.json](reference-story.json) for a complete, importable example.
Other JSON blocks in this reference are explanatory sketches and may contain placeholders or partial shapes.
`field-sets.json` snapshots current canonical field names; validation uses the game itself.

## Required Output Wrapper

Story exports use this wrapper:

```json
{
  "app": "EmberAdventures",
  "exportType": "story-template",
  "storyTemplate": {
    "id": "story-id",
    "title": "Story Title",
    "description": "Short player-facing description",
    "createdAt": "<actual ISO 8601 creation timestamp>",
    "updatedAt": "<actual ISO 8601 update timestamp>",
    "state": {
      "meta": {
        "app": "EmberAdventures",
        "genres": ["fantasy", "adventure"],
        "kink_tags": [],
        "story_guidance": "",
        "story_source": {
          "mode": "original",
          "title": "Story Title",
          "description": "Short premise description",
          "modifications": ""
        }
      },
      "location": {
        "npc_location_id": "loc-start",
        "universe": "Story Title",
        "world": "World Name",
        "continent": "",
        "region": "Starting Region",
        "settlement_type": "",
        "settlement_name": "",
        "district": "",
        "specific_place": "Starting Place"
      },
      "world_map": {
        "current_location_id": "loc-start",
        "focus_location_id": "loc-start",
        "travel_history": [],
        "locations": {
          "loc-start": {
            "id": "loc-start",
            "name": "Starting Place",
            "type": "place",
            "scale": "site",
            "parent_id": "",
            "x": 50,
            "y": 50,
            "discovered": true,
            "travel_enabled": true,
            "summary": "The place where the story begins.",
            "detail": {},
            "connections": [],
            "npcs": []
          }
        }
      },
      "time": {
        "year": 1,
        "month": 1,
        "day": 1,
        "hour": 8,
        "minute": 0
      },
      "scene": {
        "summary": "The opening situation in one concise sentence.",
        "intimacy_level": 0,
        "spicy_mode": "off",
        "party_members_present": [],
        "image_characters": ["Player"],
        "npcs_present": [],
        "image_action": "standing at the starting place",
        "sex_position": "",
        "ai_sex_position": "",
        "sex_acts": []
      },
      "player": {
        "version": 1,
        "id": "player-character",
        "name": "Player Character Name",
        "source": "Original",
        "creation_tool": "<actual tool/model> (<reasoning level>)",
        "nsfw": false,
        "loli": false,
        "can_die": false,
        "romanceable": false,
        "gender": "female",
        "fallback_name": "Player Character Name",
        "fallback_outfits": [
          {
            "id": "fallback-default",
            "name": "Fallback Default",
            "nsfw": false,
            "clothing": {
              "undershirt": "plain cotton undershirt",
              "shirt": "plain everyday shirt",
              "underwear": "plain comfortable underwear",
              "pants": "plain everyday trousers",
              "socks": "plain socks",
              "feet": "practical shoes"
            }
          }
        ],
        "fallback_starting_outfit_id": "fallback-default",
        "age": 25,
        "role": "Story protagonist",
        "personality_description": "Durable starting identity that preserves player agency.",
        "speech_style": "Natural dialogue suited to the character.",
        "boldness": 5,
        "starting_relationship_to_player": "self",
        "starting_trust": 0,
        "starting_attraction": 0,
        "starting_affection": 0,
        "starting_arousal": 0,
        "starting_state_of_mind": "neutral",
        "starting_physical_state": "healthy",
        "starting_pose": "standing at the starting place",
        "appearance": {
          "species": "human",
          "height": 10,
          "shoulder_width": 10,
          "chest": 13,
          "upper_body_build": 8,
          "midsection_build": 8,
          "hip_width": 10,
          "butt_build": 8,
          "lower_body_build": 8,
          "arm_length": 10,
          "leg_length": 10,
          "penis_size": 10,
          "skin_color": "",
          "eye_color": "",
          "hair_color": "",
          "hair_length": "",
          "hair_type": "",
          "extra_description": "",
          "extra_description_lower_body": "",
          "nonhuman_lower_body": false
        },
        "outfits": [
          {
            "id": "default",
            "name": "Default",
            "nsfw": false,
            "clothing": {
              "undershirt": "plain cotton undershirt",
              "shirt": "plain everyday shirt",
              "underwear": "plain comfortable underwear",
              "pants": "plain everyday trousers",
              "socks": "plain socks",
              "feet": "practical shoes"
            }
          }
        ],
        "starting_outfit_id": "default",
        "starting_held_items": {
          "right_hand": null,
          "left_hand": null
        },
        "starting_inventory": [],
        "starting_known_facts": [],
        "starting_nsfw_known_facts": [],
        "default_seed": 0,
        "image_prompt_config": {
          "seed_enabled": true,
          "seed": 0,
          "style": "",
          "profile_style": "",
          "negative": "",
          "negative_prompt": ""
        },
        "default_profile_image": {
          "url": "",
          "local_image_id": "",
          "source": "none",
          "seed": null,
          "prompt": "",
          "negative_prompt": "",
          "note": "",
          "male": false
        },
        "profile_image_presentations": {
          "male": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "seed": null,
            "prompt": "",
            "negative_prompt": "",
            "note": "",
            "male": true
          },
          "non_male": {
            "url": "",
            "local_image_id": "",
            "source": "none",
            "seed": null,
            "prompt": "",
            "negative_prompt": "",
            "note": "",
            "male": false
          }
        },
        "profile_images": {
          "active_image_id": "",
          "image_ids": []
        },
        "images": {
          "active_image_id": "",
          "image_ids": []
        },
        "voice": null,
        "created_at": "<actual ISO 8601 creation timestamp>",
        "updated_at": "<actual ISO 8601 update timestamp>"
      },
      "characters": {},
      "npc_directory": {
        "locations": {}
      },
      "world_flags": {
        "tone": "Concise story-specific tone guidance."
      },
      "objectives": {
        "active_id": "opening-objective",
        "no_current": false,
        "items": [
          {
            "id": "opening-objective",
            "title": "<specific immediately actionable objective title>",
            "type": "story",
            "status": "active",
            "summary": "<specific player-facing description of the opening goal>",
            "completion_control": "player",
            "completion_criteria": "<specific observable condition that proves this exact opening goal is complete>",
            "next_objectives": [
              {
                "id": "opening-objective-output-1",
                "objective_id": "next-objective",
                "target_input_group_id": "next-objective-input-1",
                "completion_instruction": "<specific immediate result, consequence, reveal, or transition for completing this exact goal>",
                "requirements": [],
                "rewards": []
              }
            ]
          }
        ]
      },
      "future_cast": {
        "enabled": true,
        "items": {}
      },
      "story_clock": {
        "elapsed_minutes": 0,
        "label": "Day 1, 8:00 AM"
      },
      "story_pacing": {
        "mode": "player_controlled",
        "pending_event_id": "",
        "timeline": {}
      },
      "timed_events": {},
      "story_rules": [],
      "story_memory": {
        "world_notes": [],
        "unresolved_threads": [],
        "relationship_notes": [],
        "rules_and_constraints": [],
        "ai_private_notes": []
      },
      "recent_changes": []
    },
    "messages": [
      {
        "role": "assistant",
        "speaker": "Narrator",
        "text": "A concise, immediately playable opening that ends with a concrete situation the player can act on."
      }
    ],
    "source": "Original",
    "app": "EmberAdventures",
    "templateType": "story",
    "creation_tool": "<actual tool/model> (<reasoning level>)",
    "genres": ["fantasy", "adventure"],
    "kink_tags": [],
    "nsfw": false,
    "loli": false,
    "default_image_model": "",
    "editor_data": {
      "story_tree": {
        "positions": {},
        "viewport": {
          "x": 0,
          "y": 0,
          "zoom": 1
        }
      }
    },
    "title_card_subjects": [],
    "title_card_image": {
      "id": "",
      "title": "",
      "prompt": "",
      "negativePrompt": "",
      "seed": "",
      "model": "",
      "source": "none",
      "url": "",
      "hosted_url": "",
      "html": "",
      "favorite": false,
      "nsfw": false,
      "upload_attestation_classification": "",
      "upload_attested_by": "",
      "upload_attested_at": "",
      "upload_attestation_policy_version": 0
    }
  },
  "exportedAt": "<actual ISO 8601 export timestamp>"
}
```

All timestamp and creation-tool strings in this example are documentation
placeholders. Replace them with factual values in final output. Preserve
`createdAt` and embedded character `created_at` when editing existing content;
update `updatedAt` and changed embedded character `updated_at` only when their
content changes. Set `exportedAt` to the actual export time.

The canonical skeleton is structural documentation, not ready-made story
content. Replace every generic title, description, location, objective,
completion criterion, completion instruction, character fact, and opening line
with concrete premise-specific content. Never emit the skeleton unchanged or
reuse its example names in a finished story.

Required state sections:

`meta`, `location`, `world_map`, `time`, `scene`, `player`, optional `players`,
`characters`, `npc_directory`, `world_flags`, `objectives`, `future_cast`,
`story_rules`, `story_memory`, `recent_changes`.

Optional top-level editor metadata:

`editor_data.story_tree` stores visual Story Builder layout only. It is not
runtime state and is not sent to narrator prompts. It may be omitted, but when
present it should use:

```json
{
  "positions": {
    "objective-id": { "x": 80, "y": 80 }
  },
  "viewport": { "x": 0, "y": 0, "zoom": 1 }
}
```

Use this only to make the manual visual tree editor nicer to open. Never put
story lore, hidden objectives, creator notes, or AI instructions in
`editor_data`. The visual tree editor derives every graph edge from
`next_objectives`, `choices`, or `outcome_routes`; each nonterminal output
stores the destination and `target_input_group_id`. Do not duplicate those
edges in `requires` and do not create separate fake branch-node objects merely
to make a diagram.

Optional hidden economy sections:

`state.player_home` optionally tracks accepted accommodation and actual used-night
charges. Read [player-home.md](player-home.md) for its complete exact contract;
omit it when the story does not use Home. Visits, offers and pricing guidance
are not accepted agreements or payments. Existing story inventory owns currency.

`story_inventory`, `character_shop_cost_templates`, `story_shops`, `story_job_offers`,
`story_job_offer_history`, `active_generated_jobs`, and
`story_generated_npc_pool`.

Use these only when the story benefits from controlled resources, shops, job
boards, item selling, or purchasable/recruitable characters. They are hidden
engine state, not narrator lore. Normal AI prompts do not receive them whole,
so any shop/job/resource behavior that must happen reliably must be represented
through the UI, objective choices, or deterministic rewards.

`story_inventory` stores story-owned resources such as `coins`, `credits`,
`adventurer_xp`, `adventurer_rank`, repair parts, suspicion, reputation, and
items. Use it for resources that should not be freely granted by narrator prose.
Items may include `id`, `name`, `type`, `quantity`, `value`, `sellable`,
`quest_item`, `description`, and the portable nested `image` slot documented in
Story Image Rules. This applies to starting story-inventory items, general-shop
items, and job reward items. Quest items should normally be non-sellable.

`story_shops` is an object keyed by shop id. A shop has `id`, `title`, internal
`type` (`"character"`, `"job"`, `"general"`, or `"clothing"`), display-only `subtype`, optional
`description`, `unlocked`, `currency`, display-only `location`, required
`npc_location_id`, optional `owner_npc_id`, and `items`. `npc_location_id` must
be a nonempty stable id that resolves to an existing
`state.npc_directory.locations` key; never put a location label or prose in that
field. `type` is hidden
engine behavior; `subtype` is just text shown to the player, such as `Slave
Shop`, `Companion Shop`, `Mercenary Guild`, `General Store`, `Outfitter`, or
`Job Board`.

An authored shop can opt into the programmatic owner catalog with this shop field:

```json
"owner_generator": {
  "role_id": "smith",
  "town_id": "redhaven",
  "category": null,
  "species_choices": [{ "species": "half-elf", "fit_id": "half-elf" }]
}
```

`role_id` is `smith`, `baker`, `apothecary`, `innkeeper`, or
`property_merchant`. `town_id` is the exact existing town/city map ID.
`category` is `good`, `bad`, `neutral`, or `null` to allow any compatible
available category. Supply the shop's exact stable `owner_npc_id` and its
normal room, stock and pricing fields. The catalog chooses a proper name,
body, outfit, appearance and coherent prewritten profile locally.

Optional `species_choices` is a nonempty list of exact `species` / `fit_id`
pairs. Species text is unrestricted and the fit selects catalog body/outfit
ranges. Omitting the list uses the human fit and species. Optional `gender`
uses male, female or futanari. Specify `fallback_gender` as male or female for
futanari. Optional `nsfw`, `romanceable`, `can_die` and `stats` control the
new actor. Defaults are an adult male/female draw, false, true, false and the
standard generated shopkeeper combat profile respectively. Explicit stats use
the existing character stats contract.

For procedural allocation, include `owner_generator` role/town metadata on
existing owned shops too so authored owners count toward the six-per-type
per-town/city capacity. Distinct shops require distinct owner NPCs. An existing
owner keeps their full identity and current state. Their explicitly authored
`shop_owner_category` controls selection for category-dependent requests.
Missing category remains unassigned and still occupies capacity. Shop metadata
never changes an established owner's category. A job can use the exact existing
shop owner ID through its `client_npc_id`.

Character-shop items should be minimal and reference `future_cast.items` by
`character_id`; do not duplicate full character definitions inside shop items.
Use `price`, `locked`, structured `requirements`, and optional
`unlock_reason` and `on_purchase_objective`. `purchased`, `purchase_count`, and
`removed` are runtime fields; do not author them as starting story state.
`on_purchase_objective` is the only approved field name. `purchase_story`,
`purchase_objective`, and `purchase_story_objective` are invalid and cause
validation failure. When the character is
purchased, EmberAdventures starts that objective and selects it unless a locked
urgent objective is currently active. Locked character-shop cards remain
visible but show only the character name, a generic locked image, and the visible
unlock requirement/reason; they do not show the real image, details, or price.
Requirements and affordability do not make an otherwise visible character
secret: the shop shows their details, price, and exact unmet status. Use explicit
`locked: true` only when the real image/details/price must remain hidden. A
character shop must set both `purchase_verb` and `purchase_completed_verb`.
These are arbitrary author-provided display strings, not enums. For example,
`purchase_verb: "Recruit"` and `purchase_completed_verb: "recruited"`, or
`purchase_verb: "Contract"` and `purchase_completed_verb: "contracted"`.
EmberAdventures never guesses either word from the shop title, subtype, or other
prose. It may set `post_purchase_presence` to
`"current_scene"` (the default) or `"roster"`; use `"roster"` only when the
character should be owned but should not physically enter the current scene.

Service listings must also define `purchase_opening` with a non-empty authored
`dialogue` string. This is the character's immediate, deterministic greeting
after the player pays or books the service. It may also include an optional
`guidance` string, hidden from the player, that tells the next AI scene reply
how the character should acknowledge the payment and begin the service. Keep
the greeting short and in the character's voice; put scene movement or
additional action in `guidance` rather than making the authored line narrate
the whole encounter. Acquisition listings do not require this field because
they add the character to the party instead of starting a booked service
scene.

Character shops support two purchase behaviors through `purchase_mode`:

- `"acquire"` is the default. It is one-time, adds the character to the owned
  roster, marks the future-cast entry joined, and uses
  `post_purchase_presence`.
- `"service"` charges the price while keeping the character as an NPC. Set
  `repeatable: true` for bookings that may be purchased repeatedly. Each
  successful purchase increments runtime `purchase_count`, places the character
  in the current scene as an NPC, and starts `on_purchase_objective` when that
  objective has not already completed. It never adds the character to
  `state.characters`, the party roster, or party scene presence.

Set `purchase_mode` and `repeatable` on the shop when all listings share the
behavior, or override either field on an individual item. Never make an
`"acquire"` listing repeatable. A service character can later be recruited only
through an explicit objective reward such as
`promote_future_character_to_party`; paying for a service never implies
recruitment.

To remove a character from a shop when a story event makes the listing
unavailable, use this objective reward:

```json
{
  "type": "remove_character_shop_listing",
  "shop_id": "stable-character-shop-id",
  "character_id": "stable-future-character-id"
}
```

The reward is idempotent. It hides that exact listing and blocks later
purchases without deleting the character, NPC record, relationship, or
objective state.

The shop owner and purchasable/talkable characters must be real full
character/NPC definitions in `future_cast`, not labels like `shopkeeper` or
`worried baker`. Apply the same rule to story shops, job boards, slave markets,
companion shops, auctions, guild counters, and generated-job role pools. Owners,
clients, witnesses, rivals, purchasable characters, and other talkable people
need proper names, roles, personalities, speech styles, outfits, appearances,
and durable facts. Reference those definitions from `future_cast` and NPC
placement; never duplicate full character data inside shop or job records.

Scale depth to importance rather than reducing people to placeholders:

- major or fixed companions and important owners usually need 6-10 concrete
  durable facts;
- ordinary purchasable or talkable stock characters usually need 3-5 concrete
  durable facts plus a specific role, species/variant, appearance, outfit,
  personality, speech style, intended stock placement, any known unlock
  requirement, and a post-purchase or post-introduction hook;
- generated job-role NPCs may be shorter, but still need a proper name, concrete
  appearance, outfit, personality, speech style, and one reusable scene hook.

Large stock pools should not make hundreds of entries main-character length,
but every entry must remain distinct enough to inspect, talk to, acquire or
recruit when applicable, remember, and use in scenes.

When a character shop has a story-specific secondary cost or state effect whose
magnitude comes from each purchasable character, define that behavior once in
`state.character_shop_cost_templates` and put the source values in the
character's `full_character.stats`. Reference the template from the shop with
`cost_template_id`. Never duplicate those stat values on individual shop
items, and never expect the engine to understand story-specific concepts such as
capacity, influence, or command points.

```json
{
  "character_shop_cost_templates": {
    "pact-bond": {
      "type": "stat",
      "costs": [
        {
          "label": "Available Pact Capacity",
          "available_expression": {
            "initial": { "path": ["story_inventory", "pact_capacity"] },
            "operations": [
              {
                "operation": "subtract",
                "operand": { "path": ["story_inventory", "pact_used"] }
              }
            ]
          },
          "op": ">=",
          "required_stat": "pack_capacity_cost"
        }
      ],
      "effects": [
        {
          "label": "Pact Capacity used",
          "operation": "add",
          "field_path": ["story_inventory", "pact_used"],
          "value_stat": "pack_capacity_cost"
        },
        {
          "label": "Pact Capacity added",
          "operation": "add",
          "field_path": ["story_inventory", "pact_capacity"],
          "value_stat": "pack_capacity_return"
        }
      ]
    }
  },
  "story_shops": {
    "bond-market": {
      "type": "character",
      "cost_template_id": "pact-bond"
    }
  }
}
```

A `type: "stat"` template evaluates every `costs[]` entry against the
selected character before applying anything. `available_expression` uses the
normal exact numeric-expression grammar. `required_stat` names a numeric key
in that character's `stats`. Each `effects[]` entry applies
`add`, `subtract`, `multiply`, or `divide` to its story-state
`field_path`, using the selected character stat named by `value_stat`.
Currency, ordinary requirements, all stat costs, all stat effects, character
acquisition, and `on_purchase_objective` startup are one atomic transaction.
A return effect can never fund its own upfront cost because every cost is
checked before any effect is applied.

Use this only for reusable per-character stat-derived costs or effects. Keep
ordinary listing-specific currency differences in `price`, and omit
`cost_template_id` entirely when a character shop does not need this feature.
The engine does not automatically reverse these effects when a character
leaves. If a story supports release, loss, or resale, author that behavior
explicitly with objective/reward templates.


General item shops use `type: "general"`. Every listing contains a stable `id`,
optional finite `quantity` (`null` or omitted means unlimited), optional
requirements/lock fields, and an `item` using the normal story-inventory item
shape. A listing may also contain `rewards`, using the exact same reward array,
reward-bundle references, reward-template invocations, validation rules, and
deterministic effects as an objective. EmberAdventures applies those rewards on
every successful unit purchase, after granting the listing's normal `item`.
Use purchase rewards for additional items, player or character known facts,
story-inventory changes, relationship/state changes, objective transitions,
images, or any other supported objective reward. The listed `item` is always
granted separately; do not repeat it in `rewards` unless the purchase is
intentionally supposed to grant another copy. An additional story-inventory
item reward uses `{ "type": "add_story_item", "item": { ...normal story-inventory item... } }`;
keep the reward discriminator separate from the nested item's own `type`.
The item's positive numeric
`value` is its underlying value and the exact
amount a buying shop pays per unit. The shop's `markup` is a number of at least
`1`; EmberAdventures charges `ceil(item.value * shop.markup)` when selling the
item. Use a markup near `1` for inexpensive low-class merchants and a larger
markup for prestigious or exploitative merchants. Higher-class shops should
also carry appropriately valuable, rare, or high-quality stock. Do not author a
separate listing `price`; derive retail prices consistently from value and
markup. Use `buying: { "enabled": true, "quest_items_rejected": true }` when
the shop buys ordinary inventory. Quest items remain unsellable.

Clothing shops use `type: "clothing"`. Each listing contains `id`, `title`,
positive integer `price`, optional requirements/lock fields, and one complete `outfit` using the
normal character outfit schema. Purchasing copies that complete preset into the
selected player or owned party character's `outfits`; it does not equip it.
Every newly authored shop outfit requires boolean `nsfw`. NSFW shop outfits are
hidden, cannot be purchased, and do not queue images when the active profile is
SFW or absent. Do not rely only on an objective or shop-level NSFW gate.
Catalog outfits may be purchased independently for multiple characters, but the
same character cannot purchase the same listing twice. Do not represent every
shirt, shoe, or accessory as a separate inventory item unless a future feature
explicitly adds mix-and-match clothing commerce.

Job boards use `type: "job"`, `visible_count`, and
`generic_jobs_enabled: true` when EmberAdventures should generate built-in rotating
jobs. Generated jobs are engine-authored, not AI-authored. Do not prefill
`story_job_offers`, `active_generated_jobs`, or `story_generated_npc_pool` in a
normal story template unless creating a deliberate starting active job. When a
generated job is accepted, EmberAdventures creates side objectives; the first is a
one-option choice to start the job, and the final is a one-option choice to
turn it in. Jobs never expire, can be abandoned, and completion clears generated
offers on all boards.

Story-specific jobs belong in `story_shops[board_id].items[]`. These are
curated authored jobs, not randomized jobs. Use this exact item schema unless a
newer bundled schema contract says otherwise:

- `id`: stable unique job item id;
- `title`: player-facing job title;
- `summary`: player-facing hook;
- `genres`: approved story genre labels required for the job to appear;
- `nsfw`: boolean; true only when the job itself is adult/NSFW and should be hidden in SFW mode;
- `rank`: nonnegative difficulty/rank number when useful;
- `requirements`: structured requirements array;
- `reward_coins`: number, or `0` when no money reward;
- `reward_xp`: number, or `0` when no XP/rank reward;
- `reward_items`: optional story-inventory item rewards;
- `client_npc_id`: optional future-cast id for the client/contact;
- `start_location`: optional location override object for the job start, using
  normal `state.location`-style keys such as `world`, `region`,
  `settlement_name`, `district`, and `specific_place`. Do not use a string
  location id here; omit `start_location` when the job should start at the job
  board's own location;
- `completion_criteria`: concrete completion check;
- `completion_instruction`: concrete narrator/objective guidance.

Do not use alternate fields such as `quest_id`, generic `reward`, `purchased`,
`on_accept_objective`, or free-text reward blobs for story jobs. The current
EmberAdventures job-board accept path does not consume `on_accept_objective`; it
creates its own generated side-objective flow from the job item's summary,
completion criteria, completion instruction, start location, optional client,
and rewards. Do not write a story job as if it will complete a separate
`linked` authored objective chain; the accepted job's own generated objective
is the playable job unless you model that content as a normal objective chain
outside the job board. If an authored objective chain must exist, make it a
normal objective chain unlocked by story progression, not a job-board item that
relies on `on_accept_objective` or text references to linked objectives.
A story job is listed only when every label in its `genres` array is present in
the story's `genres`; use this to keep genre-mixed stories precise. Story jobs
are one-time content: after acceptance/completion they should not rotate back
in like generic jobs. Use requirements such as
`story_inventory.adventurer_rank >= 1`, `story_inventory.credits >= 200`, or a
story-specific inventory flag to control when they unlock. Do not write job or
shop requirements as path/list scans against `story_rules`; use
`{ "type": "story_rule", "id": "rule-id" }` for rule gates, or mirror unlock
gates into `story_inventory` flags/lists with objective rewards when the UI
needs a resource/list requirement.

Generic jobs are EmberAdventures's fallback rotating jobs. They have genre labels on
the engine pool entries and are eligible only when all of those labels are
present in the active story. Use `generic_jobs_enabled: true` for boards that
should provide repeatable money/XP work beyond the curated story jobs, and
`false` for boards that should show only authored story jobs. New built-in offers
choose an eligible job type with equal weight, then a variant within that type;
more variants do not give a type more selection slots. Exact current rank,
story genres and the active SFW/NSFW setting still gate eligibility. Dictionary
text is selected once for the saved offer and reused consistently; a missing or
empty text dictionary is an error, never a guessed key name. Internal built-in
text pools are not an authored objective-tree or text-dictionary schema.

Guild XP is cumulative. The engine promotes at these thresholds: rank0 Copper
0XP, rank1 Bronze2XP, rank2 Iron7XP, rank3 Silver16XP, rank4 Gold35XP,
rank5 Platinum85XP, rank6 Mithril250XP, rank7 Adamantite500XP. An explicit
higher authored rank is not demoted, and these thresholds do not rewrite an
authored job's XP payout. Do not promise rotating Platinum/Mithril jobs until
that separate pool extension is implemented; Adamantite work is story-authored.

Structured requirements use:

```json
{ "path": "story_inventory.coins", "op": ">=", "value": 120 }
```

Supported operators are `>=`, `>`, `<=`, `<`, `==`, `!=`, `truthy`, `falsy`,
`includes`, and `not_includes`. Choice and shop UIs show requirements directly,
so write them as player-understandable resource/stat checks such as
`story_inventory.credits >= 500` or `Companion Name trust >= 6`.

## Field Purpose And Process-Leakage Rules

Use the authoritative `Field Purpose Standard`, `Creator Instructions Are Not
Story Data`, and `state.meta` sections below. They contain the complete rules
for player-visible fields, hidden runtime guidance, blank defaults, creator
instruction leakage, and `story_guidance`.

## Public Metadata

Use the authoritative `storyTemplate Fields`, `state.meta`, `Public Hosting
Metadata`, and `Story Image Rules` sections below. They contain the complete
source, creation-tool, genre, kink-tag, NSFW, loli, image-model, title-card,
creator-identity, and publishing contract.

## Original Story Rules

- Do not assume NSFW, romance, slavery, hypersexual tone, or kink premise unless
  the user requested it.
- Invent story-specific conflict and choices; avoid generic "chosen hero" shape
  unless requested.
- Keep the first session playable: the player should immediately understand
  where they are, who is present, what pressure exists, and what they can do.
- Use original named people. When the skill invents a new player, party member,
  NPC, or future-cast person, generate a first and last name by default. Preserve
  any user-specified/manual name exactly, including one-word or nonstandard
  names, unless the user asks to rename it.
- Do not make a story require a specific named player character unless the user
  explicitly asks for a fixed protagonist. EmberAdventures may allow the user to pick
  any character as the player. In objectives, verifier text, hidden rules,
  story rules, and player-facing prose, prefer role-neutral wording such as
  `the player`, `the protagonist`, or `the human scavenger` instead of a
  hardcoded fallback name. If the story includes a default/fallback `state.player`,
  that name is only the default option and must not be required by the story
  logic.
- Do not use titles, jobs, groups, or descriptions as generated names or speaker
  identities, such as `Guard`, `Guild Clerk`, `woman`, `traveler`, `bandits`, or
  `shopkeeper`.
- Use `EmberAdventures Character` for invented players, party members, NPCs,
  and future cast.
- Vary adult ages intentionally according to role, species, authority, and story
  position. Do not cluster everyone around one generic age.
- Keep clothing precise. Clothing slots are item slots; avoid ambiguous values
  like "adventuring clothes or maid outfit depending on scene." Create separate
  outfits when needed.
- Every outfit must describe the complete set of clothing the character normally
  wears in that look. Include applicable underwear, bra/support layer,
  undershirt, outer top, bottom, socks/hosiery, footwear, and other real layers.
  Do not provide only an outer garment when that would make partial undressing
  impossible without making the character immediately naked. Omit a layer only
  when the outfit intentionally does not include it.
- Default outfit depth for original story characters:
  - SFW story characters should usually have 3-5 tailored outfits each.
  - NSFW story characters should usually have 13-15 tailored outfits each, with
    at least 10 clearly NSFW/adult outfits when the character is an adult and
    not loli/underage.
  - Preserve the starting/default outfit as the first outfit when updating an
    existing story, then add story-specific alternatives suited to that
    character's role, species, body, personality, genre, and setting.
  - Do not add NSFW outfits to loli, underage, minor-coded, or non-adult
    characters even when the story itself is NSFW.
  - Avoid identical wardrobe dumps across the cast. A warrior, clerk, noble,
    monster, robot, ghost, student, shop owner, and love interest should not all
    receive the same outfit names or clothing text unless the uniformity is
    intentional in-world.
  - For one-piece garments that cover top and bottom, use both a top/body slot
    and a bottom coverage slot. Example: `shirt`: "one-piece black fishnet
    teddy bodysuit" and `underwear`: "same teddy covers her groin with a
    high-cut panty shape".
- Include optional side objectives and branches by default when they improve
  play, tone, character interaction, discovery, romance, comedy, combat,
  investigation, shopping, training, downtime, or problem solving.

## Spoiler And Visibility Rules

Do not expose future party members, NPCs, villains, locations, factions,
relationships, betrayals, bosses, twists, objective rewards, or planned story
events in the opening scene unless they are present, known, and actionable at
that moment.

Use hidden objectives and `future_cast` for full-story knowledge. Before
finalizing, run a hidden-future visibility pass over:

- opening messages;
- story description;
- visible objective titles/summaries;
- map summaries/details;
- current NPC fields;
- party member fields visible in library/editor UIs;
- story metadata visible in public/library cards.

Visible text should contain only what the protagonist/player could reasonably
know at the starting point. Future names, future party roles, locked locations,
hidden rewards, required relationship outcomes, future villains, and major twists
belong in hidden future cast/objectives/rewards until play reaches them.

If a present NPC has a real stored name that the player should not know yet,
store the real name in `npc_directory` for voice/state stability, but add
`player_known_name: false` and a concise `player_facing_label` such as
`damaged robot torso`, `masked prisoner`, or `unknown knight`. Until the reveal,
opening text, visible objective titles/summaries, and auto-player-facing
summaries should use the label/role/pronouns, not the hidden real name. Hidden
speaker tags may still use the stored name only to route voices, but the visible
prose must establish what the player actually knows.

## Opening Rules

The first assistant message should be vivid and immediately playable, not a lore
dump. It should normally introduce only:

- the immediate sensory situation;
- one present NPC max, unless a second person is essential and actionable;
- one visible problem;
- one concrete player action.

The opening may establish unavoidable starting circumstances, but it must
preserve player agency. Do not write the player as already having made a
meaningful choice, agreed to a relationship, submitted, attacked, flirted,
forgiven someone, accepted a job, or committed to a moral path unless that is
the explicit requested starting premise.

Use grounded, actionable details before abstract setting mechanics. Avoid
front-loading councils, prophecies, cosmic systems, charters, political
contracts, or hidden frameworks unless that concept is the single visible
problem the player can act on immediately.

End on an in-world situation or action opportunity, not a meta prompt. Never end
the opening with `What do you do?`, `How do you respond?`, `What happens next?`,
or another question that merely reminds the player that the game is interactive.

For comedy, build humor from character personalities, clumsiness,
misunderstandings, timing, social consequences, and concrete situations. Do not
make buildings, furniture, paperwork, the universe, or an unexplained game-like
system constantly watch, judge, chant at, or react to the player unless that is
the explicit premise. Do not let a throwaway joke become the world's dominant
mechanic or the AI's repeated fixation.

For surprise, danger, first-contact, or mystery openings, write the opening
objective and early completion instructions so an automatic player turn reacts
believably from limited knowledge. Do not encourage perfect diagnosis, instant
technical solutions, hidden-name usage, or optimal plot advancement unless the
player has already visibly earned that knowledge.

## Objective Rules

### Objective Behavior Names

Use the following names when planning, reviewing, or discussing objectives.
These are design names, not additional JSON `type` values. The serialized
objective behavior is still determined by its control fields, output
collection, and terminal fields.

First choose one completion family:

| Completion family | Serialized settings | How it works | Use it when |
| --- | --- | --- | --- |
| **Player Action** | `completion_control: "player"` | The verifier checks after a player-authored turn. The objective completes when the player's deliberate action, attempt, commitment, or chosen scene-ending action satisfies its one completion condition. | The player must personally do, attempt, choose, inspect, travel, sleep, leave, or otherwise decide when to advance. |
| **Player Choice** | `completion_control: "choice"` plus `choices[]` | EmberAdventures presents authored options. Selecting an eligible option completes the objective and resolves that output without an AI completion check. | The player must choose from explicit options, including a confirmation, exact spoken response, bargain, route, allegiance, boundary, or ending decision. |
| **AI Scene** | `completion_control: "ai"` without `evaluate_ai_on_activation` | The game checks whether the player turn gives the narrator enough reason to finish the objective, then uses later progress checks while the scene continues. | Another character, the narrator, combat, or the world must provide or decide the actual result after the player engages. |
| **Immediate AI** | `completion_control: "ai"` plus `evaluate_ai_on_activation: true` | The game makes one immediate AI completion decision when that activation is reached. If the answer is no, the objective remains available and follows the ordinary AI Scene flow on later turns. | A just-finished scene must be assessed immediately from recent behavior or context, but judgment still requires AI interpretation. |
| **Automatic Transition** | `completion_control: "reward_only"` plus `requirement_check_only: true` | The game makes no AI call. Once reached and its structured Completion Requirements are met, it resolves immediately, applies its selected output, and continues the dependency cascade. | A hidden convergence, deterministic gate, bookkeeping transition, automatic reward step, or state-based route should happen without narration or AI judgment. |
| **Interactive Cutscene** | `completion_control: "cutscene"` | The next completed narrator reply delivers one authored `completion_instruction`, then progression and rewards commit without a completion classifier. | A fixed authored event proceeds while the player can ask questions or react. Omit completion criteria and use one unconditional output; see [the cutscene contract](interactive-cutscenes.md). |

Then choose one output shape:

| Output shape | Meaning |
| --- | --- |
| **Linear** | One output. It applies one result and links to one next node. |
| **Branch** | Multiple outputs. Player Choice presents them; AI Scene and Immediate AI classify among eligible private routes; Player Action and Automatic Transition check deterministic outputs in displayed priority order and use the first eligible one. |
| **Ending output** | An output omits its destination and sets `ending_type` to `"freeplay"`, `"ending"`, or `"game_over"`. Different outputs from one objective may end differently. |

Combine the family and shape to name every useful behavior:

| Settings | Preferred name | Typical use |
| --- | --- | --- |
| Player Action + Linear | **Player Action Objective** | Use an object, travel somewhere, attempt a task, go to sleep, or deliberately end free time. |
| Player Action + Branch | **Player-Gated Route** | The player performs one action, then stored state deterministically selects the first eligible consequence. |
| Player Action + Finale | **Player Action Finale** | The player's deliberate final action ends the route, enters freeplay, ends the adventure, or causes game over. |
| Player Choice + one option | **Player Confirmation** | Require one explicit confirmation or exact player response before continuing. |
| Player Choice + multiple options | **Player Branch Choice** | Present two or more meaningful authored options with visible eligibility requirements. |
| AI Scene + Linear | **AI Scene Objective** | An NPC explains, teaches, escorts, accepts, refuses, or otherwise supplies the scene's result. |
| AI Scene + multiple outputs | **AI Outcome Branch** | The scene resolves through AI judgment, then eligible private route criteria choose the outcome. |
| AI Scene + Finale | **AI Scene Finale** | The narrator/world resolves the final scene and then ends the route. |
| Immediate AI + Linear | **Immediate AI Assessment** | Judge a completed conversation, negotiation, date, interview, battle, or other established scene and continue once. |
| Immediate AI + multiple outputs | **Immediate AI Outcome Branch** | Immediately classify a completed scene into one of several eligible hidden outcomes. |
| Immediate AI + Finale | **Immediate AI Finale** | Immediately judge whether an already-established final situation ends the adventure. |
| Automatic Transition + Linear | **Automatic Transition** | Apply deterministic rewards or join branches, then continue without an AI call. |
| Automatic Transition + multiple outputs | **Automatic Router** | Choose the first eligible deterministic output, with an unrestricted fallback last when needed. |
| Automatic Transition + Finale | **Automatic Finale** | End a route automatically when its structured requirements become true. |

Player Choice with no output is invalid because it has no option to present.
To let a choice end a route, put `ending_type` on that exact choice output
instead of routing through a separate ending node.

Use modifiers without inventing more schema types:

- Prefix **Side** when `type: "side"`; otherwise the objective is main story.
- Append **with Dialogue** when an output has authored `dialogue_lines`.
- Call a cyclic family **Recurring** when save-time graph analysis infers that
  it can activate again. Do not author a repeatable flag.
- Describe reward-bearing nodes normally; rewards do not create another
  objective family.

Examples of useful combined names are `Side AI Scene Objective with Dialogue`,
`Player Branch Choice`, `Immediate AI Outcome Branch`, `Automatic Router`, and
`Player Action Finale`. Use these names in plans and reviews so the behavior is
clear without treating old storage fields as separate incompatible objective
systems.

### Unified Objective Decision Order

Design each node in this order:

1. Choose Main or Side.
2. Choose Player or AI control.
3. Under Player, decide whether this is a normal Player Action or a Player
   Choice. Under AI, decide whether it is a normal AI Scene, Immediate AI, or
   Automatic Transition.
4. Choose Linear, Branch, or Finale.
5. Define incoming graph groups. Transitions inside one target input group are
   AND requirements; different groups are OR alternatives. The first objective
   is the one story start and needs no incoming group.
6. Add structured Completion Requirements only for resources, state, or other
   completed objectives that must remain true before this reached objective can
   progress.
7. Write one player-facing title, one useful summary, required non-empty hidden
   `while_active_guidance`, and exactly one simple completion condition unless
   the objective is Player Choice or Automatic Transition. Automatic
   Transitions still require `while_active_guidance` even though they make no AI
   call; use it to document the intended active behavior of the transition.
8. Configure each output's completion instruction, optional exact dialogue,
   rewards or reusable reward references, optional travel destination,
   eligibility requirements, and next node.

Prefer explicit output transitions when the source objective chooses or narrates
a distinct route. Use `requires` when the target objective naturally declares
one or more prerequisite objectives and no distinct source output is needed.
Do not duplicate the same dependency as both an output transition and
`requires`. When both are present for different reasons, every `requires` entry
must complete and one explicit incoming transition group must also be satisfied.

Incoming graph groups, Completion Requirements, Completion Conditions, and
Output Requirements answer different questions:

- **Incoming groups:** Has the story reached this node? The node and its unlock
  conditions remain hidden until one incoming OR group is satisfied.
- **Completion Requirements:** Is the reached objective currently possible?
  Unmet requirements keep it visible but unavailable/red and prevent selection,
  completion checks, AI completion calls, routing, and rewards.
- **Completion Condition:** What one player action or scene result completes the
  active objective?
- **Output Requirements:** Which result is eligible after completion? All
  requirements inside one output are AND conditions; multiple outputs are OR
  alternatives.

Use objective-completed requirements inside Completion Requirements when a
non-incoming objective must also be finished. Do not turn inventory, money,
relationship, location, or other state requirements into graph inputs.

### Recommended Combinations

- **Linear story beat:** Chain Player Action Objectives and AI Scene Objectives
  according to who controls each result. Keep each completion condition to one
  beat.
- **Character-led explanation:** Use an AI Scene Objective with Dialogue. For a
  long explanation, chain several short dialogue-bearing AI Scene Objectives;
  the first can complete when the player speaks to the character, and later
  ones when the player responds, listens, asks a relevant follow-up, or observes
  a demonstration.
- **Open-ended social or downtime scene:** Use a Player Action Objective whose
  completion condition is one explicit player-controlled exit such as leaving,
  going to sleep, or ending the conversation. Put optional activities in the
  summary and hidden pacing advice in `while_active_guidance`; do not make them
  a completion checklist.
- **Visible authored decision:** Use a Player Branch Choice. Put visible costs
  and eligibility in each output's requirements and keep hidden consequences in
  rewards and completion instructions.
- **State-based consequence:** Use a Player-Gated Route or Automatic Router.
  Order outputs from highest priority to lowest and keep the unrestricted
  fallback last.
- **Natural-language judgment:** Use an AI Outcome Branch when the active scene
  itself must finish before classification. Use an Immediate AI Outcome Branch
  after a separate player-paced scene when the completed interaction should be
  judged once without extending or replaying it.
- **Parallel convergence:** Assign every required incoming transition to one
  shared input group, then use an Automatic Transition. For alternative ways
  to reach the same node, assign each alternative to a different input group.
- **Resource-gated action:** Put the resource in Completion Requirements when
  the entire objective cannot proceed without it. Put it in Output Requirements
  when only one result spends or needs it. Every bounded-resource cost reward
  needs a matching output requirement proving the cost can be paid.
- **Shared fixed effects:** Define one `state.reward_bundles` entry and invoke
  it from each output with `apply_reward_bundle`.
- **Shared parameterized behavior:** Define one typed
  `state.reward_templates` entry and invoke it with guided typed arguments via
  `apply_reward_template`. Use templates only when the same reward behavior is
  reused with different characters or state targets.
- **Ending:** Use the appropriate Player Action Finale, AI Scene Finale,
  Immediate AI Finale, or Automatic Finale. Main finales explicitly choose
  freeplay, ending, or game over; side finales end only the side route.

- Use one active opening objective.
- Before writing the chain, decide whether the story is Telltale-style
  branching or simpler linear/mostly-linear. Telltale-style stories should use
  multiple direct choice clusters, branch-specific rewards, hidden outcome
  logic, and distinct endings when the premise supports them. Linear
  stories should use bridge objectives and occasional real choices, not fake
  menu choices that do not matter. If the user asks for multiple endings, many
  choice objectives, or a Telltale-style structure, aim for roughly 30-40%
  `completion_control: "choice"` objectives. Not every objective should be a
  choice objective; more than half is usually too many unless explicitly
  requested.
- Hidden main objectives should form a coherent story milestone chain. Every
  non-terminal main objective must route somewhere intentionally through one or
  more output transitions. If a main objective is an ending, death, or bad
  ending, make that terminal status explicit in the title/summary and use
  deterministic ending rewards such as `kill_character` with
  `ignore_can_die: true` when appropriate. Do not leave a non-final main
  objective with no dependent objective, no `next_objectives`, and no terminal
  reward; that makes EmberAdventures fall back to objective picking instead of
  authored pacing.
- Side objectives use `type: "side"`. `kind` is not an approved objective field
  and causes validation failure.
- An objective may own an optional `abandonment` policy for one explicitly
  connected quest scope. See [objective-abandonment.md](objective-abandonment.md)
  for the exact fields, consequences and resume/restart/checkpoint/permanent
  behavior. Withdrawal preserves world history and earned rewards; it is not
  objective success or guaranteed escape.
- Every nonterminal output destination and `target_input_group_id` must be
  valid.
- `requires` is a first-class objective input list. Every listed objective id
  is an AND prerequisite: the target becomes eligible only after all listed
  objectives complete. Use it when an existing story graph is naturally
  authored from the target back to its prerequisites; do not duplicate the
  same edge in `next_objectives` unless a distinct output route is needed.
- An objective with no explicit output may use its own non-empty
  `completion_instruction` when later objectives reference it through
  `requires`. The engine applies that instruction when the objective completes
  and follows the inverse dependency edge. Output-level instructions remain
  preferred when the source chooses among distinct outputs.
- Objective rewards must reference valid future-cast ids when they introduce
  people.
- `introduce_future_character.scene_presence` is required and must be exactly
  `"active"`, `"nearby"`, or `"none"`. `"active"` adds the introduced NPC to
  the current scene; `"nearby"` places the NPC at the specified location but
  outside the active scene; `"none"` does not make the NPC scene-active.
- Explicitly introduce a locked future-cast character at their first physical
  appearance before a reward adds them to a scene-reference list. Merely
  declaring them in future cast, mentioning them in completion prose, or using
  a presentation-reference token does not activate their runtime identity.
  A later `introduce_future_character` reward for an encountered NPC relocates
  that same character and preserves their current state and portraits; it does
  not recreate their original definition. Use explicit change/replacement
  rewards when an authored scene intentionally changes their state.
- Objectives must not have step fields.
- Player Action, AI Scene, and Immediate AI objectives need one verifier
  condition. Every output needs a safe authored completion instruction.
- Objective titles are the primary player-facing instruction. Read each title
  alone and make sure the player knows the intended direction.
- Choose `completion_control` based on who must provide the objective's actual
  result, not merely on whether the player acts first. Use `"player"` when a
  deliberate player action, attempt, commitment, or self-directed activity is
  itself the result, or when the player must retain control over when the scene
  advances. Common suggestions include using an object, attempting an action,
  choosing or refusing a commitment, travelling under the player's own
  direction, going to sleep, ending free time, or asking a question when asking
  it itself is the goal. Use `"ai"` when the player only needs to engage or
  cooperate and another character or the active scene must provide the actual
  result. Common suggestions include receiving an explanation or lesson,
  learning information from someone, following an established guide to a
  destination, being introduced to a group, attending a meeting that reaches a
  result, or waiting for a character/world response. A character merely being
  present does not make an objective AI-controlled; use AI control when that
  character's explanation, agreement, response, escort, teaching, or decision
  is required for completion. Use `"choice"` for direct forced player choices
  that EmberAdventures should present in a choice menu and complete immediately
  without AI verification.
- Completion and hidden routing are separate. An objective may use player or AI
  completion plus `route_control: "ai"`; once completion is proven, the same
  verifier classifies the full scene into exactly one private authored outcome.
  Outcome-route `requirements` are hard eligibility filters. Only eligible
  routes are shown to the classifier. Always include exactly one
  `fallback: true` route with no requirements so completed
  objectives always have a valid ambiguous/neutral/default route.
- EmberAdventures checks one selected objective at a time. Do not design chains that
  expect one player message to complete multiple consecutive objectives. Use
  larger scene-scale objectives or bridge objectives instead.
- Player-controlled objectives are checked after player-authored turns.
  Standard AI-controlled objectives are checked before the narrator reply on a
  normal player turn, then receive a post-reply progress-only check. Use an
  Immediate AI objective when one additional decision should happen as soon as
  the node is reached; if that decision is no, it remains an ordinary AI Scene
  objective on later turns.
- Do not use generic completion text. Never write criteria like
  `Return yes only when the player completes: {title}` or instructions like
  `Resolve the immediate outcome of {title} and move to the next objective`.
  Also reject variants such as `Return yes only when the player completes or
  survives...`, `Return yes only when the player completes, submits, or
  receives...`, or `Return yes only when the player clearly takes action toward
  this goal...`. Criteria must name the actual scene result, acceptance,
  purchase, reveal, survival outcome, conversation result, or decision that
  completes the objective.
- Player-controlled objective criteria must name the specific player action,
  attempt, commitment, self-directed travel, inspection, purchase, choice, or
  player-timed advancement that completes the objective. Do not use player
  control merely because the player starts a conversation: if an NPC must give
  the answer, lesson, acceptance, escort arrival, or other required result, use
  AI control instead.
- AI-controlled objective criteria must name the specific narrator/world state
  that counts as resolved, such as an NPC delivering the needed explanation, an
  escorted arrival occurring, a meeting reaching its result, enemies being
  defeated/routed/captured, a duel decided, a trial concluded, a reveal
  delivered, or a danger ended. AI objective criteria must not say `player
  completes`.
- Completion instructions must describe the concrete immediate outcome,
  consequence, reveal, transition, or future-cast introduction for that exact
  story beat. They are hidden narrator guidance, not a duplicate of the title.
- When a named character is present but their identity is not yet player-known,
  player-facing objective titles/summaries and player-controlled criteria should
  use what the player can perceive, such as `the damaged machine`, `the masked
  stranger`, or `the sealed voice`. Put the real stored name only in hidden
  rewards/instructions that truly need it.
- Do not create passive external-event objectives such as `Hear the Alarm` when
  the event can be revealed in the previous output's completion instruction.
- Never create meta objectives such as `Do Not Force a Fake Ending`.
- Player-facing objective titles/summaries must not spoil locked future cast,
  future locations, objective rewards, private AI notes, or required outcomes.
- Serious stories should include memorable side content unless the user asks for
  a minimal story.
- Side objectives should usually have real consequences, not only prose. Prefer
  giving them at least one appropriate reward such as an item, story rule,
  relationship/stat change, location unlock, hidden lead, image trigger, or
  scene/list update.
- For romance, dark romance, court intrigue, harem, companion, and relationship
  stories, include bridge objectives that build the relationship before major
  payoffs. Use `adjust_relationship` rewards for deterministic trust,
  attraction, affection, and arousal changes. `preset: "all"` changes trust,
  attraction, and affection; `preset: "all_and_arousal"` also changes arousal.
- For these story types, do not rely on romantic prose alone. Add objective
  rewards for relationship changes that must persist, and add direct choice
  clusters when the player is choosing trust, boundaries, desire, allegiance,
  a bargain, a partner, a betrayal, or an ending. If a serious romance/dark
  romance/harem/court story has zero `choice` objectives or zero
  `adjust_relationship` rewards, treat that as a failed quality pass unless
  the final notes explain a deliberate exception.
- Branch objectives should have actual branch effects. Use `exclusive_group` only for true mutually exclusive choice clusters where taking one path should lock the other path until the player rolls back to an older state snapshot. For forced menu choices, put `exclusive_group` on the one visible owner objective with `completion_control: "choice"` and internal `choices[]`; do not create one top-level objective per option. Later branch objectives should require the owner objective and rely on selected-choice story rules, state changes, or relationship changes to preserve which path was chosen. Do not use `exclusive_group` for optional content, hub tasks, parallel goals, or side branches/source milestones that can all be completed.
- For forced menu choices, create one visible owner objective with
  `completion_control: "choice"`, `selectable: true`, and a `choices` array.
  Each choice item should have `id`, `title`, `summary`, `rewards`, and
  optional `effects`. Choice `rewards` use the exact same reward contract as
  normal objective `rewards`; every state path must be a non-empty array, never
  a dot string or a bare string. For example, a choice that adds a player fact
  uses `{ "type": "add_state_list_item", "target": "Player", "field_path":
  ["known_facts"], "value": "Fact text." }`. Use choice `summary` for consequence-neutral
  clarification when the option title alone may not be enough. Do not leave
  summaries blank for major or meaningful choices unless the title is truly
  self-explanatory. Keep `effects` empty unless they only show visible
  requirements, visible costs, or visible story-inventory changes. Do not reveal
  death, failure, romance, sale, betrayal, ending, route labels, unlock labels,
  hidden recommendations, or hidden branch outcomes in the choice UI. Bad
  visible `effects` include `Bad ending route`, `Hana affection route`,
  `Unlocks Mira treatment route`, `Fail-forward dark route`, and
  `Best with first law: Truth or Freedom`. Good visible `effects` include
  `credits -80`, `Companion Name trust >= 6`, `suspicion +1`, and `requires cellar
  key`. Do not create one top-level objective per option, and do not
  hide the options in one objective's summary or notes. Good uses include
  choosing a first law, choosing which ally to trust, choosing a bargain,
  choosing a route, or choosing an ending. The owner title should name the
  decision, such as `First Contact` or `Choose Your First Law`; each choice
  title should be the actual option text, such as `Stay Hidden`, `Trust
  the companion`, or `Accept the Stranger's Bargain`.
- Use a choice owner objective whenever the story is clearly passing control to
  the player for a meaningful decision: trust/refuse, accept/reject a bargain,
  set a boundary, escalate/avoid intimacy, choose a lover/rival/faction stance,
  knock on a character's door or go to bed, spare/punish, choose a route, or
  choose an ending.
- Use timed events when the world should keep moving while the player does
  other things. Timed events are checked from the additive game clock after
  turns and reward processing. They can show player-visible game messages,
  apply normal objective rewards, introduce or change characters, start urgent
  objectives, or record story rules when a deadline passes. Use them for rescue
  windows, background faction progress, shop/job deadlines, travel pressure,
  worsening injuries, rival plans, and other pressure that should not wait
  forever for the player.
- Use `locked_until_complete: true` only for time-sensitive objectives that
  must be played through immediately once active. While locked, the player
  should not be able to switch to side objectives or clear the current
  objective. Use this for battles for a city, urgent attacks, time-critical
  rescue, irreversible confrontation, arrest, collapse, deathbed repair, or
  other moments where walking away would break the story. Do not use it for
  ordinary main-story guidance, normal tight objective chains, relationship
  scenes, political dinners, exposition, or author convenience.
- For immediate-merge choices, record the consequence in the choice rewards and
  let the next shared objective require only the choice owner. Use this for
  short relationship stance, boundary, flirt/refuse, mercy/cruelty, or tone
  choices where the story continues through the same next scene.
- For optional-with-skip choices, make one choice owner objective whose options
  include the optional scene and a skip option. Example: `Knock on the Companion's
  Door` versus `Go to Bed`. Put visible requirements such as relationship
  thresholds in option text/effects only when the player can reasonably know
  them; keep hidden trust, attraction, arousal, scene, or rule consequences in
  rewards and completion instructions. This is the preferred pattern for
  optional romance/NSFW moments when the user does not want separate side
  objectives.
- For multi-route convergence, do not use `exclusive_group` when all routes are
  valid and can be completed before a later event. Create separate route
  objectives/chains, then make the convergence objective require all route
  terminals. Use this for structures like defeating several generals before a
  boss, resolving several courts before a coronation, gathering several repair
  parts before a rebuild, or completing several trials before a throne scene.
- For fail-forward branches, avoid dead-ending the story on a bad choice unless
  the user explicitly wants hard failure. Let poor choices continue with debt,
  injury, lost resources, distrust, a harder route, a different ally reaction, or
  a worse ending path.
- For delayed callback choices, record the early decision with a story rule,
  relationship reward, state field, or story-inventory marker, then let a later
  objective or ending check that recorded consequence.
- For visible relationship-threshold choices, include locked options in the
  choice list with visible requirements/effects such as `Companion Name trust >= 6` or
  `Companion Name attraction >= 8`. Do not hide or swap the option text based on
  hidden stat checks; the game should show unmet options as unavailable.
- For resource-gated route order, expose multiple route objectives or choice
  options while making some require visible resources such as money, supplies,
  reputation, evidence, repair parts, or party trust before they can start.
- In Telltale-style stories, important choice clusters should usually have 2-4
  options and later objectives must preserve the selected path through
  branch-specific output transitions, story rules, relationship rewards,
  state-field changes, map
  changes, image rewards, or death/failure endings when appropriate. Re-merge
  branches only after the permanent consequences have been recorded.
- Use `story_inventory` for story-owned resources such as credits, parts,
  reputation, suspicion, evidence, or repair supplies when those resources
  should be modified only by objective rewards. Show only concrete resource
  effects or requirements in the choice UI, such as `credits +500` or
  `Companion Name trust >= 6`; keep hidden outcomes in rewards and completion
  instructions.
- Branch rewards should update state/rules/map/cast so the branches do not
  collapse back into identical play.
- Use deterministic rewards for permanent story changes. Examples include
  repairing or transforming a character with `set_state_field`, changing a hard
  constraint with `add_story_rule`/`remove_story_rule`, moving someone out of a
  scene with `remove_state_list_item`, introducing a pressure source with
  `introduce_future_character`, and queuing images with
  `generate_profile_image`, `generate_solo_normal_image`, or
  `generate_story_image`.
- Use `replace_character_definition` to replace one already-materialized
  character's definition with a normal future-cast source definition while
  retaining the target character's stable runtime identity, relationship
  continuity, party/location membership, and story history. The exact reward
  fields are `type`, `target_character_id`, `source_future_character_id`, and
  `reason`. The source future-cast entry is consumed by the replacement and
  must not also be introduced or promoted as a separate character. The new
  humanoid form is an ordinary `full_character`; do not create a special
  transformation character schema.
- Use `generate_profile_image` only when a change affects face, hair, arms,
  torso, chest, shoulders, or overall silhouette. Use
  `generate_solo_normal_image` for major visible changes that should appear in
  chat. Leg-only or lower-body-only changes should normally generate a solo
  normal image, not a profile image.
- `generate_solo_normal_image` may include an optional `outfit_id` belonging to
  its target. This uses that outfit only when constructing the rewarded image
  prompt. It does not equip the outfit, change active clothing, or mutate the
  character. Use a separate `equip_outfit` reward when the clothing should
  actually change in runtime state.
- `generate_solo_normal_image` may also include optional string fields
  `description` and `background`. `description` is appended as additional
  appearance and outfit guidance for the generated solo image. When it is
  non-empty, the runtime uses a character-only full-body composition and
  excludes the character's scene-derived pose, expression, state of mind,
  physical state, held items, sex position, scene action, and normal
  location/default background. Do not put scene direction, actions, poses,
  locations, or sex-position instructions in this field; use it only for what
  the character looks like and what clothing/outfit to show. `background`,
  when non-empty, explicitly replaces the normal location/background. It may
  be supplied with `description` when a deliberate background is wanted. A
  blank optional field is equivalent to omitting it.
- Use `generate_story_image` for authored non-character images that strengthen
  the story: important objects, locked doors, clues, symbols, maps, memory
  objects, locations, horror reveals, jump scares, ritual scenes, and other
  one-time visual beats. Include a stable `id`. Supply either an exact prompt
  for runtime generation or a nested hosted `image` slot to reveal existing
  art without generation. This is not a title-card image and does not need a
  character target.
- Use `story_rules` as runtime law, not lore notes. Good rules are active
  constraints such as locked romance gates, current danger rules, repair
  boundaries, active pursuit, or body-state restrictions. Add and remove them
  through objective rewards as the story changes.
  Never add story rules that describe future engine work, schema conversion,
  temporary compatibility, pending implementation, or what a later maintainer
  should do. Those are creator notes, not runtime story law.

## Character And Scene Rules

- `characters` is the saved-state schema key for party members. AI-facing and
  player-facing text should call them `party members`.
- `npc_directory` holds NPCs and must use the current nested runtime shape:
  `npc_directory.locations.<stable-location-id>.characters.<npc name>`. Do not use
  the old flat shape `npc_directory.<npc name>`. The flat shape is invalid and
  causes validation failure.
- `players` is optional and only for start-of-game playable character select.
  If used, `state.player` remains a fallback/default copy of the first option.
- Unselected player options are not present in the scene or party.
- Use `state.players` when the premise does not require one locked protagonist
  and player choice would improve the story. Every player option must support
  the same objective logic. Opening text, objectives, story rules, and hidden
  guidance must use role-neutral wording such as `the player`, `the repairer`,
  or `the protagonist` unless the story is intentionally locked to one named
  protagonist.
- Objectives and hidden story rules must be written to work with whichever
  player character the user selects. Do not require the fallback player's name,
  gender, anatomy, personality, voice, or backstory unless the user explicitly
  requested a locked protagonist story.
- Do not reuse names or surnames from examples, templates, skill references,
  local story files, or unrelated locations. No non-player character should share a
  surname with any player option unless the story intentionally makes them
  related and records that relationship. No unrelated characters should share a
  surname with each other. If two characters share a surname, make the
  family/household relationship explicit in their character facts or rename one
  of them.
- For characters embedded in a story, build them to serve play. Durable facts
  should include how the character affects objectives, what they can do in
  scenes, what relationship tensions matter, and what future rewards or gates
  may change about them. Do not put unlock timing, objective requirements,
  creator instructions, scheduling notes, or other implementation directions
  inside `starting_known_facts` or other character prose. For example, do not
  write `She joins after objective 12`; write the durable fictional fact, such
  as `She wants proof the player can protect the caravan before committing to
  travel with them`, and implement the actual timing in objectives and rewards.
- Opening people who are physically present but not party members belong in
  `npc_directory`, not `characters`.
- Starting templates must not include temporary speaker state. If someone can
  speak in the opening, create a real named NPC or party member.
- If opening text contains an inline voice tag such as `(First Last)`, then that
  name must resolve before play starts: put the NPC under
  `npc_directory.locations.<current-stable-location-id>.characters.First Last` and
  include `First Last` in `scene.npcs_present`, or make them a party member and
  include them in `scene.party_members_present`.
- For a present speaker whose identity is intentionally hidden, create the real
  NPC entry, set `player_known_name: false`, and set `player_facing_label` to
  the visible description the player can use. Add a later objective reward that
  sets `player_known_name` to `true` only when the story actually reveals the
  name.
- The player must never be placed in `scene.party_members_present` or
  `scene.npcs_present`.
- `scene.speak_targets` is manual player UI state only. Do not author it beyond
  an empty starting array, and never change it with an objective reward, reward
  bundle, reward template, state mutation, or any other story-authored effect.
  It is not required to make a named character interactable; story objectives
  must use physical presence lists instead.
- `scene.image_characters` should normally be `["Player"]` for the opening
  normal image, even when NPCs or party members are present. Opening NPCs and
  party members can receive their own profile/solo images through the app's
  character-image paths or objective image rewards. Only include other names in
  `scene.image_characters` when the story deliberately needs a group opening
  image instead of a solo player opening image.
- Objective rewards must intentionally maintain scene membership when the story
  fiction changes who is physically present. Do not rely on the engine to infer
  every entrance, exit, departure, recruitment, dismissal, travel move, private
  scene isolation, or aftermath cleanup from prose alone.
- As a recommended reliability pattern, every player, AI, or choice objective
  that expects specific named people in the scene should include idempotent
  `add_state_list_item` rewards for those people. Use
  `scene.party_members_present` for recruited party members and
  `scene.npcs_present` for non-party NPCs.
- Authored character references continue to identify the same person after
  presentation changes or recruitment. At reward execution, scene-presence
  add/remove effects use that person's current party/NPC owner. A replacement
  presence list replaces the requested role list and adds any referenced person
  who changed roles to their current role list, preserving unrelated members of
  that other list. This does not recruit anyone or reset their state. Starting
  scene lists still require their actual authored owners, and unknown people
  remain errors. Image targets use the same identity without changing presence.
- Consider repeating the same presence rewards on consecutive objectives that
  continue in one scene. Repeating an idempotent add is harmless and helps
  prevent a required participant from disappearing between objectives.
- Prefer explicit `remove_state_list_item` rewards only when the fiction moves
  to another scene or a person leaves, is released, sold, killed, or otherwise
  stops being physically present. This is recommended authoring guidance, not a
  validation requirement; a story may use another coherent presence pattern.
- When a non-party NPC enters the current scene, add their proper name to
  `scene.npcs_present` with `add_state_list_item`; when they leave, remove them
  with `remove_state_list_item`. If the NPC should also appear in generated
  scene images, update `scene.image_characters` intentionally.
- When a party member becomes physically present with the player, add their
  proper name to `scene.party_members_present`; when they leave the immediate
  scene but remain in the party/roster, remove only the scene-list entry. Do
  not remove them from `state.characters` unless the story is actually removing
  them from the party.
- `promote_future_character_to_party` preserves an existing NPC's current
  character state, adds them to the party and present-party list, and removes
  their NPC-presence entry. It uses the future-cast definition only for missing
  character details. No preservation flag is needed or accepted. If the new
  party member remains elsewhere, explicitly remove them from the present-party
  list afterward; roster membership and physical presence are separate.
- Scene-list rewards should match the immediate fiction at the end of the
  objective or route. For example: after a council meeting ends, remove
  council-only NPCs from `scene.npcs_present`; after a shopkeeper steps into a
  private conversation, add that named NPC; after a purchased companion joins
  the player, promote/add them and then add them to the appropriate present
  party list unless the story says they will arrive later.

## Runtime-State Separation

Use the authoritative field contract and final `Schema` checklist below. They
contain the complete immutable-definition, live-state exclusion, profile/image,
progression, preference, and blocked-meta-field rules.

## Story Memory Rules

Use the authoritative `state.story_memory` section below. It defines the only
supported memory buckets and the boundary between memory, rules, objectives, and
creator/process notes.

## Validation Checklist

Before finishing:

- JSON parses.
- Wrapper keys are present.
- Required state sections exist.
- Public metadata is present and uses approved genres.
- `creation_tool` matches the actual tool/model/intelligence used for this run,
  not a stale example value.
- For source-free stories, `source` is `"Original"`. High-level inspiration
  remains original when the finished setting, cast, conflicts, and plot
  expression are distinct. For an actual retelling, adaptation, continuation,
  or direct use of recognizable source material, verify the source value under
  the Source EmberAdventures Story extension instead.
- `nsfw` and `loli` follow current rules.
- `title_card_image` exists and stores only one active/default reference.
- `title_card_subjects`, if present, is a short non-spoilery list of visible
  cover subjects, not printed text.
- The creative-direction pass is complete: the core player fantasy, emotional
  target, world hook, progression/building axis, main relationship focus when
  relevant, midpoint or reevaluation moment, climax, ending/postgame shape, and
  structure mode are clear before final JSON.
- If the initial prompt could become several different games, the skill asked
  story-juice questions or proposed 2-3 directions instead of blindly choosing
  a generic plot.
- The objective spine acts as the story director: it creates anticipation,
  payoff, world motion, relationship pacing, and intentional failure/branch
  outcomes instead of relying on the live AI to invent them later.
- `world_map.locations` exists and is an object.
- `future_cast.enabled` exists and `future_cast.items` is an object.
- `state.location.npc_location_id` is nonempty and resolves to an existing
  `state.npc_directory.locations` key.
- Every `story_shops[id].npc_location_id` is nonempty and resolves to an
  existing `state.npc_directory.locations` key. `location` remains display text
  only.
- Objectives are arrays and all references are valid.
- No objective uses boilerplate verifier text such as
  `Return yes only when the player completes: {title}`.
- No objective uses generic verifier text such as
  `Return yes only when the player clearly takes action toward this goal`.
- No objective uses boilerplate narrator text such as
  `Resolve the immediate outcome of {title} and move to the next objective`.
- AI-controlled objectives do not use `player completes` phrasing in
  `completion_criteria`.
- Every objective family that uses a verifier has concrete criteria, and every
  output has an instruction that can be understood without reading the title as
  its only source of meaning.
- One opening objective is active unless requested otherwise.
- The progression design pass is complete: current state, future state,
  starting rules, reward-driven changes, map unlocks, branches, image triggers,
  and future-cast introductions have all been intentionally considered.
- The feature-utilization pass is complete: any omitted major feature is omitted
  because it does not serve this story, not because it was forgotten.
- For romance, dark romance, harem, court, companion, and relationship-driven
  stories, the final check reports or internally verifies the number of direct
  choice objectives, the number of `adjust_relationship` rewards, and at least
  one relationship-building/test objective for each major relationship lead.
- Serious stories use deterministic objective rewards for important permanent
  changes instead of relying only on narrator prose.
- Side objectives have useful story/game consequences where appropriate.
- Branches that are truly one-path-only use `exclusive_group`, branch-specific
  output rewards/state markers and distinct output transitions. Branches that
  can all be completed do not use `exclusive_group`.
- Conditional consequence routing uses `next_objectives` on the completed
  objective, not a fake visible choice or separate empty branch node. Every
  referenced next objective exists, requirements are structured and
  story-state-based, and any default fallback is last.
- Scene-adjudicated hidden routing uses `route_control: "ai"` and
  `outcome_routes`, never a fake visible choice. Route ids and criteria are
  private, route ids are unique, exactly one route is the no-requirements
  fallback, and every route has a valid next objective/input group or ending type,
  and the objective does not also contain `next_objectives`.
- Visual tree integrity is valid: every objective id is unique, every
  output id is unique, every nonterminal output destination exists, and every
  output has a valid `target_input_group_id`. Every non-starting main objective
  has at least one reachable incoming input group. Direct choice objectives
  have owned `choices[]`, visible option titles, and deterministic
  rewards/effects. Main objectives, Player Choices, AI-routed objectives, and
  Automatic Transitions require at least one output. An ordinary Player Action
  or AI Scene side objective may finish with no outputs; use its own
  `completion_instruction` for the result and preserve the current main story.
  A freeplay, ending, or game-over path sets `ending_type` on that specific output. Do not leave hidden/future objectives
  unreachable or rely on fallback objective picking as normal story flow.
- Choice-heavy stories keep choice objectives meaningful but not constant:
  roughly 30-40% choice objectives for multiple-ending/Telltale-style requests,
  and normally never more than half unless explicitly requested.
  Hidden shop-triggered post-purchase hooks and one-option job start/turn-in
  objectives are counted separately and do not count as visible pacing choices.
- Optional romance/NSFW moments can be baked into the main flow with an
  optional-with-skip choice owner objective rather than a separate side
  objective.
- Multi-route convergence uses separate playable branches that all must be
  completed before the merge objective; reserve `exclusive_group` for true
  one-path-only decisions.
- Fail-forward branches keep the story playable after bad choices through debt,
  damage, distrust, worse routes, or altered endings instead of accidental
  dead-ends.
- Delayed callback choices persist early choices through explicit rewards/rules
  so later objectives or endings can react to them.
- Relationship-threshold choices show locked options and visible requirements in
  the choice UI; do not hide or rewrite options based on hidden thresholds.
- Choice option `effects` are player-facing UI text. They may show only
  currently visible requirements or concrete mechanical deltas such as
  `credits -80`, `trust >= 6`, `suspicion +1`, or `key required`. Do not put
  route labels, ending labels, unlock labels, hidden recommendations, or
  outcome spoilers in `effects`; store those consequences in rewards, story
  rules, and completion instructions instead.
- Resource-gated route order uses visible requirements for money, supplies,
  reputation, evidence, parts, or trust when a route is available but not yet
  startable.
- `state.players`, if present, contains full player definitions and only exists
  for real player select.
- For player-select stories, opening text, objective text, story rules,
  relationship memories, shop notes, future-cast notes, and hidden guidance use
  generic role/protagonist prose unless the field belongs to one specific
  player definition. No fallback player name, gender, pronoun, anatomy,
  backstory, or voice leaks into shared story text.
- No non-player character shares a surname with any player option unless they
  are intentionally related and that relationship is explicit in durable facts.
  No unrelated characters share surnames with each other. No example/template/
  reference names or surnames were reused accidentally.
- If duplicate surnames remain, every duplicate has an explicit family,
  household, clan, or source relationship in durable facts.
- Embedded characters use the current character schema.
- Standalone/public character-library definitions remain humanoid characters
  aged 18 or older. A story-embedded humanoid may be younger than 18 only when
  `nsfw` and `romanceable` are both `false` and both `starting_attraction` and
  `starting_arousal` are `0`. Never place that character in sexual content,
  nudity, spicy-scene participation, sexual rewards, or sexual image guidance.
- Use `animal_definition`, not `full_character`, for a genuinely non-humanoid
  animal form. An NPC or future-cast item contains exactly one of
  `full_character` and `animal_definition`. An animal definition uses animal
  fields such as `species`, `physical_description`,
  `personality_description`, and `communication_style`; it does not contain
  humanoid `appearance`, outfits, clothing, held items, romance, attraction,
  arousal, NSFW, or loli fields. Animal images describe the animal directly and
  never run humanoid age, anatomy, or clothing projection.
- Required `animal_definition` fields are `version`, `id`, `name`, `source`,
  `creation_tool`, `can_die`, `gender`, `age`, `role`, `species`,
  `physical_description`, `personality_description`, `communication_style`,
  `starting_relationship_to_player`, `starting_trust`, `starting_affection`,
  `starting_state_of_mind`, `starting_physical_state`, `starting_pose`,
  `starting_known_facts`, `created_at`, and `updated_at`. `stats` and the normal
  image-reference/configuration fields are optional. Omitted image configuration
  receives deterministic runtime defaults; do not add empty image metadata just
  to imitate a humanoid definition.
- Embedded characters use `speech_style` for durable dialogue behavior and
  `personality_description` for identity/motivation. Do not put TTS voice names,
  current mood, or private story instructions in `speech_style`.
- `can_die`: Internal boolean plot-armor flag. Standalone character definitions default to `false`. Story-embedded important characters should usually be `false`; disposable/simple NPCs may be `true`. This field is hidden from AI prompts and should never be explained in player-facing prose. Objective rewards may change it with `set_state_field`, and `kill_character` can override it only with `ignore_can_die: true`.
- Embedded character definitions do not include `power`, active `known_facts`,
  active `clothing`, active `inventory`, active `image`, profile image history,
  story-image history, or other live/runtime fields.
- Important embedded characters pass the character-depth floor: concrete
  durable facts cover identity, role, personality under pressure, usefulness,
  relationship dynamics, quirks/preferences, and relevant story complications.
- Embedded character names are proper names, not titles/jobs/groups.
- Body/appearance fields are meaningful and current.
- `appearance.extra_description` is the general extra durable visual-detail field.
  Use it for unusual upper-body anatomy, scars, markings, species details, or
  visual facts that no specific appearance field can express. Do not repeat body
  size/shape/proportion already represented by `height`, `shoulder_width`,
  `chest`, `upper_body_build`, `midsection_build`, `hip_width`, `butt_build`,
  `lower_body_build`, `arm_length`, `leg_length`, `penis_size`, hair, skin, or
  eyes. Bad examples: `thin adult body`, `large breasts`, `wide hips`,
  `defined abs`, or `long legs` when those are already encoded by numeric/body
  fields.
- `appearance.male_only_extra_description` and
  `appearance.non_male_only_extra_description` are optional and narrow. Missing
  or `null` means no additional prompt text. Use them only for an important
  visual feature that genuinely differs between presentations and no other
  field owns, primarily optional male facial hair. Never use them for a general
  description, breasts, pecs/chest, genitals, or other structured anatomy. Do
  not put clothing, pose, scene state, personality, sexual behavior, or
  instructions in them. The engine selects only the field matching the active
  presentation.
- Set `appearance.nonhuman_lower_body` to true only when ordinary humanoid hips,
  buttocks, thighs/calves, and legs are replaced by a distinct nonhuman lower
  body. Keep all eleven numeric fields structurally present, but suppress
  `hip_width`, `butt_build`, `lower_body_build`, and `leg_length` from prompt
  projection when they do not apply. Describe the complete replacement in
  `appearance.extra_description_lower_body`; do not invent ordinary legs or
  glutes. Keep every clothing slot the character actually wears. Profile prompts
  omit this lower-body description, while
  lower-body-capable normal and group prompts include it.
- When `appearance.nonhuman_lower_body` is false,
  `appearance.extra_description_lower_body` may still contain a concrete visual
  detail that applies only below the waist; otherwise use `""`.
- Clothing and outfits use current clothing slots only.
- `voice` is always `null` in authored character definitions. Story-generation
  tools do not have the installed TTS/screen-reader voice data needed to assign
  it correctly. Do not infer a voice, use a character or actor name, or ask for
  voice metadata during normal story creation.
- Current scene fields exist: `intimacy_level`, `spicy_mode`,
  `party_members_present`, `image_characters`, `npcs_present`, `image_action`,
  `sex_position`, and `ai_sex_position`.
- The player is not in scene presence lists.
- Every starting `scene.npcs_present` entry resolves to an NPC under
  `npc_directory.locations.*.characters`, and every inline opening speaker tag
  resolves to a present NPC or party member. There are no flat
  `npc_directory.<npc name>` entries.
- Temporary speaker state is omitted.
- Locked future cast is not visible in map/current scene/opening/library text.
- Shop/future-cast integrity is valid: every character-shop `character_id`
  exists in `future_cast.items`, every future-cast item id matches its key,
  every `on_purchase_objective` exists or is intentionally pending with a note,
  every `purchase_mode` is `"acquire"` or `"service"`, only service listings
  are repeatable, every character appears at most once per shop, every
  `remove_character_shop_listing` reward resolves to an existing character-shop
  listing, every locked shop item has visible requirements or an unlock reason, full
  character data is not duplicated inside shop items, and purchasable characters
  are not present in the map/current scene before unlock.
- Story job-board items use the exact common fields `id`, `title`, `summary`,
  `genres`, `nsfw`, `rank`, `requirements`, `reward_coins`, `reward_xp`, and
  optional `reward_items`. Flat jobs may additionally use `client_npc_id`,
  `start_location`, `completion_criteria` and `completion_instruction`.
  Authored-tree jobs instead use `objective_tree:{entry_id,items}` and optional
  `text_dictionaries`; omit the flat completion fields. Either flow may set
  optional boolean `repeatable`. See [job-trees.md](job-trees.md) for the full
  graph, token, identity, completion and persistence contract. No alternate
  `quest_id`, generic `reward`, `purchased`, `on_accept_objective` or free-text
  reward blob fields are accepted.
- Every flat-job `start_location`, if present, is a location object rather than
  a string ID. Flat jobs remain self-contained in their generated objective
  flow; use an actual `objective_tree` when the author needs a precise sequence.
- Every `story_shops[type="job"].items[].genres[]` label exists in the
  story's public `genres[]`; otherwise the job may be hidden by genre
  filtering.
- Recursively scan every reward container before export: objective `rewards`,
  direct-choice rewards, AI `outcome_routes[].rewards`, reward bundles, reward
  templates, and timed-event rewards. Every `introduce_future_character` must
  have a `character_id` matching an existing `future_cast.items` key and a
  nonempty `npc_location_id` resolving to `state.npc_directory.locations`.
- Every `story_inventory.rule_flags includes X` requirement is reachable:
  either `X` is present in the starting `story_inventory.rule_flags` array or
  some objective reward can add `X` with `add_state_list_item`.
- `adjust_story_inventory.field_path` is exactly `["story_inventory", "resource_key"]` for one top-level numeric resource, never a relative key, `items`, or a nested path. Include an explicit `operation` and finite `amount`; authoring and runtime use the same exact path check.
- Numeric story-inventory changes use `adjust_story_inventory` deltas for
  add/spend changes, `operation: "multiply"` or `"divide"` for percentage or
  ratio math, and `operation: "set"` only when a deliberate exact reset/set is
  intended. Do not accidentally overwrite `story_inventory.coins`, credits,
  XP, reputation, suspicion, or parts with `set_state_field` when the story
  meant to change a numeric amount.
- Before final export, search story text for known process/future-system
  phrases and remove or rewrite any hits as current in-world runtime
  constraints: `future engine`, `future shop`, `future quest`, `should later`,
  `convert these`, `until those systems exist`, `linked objective`,
  `authored objective`, and `objective chain`.
- Clean exports do not rely on `settings` or `meta.allow_spicy`.
- Public metadata uses `starting_party_member_count`, never
  `starting_character_count`.
- Story descriptions are player-facing pitches, not hidden outlines.
- Player-visible fields do not reveal future cast, future roles, locked
  locations, hidden rewards, private AI instructions, or implementation notes.
- `state.meta.story_source` has no old planner-summary or source-outline
  fields.
- `story_memory.ai_private_notes` contains only concise in-world continuity
  constraints when needed; it does not contain coverage-table text, omission
  reports, audit notes, or creator-process instructions.
- No removed genre tags such as `game`, `progression`, `survival`, or `litRPG`.
- No mojibake or accidental replacement characters in prose.
- Do not rely on a later main-thread cleanup pass. The final JSON must be the
  best complete version this skill can produce on its own.
- Do not rely on cherry-picking between drafts. The final JSON must already
  contain the best internally selected objective structure, cast coverage,
  character definitions, map, metadata, opening, and validation fixes.

## Durable Guidance Updates

If new reusable normal-story guidance appears, update this base skill or
propose the update before continuing. Guidance that applies only to
source/canon research or adaptation belongs in the source extension. Minor
process clarifications can be patched directly; substantive workflow changes
should be discussed with the user first.


# EmberAdventures Story Definition Field Contract

Use this contract when creating, reviewing, or migrating EmberAdventures story-template JSON. This contract describes the immutable/default parts of the current story-template format. It does not introduce a new reference system. Use the current EmberAdventures story method: player is a player object, party members are keyed by character name in the saved `state.characters` object, NPCs/future cast use the current story-template structures, and scene/runtime lists use names after import.

Story-embedded character definitions use the same single `appearance.species`
field as standalone characters. Put the complete identity in that field,
including meaningful subtypes, groups, visual qualifiers, or lineage such as
`"Cosmic Ghost"` or `"Iron Coast Dwarf"`. Do not add `appearance.race` or
`appearance.ancestry`; those fields are invalid and removed. The rest of this
story contract governs which character fields are allowed in each story
location.

## Field Purpose Standard

For every field you write, ask these four questions before final export:

1. What is this field for in EmberAdventures?
2. How does EmberAdventures use or display it?
3. Does the value actually accomplish that purpose?
4. Could the value be shorter, clearer, less spoilery, or less like process text?

Do not fill fields because they exist. Empty strings, empty arrays, empty
objects, or `null` are often better than invented filler when the app treats the
field as optional/default state.

## Creator Instructions Are Not Story Data

Instructions from the user to Codex/the story creator must guide construction
but must not be copied into the story definition as story prose, objective text,
world facts, character facts, player guidance, or metadata.

Examples of creator/process instructions that must not appear as story content:

- `source faithful`, `follow canon`, `hide future cast`, `do not spoil`;
- `do not force a fake ending`, `continue at the current frontier`;
- `make objectives player-facing`, `use objective rewards`;
- `current app compatibility`, `story template`, `clean export`;
- `adult-only when settings allow`, `SFW/NSFW policy`;
- `do not introduce future characters unless unlocked`.

Convert those instructions into the correct field behavior instead. For
example, "do not force a fake ending" means the objective chain should continue
with concrete unresolved goals; it does not mean the story should contain an
objective or completion message that says "Do Not Force a Fake Ending."

If a field is player-visible, it must read like story content. If a field is
hidden runtime guidance, it should still be concise and story-specific, not a
verbatim copy of Codex process instructions.

## Top-Level Export Wrapper

- `app`: Must be `"EmberAdventures"`. This identifies the export owner. Do not use a story title, source title, or creator name here.

- `exportType`: Must be `"story-template"`. This tells import that the file is a story template, not a save file, character file, or settings export.

- `storyTemplate`: Object containing the actual template. This is the immutable story package plus starting-state defaults.

- `exportedAt`: ISO timestamp for when the export file was created. This is metadata only. It is not story time.

## storyTemplate Fields

- `id`: Stable story-template id string. Use a lowercase slug based on the
  finished title, represented generically as `"story-title-slug"`. Do not copy
  an id from skill examples, use a database id, random timestamp, or array index.
  Hosted downloads are imported locally; gameplay should not point at a live
  public database.

- `title`: Player-facing story title. Use a real title, not a setup answer,
  development label, or setting flag. Do not copy names from this skill's
  structural examples into a new story. Avoid translating the premise literally
  into an on-the-nose title or revealing the central twist. Prefer a concise
  in-world place, institution, object, phrase, family name, or evocative idea
  that fits the story without summarizing its entire setup.

- `description`: Short player-facing library/UI description of the premise. Keep it concise. Write it as a sales pitch, not an outline: describe the kind of adventure, the starting fantasy/genre appeal, and the immediate premise. Do not include hidden future spoilers, locked cast lists, future objective lists, ending/villain twists, private implementation notes, or objective verifier instructions.

- Keep the genre combination coherent. Use only tags the story genuinely serves,
  and do not bolt together unrelated genres, powers, factions, or cosmic systems
  merely to make the premise sound larger or cover more categories. A focused
  story may use one genre or a small compatible cluster.

- `createdAt`: ISO timestamp for original template creation. Preserve the
  existing value when editing an existing template.

- `updatedAt`: ISO timestamp for the most recent actual template edit. Change it
  only when template content changes.

- `state`: Starting story state object. This contains immutable/default story setup that is copied into a mutable game state when starting a new game.

- `allow_any_player`: Required boolean, default `false`. This answer must come
  from the creator during every new-story intake. When `true`, the start-of-game
  character selector includes `Select Character From Library` in addition to
  any authored `state.players` options. When `state.players` is absent or empty,
  EmberAdventures assumes arbitrary-player selection is required even if this
  value is false; therefore use `true` explicitly for that design. Use `false`
  when the premise depends on a fixed protagonist identity, body, history,
  relationships, abilities, or authored personal arc that cannot safely be
  supplied by an unrelated library character.

- `any_player_starting_state`: Optional object applied only when the player
  chooses a Character Library character through `allow_any_player`. For a
  normal arbitrary-player story, include this object and explicitly author all
  supported replacement groups. The default intent is to use the selected
  library character for identity, personality, appearance, voice, and profile
  image while the story replaces the character's role, inventory, stats, held
  items, current condition/pose, and outfits. Empty arrays, empty objects, and
  null hands are meaningful replacements and must be authored when the player
  is supposed to start without those things. Omit a child field only after the
  creator intentionally decides that field group may carry in from unrelated
  Character Library content. Supported fields are:

  ```json
  {
    "role": "story-specific role",
    "starting_known_facts_to_add": [],
    "starting_inventory": [],
    "stats": {},
    "starting_held_items": {
      "right_hand": null,
      "left_hand": null
    },
    "starting_state_of_mind": "focused",
    "starting_physical_state": "healthy",
    "starting_pose": "standing",
    "male_outfits": [],
    "male_starting_outfit_id": "male-story-outfit",
    "non_male_outfits": [],
    "non_male_starting_outfit_id": "non-male-story-outfit"
  }
  ```

  `role` replaces the selected character's role for this playthrough.
  `starting_known_facts_to_add` is the only additive field: its entries are
  appended without exact duplicates to both starting and current runtime known
  facts. `starting_inventory`, `stats`, and `starting_held_items` replace the
  selected character's corresponding definition defaults and current runtime
  values. The three `starting_*` condition fields replace both their immutable
  starting values and live `state_of_mind`, `physical_state`, and `pose` values.
  Story numeric-precision rules apply to overlay `stats` exactly as they apply
  to authored character stats.

  Outfit overrides are gender-branch replacements. By default, provide both
  branches so foreign library outfits cannot enter the story. A selected
  character whose resolved gender is `male` uses `male_outfits`; every other
  gender uses `non_male_outfits`. When a branch is present, it must be a nonempty list of
  valid full outfit records, and its matching starting outfit id must reference
  an id in that list. That branch replaces all copied library outfits, starting
  and active outfit ids, and current clothing for this playthrough. When a
  branch is omitted, the engine retains the library character's outfits and
  active outfit. Omit a branch only when the story intentionally permits
  foreign outfits and clothing for that gender branch. Do not provide a
  standalone clothing override.

  Before finalizing an arbitrary-player story, record an explicit decision for
  every replacement group: role, inventory, stats, held items, condition/pose,
  male outfits, and non-male outfits. Unless the premise has a specific reason
  to accept library content, author replacements for all groups. Use `[]` for
  no starting inventory, `{}` for no story stats, and null hand values for no
  held items. Do not omit these fields merely because their intended values are
  empty. This prevents unrelated weapons, quest items, currencies, abilities,
  uniforms, or outfits from leaking into a new story.

  Never put library-owned identity fields in this object: `name`, `age`,
  `gender`, `species`, appearance, personality, speech style, voice, image
  configuration, and profile image remain owned by the selected Character
  Library definition. The copied runtime Player receives the overlay; the
  reusable library definition is never modified.

- `messages`: Array of prewritten opening messages. Include at least the opening narrator message. Opening messages are immutable starting content only: do not store live chat history, post-start messages, or save-game transcript data in a story definition. Opening messages are shown to the player and treated as already represented by the starting state; they are not reprocessed as new state changes.

  Opening messages should contain only clean exported message fields needed to
  start play: `role`, `speaker`, `text`, optionally `nsfwMode`, and optionally
  `at`. Do not author `id` or `entryId`; the normal story exporter does not
  preserve them. Do not include runtime-only fields such as `streaming`, `detail`,
  `stateSyncStatus`, `spicySyncStatus`, `voiceMeta`, `voiceSpeakers`, or
  `objectiveComplete`.

- `settings` is not an approved story-template field and causes validation
  failure. Do not put settings or story state there.

- `source`: Use `"Original"` for original/source-free stories. This is the
  creative source label, not the creator's name, player name, profile name, or
  author alias. Never use `"Player"` as a story source. For source/canon work,
  the Source EmberAdventures Story extension determines the exact source title
  while this base skill continues to own the field's schema.

- `app`: Must be `"EmberAdventures"` inside `storyTemplate` as well.

- `templateType`: Must be `"story"`.

- `creation_tool`: Factual tool/model label used to create or finalize the
  template. Use `"<tool> <model> (<reasoning/intelligence level>)"` when those
  parts are available. Never copy a model label from an example and never leave
  this null. If the current tool/model/intelligence cannot be determined, ask
  before final export.

- `genres`: Array of one or more approved EmberAdventures genre strings. Copy the same approved list into `state.meta.genres` so public library/import validation and runtime prompt projection agree.

  Approved genre tags are: `anime`, `fantasy`, `sci-fi`, `modern`, `historical`, `romance`, `adventure`, `action`, `comedy`, `drama`, `mystery`, `thriller`, `horror`, `dark`, `cozy`, `slice of life`, `superpower`, `isekai`, `school`, `workplace`, `political`, `war`, `crime`, `mythology`, `supernatural`, `post-apocalyptic`, `western`, `cyberpunk`, `steampunk`, `harem`.

- `kink_tags`: Public-library discovery metadata for content the story intentionally supports or guarantees. This is a closed vocabulary and is separate from player sexual preferences. Every value must exactly match one of the canonical lowercase strings below; these are the only valid options. Do not invent, combine, pluralize, reword, or add tags. Interpret every kink tag from the player's perspective: `dominance` means the player acts dominant, `submission` means the player acts submissive, `owning partners` means the player owns partners, and `being owned` means the player is owned. A companion's behavior or preference alone does not justify the opposite player-perspective tag. Copy this exact array to `state.meta.kink_tags`; the two arrays must be identical. Use `[]` when none apply. Do not use vanilla kissing, oral sex, vaginal sex, ordinary romance, tone, body appearance, or broad genres as kink tags. This field is story discovery metadata only: omit `kink_tags` from every story-embedded character definition, including `state.player`, `state.players[]`, `state.characters`, NPC `full_character` definitions, future-cast shells, and future-cast `full_character` definitions. Do not use an empty array there.
  - **Power Exchange:** `dominance`, `submission`, `switching`, `owning partners`, `being owned`, `serving partners`, `being served`, `disciplining partners`, `being disciplined`, `punishing partners`, `being punished`, `training partners`, `being trained`, `brat taming`, `being a brat`, `using partners freely`, `being freely used`, `taking control in cnc`, `being overpowered in cnc`, `hypnotizing partners`, `being hypnotized`, `mind controlling partners`, `being mind controlled`, `corrupting partners`, `being corrupted`, `financial domination`, `financial submission`.
  - **Bondage And Restraint:** `bondage`, `binding partners`, `being bound`, `collaring partners`, `wearing a collar`, `leashing partners`, `being leashed`, `gagging partners`, `being gagged`, `blindfolding partners`, `being blindfolded`, `sensory depriving partners`, `being sensory deprived`, `enforcing chastity`, `wearing chastity`, `denying partners orgasms`, `being denied orgasm`, `forcing partners to orgasm`, `being forced to orgasm`.
  - **Impact And Pain:** `spanking partners`, `being spanked`, `slapping partners`, `being slapped`, `whipping partners`, `being whipped`, `flogging partners`, `being flogged`, `paddling partners`, `being paddled`, `caning partners`, `being caned`, `pulling hair`, `having hair pulled`, `biting partners`, `being bitten`, `scratching partners`, `being scratched`, `choking partners`, `being choked`, `sadism`, `masochism`.
  - **Sensation And Edge Play:** `wax play`, `temperature play`, `electrostimulation`, `tickling`, `needle play`, `knife play`, `blood play`.
  - **Psychological And Verbal:** `humiliating partners`, `being humiliated`, `degrading partners`, `being degraded`, `objectifying partners`, `being objectified`, `writing on partners`, `being written on`, `feminizing partners`, `being feminized`, `bimbofying partners`, `being bimbofied`, `praising partners`, `being praised`, `making partners beg`, `being made to beg`, `worshipping partners`, `being worshipped`, `dirty talk`.
  - **Roleplay:** `authority figure roleplay`, `subordinate roleplay`, `medical roleplay`, `pet owner`, `being a pet`, `primal predator`, `primal prey`, `uniforms`, `crossdressing`.
  - **Exposure And Multiple Participants:** `exhibitionism`, `voyeurism`, `public sex`, `group sex`, `participating in gangbangs`, `being gangbanged`, `sharing partners`, `being shared`, `watching partners with others`, `being watched with others`, `cuckolding partners`, `being cuckolded`, `swinging`, `double penetration`.
  - **Sexual Activities:** `penetrating partners anally`, `receiving anal`, `masturbation`, `using toys on partners`, `partners using toys`, `fisting partners`, `being fisted`, `pegging partners`, `being pegged`, `rimming partners`, `being rimmed`, `sitting on partners' faces`, `being facesat`, `giving titjobs`, `receiving titjobs`, `giving thighjobs`, `receiving thighjobs`, `giving creampies`, `receiving creampies`, `cum play`, `squirting`, `lactation`, `breeding partners`, `being bred`, `impregnating partners`, `being impregnated`, `being rough with partners`, `partners being rough`, `clothed sex`.
  - **Fantasy:** `using tentacles`, `receiving tentacles`, `futanari`, `transforming partners`, `being transformed`, `oviposition giving`, `oviposition receiving`.
  - **Fantasy Partners:** `angels`, `demons`, `succubi and incubi`, `vampires`, `werewolves`, `demi-humans`, `anthropomorphic characters`, `monsters`, `aliens`, `androids`, `robots`, `elves`, `dark elves`, `orcs`, `goblins`, `dragons`, `fairies`, `merfolk`, `centaurs`, `minotaurs`, `lamias`, `harpies`, `arachne`, `ghosts`, `undead`, `shapeshifters`, `living dolls`, `golems`, `elementals`, `deities`.
  - **Materials And Clothing:** `latex`, `leather`, `lingerie`.
  - **Fluids And Functions:** `watersports`, `scat`, `spit`, `sweat`, `food play`.

- `nsfw`: Boolean declaring whether the story template itself is unsafe or
  inherently adult in SFW mode because its premise, opening state, required
  objectives, required characters, or required storylines contain NSFW/adult
  content. This is public metadata and must always be explicitly true or false.
  Do not set this true merely because EmberAdventures can switch any story into
  NSFW mode, because optional player behavior could become sexual, because the
  user's preferences allow adult content, or because a SFW story can later be
  converted into a NSFW playthrough. A story that can be played safely in SFW
  mode should use `nsfw: false` even if runtime profile/playthrough settings can
  permit spicy play later. For those stories, omit public-visible adult scene,
  NSFW, and kink-facing prose. SFW means "no inherent NSFW tag," not "NSFW is
  blocked forever."

- `loli`: Boolean declaring whether the story template contains one or more
  embedded character entries marked `loli: true`. This is public metadata and
  must always be explicitly true or false. Do not mark the story loli based on
  source age/school context alone when every embedded character is an
  adult/non-loli variant with `loli: false`.

- `title_card_subjects`: Optional array of 0-5 visible subjects for generated
  story title-card art. Use story-start-visible people, factions, locations,
  objects, or scene motifs. These guide the background/cover subject only; they
  are not extra printed text. Do not include spoilers or future cast that is not
  visible at the start.

- `title_card_image`: Optional default story title-card image slot. This is the active/default image reference for the story card, not story image history. Its clean normal-story shape uses `id`, `title`, `prompt`, `negativePrompt`, `seed`, `model`, `source`, `url`, `hosted_url`, `html`, `favorite`, and `nsfw`. User-uploaded slots additionally retain `upload_attestation_classification`, `upload_attested_by`, `upload_attested_at`, and `upload_attestation_policy_version`; generated images leave those fields blank/default. It does not use `negative_prompt` or `note`. Public story publishing requires a hosted/default image URL. Local title-card image history is stored outside the story definition and should survive story deletion/reimport. Generated title-card prompts should describe only the background/cover art and must not ask the image generator to print the story title, logo, lettering, typography, subtitles, taglines, author names, captions, menu text, UI text, random letters, or character names as text. EmberAdventures overlays the story title itself. Keep `negativePrompt` blank in normal story templates.

- `default_image_model`: Optional story-level default image style id for normal generated story images and AI-created characters/NPCs created inside games that use this story. Use `""` by default. Supported ids include app image-style preset ids such as `"fantasy-rpg"` for the default cinematic fantasy look and `"polished-animation"` for the newer polished high-budget animated fantasy look. Set this only when the story creator intentionally wants the whole story to default to that image style; otherwise leave it blank so the player's global image style is used. If nonblank, also copy the value to `state.meta.default_image_model`.

- `editor_data`: Optional top-level editor-only metadata. It is not runtime
  story state and is not sent to narrator prompts. The supported story-tree
  shape is `editor_data.story_tree.positions`, an object keyed by objective id
  with `{ "x": number, "y": number }`, and
  `editor_data.story_tree.viewport` with `{ "x": 0, "y": 0, "zoom": 1 }`.
  Use this only to help the manual visual Story Builder open with a readable
  layout. Never store lore, hidden plot, creator notes, objective instructions,
  or AI guidance here. The visual editor derives links from output destinations
  and `target_input_group_id` values in `next_objectives`, `choices`, and
  `outcome_routes`.

## state.meta

- `meta`: Story/game metadata. Include only fields the app uses or needs for prompt projection.

- `meta.story_guidance`: Player-specific runtime guidance. Leave blank by
  default. Do not put general story guidance, source policy, canon policy,
  tone guidance, hidden-future rules, objective design instructions, or Codex
  process notes here. Populate this only when the story creator explicitly asks
  to put text in player guidance or explicitly approves text for this exact
  field. If the creator says "make it source faithful," "hide future
  characters," or "do not force a fake ending," treat that as authoring
  guidance, not player guidance.

- `meta.default_image_model`: Mirror the top-level `default_image_model` when
  that story-level image style default is nonblank. Omit it or use `""` when
  the story should inherit the player's global image style.

- `meta.genres`: Array of general story-category tags. Use one or more approved genre tags from the app genre vocabulary. Do not use removed/invalid tags such as `"game"`, `"progression"`, `"survival"`, or `"litRPG"`. Do not use a single `genre` string and do not invent compound values like `"dark romance"`, `"dark fantasy"`, `"cozy adventure"`, or `"mystery thriller"`; combine simple tags instead.

- `meta.kink_tags`: Copy of public `kink_tags` for local story-builder/search use. These are searchable tags, not runtime player preferences. Together with top-level `kink_tags`, this is the only valid location for story discovery kink tags.


- `meta.allow_spicy`: Legacy/local draft runtime setting. Clean exported/public story definitions strip `meta.allow_spicy`; do not use it as immutable story identity. Public `nsfw` should only be true when the template cannot honestly be treated as SFW-safe.

- Blocked `meta` fields: do not include `setup_complete`, `is_spicy`,
  `allow_spicy`, `adult_warning_accepted`, `nsfw_has_ever_been_enabled`,
  counters, player counts, upload/publication counts, save ids, warning
  acceptance flags, runtime status, or UI flags. These are live app/UI state,
  not story-template identity.

- `meta.story_source`: Optional object for source/original setup. It may
  identify the source title and approved modifications. Its visible
  `description` should be short source/premise metadata, not a route outline.
  Do not add hidden full-story summaries, route outlines, or old planner fields
  here.

- Do not put user-profile preference arrays in story state metadata. `meta.player_preferences`, `meta.kink_preferences`, `meta.ick_limits`, and genre/entertainment preference lists belong on user profiles or runtime settings only, not in `state.meta` or exported story templates.

## state.location

- `location`: Current starting location summary fields. These are copied into runtime as the initial location state.

- `location.universe`: Source universe or original story universe. Be careful with source titles in ordinary prompts; projection should hide irrelevant source knowledge.

- `location.world`, `continent`, `region`, `settlement_type`, `settlement_name`, `district`, `specific_place`: Starting location labels. Use player-known starting facts. Do not spoil future locations or locked cast.

## state.world_map

Optional `hex_layout` opts a story into bounded hex exploration; omit it for an ordinary map. Read [hex-exploration.md](hex-exploration.md) for the exact area, passage, outcome and generation contracts and a complete example. Within a hex area, location `x/y` are integer axial q/r coordinates. Optional location `hidden_description` contains narrator-only text; public `summary/detail` stay player-known.

- `world_map`: Current map definition and starting map runtime defaults. Use the current app shape with `locations` as an object keyed by location id.

- `world_map.current_location_id`: Location id where the story starts. Must exist in `world_map.locations`.

- `world_map.focus_location_id`: Location id used as the current map focus. Usually same as the current location or its parent area.

- `world_map.travel_history`: Starting travel history array. Usually includes the starting location id or is empty if the app initializes it.

- `world_map.locations`: Object keyed by stable location id. Do not use old `visible_locations`.

- `world_map.locations[id].id`: Stable location id string. Must match the object key.

- `world_map.locations[id].name`: Player-facing location name.

- `world_map.locations[id].type`: Location type such as `"room"`, `"building"`, `"district"`, `"village"`, `"region"`, `"world"`, `"site"`.

- `world_map.locations[id].scale`: Hierarchy scale such as `"room"`, `"site"`, `"building"`, `"district"`, `"settlement"`, `"region"`, `"world"`.

- `world_map.locations[id].parent_id`: Parent location id or `""`/`null` for root.

- `world_map.locations[id].x`, `y`: Optional map coordinates. Use numbers if present.

- `world_map.locations[id].discovered`: Starting discovered boolean. Opening-known locations can be true; future/spoiler locations should usually be false.

- `world_map.locations[id].travel_enabled`: Starting travel-enabled boolean. Do not enable future locations before objectives reveal them unless the story starts with free travel.

- `world_map.locations[id].summary`: Short player-known location summary. Do not mention future cast or future plot events before they are unlocked.

- `world_map.locations[id].detail`: Optional object for extra location detail. Keep it player-known. Do not place hidden future planners, locked future cast, undiscovered source events, objective rewards, or private AI instructions here.

- `world_map.locations[id].connections`: Array of connected location ids. Every id should exist or be intentionally created later by objectives.

- `world_map.locations[id].npcs`: Array of NPC names already known/introduced at the start. Do not put locked future-cast names here. Future placement belongs in `future_cast.items[id].npc_location_id`, objective rewards, and `completion_instruction`. Public/map views may show these names, so this list must contain only visible, current, named people.

- Do not add location `tags`. The app does not use them and they add clutter.

## state.time

- `time`: Starting in-world time.

- `year`, `month`, `day`, `hour`, `minute`: Integers. Do not use prose dates inside these fields.

## state.scene

- `scene`: Starting scene runtime defaults. This is copied into mutable runtime and should represent the opening moment only.

- `scene.summary`: Current starting scene summary. Keep it concise and aligned with the opening message.

- `scene.intimacy_level`: Starting runtime intimacy number. Use `0` for normal story templates. Only use a nonzero value if the user explicitly requested that the story begin already inside an intimate/spicy scene.

- `scene.spicy_mode`: Starting runtime spicy-scene state, as the current engine string `"off"` or `"on"`. Use `"off"` for normal story templates. Only use `"on"` if the user explicitly requested that the story begin already inside a spicy scene.

  During play, intentional clothing removal starts a spicy scene when it is
  intended to be sexual or progress toward sex. The spicy runtime can remove
  all top clothing, all bottom clothing, all clothing, or exact individual
  structured clothing slots. Broad and individual removal commands are
  mutually exclusive for one participant in one update; never request both.
  Partial removal does not authorize invented slot-specific exposure prose in
  image prompts. Complete bare-top or bare-bottom wording is derived only when
  the corresponding structured clothing group is empty.

- `scene.party_members_present`: Array of known party-member names physically present right now. Do not include the player, `"Player"`, protagonist labels, unknown placeholders, generic groups/titles/jobs, or future cast that is not actually present. Entries must be proper character names backed by actual party-member data.

- `scene.image_characters`: Array of names to include in starting image composition. The opening normal image should usually be a solo player image, so this should normally be `["Player"]` even when NPCs or party members are present. Opening NPCs and party members can receive their own profile/solo images through character-image paths or objective image rewards. Include other names only when the story deliberately needs a group opening image. This is image/UI state and should not be shown to ordinary narrator/state/objective prompts except through image-specific flows.

- `scene.npcs_present`: Array of nearby known non-party NPC names close enough to interact. Do not use as long-term memory. Do not put generic labels such as `"guards"`, `"travelers"`, `"Guild Clerk"`, or `"cart drivers"` here; use proper named NPCs or leave it empty.

- `scene.speak_targets` is manual player UI state only. In authored story JSON,
  omit it or set the starting value to `[]`; never target it with objective
  rewards, reward bundles, reward templates, or any other authored state
  mutation. Do not rely on it to make characters available for conversation;
  use `scene.party_members_present` and `scene.npcs_present` to describe who is
  physically available.

- `scene.image_action`: Short visual phrase, usually 2-8 words, no comma and no full sentence.

- `scene.sex_position`, `scene.ai_sex_position`: Empty strings unless starting in a spicy scene. Blank values may exist in stored/exported JSON for schema consistency, but AI prompt projections should omit these keys entirely when blank.

- Do not add a separate scene boolean for player presence. The player is always present during normal play and is represented by `state.player`, not by scene presence lists.

## state.player

`player` is the authored fallback/default protagonist. It uses current story
method fields, with immutable/default fields copied from the common character
definition where possible. It may be omitted only when `state.players` is empty
and the story intentionally requires Character Library selection.

- `player.name`: Real character name. Do not use `"Player"`, `"Protagonist"`, `"Hero"`, `"Main Character"`, or placeholders.

- `player.age`: Integer age in years. If adult/spicy capable, must be 18 or older.

- `player.gender`: Player character gender/anatomy text.

- `player.role`: Durable player role/archetype.

- `player.personality_description`: Durable player identity. Keep player agency in mind: this is a starting description, not a script for future choices.

- `player.speech_style`: Durable player dialogue style for auto-player narration/speech when applicable. Keep it concise and do not script future choices.

- `player.starting_arousal`: Immutable/default starting arousal value. Usually
  `0`. Do not author active `arousal` in a clean reusable story definition.

- `player.starting_inventory`: Immutable/default starting inventory array. Do
  not author active `inventory` in a clean reusable story definition.

- `player.known_facts`: Mutable runtime field. Do not include active
  `known_facts` in clean story definitions. Put starting player facts in
  `starting_known_facts`.

- Character-definition-style starting fields such as outfits, starting outfit,
  boldness, starting relationship meters, default image config, and default
  profile image are immutable/default fields. Clean story definitions use the
  current character-definition shape and do not add live runtime-only fields.

## state.players

- `players`: Optional array of full authored playable character definitions for
  stories that let the player choose a protagonist before the opening prompt.
  This is independent of `allow_any_player`: a story may offer authored options,
  the Character Library option, or both.

- A fixed single-protagonist story must put that protagonist in `players` as a
  one-entry array and copy the same definition to `state.player`. With
  `allow_any_player: false`, the app starts that sole option directly without a
  picker. Do not omit `players` for a fixed protagonist: an absent or empty list
  intentionally means the player must choose from the Character Library.

- When `players` contains more than one entry, the app opens a character-select screen before starting the first playable prompt. The chosen entry is copied into runtime `state.player`, and runtime play must not keep the full `players` array as mutable game state.

- When `players` contains authored entries, `state.player` must still exist as a
  fallback/default and should copy the first/default option. When `players` is
  absent or empty, the app requires Character Library selection before runtime;
  `state.player` may be omitted because the selected library character becomes
  the runtime player before the opening scene starts.

- Every `players[]` entry must use the same immutable/default character
  definition shape as `state.player`: real `name`, integer `age`, `gender`,
  `role`, durable `personality_description`, durable `speech_style`, appearance,
  outfits, `starting_inventory`, `starting_known_facts`, blank image defaults,
  and `voice: null`.

- Do not include `power` while progression is shelved. It is not part of clean
  current story definitions.

- Do not put unselected playable options in `state.characters`, `scene.party_members_present`, `scene.npcs_present`, `npc_directory`, or opening messages as present party members. They are not in the scene unless the story explicitly introduces them later.

- Opening messages for multi-player-select stories should be written so they work for any selected protagonist, or should refer to the selected character generically by role/title. Do not assume the fallback player name unless every option shares that name.

- Voice/speaker tags for a gender-flexible non-player character may use exactly
  either that definition's `name` or `fallback_name`. Both resolve to the same
  runtime character. Do not author any additional name aliases and do not rely
  on broad prose replacement.

- In authored prose fields that mention another character by name, use explicit
  character reference tokens instead of hardcoding either presentation name:
  `|[character:stable-character-id]|`. This includes relationship text, known
  facts, opening narration, objective titles/summaries/criteria, choice text,
  shop/job descriptions, scene summaries, story rules, and memory entries. The
  UI and runtime prompts resolve the token to the active gender presentation
  name. Use `|[character_first:stable-character-id]|` when the prose needs only
  the character's first name. Examples:
  `"Married to |[character:daniel-mercer]|."` and
  `"Ask |[character_first:daniel-mercer]| what happened."`.

- Scene-reference rewards for `scene.party_members_present`, `scene.npcs_present`
  and `scene.image_characters` may use a complete `|[character:stable-character-id]|`
  value, or a complete `|[character_first:stable-character-id]|` value. Both
  resolve by the explicit stable ID to the full runtime identity; the engine
  never looks up the rendered first name. `|[player_name]|` and
  `|[player_first_name]|` identify the selected player. This works after gender
  adaptation and reopening. An authored character name remains supported.
  Pronouns, titles, surrounding prose and unknown IDs are not character
  identities. Keep ordinary names in initial
  scene lists and raw stable IDs in typed fields such as reward `character_id`
  and objective IDs; those fields do not use presentation tokens.

- Every character token must resolve through the canonical runtime registry:
  `state.player`, `state.characters`, a current NPC entry under
  `state.npc_directory.locations[id].characters` (including its
  `full_character`), or `future_cast.items`. For an NPC who is already present
  in the opening or another starting scene, create the real NPC-directory entry
  with the same stable character id and use that id in tokens. Do not put a
  starting NPC only in `future_cast` just to make tokens resolve; future cast is
  for people not yet introduced.

- Use explicit pronoun tokens whenever a gender-flexible character or the player
  would otherwise be referred to as he, she, him, her, his, or herself. The
  subject forms are `|[character_pronoun:stable-character-id]|` and
  `|[player_pronoun]|`; use `_cap` for a sentence start, such as
  `|[character_pronoun_cap:stable-character-id]|` or
  `|[player_pronoun_cap]|`. Object, possessive, and reflexive forms use
  `character_object_pronoun`, `character_possessive_pronoun`, and
  `character_reflexive_pronoun` with the same `:stable-character-id` suffix,
  or `player_object_pronoun`, `player_possessive_pronoun`, and
  `player_reflexive_pronoun`; each also supports `_cap`. For example:
  `"|[character_pronoun_cap:danielle-mercer]| places her hand on the stone."`
  and `"The guard follows |[player_object_pronoun]|."` The app resolves these
  once when a new save finalizes gender presentation, so the AI receives only
  ordinary finished prose. Do not hardcode gendered pronouns for adaptable
  characters or arbitrary-player stories.

- For arbitrary-player stories, write opening messages with `|[player_name]|`
  when the full selected player name is needed, or `|[player_first_name]|` /
  `|[player_first]|` when only the first name is needed. Avoid assumptions about
  gender, body, appearance, personality, personal history, or preexisting
  relationships unless the story supplies the required fact through
  `any_player_starting_state`. Story objectives, rules, shops, rewards, and
  dialogue must remain coherent for every compatible library character. Use
  `"Player"` only in structured runtime target fields that the engine resolves,
  such as `scene.image_characters`; do not use it as a literal character name.

- If the premise requires story inventory, stats, held items, condition, pose,
  role, known facts, or genre-appropriate clothing regardless of the selected
  library character, define them in `any_player_starting_state`. The default is
  to define every supported story-controlled group, including explicit empty
  replacements. Preserve a library field group only when the creator
  intentionally wants foreign content from that group to remain available and
  the story remains coherent with arbitrary values from it.

## state.characters

- `characters`: Object keyed by character display name. These are saved party-member/current-companion entries at the start of play. It can be empty. Treat `characters` as the stored JSON schema key; use `party members` in AI-facing text and explanatory guidance.

- Each value must use the immutable/default character-definition shape from
  `EmberAdventures Character`. Use `starting_*` fields and
  `starting_known_facts`; do not author current relationship meters, arousal,
  pose, clothing, inventory, known facts, or image history.

- Every full non-player character definition requires `romanceable: true` or
  `romanceable: false`. Use true for intended potential romantic or sexual
  interests. Use false intentionally for plot-only officials, incidental
  contacts, antagonists, or characters who should not normally adapt to the
  player's preferred romantic genders. Most recurring characters should be
  romanceable unless their role provides a concrete reason not to be.
  `romanceable: true` tells runtime preference adaptation to use a presentation
  allowed by the player profile. The profile's swap-all setting instead adapts
  every non-player character. Neither setting changes identity, appearance,
  personality, facts, relationships, role, stats, or inventory: only the active
  name, profile images, and outfits change. The player character is never
  adapted by `romanceable` or swap-all.

- Story-embedded character definitions inherit discovery metadata from the
  story. Omit `catalog_hook`, `default_image_background`, `genres`, `kink_tags`, `chat_story`,
  `chat_opening_message`, `chat_starting_location`, and `chat_story_template`
  from `state.player`, every `state.players[]` option, `state.characters`, NPC
  shells and `full_character` definitions, and every
  `future_cast.items[id]` shell and `full_character`. Store story genres and
  kink tags only in their documented top-level and `state.meta` locations.

- Gender-flexible characters keep their canonical `name`, `gender`, `outfits`,
  and `starting_outfit_id`, and require `fallback_name`, nonempty
  `fallback_outfits`, and `fallback_starting_outfit_id` for the same character's
  opposite male/non-male presentation. Do not create aliases lists. Prefer fallback names
  that retain at least the first letter, and preferably the first two letters,
  of the canonical name, but always prefer a natural, setting-appropriate name
  over a strained copy. Fallback outfits must preserve each canonical outfit's
  purpose, colors, equipment, status, and general visual identity while changing
  only gendered construction, underwear, fit, and similar presentation details
  unless a larger change is specifically justified. Appearance, personality,
  facts, and relationships stay unchanged. A canonical futanari
  character may additionally use `fallback_gender: "male"` or `"female"`;
  split these evenly across a cast. Treat the three fallback presentation fields
  as one atomic group and ensure the fallback starting id references a fallback
  outfit. Because profiles may enable swap-all adaptation, provide this complete
  group for every full non-player character, including `romanceable: false`.

- When migrating an existing cast, preserve identity. If an existing female
  character becomes canonical male, move the original female name, outfits,
  and starting outfit id into `fallback_name`, `fallback_outfits`, and
  `fallback_starting_outfit_id`, then author a natural canonical male name and
  equivalent male outfits. If she remains canonical female, preserve her current
  name and outfits and add a male fallback. If she becomes canonical futanari,
  preserve the current non-male presentation as canonical, add a male fallback,
  and distribute `fallback_gender` evenly across the futanari cast. Never alter
  appearance, personality, facts, role, stats, relationships, or inventory merely
  because the canonical gender presentation changed.

- Apply the character skill's same boldness scale to every gender. Boldness is
  romantic or sexual initiative and directness; aggression, confidence,
  exhibitionism, and dominant/submissive dynamics are separate traits. Gender
  adaptation never changes any of them.

- The 40% male / 40% female / 20% futanari balance is an optional authored
  default-presentation workflow, not a restriction on the story concept. Ask the
  creator whether to use it and explain the effect before applying it; retaining
  the creator's intended default genders is valid. This option is especially
  useful when a cast was first designed as all one gender but should present a
  varied default roster without changing who the characters are.

- When the creator chooses the balanced workflow, design the cast in its
  intended genders first, then perform one final presentation-only pass across
  every romanceable definition in every story container, including the starting
  party, NPC directory, future cast, shops, heroes, antagonists, and other
  embedded definitions. Assign stable authored order through the repeating
  sequence `male`, `female`, `male`, `female`, `futanari`; this gives
  deterministic rounding and an exact 40/40/20 ratio for each complete group of
  five. Split futanari `fallback_gender` values as evenly as possible between
  `male` and `female`, using stable authored order to resolve an odd remainder.
  For generated non-romanceable job characters, use a deterministic 50% male /
  50% female default mix. Swapping a default presentation changes only the
  canonical/fallback name and outfit placement. It must not change appearance,
  personality, facts, role, stats, relationships, inventory, or any other
  identity field.

- A standalone character copied or exported from the story retains the
  creator-intended canonical gender from before any story-cast balancing pass;
  do not make a story-only default-presentation swap canonical in the standalone
  library copy. Runtime still adapts romanceable characters to the active
  player's preferred genders, or all non-player characters when swap-all is
  enabled, regardless of whether the optional authored balance was used.

- `gender` is the sole source of gender mechanics. `male`, `trans male`, and
  `trans-male` use the male bucket. `futa` and `futanari` identify futanari
  characters, which otherwise use the female bucket except for penis-specific
  behavior. Every other gender value uses the female bucket. Never infer gender
  from kink tags, tags, sexual preferences, appearance prose, role, or any other
  field. Import and publish validation reject exact futa/futanari metadata on a
  character whose `gender` is not futa or futanari.

- `appearance.penis_size` is required on every player and non-player character
  definition and must be an intentional integer from 0 to 20. This includes
  female, non-binary, futanari, male, non-romanceable, and other characters.
  Runtime ignores it unless the current presentation is male or futanari, but
  the field must already exist because runtime adaptation can change presentation.

- Every character `default_profile_image` includes required boolean `male`
  presentation metadata. Use `true` only when the image depicts a male or
  trans-male presentation. Use `false` for female, futanari, non-binary, and
  every other non-male presentation; female and futanari intentionally share
  one profile-image bucket. A story may provide a profile image for either the
  canonical or fallback presentation, so set this from what the image actually
  depicts rather than from the character's canonical `gender`. For a blank
  authored image slot, initialize it from the canonical presentation.

- A profile image is eligible at runtime only when its `male` metadata matches
  the character's active male/female presentation. Never use the opposite
  presentation as a fallback. Every story-embedded character definition should
  include `profile_image_presentations.male` and
  `profile_image_presentations.non_male` keys, but those slots must remain
  null/blank until they contain real image references. If a real profile image
  is available, the slot must include the correct `male` boolean (`true` for
  male, `false` for female/futanari). This applies to `state.player`, every
  `state.players[]` option, `state.characters`, nested NPC `full_character`
  entries, and every `future_cast.items[id]` shell and `full_character`. Never
  use fake image data, transparent data URLs, or placeholder image objects in
  story or character files. Public publishing requires real resolving images
  for both presentations; local authoring/import may leave the slots blank until
  EmberAdventures generates or assigns real images. The `male` field belongs
  only to profile images. Never add it to normal/full-body, group, story, item,
  outfit, title-card, or other image records.

- Do not put opening handlers, registrars, merchants, quest givers, clerks, or future companions here unless they truly start as joined party/current companion characters.

- Do not duplicate the same person in both `characters` and active NPC containers unless the current app explicitly expects it.

## state.npc_directory

- `npc_directory`: Known local NPC directory for NPCs that exist now.

- `location.npc_location_id`: Stable lowercase NPC-directory location id for the current place. It must match an `npc_directory.locations` key. Use lowercase letters, numbers, and hyphens only.

- `npc_directory.locations`: Object keyed by stable location id, never a display name, runtime token, or player-facing sentence.

- `npc_directory.locations[id].label`: Required player-facing location label. This value may use runtime character-name tokens; keep it separate from the stable object key.

- `npc_directory.locations[id].characters`: Object keyed by NPC display name.

- Do not use the old flat shape `npc_directory.<npc name>`. It is invalid and
  causes validation failure. Use only
  `npc_directory.locations.<location-id>.characters`.

- NPC entry fields such as `name`, `gender`, `age`, `role`, `relationship`,
  `note`, `current_appearance`, `inspected`, `voice`, and `full_character` follow
  the current app shape. Use `role` for job/title/role text.

- NPC death is structured state, never inferred from prose. A dead NPC must use
  exact `status: "dead"` and a non-empty `death_note`. If the player caused the
  death, also set `killed_by_player: true` and set `killed_by` to the exact player
  name; otherwise set `killed_by_player: false`. Do not encode death only in
  `relationship`, `physical_state`, `state_of_mind`, `pose`, `note`, or recent
  change prose.

- `current_appearance` contains only temporary or scene-current visible changes
  to the NPC's base appearance. It must not duplicate base appearance from
  `full_character.appearance` or the compact uninspected description. Leave it
  blank when there is no temporary difference.

- For an uninspected NPC without `full_character`, use `note` for one concise,
  player-visible summary of currently knowable appearance and personality. Do
  not invent a separate shell `appearance` or `personality` field. Those fields
  are invalid on an NPC shell; put the compact information in `note`.

- Authored NPC `voice` is `null` or omitted. Never infer a TTS/screen-reader
  voice, actor, or character name. Runtime voice assignment belongs to the app.

- Active/current NPC `role`, `relationship`, and `note` must be safe to show to
  the player unless the app explicitly stores them in a private hidden field. Do
  not put future plot facts, hidden allegiances, unrevealed twists, objective
  instructions, or private AI behavior notes in visible NPC fields. For
  uninspected NPCs, keep visible fields especially minimal and describe only what
  the player can currently know.

- `full_character`: Full character definition for inspected/opening important NPCs. Use the current app field names while preserving the immutable/default intent from the character definition contract. Do not make a separate "inspected NPC definition" type.

  The same required `romanceable` and optional gender-fallback fields described
  for `state.characters` apply here and to every future-cast full character.

  Full character payloads must be rich enough for play. Main party members and
  important NPCs usually need multiple concrete durable facts, not one generic
  fact. Facts should cover identity, role, personality under pressure,
  usefulness, relationship dynamics, quirks/preferences, and story-specific
  complications when relevant.

- NPC keys and `name` values must be proper character names. Do not create NPCs
  named by title, job, group, or generic description such as `"Gate Guard"`,
  `"Guild Clerk"`, `"travelers"`, `"novice adventurers"`, `"cart drivers"`, or
  `"shopkeeper"`. For original stories, invent a full first-and-last name when
  an NPC needs to speak or exist in the starting state.

## state.future_cast

- `future_cast`: Important future characters not yet introduced or not yet available. This is the current story method for future character storage.

- `future_cast.enabled`: Boolean.

- `future_cast.items`: Object keyed by future-cast id slug. Do not use
  numeric/index object keys such as `"0"` or `"15"` for future cast unless that
  numeric string is truly the stable character id.

- Supported authored shell fields are `id`, `name`, `status`,
  `canonical_order`, `introduce_as`, `can_die`, `npc_location_id`,
  `scene_presence`, `role`, `relationship`, `note`, `personality_description`,
  `greeting`, `full_character`, `meet_condition`, `join_condition`, `on_unlock`,
  `unlocked_by`, and `last_triggered_reason`, plus the required character
  definition fields needed by import/upload validation.

- Future-cast shell validation is strict. `future_cast.items[id]` and
  `future_cast.items[id].full_character` must both satisfy the normal
  EmberAdventures character definition requirements. Do not rely on
  `full_character` alone to repair a thin shell during import. Mirror required
  identity, gender, appearance, outfit, fallback presentation, profile-image,
  relationship/default-state, and speech fields onto the shell when validation
  requires them, and keep those values consistent with `full_character`.

- Humanoid `future_cast.items[id]` shells and `full_character` definitions must
  both include non-empty
  `outfits`, a valid `starting_outfit_id`, non-empty `fallback_outfits`, and a
  valid `fallback_starting_outfit_id`. A genuinely non-humanoid animal, monster,
  spirit, or natural form uses `animal_definition` instead and has no outfit or
  clothing fields. A humanoid character who merely has fur, scales, wings, a
  tail, or another nonhuman feature remains a `full_character` and still follows
  the humanoid outfit contract.

- The story-wide future-cast check must include omissions. If an important
  planned companion, merchant, authority, antagonist, political/family figure,
  side-arc NPC, or future continuity figure is not included, document why in
  notes outside the final JSON or revise the cast.

- `future_cast.items[id].id`: Same slug as the object key. Use a stable
  lowercase id such as `"character-name"`. Objective rewards use
  `future_cast.items[character_id]`, so object key, entry `id`, and reward
  `character_id` must match exactly.

- `future_cast.items[id].name`: Character display name.

- `future_cast.items[id].canonical_order`: Integer ordering hint for future cast.

- `future_cast.items[id].introduce_as`: Use `"npc"`. Current runtime preserves
  this metadata but does not use `"party_character"` to join the party. Joining
  must happen through `promote_future_character_to_party`. Promotion does not
  replace a separate scene-presence reward when the new party member should be
  physically present immediately.

- `future_cast.items[id].can_die`: Optional boolean mirrored into the introduced
  NPC/full character when the story intentionally controls plot armor.

- `future_cast.items[id].npc_location_id`: Stable NPC-directory location id for where the character is introduced. Do not expose locked future names in visible map `npcs`.

- `future_cast.items[id].scene_presence`: Use `"nearby"` for an introduced NPC.
  Do not use `"active"` as a shortcut for party membership. A character joins
  the party only through `promote_future_character_to_party`.

- `future_cast.items[id].status`: Use `"locked"` in immutable templates unless
  the character intentionally starts introduced. Runtime progression may move
  the entry through `"introduced"`, `"recruitable"`, and `"joined"`. Do not
  pre-author a later runtime status merely because the full payload exists.

- `future_cast.items[id].role`: Short job/title/role text. Avoid leaking this through objective text before unlock.

- `future_cast.items[id].relationship`: Starting relationship text, usually `"not yet met"`.

- `future_cast.items[id].note`: Future setup note. Hide from ordinary narrator prompts until relevant.

- `future_cast.items[id].personality_description`: Durable personality summary.

- Store durable dialogue behavior only in `full_character.speech_style`; the
  future-cast shell does not preserve a separate `speech_style` field.

- Future-cast notes, personality summaries, and full-character facts must not
  contain scheduling/process instructions such as `Should not appear before X`
  or `Introduce only after Y`. Put timing in graph inputs, objective rewards,
  `meet_condition`, `join_condition`, or hidden future-cast notes, not in
  character `known_facts`/`starting_known_facts`.

- `future_cast.items[id].profile_images` and shell-level `images` are not
  approved future-cast shell fields and cause validation failure. Inside
  `full_character`, use the canonical blank character image
  fields: blank `default_profile_image`, blank `profile_images`, and blank
  `images`. Generated image history stays local.

- `future_cast.items[id].meet_condition`, `join_condition`: Optional condition text or `null`.

- `future_cast.items[id].on_purchase_objective`: Optional objective id for the
  character's follow-up/purchase story. This is the only approved field name;
  `purchase_story`, `purchase_objective`, and `purchase_story_objective` cause
  validation failure. When the character is introduced by objective reward or purchased
  from a character shop, EmberAdventures starts this objective and selects it
  unless a locked urgent objective is currently active.

- `future_cast.items[id].on_unlock`: Object controlling introduction behavior.

- `future_cast.items[id].on_unlock.greeting`: Optional narrator guidance used
  only when the character unlocks. Do not duplicate it in a top-level
  `greeting` field.
  Keep either form concise and scene-flexible. Do not use unsupported
  `ai_greeting` or `greeting_instruction` keys, and do not write boilerplate
  such as `has just been introduced by an objective reward`.

- `future_cast.items[id].on_unlock.image`: Optional image instruction object.

- `future_cast.items[id].unlocked_by`, `last_triggered_reason`: Empty strings in immutable templates; runtime may fill them.

- `future_cast.items[id].greeting`: Short setup/greeting text for unlock.

- `future_cast.items[id].full_character`: Full character data using the complete
  current `EmberAdventures Character` definition shape. This is embedded
  in the story file so hosted/local imports behave the same.

  Full character payloads must be rich enough for play. Main party members
  usually need 6-10 specific durable facts. Major NPCs usually need 4-6. Minor
  one-scene utility NPCs may be shorter, but one generic fact is draft quality.
  Do not include `power`, active `known_facts`, active `clothing`, active
  `inventory`, active `image`, populated profile/image history, or other
  live/runtime fields in `full_character`.
  `full_character` must pass the same final validation as a standalone character
  definition, including complete gender fallback presentation and non-empty
  outfit arrays. Do not use `{}` as a placeholder outfit for animal or natural
  forms.

## state.objectives

- `objectives`: Objective state defaults and immutable objective definitions.

- Story structure mode is an authoring decision, not a JSON field. Before
  writing objectives, decide whether the story should be Telltale-style
  branching with direct choices and multiple endings, or simpler
  linear/mostly-linear. Do not write that process decision into story JSON.

- Stored/exported JSON keeps the `objectives` object, but normal narrator prompts should not include an `objectives` object inside the `STATE` JSON. If there is an active objective, show it as a plain text prompt section outside `STATE`. Completed-objective handling should use the dedicated completion/turn directive text, not hidden story-source policy metadata.

- Objective prompt visibility is deliberately narrow. Before the active objective
  completes, the narrator and other ordinary turn/verification prompts may receive
  only that objective's player-facing `title`, `summary`/`description`,
  `completion_criteria`, and private `while_active_guidance`. Do not expose
  `completion_instruction`, `rewards`,
  `next_objectives`, route ids, route criteria, future objective details, or other
  private implementation data before completion. Put information that must be
  unlocked at a specific moment in the completing objective's deterministic
  rewards and/or its completion instruction. Only after the engine has confirmed
  completion should the dedicated follow-up prompt provide the completion
  instruction and let the narrator present the newly unlocked information. The
   completion instruction must not be used as a substitute for durable state
   rewards when the revealed fact needs to persist.

- `objectives.active_id`: Id of the active objective at game start, or `""` if no objective starts selected.

- `objectives.no_current`: Boolean indicating no selected/current objective. Usually false when `active_id` is set.

- `objectives.items`: Array of objective objects. Must be an array, not an object keyed by id.

- Objective `id`: Stable slug string.

- Objective `title`: Player-facing objective title. Do not name locked future characters or role spoilers before they are introduced.

- Objective `type`: `"story"` or `"side"`. Dialogue is configured on outputs;
  do not use `"dialogue"` as a separate objective type in clean new stories.

- Objective `kind`: Do not author this redundant editor field in clean normal
  story JSON. Use `type: "story"` or `type: "side"`; the visual editor may derive
  its own `kind` value while editing.

- Objective `status`: Starting status such as `"active"`, `"hidden"`, or `"completed"` only for template initial state. Runtime changes this after play.

- Objective `summary`: Player-facing objective text shown in UI. There is no separate `objective` field.

- Objective `while_active_guidance`: Required non-empty hidden AI-only text on
  every objective. Keep `summary` fully player-facing and put private pacing,
  behavior, secrecy, or scene-direction guidance here. Automatic Transitions
  require it for a uniform auditable objective definition even though their
  runtime resolution makes no AI call. Import and public upload reject missing
  or blank guidance; never omit it or fill it with generic boilerplate.

- Objective `completion_requirements`: Optional array of structured
  requirements that must all remain true before a reached objective can
  progress. Unmet requirements keep a visible objective unavailable and
  prevent completion checks, routing, and rewards.

- Output `rewards`: Array of reward objects, bundle references, or template
  invocations on each `next_objectives`, `choices`, or `outcome_routes` entry.
  Ending rewards belong to the exact ending output. Future character rewards
  must use `character_id` equal to an existing
  `future_cast.items` object key. Do not use old reward bucket objects such as
  `rewards.unlock_locations`, `rewards.introduce_future_characters`, or
  `rewards.story_rules`. Do not use XP, level, rank, or progression-skill
  rewards while progression is shelved.

Supported deterministic objective rewards include: `introduce_future_character`, `make_future_character_recruitable`, `promote_future_character_to_party`, `replace_character_definition`, `unlock_location`, `set_hex_passage_status`, `enable_triggered_objective`, `add_item`, `grant_item`, `add_story_item`, `adjust_story_inventory`, `advance_time`, `complete_generated_job`, `start_objective`, `complete_objective`, `add_story_rule`, `remove_story_rule`, `set_state_field`, `modify_integer`, `modify_number`, `adjust_relationship`, `grant_outfit`, `equip_outfit`, `delete_outfit`, `delete_all_outfits`, `add_state_list_item`, `remove_state_list_item`, `kill_character`, `generate_profile_image`, `generate_solo_normal_image`, `generate_story_image`, `apply_reward_bundle`, and `apply_reward_template`. Do not invent reward types. Use `apply_reward_bundle` only as a reference to `state.reward_bundles`; do not put actual rewards inside the reference. Use `apply_reward_template` only as a typed invocation of `state.reward_templates`. Use `adjust_relationship` for objective-owned trust, attraction, affection, or arousal changes; `preset: "all"` means trust/attraction/affection and `preset: "all_and_arousal"` includes arousal. Use `grant_outfit` to add a complete saved outfit to a stable `character_id`; it does not equip unless `equip: true`. Use `equip_outfit` to atomically apply an already-owned `outfit_id`; never swap outfits by setting `active_outfit_id` directly. Use `delete_outfit` and `delete_all_outfits` only for permanent runtime wardrobe removal, never to rewrite reusable character-definition outfit fields. Use `add_story_item` and `adjust_story_inventory` for controlled story-owned resources/items. Use `advance_time` for additive game-clock pressure from travel, jobs, training, repairs, recovery, research, shopping, and chapter transitions. Use `complete_generated_job` only inside generated/story job turn-in objective choices. Use `generate_profile_image` only for changes that affect a character's face, hair, arms, torso, chest, shoulders, or overall silhouette. Use `generate_solo_normal_image` for major visible changes that should appear in chat. Leg-only changes should normally generate a solo normal image, not a profile image. Use `generate_story_image` for authored non-character story images such as important objects, locations, clues, ritual scenes, horror reveals, and jump scares. Its generated form is `{ "type": "generate_story_image", "id": "stable-image-id", "title": "Optional Display Title", "prompt": "exact positive image prompt", "negative_prompt": "optional negative prompt" }`; its hosted form uses the same reward with `image.url`. It does not require a target character. Every state-path reward must follow the definition-versus-runtime rules in the Rewards section; never target `starting_*`, `default_*`, `players`, or `durable_known_facts`.

`remove_character_shop_listing` is also a supported deterministic reward. It
requires stable `shop_id` and `character_id` values and hides that exact
character-shop listing without deleting the character or NPC.

State-list rewards support all five existing `story_memory` categories:
`world_notes`, `unresolved_threads`, `relationship_notes`,
`rules_and_constraints`, and `ai_private_notes`. Add/remove text in its own
category; private continuity notes remain private rather than becoming public
story rules.

For character `known_facts`, prefer a stable `character_id` with
`field_path: ["known_facts"]`. Exact declared character names and explicit
`|[character:stable-id]|` targets also work. Definition validation can resolve
future-cast declarations without introducing them. At application time the
actual character must exist, or an explicit earlier introduction in that reward
transaction must materialize them. Never mutate the reusable future definition
to give a character runtime knowledge.

`set_state_field` can update an existing event's exact status path:
- `["story_pacing", "timeline", "event-id", "status"]`: `active`, `complete`,
  `cancelled`, `declined`, or `missed`; plot points allow only `active` or
  `complete` through this reward.
- `["timed_events", "event-id", "status"]`: `complete` or `cancelled`.

These writes clear that timeline event's pending invitation but do not complete
its objective, run its rewards, reset its clock, or undo already-applied stages.
Use a separate `start_objective` reward when an authored branch must also start
an objective. Schedule activation/reset belongs to the owning scheduler; do not
use `create_path` or fabricate an event. Timers use canonical duration objects
in `time_limit` and stage `after`, never legacy minute fields.

Objective definitions under `state.objectives` are immutable during play.
Never target `objectives` or `state.objectives` with `set_state_field`,
`modify_integer`, `modify_number`, `add_state_list_item`,
`remove_state_list_item`, character-shop effects, or any equivalent state-path
reward. This rule applies recursively to normal objective rewards, choice and
outcome-route rewards, reward bundles, reward templates, shops, timed events,
and story-pacing events. Use `start_objective` and `complete_objective` with
stable ids of already-authored objectives for runtime objective transitions.
Story import and public upload reject authored objective-state mutations.

`introduce_future_character` must include `npc_location_id`, pointing to an
existing stable `state.npc_directory.locations` key. It may include
`npc_location_label` only as display text when creating a new runtime bucket.
Do not use the old `npc_location`, `location_hint`, or a player-facing location
name as an NPC directory key.

- Objective `requires`: Optional array of existing objective ids. Every listed
  prerequisite is required. When the target has no explicit incoming output,
  this list also provides its implicit incoming dependency; when explicit
  incoming groups exist, `requires` gates those groups rather than replacing
  them. Do not duplicate the same dependency in both forms.

- An ordinary side objective with `completion_control: "player"`, `"ai"` or `"cutscene"`
  and no `route_control: "ai"` may omit outputs or use `next_objectives: []`.
  It finishes that task, clears its side focus and returns to the existing main
  objective without ending the story. Put its immediate result in the objective
  `completion_instruction` and deterministic effects in its `rewards`. Do not
  add a fake successor or a freeplay ending merely to finish a side errand.
  Main objectives, Player Choices, AI-routed side objectives and Automatic
  Transitions still require explicit continuing or ending outputs.

- Objective `next_objectives`: Optional ordered array on the objective that just
  completed. Use it for deterministic Linear/Branch outputs on Player Action
  and Automatic Transition families, plus Linear AI outputs. Every entry is an
  object with a unique stable `id`, destination `objective_id`,
  `target_input_group_id`, `completion_instruction`, optional
  `dialogue_lines`, `requirements`, `rewards`, and optional
  `travel_location_id`. Deterministic Branch entries are checked in displayed
  order; the first eligible output is used. Put one unrestricted
  `fallback: true` output last when fallback behavior is needed.

- Output `target_input_group_id`: Stable generated group id on every
  continuing output. At the destination, incoming transitions sharing one
  group id are AND requirements; different group ids are OR alternatives.
  Track the specific selected output transition, not merely completion of its
  source objective.

- Output `requirements`: Optional structured eligibility requirements for that
  result only. Player-facing output requirements remain visible. AI route
  requirements are private. A reward that spends a bounded resource must have
  a matching output requirement proving sufficient quantity.

- Output `completion_instruction`: Required authored narrator guidance for that
  result. It describes the immediate outcome, consequence, reveal, transition,
  or travel arrival. Do not put future objectives, route ids, or implementation
  instructions into it.

- Output `ending_type`: Optional on entries in `next_objectives`, `choices`, or
  `outcome_routes`. It must be exactly `"freeplay"`, `"ending"`, or
  `"game_over"`. When present, omit the destination field and
  `target_input_group_id`. `ending_title` and `ending_message` are optional text
  on that same output. Objective-level `terminal`, `terminal_mode`, and
  `end_state` are not approved fields.

- Objective `route_control`: `"ai"` only when hidden consequences must be
  classified from natural scene context. Omit it for normal routing; an empty
  string is invalid.

- Objective `outcome_routes`: Hidden array used only with
  `route_control: "ai"`. Each route has a unique stable `id`, private
  `criteria`, optional structured `requirements` used as hard eligibility
  filters, `completion_instruction`, deterministic `rewards`,
  and either `next_objective_id` plus `target_input_group_id` or `ending_type`.
  By default exactly one route has `fallback: true`, and that route
  must have no requirements. The runtime records
  `selected_outcome_id` privately and applies base plus selected-route rewards
  once. Authors must not prefill runtime selection fields.

  Optional `unresolved_route_behavior: "keep_pending_no_effects"` is allowed only
  with AI routing. In this mode there is no fallback; an undetermined/invalid
  classification leaves the objective pending without completion, transition or
  objective effects. A side outcome may omit its successor/ending and simply
  finish its task. See [numeric eligibility and pending outcomes](numeric-requirements-and-pending-outcomes.md)
  for the complete contract and example.

- Objective `travel_location_id`, `travel_location_name`: Optional travel target metadata.

- Objective `unlock_mode` is not an approved field and causes validation
  failure. Automatic Transitions use grouped output transitions plus
  `completion_control: "reward_only"` and `requirement_check_only: true`.

- Objective `exclusive_group`: String. Use `""` when not needed. Use a stable
  branch id on the visible owner objective for a mutually exclusive choice
  cluster. Do not put each option in the objective list. Later objectives in a
  branch should usually leave this blank and use their incoming output
  transitions plus selected-choice story rules/state changes for gating.

- Objective `selectable`: Boolean. Whether the player can manually select this objective.

- Objective `locked_until_complete`: Boolean. In `player_controlled` stories,
  use `true` only for urgent time-sensitive active objectives that must be
  finished before the player can switch to side objectives or clear the current
  objective. In `time_controlled` stories, every main story objective that can
  become active before final aftermath/freeplay should use
  `locked_until_complete: true`. Timed events may start a locked objective when a
  deadline, attack, collapse, arrest, rescue window, battle for a city, scheduled
  meeting, political session, relationship set-piece, or other authored main
  event arrives.

- Objective `available_now`: Starting availability boolean. Runtime may change it.

- Objective `blocked_reason`: Starting blocked reason string. Use `""` when not blocked.

- Objective `notes`: Array of objective notes. Keep internal/AI notes out of player-facing fields.

- Objective `choices`: Array used only when `completion_control` is `"choice"`.
  Each choice output has a stable `id`, visible `title`, optional `summary`,
  destination `next_objective_id`, `target_input_group_id`,
  `completion_instruction`, optional `dialogue_lines`, `rewards`,
  `requirements`, and optional `effects`. These are options shown in the forced
  choice UI, not top-level objectives. Use player-facing `summary` only for
  non-spoilery clarification. Keep `effects` empty unless they show visible
  requirements, costs, or story-inventory changes.
  Do not reveal hidden outcomes such as death, failure, sale, romance,
  betrayal, ending, route labels, unlock labels, hidden recommendations, or
  unchosen branch consequences in the choice UI. Bad visible `effects` examples
  include `Bad ending route`, `Hana affection route`, `Unlocks Mira treatment
  route`, `Fail-forward dark route`, and `Best with first law: Truth or
  Freedom`. Good visible `effects` examples include `credits -80`, `trust >=
  6`, `suspicion +1`, and `requires cellar key`.
  Auto mode may complete choice objectives without opening the UI. It asks the
  AI to choose among currently selectable options using only player-visible
  state and recent context; it does not use array order or an author-selected
  preferred route. Unless every option is intentionally fatal or ending-only,
  provide at least one selectable continuation option with no requirements that
  keeps the story moving.

- Objective `choice_response_mode`: `"optional_text"` lets the player select an
  option and optionally type additional text. `"exact_text"` requires
  non-empty `player_text` on every choice output and sends that exact authored
  player dialogue. Use exact text for a precise spoken line; use optional text
  when the player should retain control over wording.

- Objective `completion_message`: Optional completion message string. Use `""` if not needed.

- Output `dialogue_lines`: Optional non-empty ordered array of exact character
  dialogue lines on a `next_objectives`, `choices`, or `outcome_routes` entry.
  Each line uses a parenthesized speaker tag and quoted dialogue, for example
  `(|[character:mentor-id]|) "Exact line."`. The narrator must include every
  line exactly once in order when that output resolves. The same output's
  `completion_instruction` directs the whole response.

- Objective `completion_control`: `"player"` creates a Player Action family;
  `"ai"` creates an AI Scene family; `"choice"` creates a Player Choice family;
  `"reward_only"` is valid only with `requirement_check_only: true` for an
  Automatic Transition family; and `"cutscene"` delivers one fixed beat after
  a completed narration, with a nonempty `completion_instruction` and omitted
  `completion_criteria`. Cutscenes allow no completion/output requirements,
  choices, AI outcome routing or activation checks and at most one output.
  Use the Objective Behavior Names table rather
  than treating these storage values as unrelated schemas.

- Objective `evaluate_ai_on_activation`: Optional `true` only with
  `completion_control: "ai"`. It converts an AI Scene family into Immediate AI:
  one AI completion decision runs when the activation is reached. A no answer
  is remembered for that activation, leaves the objective available, and does
  not prevent normal later AI completion checks.

- Objective `requirement_check_only`: Optional `true` only with
  `completion_control: "reward_only"`. It creates an Automatic Transition
  family, omits `completion_criteria`, makes no AI call, and resolves only from
  graph reachability plus structured `completion_requirements`.

Automatic Transition rules:

- Keep it hidden from the normal objective list; it is graph infrastructure.
- It may apply rewards, travel, or no state change at all before routing.
- It must have at least one valid continuing or ending output.
- It cannot contain player choices, dialogue, AI route criteria, or a
  completion condition.
- Do not use it to deduplicate repeated rewards; use `state.reward_bundles` or
  typed `state.reward_templates`.

## state.reward_bundles

`state.reward_bundles` is optional. When present, it is a map of stable bundle
ids to arrays of normal rewards or other bundle references:

```json
"reward_bundles": {
  "reward-pack-rescue-earned-trust": [
    {
      "type": "add_story_rule",
      "rule_id": "rescued_lyra",
      "text": "Lyra believes the player risked themself to rescue her."
    },
    {
      "type": "adjust_relationship",
      "target": "Lyra",
      "trust": 2,
      "affection": 1
    }
  ]
}
```

Reference a bundle from an objective, direct choice, hidden outcome route,
timed event, or timeline event:

```json
"rewards": [
  "reward-pack-rescue-earned-trust"
]
```

or:

```json
"rewards": [
  {
    "type": "apply_reward_bundle",
    "bundle_id": "reward-pack-rescue-earned-trust"
  }
]
```

Use bundles when two or more places need the same exact deterministic effect.
Example: if three possible objectives can all prove the player protected a
companion, put the trust/fact rewards in one bundle and reference the bundle
from all three objectives. Do not paste the same `add_story_rule`,
`adjust_relationship`, `set_state_field`, or inventory reward into multiple
tree locations.

Use inline rewards when the effect is unique to one place. If only one route
gives an extra clue, keep that clue inline in that route. If two routes share a
base effect and one has an extra effect, reference the shared bundle plus an
inline extra reward on the route that needs it.

Use reward-only objectives when the objective graph itself needs a shared
transition point, such as several branches converging into one hidden node that
applies rewards and selects the next beat. Reward-only objectives and reward
bundles can be used together, but they solve different problems: bundles remove
duplicate reward definitions; reward-only nodes shape the graph.

  For Telltale-style stories, use `"choice"` owner objectives for direct menu
  choices. The owner objective is the only top-level visible objective; put the
  options in a `choices` array. Later objectives in that branch should require
  the owner objective and rely on the selected option's rewards, story rules,
  relationship changes, or state changes to preserve the chosen path. Failure
  or death choices may use `kill_character` with `ignore_can_die: true` when
  the story objective owns the death outcome. For simpler linear stories, do
  not add fake menu choices.

- `story_inventory`: Optional state object for resources controlled by the
  story/objective system, such as credits, parts, suspicion, reputation,
  evidence, or repair supplies. Use objective rewards with `field_path` values
  under `story_inventory` to change these resources; do not rely on narrator
  prose or the AI to freely edit them. Choice UI may show concrete visible
  resource requirements/effects such as `credits +500` or `credits >= 1200`.

- Objective route integrity: Every main objective must have a planned
  route forward through `next_objectives`, `choices`, or `outcome_routes`, and
  every output has either a valid destination/input group or an `ending_type`.
  An objective with no output is invalid. Do not rely on fallback objective
  picking as normal story flow.

- `story_shops`: Optional hidden object for story shops and job boards. Keys are
  stable shop ids. Each shop has `id`, `title`, internal `type`
  (`"character"`, `"job"`, `"general"`, or `"clothing"`), display-only `subtype`, optional
  `description`, `unlocked`, `currency`, display-only `location`, required
  `npc_location_id`, optional `owner_npc_id`, and `items`. `npc_location_id`
  must be a nonempty stable id resolving to `state.npc_directory.locations`;
  `location` is display text only. `story_shops` is not sent
  wholesale to normal narrator prompts.

  Character shop items reference `future_cast.items[id]` with `character_id`
  and may include `price`, `purchased`, `locked`, structured `requirements`,
  `unlock_reason`, and `on_purchase_objective`. `on_purchase_objective` is the
  only approved field name; `purchase_story`, `purchase_objective`, and
  `purchase_story_objective` cause validation failure.
  When a purchased or introduced future-cast character has one of these fields,
  EmberAdventures starts that objective and selects it unless a locked urgent
  objective is currently active. Do not duplicate full character definitions in
  shop items. Locked character-shop cards remain visible but show
  only the character name, a generic locked image, and the visible unlock
  requirement/reason; they do not show the real image, details, or price.
  Unmet requirements and insufficient funds keep non-secret character details
  visible. Character shops must define arbitrary non-empty `purchase_verb` and
  `purchase_completed_verb` strings; the first is used for the command and the
  second in completed-action text. The game never infers these words. They may
  also define
  `post_purchase_presence` (`"current_scene"` or `"roster"`).

  Character shops and individual listings may define `purchase_mode:
  "acquire"` or `purchase_mode: "service"`. Acquire is the one-time default and
  adds the character to the owned roster. Service keeps the character as an NPC;
  use `repeatable: true` when it may be purchased repeatedly. Service purchases
  increment runtime `purchase_count`, add the character to current NPC presence,
  and may start `on_purchase_objective`, but never recruit or add party
  presence. Use `remove_character_shop_listing` with `shop_id` and
  `character_id` when an objective should permanently hide one listing.

  General shops use `markup` and optional `buying.enabled`. Their listings own a
  normal `item`; retail price is `ceil(item.value * markup)`, while merchants
  buy eligible inventory at exactly `item.value`. A general-shop listing may
  also have a `rewards` array with the complete objective reward grammar,
  including reward-bundle ids and typed reward-template invocations. Those
  rewards run on every successful unit purchase after the listing's normal
  `item` is granted. Do not duplicate the listed item inside `rewards` unless an
  extra copy is intentional. Clothing shops own complete
  outfit listings with explicit positive integer `price` and `outfit`; purchases add the preset
  to one selected owned character without equipping it.

  Job boards use `type: "job"`, `visible_count`, and optionally
  `generic_jobs_enabled: true`. Generated jobs are EmberAdventures-authored engine
  content, not AI-generated story prose. Templates should normally leave
  `story_job_offers`, `story_job_offer_history`, `active_generated_jobs`, and
  `story_generated_npc_pool` empty unless deliberately starting with an active
  generated job.

  Job-board `items[]` are story-authored one-time jobs, not randomized generic
  jobs. Each may include `id`, `title`, `summary`, `genres`, `rank`, `nsfw`,
  `requirements`, `reward_coins`, `reward_xp`, `reward_items`,
  `client_npc_id`, `start_location`, `completion_criteria`, and
  `completion_instruction`. `start_location`, when present, must be an object
  with normal location keys such as `world`, `region`, `settlement_name`,
  `district`, and `specific_place`; do not use a string location id. Do not
  include `on_accept_objective` on story job items; the job-board accept path
  creates its own generated side-objective flow from the job item fields and
  does not start authored objective ids. Do not write completion criteria or
  instructions that depend on a separate linked authored objective chain; if
  the story needs an authored chain, create it as normal objectives outside the
  job board. Write job instructions as playable runtime guidance, such as
  where the job starts, what problem the player must solve, what proof or
  result counts, and how payment is claimed. Do not store schema commentary
  such as `generated from the board`, `linked objective`, or `authored
  objective` in player/runtime job text.
  Every label in a job item's `genres` array must be present in the story's
  public `genres` for that job to appear. Use this for curated story-specific
  contracts with explicit unlock conditions. Generic rotating jobs are
  controlled by `generic_jobs_enabled` and the engine's genre-labeled job pool.

  Structured requirements use objects such as
  `{ "path": "story_inventory.coins", "op": ">=", "value": 120 }`.
  Supported operators are `>=`, `>`, `<=`, `<`, `==`, `!=`, `truthy`, `falsy`,
  `includes`, and `not_includes`. For common story conditions, prefer explicit
  typed requirements instead of fragile path/list checks:
  `{ "type": "objective_complete", "id": "objective-id" }`,
  `{ "type": "story_rule", "id": "rule-id" }`,
  `{ "type": "known_fact", "target": "stable-character-id", "id": "fact-id" }`,
  `{ "type": "party_member", "target": "stable-character-id" }`,
  `{ "type": "character_alive", "target": "stable-character-id" }`,
  `{ "type": "character_dead", "target": "stable-character-id" }`, and
  `{ "type": "currency", "id": "coins", "op": ">=", "value": 120 }`.
  Use direct path requirements for concrete `story_inventory`, `world_flags`,
  player, character, NPC, or map fields when a typed shortcut does not exist.
  For exact arithmetic eligibility, `type: "numeric_expression"` uses expression,
  a numeric comparison op and finite numeric value. See
  [numeric eligibility and pending outcomes](numeric-requirements-and-pending-outcomes.md).
  Upfront gates belong before rewards; deterministic next-output requirements
  retain their existing after-reward routing semantics.
  Completion Requirements and player-choice/deterministic Output Requirements
  are player-visible, so their human-readable descriptions must not reveal
  spoilers. Only AI `outcome_routes` criteria and requirements are private.
  For numeric resource rewards or costs, use `adjust_story_inventory` with a
  positive or negative delta. Do not use `set_state_field` on
  `story_inventory.coins`, `story_inventory.credits`, XP, rank progress,
  reputation, suspicion, or parts unless the story intentionally needs an exact
  absolute assignment.

- Objective `completion_criteria`: One verifier-only condition. The verifier
  returns exactly `yes` or `no`. Required for Player Action, AI Scene, and
  Immediate AI; omitted for Player Choice and Automatic Transition.

- Output `completion_instruction`: Narrator-only instruction used when that
  output resolves. Use it to show consequences, travel, reveals, and predefined
  future-cast introductions. Do not use it to decide player choices. Ending
  instructions stay on the exact ending output.

  Write this as a direct story instruction for this objective's immediate
  outcome. Do not paste broad boilerplate such as `Show the immediate story
  outcome without introducing future characters...`. Apply hidden-future rules
  while writing the instruction, but do not store the rule itself as the
  instruction. Good: `The player steps outside and sees smoke, fleeing
  villagers, and bandits attacking the road.` Bad: `Show the immediate story
  outcome without introducing future hooks unless rewards unlock them.`

- Objective `auto_completed_from_prereqs`: Runtime-derived compatibility state.
  Do not author it in immutable templates.

- Forbidden objective fields: Do not use `objective`, nested `completion`,
  `steps`, `current_step_id`, `selected_step`, `selected_step_id`, authored
  `repeatable`, or old step-based fields. `unlock_mode`,
  `objective_mode`, `timeline_event_id`, and `auto_completed_from_prereqs` are
  also invalid. Any listed field causes validation failure. `requires` is the
  approved first-class prerequisite field described above.

## state.world_flags

- `world_flags`: Concise durable facts about the starting world's tone or
  conditions. Every entry must describe the fictional world itself.

- Never author `world_flags.adult_content_rule`, content-mode policy, user
  preferences, creator/process notes, future-system notes, or future-cast
  scheduling. Put active behavioral constraints in `story_rules`, ordinary
  continuity in `story_memory`, and deterministic unlock timing in objectives
  and `future_cast`.

## state.story_rules

- `story_rules`: Array of durable story-rule objects used as hidden progression constraints. Each rule is `{ "id": "stable-rule-id", "text": "Current rule text." }`.
- Story rules are sent to most narrator/state/image-related AI prompts as text under STORY_RULES. They are not sent to the auto-player prompt.
- Use story rules for current hard constraints that must guide AI behavior, such as locked romance gates, hidden danger rules, repaired body state constraints, or source/story-specific world rules.
- Do not use `story_rules` as a generic notes dump. If a fact is ordinary lore, put it in `story_memory`; if it is a deterministic unlock/change, put it in objective rewards.
- Do not use `story_flags`. There is no current story flag system.

## state.story_memory

- `story_memory`: Memory buckets the app expects.

- `world_notes`: Durable notes that are genuinely useful and not better expressed as objectives/future cast.

- `unresolved_threads`: Starting unresolved threads. Usually empty.

- `relationship_notes`: Starting relationship notes. Usually empty.

- `rules_and_constraints`: Hard rules only. Avoid broad story planners.

- Story memory is for compact runtime continuity, not story-creation process.
  Do not write notes like `Use objectives as the only story progression system`
  unless the app literally needs that as hidden runtime guidance. Prefer
  concrete continuity facts and constraints.

- `ai_private_notes`: Private AI notes only when needed; hide from
  player-facing UI and ordinary irrelevant prompts. Use concise in-world
  continuity constraints, not story-creation process notes, coverage-table
  reports, omission reports, audit notes, or instructions such as avoiding a
  fake ending.

## state.story_clock, state.story_pacing, and state.timed_events

Triggered side quest trees use the exact `story_pacing.interruptions` namespace in
[short-interruptions.md](short-interruptions.md), in either pacing mode. Omit it
when unused. Its readiness does not change main-story availability semantics.

- `story_clock`: Additive runtime game clock. Immutable story templates should
  start with `{ "elapsed_minutes": 0, "label": "Day 1, 8:00 AM" }` unless the
  premise needs a different visible starting label. Story content should advance
  the clock with `advance_time` rewards, not by directly setting absolute time.

- `story_pacing`: Story pacing and triggered-quest return contract. Its three base
  fields remain required even when the timeline is empty. Pending main plot-point
  availability and optional short interruptions work in either pacing mode.

- `story_pacing.mode`:
  - `"player_controlled"`: creator-facing name Player-Paced Story. Main story
    objectives use ordinary objective flow. Optional pending main plot points
    may become available later without selecting them for the player; see
    [main-plot-points.md](main-plot-points.md).
  - `"time_controlled"`: creator-facing name Time-Controlled Story. The main
    story has authored events that begin at story-clock times or after
    prerequisite objectives. The recommended form includes intentional downtime
    between main events so the player may spend time on side objectives, shops,
    jobs, travel, and exploration, then use the timeline prompt to wait for the
    next main event. In this mode, main story objectives are time-controlled
    commitments, not ordinary swappable guidance.

- Strict Time-Controlled Story is not a separate `story_pacing.mode`; implement
  it with `"time_controlled"` plus back-to-back timeline events and
  time-locked objectives where side objectives/jobs are unavailable until the
  urgent sequence ends. Use it sparingly for scenes that should feel
  intentionally restrictive.

- `story_pacing.timeline`: Object keyed by stable event id. Timeline entries
  are for main-story events that should happen at a meaningful time. They are
  not generic background timers.

- Timeline event fields:
  - `id`: stable event id matching the object key.
  - `title`: short event title shown in timeline prompts.
  - `status`: usually `"waiting"` at template start. Runtime may use
    `"ready"`, `"active"`, `"complete"`, `"missed"`, or `"declined"`.
  - `objective_id`: objective started by this event.
  - `trigger`: object with either `at_elapsed_minutes` for an absolute
    story-clock minute, or `objective_id` for "after this objective completes".
    A trigger may include both.
  - `prompt`: player-facing decision text when the event is ready. Include
    `message`, `accept_label`, and `decline_label`.
  - `accept`: usually `{ "objective_id": "<objective id>" }`. May also include
    normal deterministic `rewards` and `travel_to_location_id`.
  - `decline`: optional `message` and deterministic `rewards` if the player
    intentionally skips the event.
  - `missed_due_to_conflict`: optional `message` and deterministic `rewards`
    when this event starts while another time-locked objective is active.
  - `auto_start`: use sparingly. If true, the event starts as soon as the
    trigger is met instead of waiting for the player prompt.

- In `time_controlled` stories, every main story objective that can become
  active before the final aftermath/freeplay phase should use
  `"locked_until_complete": true`. The timeline event controls when the
  objective starts; do not add `objective_mode` or `timeline_event_id` to the
  objective. A locked objective cannot be deselected or replaced by side
  content until it completes.

- Free time belongs between locked main objectives, not inside them. Create
  downtime by spacing timeline triggers, using objective-triggered future
  events, or prompting the player to wait for the next scheduled event. During
  those gaps, side objectives, shops, jobs, travel, and exploration can remain
  selectable.

- Do not leave a main story objective unlocked in a `time_controlled` story
  merely because the player has time before it begins. If the story is waiting
  for that beat, schedule it later and let the player spend the gap freely.

- The only normal exception is the end of a time-controlled story: after the
  final fight, final conflict, or last scheduled event, remaining aftermath,
  epilogue, romance wrap-up, freeplay, or player-paced cleanup may use ordinary
  unlocked objectives.

- If a locked main objective immediately starts another main-story crisis,
  meeting, battle, negotiation, or relationship set-piece, the follow-up main
  objective should also be time-locked unless it is deliberately part of the
  final player-paced aftermath.

- Use downtime between timeline events intentionally. If a later main event is
  scheduled in the future, EmberAdventures can ask whether the player wants to
  wait for it, with the tradeoff that the skipped time could have been spent on
  side objectives, shops, jobs, travel, or exploration.

- If two important timeline events are intentionally mutually exclusive, schedule
  them close enough that the first time-locked event can cause the second to be
  missed. Author `missed_due_to_conflict` consequences so the world changes
  coherently instead of silently ignoring the missed event.

- Use `time_controlled` pacing when the story benefits from pressure, downtime,
  and scheduled set-piece events. Prefer Time-Controlled Story with deliberate
  gaps over Strict Time-Controlled Story for most guided stories. If the player
  should decide when to pursue the main plot, keep the story
  `player_controlled`.

- Example:

```json
"story_pacing": {
  "mode": "time_controlled",
  "pending_event_id": "",
  "timeline": {
    "briar-moon-invasion": {
      "id": "briar-moon-invasion",
      "title": "Briar Moon invasion",
      "status": "waiting",
      "objective_id": "defend-briar-moon",
      "trigger": { "at_elapsed_minutes": 4320 },
      "prompt": {
        "message": "The Briar Moon invasion begins tonight. Wait for the attack and take part?",
        "accept_label": "Defend the city",
        "decline_label": "Do not go"
      },
      "accept": {
        "objective_id": "defend-briar-moon",
        "travel_to_location_id": "loc-briar-moon"
      },
      "decline": {
        "message": "You stay away. By dawn, the city has changed without you.",
        "rewards": [
          {
            "type": "add_story_rule",
            "rule_id": "briar_moon_not_defended",
            "text": "The player declined to take part in the Briar Moon invasion."
          }
        ]
      },
      "missed_due_to_conflict": {
        "message": "The Briar Moon invasion happened while another urgent event held you elsewhere.",
        "rewards": [
          {
            "type": "add_story_rule",
            "rule_id": "briar_moon_fell_unopposed",
            "text": "The Briar Moon invasion was missed because the player was locked into another urgent event."
          }
        ]
      }
    }
  }
}
```

- `timed_events`: Object keyed by stable event id. Use timed events when the
  story needs background consequences, private deadlines, warnings, or world
  changes that are not the main objective spine. Good uses include injuries
  that worsen after a window, enemies advancing in the background, missed
  meetings, shops/jobs rotating after time, rescue deadlines, rival plans, and
  world events that become visible if the player ignores them.

- Timed event fields:
  - `id`: stable event id matching the object key.
  - `title`: short private/authoring title.
  - `status`: usually `"waiting"` at template start. Runtime may use
    `"active"`, `"complete"`, or `"cancelled"`.
  - `visibility`: `"hidden"`, `"vague"`, or `"visible"`. Use `"hidden"` for
    private timers, `"vague"` for pressure the player should sense without exact
    mechanics, and `"visible"` for explicit deadlines.
  - `trigger`: object with `objective_id` or `immediately: true`. The timer
    starts when the trigger is met.
  - `time_limit`: object such as `{ "hours": 24 }` or
    `{ "days": 2, "hours": 6 }`.
  - `cancel_objective_id`: optional objective id that cancels the event if
    completed before the deadline.
  - `message`: optional player-visible game message when the deadline fires.
  - `stages`: optional warning/escalation array. Each stage has `id`, `after`,
    optional `visibility`, optional `message`, and optional `rewards`.
  - `rewards`: normal deterministic reward objects applied when the deadline
    fires.

- Do not use `timed_events` as the main-story scheduling system. Use
  `story_pacing.timeline` for scheduled main-story events and use
  `timed_events` for background consequences.

Example:

```json
"timed_events": {
  "litia-power-failure": {
    "id": "litia-power-failure",
    "title": "Litia power failure",
    "status": "waiting",
    "visibility": "vague",
    "trigger": { "objective_id": "find-litia" },
    "time_limit": { "hours": 24 },
    "cancel_objective_id": "repair-litia-core",
    "message": "Litia's damaged core has failed. The chance to save her has passed.",
    "stages": [
      {
        "id": "power-warning",
        "after": { "hours": 12 },
        "visibility": "vague",
        "message": "Litia's power is fading faster than expected."
      }
    ],
    "rewards": [
      {
        "type": "kill_character",
        "target": "Litia",
        "ignore_can_die": true
      },
      {
        "type": "add_story_rule",
        "rule_id": "litia-dead-from-delay",
        "text": "Litia died because her major damage was not repaired in time."
      }
    ]
  }
}
```

## Runtime Temporary Speaker State

- Do not include temporary speaker state in exported story templates. It is
  mutable runtime state only. If someone can speak in the opening/starting
  scene, create a real named NPC entry in `npc_directory` and reference that
  proper name from scene arrays/opening voice tags.

## state.recent_changes

- `recent_changes`: Must be an empty array for exported story templates. New game files should not start with stale change logs.

## Opening Messages

- Opening messages array should contain at least one assistant narrator message.

- Opening messages are not save messages. They must contain only the immutable starting narrator/setup messages needed before live play begins.

- If prewritten opening dialogue comes from a known opening character/NPC, put a hidden voice tag immediately before **every** quoted spoken line using `(Full Name) "spoken words"`. Do not include gender in the tag. The tag must be a real predefined character's proper name, not a title/job/group/generic description such as `(Gate Guard)` or `(Guild Clerk)`.

- Voice tags route only quoted dialogue. Keep action prose and narration outside the quotes; it will use the Narrator voice. Do not rely on a standalone name heading, a bold name, `she says`, `he replies`, a nearby mention of the character, or a prior tag to identify later opening dialogue. Those forms do not reliably assign a character voice. Repeat the `(Full Name)` tag before each separate quoted line, including lines spoken by the same character after narration or another speaker.

  Correct: `(Avery Stone) "The gate is open." Avery steps aside. (Avery Stone) "Go now."`

  Incorrect: `Avery Stone\n\n"The gate is open," she says. "Go now."`

- Use plain ASCII quotes for spoken dialogue. Curly quotes can break tag stripping/voice assignment.

- The opening should start playable action immediately and end with a concrete action the player can take.

## AI Visibility Rule

The story template may store future cast, future objective instructions, rewards,
hidden locations, hidden original-story knowledge, and default image metadata.
Normal gameplay AI must not receive the raw full template. Build task-specific
projections so the narrator sees only current runtime state, known current
characters/NPCs, visible/current location, and the active objective projection.
Future-cast `full_character` data is hidden until an objective reward or current
context makes that character relevant.
Outcome route ids, criteria, requirements, unchosen routes, and selected route
metadata are private process data. They must never appear in objective banners,
completion messages, narration, choice menus, or player-visible effects.

## Player-Visible Field Rule

Before final export, audit every field that can appear in a library card,
story-definition UI, map, objective list, opening message, character card, or
read-only definition view. Player-visible fields must not reveal hidden future
cast, future party roles, future locations, unrevealed twists, objective rewards,
private AI instructions, locked relationship outcomes, or implementation notes.

At minimum, audit `storyTemplate.title`, `storyTemplate.description`, public metadata, `messages[]`, `state.location`, `world_map.locations[*].name`, `summary`, `detail`, `npcs`, `scene.summary`, objective `title` and `summary`, current NPC `role`, `relationship`, `note`, and any embedded character fields that the library/editor can display.

Public-library cards may show counts and tags, but not hidden future-cast names, hidden objective titles, future location names, or locked side-arc spoilers.

## Public Hosting Metadata

Public hosted stories need enough metadata for Supabase/library search before upload:

- required base metadata: `source`, `creation_tool`, approved `genres`, `nsfw`, and `loli`
- required default image: a real hosted/default `title_card_image.url`; never
  fabricate a URL when no hosted image exists
- required character images: every embedded character definition needs
  real resolving `profile_image_presentations.male` and
  `profile_image_presentations.non_male` candidates before upload. This includes
  `state.player`, every `state.players[]` option, `state.characters`, nested NPC
  `full_character` entries, and every `future_cast.items[id]` shell and
  `full_character`. If real authored images are not available at story authoring
  time, leave those slots null/blank and generate or assign real images in
  EmberAdventures before publishing. Never use fake image data, transparent data
  URLs, or placeholder image objects. The `default_profile_image` slot should
  remain null/blank until it can match one of those real presentation slots.
- derived library counts: player-select boolean/count, main objective count, side
  objective count, future character count, starting party member count, and
  starting NPC count

The application derives those counts from the story during publishing. Do not
author them as extra `storyTemplate` fields. In the public-library record the
current field is `starting_party_member_count`, not
`starting_character_count`. Public story definitions must not include
player-specific `last_played`, live save data, or local-only image ids.

## Story Image Rules

- User image uploads are allowed only for the story title card. Never upload a
  player, party, NPC, future-cast, or other character profile image. Character
  portraits must be generated from the structured character definition.
- Story title-card generation follows the story's `nsfw` classification.
  Character profile generation follows the character classification, or the
  exact prompt outfit classification when the character is SFW. Normal scene
  and event images generated during play follow the runtime session mode.
- Generated image classification is immutable. Never relabel an image generated
  in NSFW mode as SFW. An uploaded title card may be declared SFW only through
  EmberAdventures' uploader attestation. That record includes uploader id,
  classification, timestamp, and policy version.
- A SFW story cannot be publicly published while any selected title, character
  profile, authored reward, unlock, or other story image is NSFW or unclassified.
  If any embedded character is inherently NSFW, import upgrades the whole story
  to NSFW and publishing offers the same local upgrade or aborts before network
  activity.
- Downgrading a story to SFW performs structural and character checks first.
  It then asks for the uploaded title-card attestation when needed. Generated
  NSFW title images and selected NSFW character profile images are deselected;
  they are never reclassified.

- Every authored story image must support a real hosted URL. Use a portable
  nested slot for ordinary story assets:

  ```json
  {
    "image": {
      "url": "https://example.com/image.png",
      "hosted_url": "https://example.com/image.png",
      "local_image_id": "",
      "source": "hosted",
      "prompt": "Optional prompt or provenance metadata",
      "negative_prompt": "",
      "seed": null,
      "model": ""
    }
  }
  ```

  `url` is the portable reference; when `hosted_url` is present, keep it equal
  to `url`. `local_image_id` is optional local runtime linkage and must never be
  the only image reference in a public story. Never author placeholder, blank,
  transparent, or fake images. A missing real image is `null`/absent until a
  real hosted or generated image exists.
- Use this nested slot on `generate_profile_image`,
  `generate_solo_normal_image`, and `generate_story_image` rewards; story
  inventory items; general-shop items; curated/generated job reward items;
  clothing-shop outfits; and any granted outfit that intentionally owns image
  art. The runtime resolves an existing local image first, then the hosted URL,
  then generates from the prompt. A resolved hosted image must not trigger a
  Perchance request.
- `generate_profile_image` and `generate_solo_normal_image` may omit the nested
  image to generate from the current runtime character. `generate_story_image`
  must have either a real image reference or a prompt. Hosted story-image
  rewards may omit the prompt, though useful prompt/provenance metadata is
  encouraged.
- A generated `generate_solo_normal_image` reward may additionally carry
  optional top-level `description` and `background` strings as documented in
  the Rewards section. These fields affect only generated solo images; a real
  nested hosted `image` is used directly and does not invoke the generator.
- `title_card_image` and character `profile_image_presentations` remain their
  specialized schemas documented elsewhere. They still require real hosted
  URLs for public upload; do not replace those fields with the generic nested
  slot.
- `title_card_image` stores the active/default story image reference only.
- Story title-card image history is local data outside the story definition.
- Deleting a story definition must not delete local story images; reimporting the same story should be able to reuse existing local title-card images.
- Public story publishing requires a default hosted title-card image.
- `title_card_image.prompt` must describe only the cover/background image. Do
  not ask the image generator for title text, readable text, exact title text,
  logos, typography, subtitles, captions, UI text, or character-name lettering.
  EmberAdventures overlays the story title itself. Keep
  `title_card_image.negativePrompt` blank; the current normal exporter clears it.
- Ordinary Generate new story image builds fresh visual guidance from the story
  premise and `title_card_subjects`; it does not recycle a finished image's
  stored provider prompt. Use Image Lab for an explicit custom prompt. Image
  history retains each completed request for provenance.
- Keep positive image guidance about visible scenery and composition. The app's
  negative prompt owns lettering/logo/signature exclusions; do not insert the
  application name, a reserved title overlay, or phrases such as "no signatures"
  into the positive image description.
- Authored `generate_story_image` objective rewards may
  include `negative_prompt` when it helps prevent wrong objects, extra people,
  text, logos, or unsafe content.


---


For the exact `set_hex_passage_status` fields and passage ownership rules, see
[hex-exploration.md](hex-exploration.md#authored-passage-status-rewards).


## Optional fixed combat

`state.combat` opts into the single fixed combat system. See [combat.md](combat.md)
for its exact control/receipt schema, six numeric character stats, BASE damage
contract, and `set_combat_active` objective reward. It accepts no story-defined
equations or alternative damage mode. Omit the root for ordinary stories.