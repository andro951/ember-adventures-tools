# Pending main-story plot points

Use this timeline variant for main-story opportunities that should become
available later without choosing for the player. It works in either pacing mode.
Keep the objective graph for important plot milestones and detailed scenes.
This does not replace ordinary timed/urgent timeline events.

Author each point under `state.story_pacing.timeline` with an exact matching key
and id. These are the required fields:

```json
{
  "kind": "plot_point",
  "id": "workshop-note-ready",
  "title": "The workshop note is ready",
  "order": 0,
  "status": "waiting",
  "objective_id": "read-workshop-note",
  "trigger": {
    "objective_id": "ask-about-repairs",
    "at_elapsed_minutes": 3
  },
  "rewards": []
}
```

The target must be an existing main objective, normally initially hidden.
Keep its ordinary completion criteria, guidance, rewards, outputs and endings.
Connect it through the objective graph as usual. Incoming transitions must not
travel for the player or narrate this later opportunity prematurely. Finish the
previous beat and allow the player to pursue optional activities while waiting.

`order` is a unique non-negative integer. Only the next waiting point in this
order is evaluated. Each main objective may have only one availability point.
The trigger's optional `objective_id` is a hard completed-objective prerequisite.
Do not require a point later in the same queue or create a self-dependency.

`at_elapsed_minutes` is an absolute non-negative integer on the existing story
clock. It is not a calendar date, turn count, or delay reset on reload. Seven
elapsed days is 10080 minutes. For a paced point, add or substitute a nonempty
`readiness_guidance` string:

```json
{
  "objective_id": "read-workshop-note",
  "readiness_guidance": "After the note is read, allow an ordinary conversation or optional activity. Reveal the next opportunity at a natural pause without assuming agreement or travel."
}
```

At least scheduled minutes or readiness guidance is required. When both appear,
the time is a hard earliest threshold and the model also evaluates the guidance.
The engine checks readiness against established context and expects one exact
plain-text yes/no readiness line. Guidance is private; do not put it in the
player-facing objective summary or title.

An unlock makes the main objective available. It does not select it over a side
task, override Stop Tracking, accept a request, teleport, lock it until complete,
or mark it missed because the player is busy. The player receives one OK notice:
“A new main story objective has unlocked.” followed by the objective name.
While main story remains pending with no available main objective, the badge is
“Keep playing to continue the main story.” No countdown or author guidance is
shown. Use the ordinary urgent timed-event system for deliberately missable or
locking events; do not add accept/decline/auto_start fields to this variant.

Availability `rewards` may use only `add_item`, `add_story_item`,
`adjust_story_inventory`, `add_story_rule`, `remove_story_rule`,
`generate_profile_image`, `generate_solo_normal_image`, or `generate_story_image`.
They still use the normal exact reward schemas and once-only reward journal.
Other state/control/travel rewards belong on an explicit authored interaction
or completed objective. The target objective retains its normal full reward
contract.

Runtime status becomes `active` when available and `complete` after its objective
completes. Optional runtime receipts `unlock_notice_shown` (boolean) and
`last_readiness_message_id` (text) are engine-owned; omit them from fresh stories.
The exact record field set is in `field-sets.json` under MAIN_PLOT_POINT_FIELDS;
trigger fields are MAIN_PLOT_POINT_TRIGGER_FIELDS. Do not invent aliases.

The complete [plot-point-story.json](plot-point-story.json) example supplies a
scheduled point, a paced point, and an optional festival side task. Validate the
entire story and manually play the availability/selection/save-reload cases;
schema validity alone does not prove model pacing quality.
