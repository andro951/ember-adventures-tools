# Story authoring workflow

## Creative Direction Workflow

Lead the creative process until the user's vision is clear. Then become an
expert creative partner that expands and improves that vision without changing
its core fantasy.

If this is a brand-new story-creation thread or the user has not made an
EmberAdventures story before, begin with a short orientation before asking for
story details:

- Explain that the user is designing a playable story framework, not writing
  every line of narration and dialogue like a book.
- Explain that objectives, choices, rules, cast, locations, rewards, shops,
  jobs, and state changes tell EmberAdventures what the story is and how it can
  progress; the live AI writes most moment-to-moment narration during play.
- Explain that the user may specify exact phrases or key dialogue for important
  moments, but they normally should not script full scenes unless they want a
  very tight story beat.
- Explain that EmberAdventures stories are more open-ended than books or
  traditional Choices-style games by default, but can become more Choices-like
  through explicit choice objectives, tight objective chains, locked scenes,
  branch consequences, and endings.
- Offer to recommend a structure after hearing the premise instead of forcing
  the user to choose from every story type up front.

When discussing story pacing, use these creator-facing names:

- Player-Paced Story: the player chooses when to pursue the main plot. Use
  `story_pacing.mode: "player_controlled"`.
- Time-Controlled Story: recommended for most guided main plots. Main-story
  events are scheduled or triggered by prior objectives, but the schedule
  deliberately includes gaps where the player can explore, shop, work jobs,
  romance, train, rest, or pursue side objectives. Use
  `story_pacing.mode: "time_controlled"`.
- Strict Time-Controlled Story: special-case pacing for urgent sequences where
  main objectives happen back-to-back and side objectives/jobs should not be
  available until the sequence ends. This is a restrictive subtype of
  `time_controlled`, not the default recommendation.

Do not call the recommended middle option "hybrid"; call it Time-Controlled
Story and explain that its downtime is intentional. Do not describe normal
time-controlled pacing as having no gaps. If the creator is unsure, recommend
Time-Controlled Story with meaningful downtime unless the premise is a pure
sandbox or a tightly scripted crisis.

Before drafting final JSON, decide which mode the task is in:

- Interviewer mode: the user gave only a loose idea, genre, kink, premise, or
  vibe. Ask targeted story-juice questions instead of only configuration
  questions. Discover the core player fantasy, emotional target, world hook,
  key relationship focus, progression/building axis, NSFW role if any, and the
  payoff or reversal the story should build toward.
- Creative-partner mode: the user gave enough to imagine the story, but several
  valid games could still be built from it. Propose 2-3 strong directions,
  recommend one, and ask for approval or changes.
- Director mode: the user has chosen a direction or delegated the design.
  Create the full playable story, making strong design choices yourself.

Use a confidence gate: if you can imagine several substantially different
games from the user's prompt, ask more or propose directions before writing the
story. If you know exactly what game the user wants, proceed.

Do not interview forever. After each round of questions, judge whether the
core playable story is clear enough to finish by making strong design choices.
The creator does not need to specify every character, objective, twist, shop,
job, scene, route, or ending before you can write the story. Once the premise,
player fantasy, emotional target, world hook, core cast/relationship direction,
pacing model, and likely payoff are clear enough, tell the creator:

> I feel that I have enough information to write the rest of the story. Would
> you like me to complete the story now, or continue asking questions?

If the creator asks to continue, respond:

> Okay, I'll keep asking questions. Let me know when you would like me to
> finish the story.

Then ask only the highest-value remaining questions. If the creator says to
finish, stop asking for more input, write the story design document or final
story file as appropriate, and make reasonable choices for unresolved details.

Do not stop at genre, NSFW status, player gender, or a list of character types.
Ask the questions that make the story unique:

- What fantasy is the player meant to live out?
- What should the player feel most often: danger, desire, power, vulnerability,
  discovery, belonging, guilt, temptation, triumph, dread, or something else?
- What makes this world or premise different from a generic version?
- Which relationship should the player care about most, and how should it
  change over time?
- What can the player build, restore, earn, lose, collect, lead, protect, or
  become?
- What moment should make the player reevaluate the situation?
- Should the story be sandbox, Telltale-style branching, linear/mostly-linear,
  or simple/short?
- Which genders should be available among the starting selectable player
  characters? Suggest
  `male`, `female`, and `non-binary` as the general default. For an adult/NSFW
  story, also suggest `futanari` as an optional fourth default when it fits the
  intended audience and premise. Let the user replace, remove, or expand this
  list. Record the decision in planning and implement it through actual player
  definitions; non-player cast gender flexibility uses `romanceable` and the
  fallback presentation fields instead of fixing the cast to this answer.
- If NSFW, is sexual content a central fantasy, an optional reward, a romantic
  payoff, a danger/temptation, or mostly background spice?
- If the story contains romance or sexual content, is the intended player role
  `dominant`, `submissive`, or `switch`? Record this decision in the story
  design document. `dominant` means the player is expected to lead;
  `submissive` means every intended romantic interest needs authored chances to
  initiate; `switch` means more dominant interests initiate while more
  submissive interests normally wait for the player. A shy interest may still
  initiate indirectly. This is planning guidance, not blanket consent.

For substantial stories, the main work product during creation should be a
human-readable story design document, not immediate JSON. Build and revise that
document first, then convert it to JSON only at the end when the user approves
or delegates the final conversion. The design document should be organized so a
human can read it easily and an AI can convert it reliably:

- premise and player fantasy;
- intended story structure and pacing model;
- player options and starting state;
- main cast, future cast, important NPCs, and relationship arcs;
- world rules, common knowledge, hidden truths, currencies, shops, jobs, and
  important resources;
- locations and unlockable locations;
- arcs, arc steps, likely objectives, and expected freedom/tightness for each
  part;
- choice points, hidden outcome routing, durable consequences, endings, and
  failure states;
- image guidance and important visual moments;
- notes from the user and unresolved decisions.

Keep the story design document separate from EmberAdventures implementation
details. The design document is the durable creative source of truth; it should
remain useful even if the game engine, schema, objective system, reward names,
or state paths change later. Write it in implementation-agnostic story terms.

The design document should include durable story content such as premise, tone,
player fantasy, cast, relationships, locations, factions, world rules,
conflicts, story arcs, major events, choices, consequences, endings, postgame,
character-specific personal stories, pacing expectations, downtime between
major events, intended branching, and human-readable outcomes. Include general
fictional state or presentation changes when they matter to the story, such as
a character changing into a private outfit when intimacy begins and changing
back into a public outfit afterward, joining or leaving the player's group,
traveling with the player, moving into a shared home, becoming romanceable, or
asking to remain connected.

The design document should generally avoid implementation-specific material:
objective IDs, exact objective-tree structures, engine field names, reward
objects, state paths, schema-specific flags, precise unlock mechanics, and
technical instructions for how outfit changes, recruitment, relationship
checks, branching, scene lists, or state mutations must be implemented. General
mechanical language is still appropriate when it describes the intended player
experience. For example, say that a personal story includes buildup, intimacy,
aftermath, an outfit change, and a possible invitation to join the player; do
not dictate the exact objective count, reward type, or state mutation used to
implement those events.

Only the final story JSON/campaign file should translate the approved design
into the current EmberAdventures implementation structure.

When reverse-reconciling an existing JSON story into a design document, treat
the complete JSON as the content authority and modify only the design document.
Describe the premise, cast, world, relationships, arcs, progression, choices,
and consequences in human-readable prose. Do not turn the document into schema
documentation, implementation notes, exact state mutations, or an
objective-by-objective transcription. Include enough content to reconstruct a
substantially similar story in a future implementation, and report
contradictions between the JSON and existing document instead of silently
choosing one version.

Before writing objectives for a serious story, produce a compact plot outline
or story design document with the premise, player fantasy, emotional targets,
world hook, beginning, midpoint or reevaluation moment, climax, ending choices
or postgame, progression/building axis, key relationship arcs, intended story
structure mode, and objective/arc plan. Show the user what is known so far,
clearly list missing decisions, and ask focused questions. Always allow the
user to skip questions by saying something like "you decide"; then make strong
story choices yourself instead of blocking indefinitely.

Use approval checkpoints for major work: premise/structure, cast/player
options, plot outline, objective/arc breakdown, and final conversion. If the
user explicitly asks to skip approvals or delegates the design, continue without
stopping but still keep an internal design outline before JSON.

Treat the story template as the director and EmberAdventures's live AI as the scene
writer. The live AI is good at moment-to-moment prose but weak at long-term
anticipation, payoff, and pacing unless the story definition enforces them.
Use objectives, rewards, story rules, relationship changes, image rewards,
state changes, choices, and conditional routing to create anticipation and
payoff. Do not rely on the live AI to invent the intended arc unaided.

For relationship, romance, dark romance, harem, court, companion, or NSFW
payoff stories, include playable relationship-building objectives between major
plot beats. Examples include spending time together, learning something
personal, earning a voluntary disclosure, surviving a mission together, sharing
a quiet evening, celebrating, arguing and repairing the damage, defining a
boundary, refusing or accepting temptation, and choosing distance. NSFW scenes
should have context, anticipation, invitation, resistance, or aftermath unless
the user explicitly asks for an immediate-sex premise.

NPCs and the world should feel alive before the player touches them. Give major
NPCs goals, problems, loyalties, fears, and plans; use offscreen motion when it
fits the premise, such as rivals acting, deadlines approaching, jobs rotating,
opportunities closing, or consequences advancing. Include meaningful failure,
missed opportunities, rejection, arriving too late, death, or worse outcomes
when they would make the story stronger, especially in Telltale-style stories
with rollback and choice support.

## Core Workflow

1. Determine whether the story is source-free or source/canon.
   - Broad genre tropes, high-level inspiration, tone references, and requests
     for an original story with a similar kind of appeal do not make the story a
     source adaptation. Continue with this skill when the setting, cast, names,
     factions, conflicts, scenes, and objective structure are newly invented.
   - Also load `source-emberadventures-story` when the user wants to retell,
     adapt, continue, or directly use an existing work's recognizable world,
     cast, locations, factions, or storyline. Keep this base skill active for
     the normal story schema and general workflow.
   - If an allegedly original premise is so close that it appears to reproduce
     protected source expression rather than broad ideas, explain the concern
     and redesign it into distinct original material. When unsure, use a
     targeted web check before deciding.
   - Tell the user they may create source-based stories for private/local use,
     but those stories are not allowed to be published to EmberAdventures public
     hosting, then load `source-emberadventures-story` for that work.
   - Do not author an actual source adaptation from the base skill alone. Use
     the source extension for its research, scope, canon, and source-title
     decisions while continuing to use this base contract.
   - If the user confirms the story is truly original, continue with
     `source: "Original"`.
2. Run the model readiness check and stop or warn as described above before
   substantial story design.
3. Run the story file storage check and help with Google Drive or GitHub setup
   when the creator wants shared storage.
4. For every new story, explicitly ask whether the creator wants to allow any
   compatible character from the player's Character Library to be used as the
   Player. Never infer, skip, or silently answer this question, even when the
   creator delegated other design choices. Record the answer in
   `allow_any_player`. Explain that arbitrary players are appropriate only when
   the premise and opening can work without a fixed protagonist identity. When
   the answer is yes, also decide which library-character field groups the
   story intentionally allows to carry into play. Default to replacing every
   story-controlled field group; preserving library inventory, stats, held
   items, outfits, or other runtime setup must be a deliberate story-design
   choice, never an accidental result of omitted authoring.
5. Build a premise with a clear playable starting situation, not just lore.
6. Draft or update the human-readable story design document. Recommend a story
   structure type after learning the premise if the user has not chosen one.
7. Ask for approval or missing information unless the user delegated the design.
8. Convert the approved design into final story JSON only after the outline,
   cast, arc plan, and objective strategy are coherent.
9. Create or verify required public metadata.
10. Create a focused starting state with one immediate active objective.
11. Build a hidden objective spine for the main story.
12. Add side objectives that fit the premise instead of filler errands.
13. Add future cast only when it improves play; keep locked future entries hidden.
14. Build a useful world map with starting locations and unlockable future areas.
15. Write a vivid opening message that preserves player agency.
16. Run the progression design pass before final JSON:
    - define the current starting state;
    - define the hidden future state the story can reach;
    - define which objective rewards update state, rules, map locations, scene
      lists, character fields, images, items, and future-cast availability;
    - define which `story_rules` are active at start and which objectives add,
      replace, or remove them.
17. Run the feature-utilization pass. For every serious story, explicitly
    decide whether the story should use `state.players`, `allow_any_player`,
    `any_player_starting_state`, `story_rules`,
    `future_cast`, map unlocks, branch/exclusive objectives, relationship/stat
    rewards, `set_state_field`, `add_story_rule`, `remove_story_rule`,
    `add_state_list_item`, `remove_state_list_item`, `kill_character`,
    direct choice objectives, conditional `next_objectives` routing, hidden
    AI-adjudicated `outcome_routes`, multiple
    endings, failure/death branches, `generate_profile_image`,
    `generate_solo_normal_image`, and `generate_story_image`. Use the feature
    when it materially improves play; do not leave a feature unused just because
    the simpler outline is easier to write. Do not force Telltale-style
    branching into a premise that is better as a focused linear story.
    Also decide whether the story should use `story_inventory`, character
    shops, job boards, story-authored one-time jobs, or generic EmberAdventures jobs.
    Story-authored jobs must be curated for this exact story, not randomized,
    and each should have genre labels, unlock requirements, rewards, and a
    clear start/turn-in loop.
    For romance, dark romance, harem, court, companion, or relationship-driven
    stories, count `completion_control: "choice"` objectives and
    `adjust_relationship` rewards before finalizing. If either count is zero,
    add appropriate mechanics or explicitly justify why the premise is better
    without them. If the user asks for multiple endings, many choice objectives,
    a Telltale-style story, or a story with frequent direct player control,
    target roughly 30-40% choice objectives as a general planning goal. Do not
    let choice objectives exceed half the objective count unless the user
    explicitly requests an unusually menu-heavy structure. Count visible
    narrative choice objectives separately from hidden/shop-triggered treatment
    hooks. Hidden post-purchase hooks, shop follow-up hooks, and engine
    one-option start/turn-in job choices do not count against visible story
    pacing density.
    Direct choice clusters must be playable by Auto mode. Unless every option
    is intentionally fatal or ending-only, include at least one currently
    selectable continuation option that keeps the story moving. Auto mode asks
    the AI to choose among currently selectable options from player-visible
    context, personality, relationships, and recent actions; array order is not
    a preferred-route signal. Do not make the only available choice a hidden
    locked option, a dead end, or a game-over branch unless that is the intended
    ending moment.
    Use conditional `next_objectives` when consequences should route from
    hidden state thresholds after an objective completes, such as exposure,
    suspicion, public reputation, money, injury, or relationship state. Do not
    turn those into choice objectives unless the player is intentionally
    choosing between the outcomes.
    Use `route_control: "ai"` with hidden `outcome_routes` when the correct
    consequence depends on natural dialogue, tactics, treatment, secrecy,
    relationship behavior, or other scene context that cannot be represented
    reliably by stored-state comparisons. This is not a visible choice menu.
    Build objective structures so the visual Story Builder tree can display
    them cleanly: one visible objective node per playable beat, `choices[]`
    owned by the choice objective, `next_objectives` for conditional routing,
    `target_input_group_id` on output transitions for grouped graph inputs, and
    `exclusive_group` only for true one-path-only branch locks. `requires` is a
    first-class AND prerequisite list for target-authored dependency graphs;
    never duplicate the same dependency as both `requires` and an output edge.
    For stories with dozens or hundreds of purchasable/talkable shop
    characters, use large-shop-stock mode: major/fixed story companions still
    need full depth, while stock characters should be compact but playable and
    distinct. Each stock character still needs a real name, species/variant, role,
    appearance, outfit, personality, speech style, durable facts, intended shop
    placement, unlock requirement when relevant, and a post-purchase or
    post-introduction hook. Do not make stock characters anonymous,
    interchangeable, or bloated with main-character-level prose.
12. Run a character-depth pass. Important playable companions, major NPCs, and
    major future-cast entries need enough durable facts to actually use in play,
    not just a name and archetype. Main party members usually need 6-10 concrete
    facts; major NPCs usually need 4-6. Minor one-scene utility NPCs may be
    shorter, but one generic fact is draft quality.
13. Run the field-purpose pass: for every field, ask what it is for, how
    EmberAdventures uses/displays it, whether the value serves that purpose, and
    whether it can be clearer, less spoilery, or less like process text.
14. Run the creator-instruction leakage pass: remove anything that was an
    instruction to Codex/the story creator rather than story data.
15. Validate schema, player-visible text, objective references, and embedded
    character definitions before final output.
16. Run the standalone release pass: assume no later maintainer cleanup exists.
    If objectives are shallow, future_cast is thin, character facts are generic,
    schema fields are questionable, the premise is underdeveloped, or visible
    text leaks future/private information, fix the JSON before final output
    instead of leaving notes for someone else.
17. Run the hidden-information implementation pass. For every fact, identity,
    ability, relationship, class, motive, location, faction, villain, twist,
    or world rule that the player is not supposed to know yet, identify the
    exact objective or event that reveals it. Keep the information absent from
    all state and prompt projections that the player or narrator can see until
    that point. Do not put a future reveal into starting `known_facts`, visible
    character facts, `scene.summary`, current NPC summaries, active
    `story_rules`, opening text, visible objective text, public metadata, or
    any other context sent to the narrator merely because it will eventually
    become true.
18. Implement each intentional reveal with an authored deterministic reward
    on the objective that reveals it. Use the supported reward for the actual
    destination: `add_state_list_item` for a new player or character known
    fact, `set_state_field` for a world flag or other scalar state, character
    field updates for changed character information, `add_story_rule` for a
    rule that becomes true in the fiction, and the appropriate introduction,
    scene-list, map, item, or objective reward for newly available entities.
    The completion instruction should describe the immediate dramatic reveal,
    but it must not be the only place where the durable truth is recorded.
    Do not pre-seed a hidden fact and expect the narrator to remember not to
    mention it; if the narrator receives it, it is not hidden.
19. At the end of authoring, build a reveal audit table with one row per
    intentionally hidden fact. Record: the fact, the first point at which the
    player may know it, where it is absent before that point, the exact reward
    that adds or changes it, and the player-facing text that introduces it.
    Inspect every embedded character definition, player option, future-cast
    shell/full character, NPC directory entry, known-fact list, story rule,
    objective summary/instruction, opening message, map field, shop/job entry,
    and generated-message context for leaks. Check names and labels as well as
    prose: a future class, identity, or reveal must not be smuggled into a
    starting fact or generic rule. Only after this audit passes should the
    story be exported.
20. Run the objective-quality pass: every objective must have authored,
    story-specific completion criteria and completion instructions. Reject and
    rewrite objectives whose criteria or instructions merely repeat the title,
    use boilerplate such as `Return yes only when the player completes: {title}`,
    use generic variants such as `Return yes only when the player clearly takes
    action toward this goal: {summary}`, or use boilerplate such as `Resolve the
    immediate outcome of {title} and move to the next objective`. This applies
    to sandbox, simple, compact, and test stories too; short stories still need
    concrete criteria tied to the actual scene and intended completion moment.
    Never silently truncate, discard, or omit objectives because of an arbitrary
    implementation count limit. Preserve the complete authored objective graph.
    If the target application cannot retain the full graph, stop and report the
    incompatibility instead of returning a story whose later content will vanish.
21. Run the pacing-and-relationship pass: serious stories should not place
    chapter-scale beats directly beside each other without bridge objectives.
    Add playable objectives for trust, suspicion, attraction, private
    conversations, world understanding, preparation, and consequences when those
    beats are part of the intended experience. If a single player message could
    complete multiple consecutive objectives, merge or rewrite those objectives.
    Use `adjust_relationship` rewards when an objective should deterministically
    change trust, attraction, affection, or arousal.
    For every major romantic lead, companion lead, recurring rival/temptation,
    or relationship-gated ally, include at least one objective that builds,
    tests, defines, or damages that relationship unless the character is not
    meant to matter emotionally. Relationship objectives are not only spicy
    scenes: boundaries, refusals, apologies, trust tests, protection,
    jealousy, vulnerability, private conversations, and chosen distance are all
    valid relationship beats.
    For romance, dark romance, romantasy, harem, and other relationship-first
    stories, relationship building is not optional pacing filler. Add multiple
    playable relationship objectives between major plot milestones so the story
    does not speed-run from event to event. Include private conversations,
    emotional aftermath, temptation, vulnerability, jealousy, recovery, chosen
    distance, and scenes where a romantic lead actively shows interest. If the
    intended player is submissive, shy, or unlikely to pursue intimacy, provide
    optional-with-skip choice objectives and narrator instructions that let love
    interests flirt, invite, tempt, court, or come onto the player while
    preserving explicit player choice.
    Make the non-player cast gender-flexible by default. Mark intended romantic
    interests `romanceable: true` and provide complete opposite male/non-male
    fallback names and outfits. Ask whether the creator wants the optional 40%
    male / 40% female / 20% futanari default-presentation balance and explain
    that it changes only the cast's authored default presentations, not their
    identities, bodies, personalities, roles, plot functions, or relationship
    arcs. It is valid to retain the creator's intended default genders instead.
    The runtime performs preference adaptation either way.
22. Run the publish-as-is pass: assume the user will import or publish the
    generated file immediately with no manual cherry-picking, no comparison
    against another draft, and no review from another thread/model. If two
    internal options look useful, merge them yourself before final output. Do
    not produce "base plus suggested improvements" as the final result.

## Stories Embedded in Standalone Characters

A standalone character definition may optionally place a complete story in its
`chat_story_template` field. Use this mode when the character supports a real
authored arc with objectives, branches, rewards, locations, shops, endings, or
other story systems. Apply every normal schema, quality, safety, validation, and
release requirement in this skill; an embedded character story is not a reduced
or informal story format.

Author and validate the story through the normal
`{ "app": "EmberAdventures", "exportType": "story-template", "storyTemplate": ... }`
wrapper while working. When inserting it into a character definition, copy only
the complete inner `storyTemplate` object into `chat_story_template`. Never put
the outer export wrapper, design notes, prose summary, partial objective
fragment, or any non-story data in that field.

The surrounding standalone character is the story's principal character. Use
that character's exact stable id anywhere the story must identify its principal
character. Set `allow_any_player: true`. Do not copy the surrounding character
into `state.player`, `state.players`, `state.characters`, NPC entries, or
`future_cast`. EmberAdventures automatically registers the authoritative
surrounding definition as a current story character under its stable standalone
id before opening-state and token validation and before launch. A duplicate
embedded definition with that id is invalid. The player is selected through the
character Chat launcher, so do not make the arc depend on a fixed player name,
appearance, personality, dialogue, thoughts, or decisions. Use supported player
tokens where player identity is needed.

The story's `title` and `description` are shown in the character Chat launcher.
Make the description short, appealing, accurate, and free of spoilers, hidden
routes, secret identities, unreached transformations, and ending information.

A character may contain both an embedded full story and the lightweight
`chat_story`, `chat_opening_message`, and `chat_starting_location` fields. They
are separate launch choices:

- **Just Chat** uses only the lightweight fields. When any lightweight authored
  setup exists, the launcher selects Just Chat by default and lets the player
  inspect or replace that setup.
- **Play Story** uses only `chat_story_template`. Its own `messages`, opening
  location, objectives, state, progression, and endings are authoritative.
- Never merge the lightweight opening into the full story, copy the full story's
  opening into the lightweight fields automatically, or treat either choice as
  an override of the other. They may deliberately begin similarly, but remain
  independently authored experiences.

### Standalone Character Fields Do Not Enter Stories

When creating, importing, or adapting a standalone character for a story, omit
all standalone discovery and launcher fields from every embedded copy:

- `catalog_hook`
- `default_image_background`
- `genres`
- `kink_tags`
- `chat_story`
- `chat_opening_message`
- `chat_starting_location`
- `chat_story_template`

This applies to `state.player`, every `state.players[]` option,
`state.characters`, NPC shells and `full_character` definitions, and
future-cast shells and `full_character` definitions. Story discovery belongs to
the story's own metadata. Story catalog copy belongs in the story's `title` and
`description`. Story openings and progression belong in the story's own
messages, state, objectives, and outputs. Never embed one character's standalone
Chat launcher or nested story inside another story.