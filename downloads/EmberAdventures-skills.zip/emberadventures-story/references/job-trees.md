# Authored job trees and repeatable instances

See [authored-job-story.json](authored-job-story.json) for a complete valid
original example with two authored work nodes and repeatable text choices.
The engine adds Start and Turn-in;do not copy generated instance IDs into files.

A job-board listing may use either the original flat job flow or an authored
objective tree. All ordinary board locks, genre/content filters and exact
current-rank eligibility still apply. `generic_jobs_enabled: false` on the
board disables rotating built-in offers; its omission keeps them enabled.

## Listing fields

Keep the ordinary `id`, `title`, `summary`, `genres`, `nsfw`, `rank`,
`requirements`, `reward_coins`, `reward_xp` and optional `reward_items`.
`title` and `summary` are fixed board previews. Add these optional fields:

- `objective_tree`: exactly `{ "entry_id": "local-id", "items": [...] }`.
- `text_dictionaries`: an object mapping a lowercase key to a nonempty array
  of nonempty text choices; allowed only with `objective_tree`.
- `repeatable`: a boolean. Omitted or false means one completion. True permits
  accepting a fresh instance after completion or abandonment; one instance of
  the same listing may be active at a time. This also works for flat jobs.

For an authored tree, omit the listing's flat `completion_criteria` and
`completion_instruction`. Put the exact authored behavior on the tree's nodes.
The engine adds explicit Start and Turn-in objectives around the authored work
tree. It does not replace the work with a generic task or rewrite it with AI.
`start_location` and `client_npc_id` belong to the flat flow; for a tree,
explicitly introduce an existing future-cast actor or travel through ordinary
node/output rewards. Listing payouts are a turn-in bonus in addition to
any explicitly staged rewards in the graph. Use zero for no extra bonus.
Random replacements are intended for repeatable jobs. Fixed authored jobs such
as MOWF's existing one-time commissions do not need conversion or randomness.

## Objective graph

Every item is an ordinary canonical objective with `type: "side"`. The
`entry_id` names exactly one queued node; other nodes begin hidden, locked or
future. Use the same full objective, choice, outcome-route, requirement,
abandonment and reward contracts as ordinary story objectives. Local IDs use
the normal lowercase stable-ID format and must not begin with `job-`.

Use typed local references in `requires`, output destinations,
`objective_complete`/`objective_not_complete` requirements,
`start_objective`/`complete_objective` rewards and abandonment scopes. The
engine scopes these IDs, output IDs, exclusive groups and input groups to the
accepted instance. Existing world-location IDs, character IDs, inventory IDs
and global objective references remain exact external references. Do not put
job-local references into global reward bundles or global numeric expressions.

A terminal side choice/route can omit its next destination using the ordinary
return-to-main contract. A side AI/player task may simply have no outputs.
Terminal work completion unlocks Turn-in without paying the listing bonus,
closing the instance,teleporting the player or clearing the scene. The separate
Turn-in choice returns to the board and pays once,then retains branch/progress
history while removing the instance's active objective views. Neither a new
attempt nor turn-in reverses earlier world consequences.
Do not author `complete_generated_job` with a guessed future instance ID.

## Named text substitutions

Use `{{parcel}}` with, for example:

```json
"text_dictionaries": {
  "parcel": ["blue dispatch", "red dispatch"]
}
```

Dictionary keys begin with a lowercase letter and use only lowercase letters,
digits and underscores. Values are plain strings without nested placeholders.
Every referenced key must exist; a missing key is a path-based validation error.
The engine chooses once at acceptance and stores the chosen text and filled
objective definitions. Save/load, undo and retry preserve them. A fresh repeat
may choose the same value again; it does not promise exhaustive rotation.

Tokens are allowed only inside the tree's prose fields: `title`, `summary`,
`while_active_guidance`, `completion_criteria`, `completion_instruction`,
`player_text`, `notes`, `completion_message`, `ending_title`, `ending_message`,
`reason`, `criteria`, `blocked_reason`, `description`, `text`, `instruction`,
`prompt`, `negative_prompt`, and strings in `dialogue_lines`.
Do not use tokens in IDs, destinations, character references, requirement
values, location names, numeric fields or expressions. Board preview fields
remain literal. A dictionary chooses wording; it does not create a character,
shop or other entity. Use persistent entity IDs for those systems.

## Persistence and author checks

Each accepted run has fresh instance/objective IDs, progression and reward
eligibility. Closed runs stay complete or abandoned, with their frozen text,
selected branch IDs and completed-step records retained. Repeating does not
restore injuries, purchases, relationships, knowledge or old rewards. Native
undo reverses that turn's engine transaction; accepting a new instance does
not reopen the old one. No old-save migration fabricates missing history.

Authored scene-membership rewards follow a character's current NPC/party owner.
Removing someone from the final scene also removes their current image
selection;it does not delete their character or historical images. Someone
still present under the other owner remains selected. Do not delete character
records or add story workarounds to compensate for a departure.

Validate the complete export. Test the actual authored choices, failure route,
turn-in bonus and staged rewards; accept again, reopen midway and verify
that IDs and wording remain stable within each run and distinct across runs.
