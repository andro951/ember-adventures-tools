# Confirmed objective abandonment

Use this optional contract when a quest should support a deliberate narrative
withdrawal. It is distinct from Stop Tracking, choosing another objective,
taking a break, tactical movement or an unfinished side quest. The player must
clearly propose giving up the selected quest, then choose **Abandon** in the
confirmation. **Continue objective** keeps the quest active and overrides their
tentative earlier wording. Repeating background context does not ask again.

## Authored contract

Put `abandonment` on the root objective of one bounded quest scope:

```json
"abandonment": {
  "policy": "checkpoint",
  "objective_ids": ["accept-survey", "inspect-marker", "report-survey"],
  "instruction": "Mira records the withdrawal. Any advance already paid stays recorded. The courier can continue other work; the marker remains unchecked unless actually examined.",
  "rewards": [],
  "checkpoint_objective_id": "inspect-marker"
}
```

This is a field fragment, not a complete importable story. All fields shown are
required except `checkpoint_objective_id`, which is required for `checkpoint`
and forbidden for the other policies. Omit the entire object for ordinary quests.
The [complete survey example](abandonment-story.json) uses the same policy with
exact IDs `survey`, `marker`, `report`, and explicit triggered activation. Merely
adding an unreachable hidden quest is invalid; preserve normal graph activation.

- `policy`: exactly `resume`, `restart`, `checkpoint` or `permanent`.
- `objective_ids`: unique existing exact IDs, including the owning root. They
  must form a connected scope from that root using existing objective edges,
  have one main/side category, and not overlap another abandonment scope.
- `instruction`: nonempty hidden scene consequence. It is narrator guidance,
  not the player-facing confirmation. Do not assume an advance, injury or other
  event occurred unless the actual play history establishes it.
- `rewards`: the existing canonical reward array, used for structured withdrawal
  consequences. Empty is valid. Use normal reward types and valid references;
  do not invent an abandonment-specific reward language.
- `checkpoint_objective_id`: an objective inside this same scope.

| Policy | What Resume does |
| --- | --- |
| `resume` | Selects the actual step where the player stopped, preserving its task progress. |
| `restart` | Resets scoped task progress from the root. |
| `checkpoint` | Resets the checkpoint and its scoped descendants if that checkpoint was reached; otherwise starts at the root. Never skips forward to an unreached checkpoint. |
| `permanent` | Offers no Resume; the withdrawn quest remains unavailable. |

These are task-progress policies, never save rewinds. Resume does not teleport,
complete a journey, restore an item, waive access conditions or act for the
player. A resumed player-action objective still requires a fresh relevant action
in that attempt; historical inspection cannot automatically satisfy a reset
inspection step. World-state conditions can remain satisfied by retained facts.

## Consequences and repeated attempts

Withdrawal is not successful completion and must not deliver the withdrawn
objective's old completion beat. Existing purchases, injuries, relationships,
knowledge, world changes and already earned rewards remain. Abandoning combat
is a contested attempt to disengage; it does not disable combat or guarantee
escape. Ordinary opposition still determines what happens next.

Structured withdrawal consequences have one stable invocation site per authored
scope. Withdrawing again after resumption does not farm that reward or repeat a
one-off structured penalty. The narrator still describes the current refusal.
Do not use this contract for a per-attempt penalty that must repeat indefinitely.

Previously issued objective rewards keep their existing invocation receipts.
Restarting does not pay an earlier advance twice. Repeated outcomes acknowledge
the established result instead of replaying old reward scenes. A genuinely new
route can deliver its own instruction and distinct unconsumed rewards. Prior
completed steps and selected outputs remain available to prerequisites outside
the resetting scope; that scope cannot use this history to skip its fresh steps.

## Triggered quests, sleep and persistence

A selected triggered side quest returns to its interrupted quest selection when
withdrawn. The trigger is not rearmed and the withdrawn task is not marked
complete. Other unfinished triggered trees can still be selected normally; a
resumable abandoned task appears separately in the objective picker. An abandoned
bedtime entry no longer blocks later sleep, but lodging terms and actual-night
billing remain unchanged. Refusal alone is not completed sleep or a refund.

`state.story_pacing.abandonments` is optional engine-owned progress. Do not author
fake player decisions or use it to prepay/reseed rewards. When reviewing an
actual runtime save, its keys are exact authored root IDs. Each record contains
`status` (`continued`, `withdrawn`, `resumed`), `objective_id`,
`resume_objective_id` (empty for permanent), `source` (actual `message_id` and
`text`), and `completed_objectives`. That last map records each completed scoped
ID with `selected_output_ids`, an array retaining actual historical choices.
Native save/reload and ordinary source-message editing own this progress.
Retrying the same decision source preserves it without another prompt/payment;
editing a source must use normal checkpoint replay, never hand-edit the book.

## Acceptance checks

Play a believable quest, accept an advance, acquire information and keep an old
injury/item before withdrawing. Check incidental movement, declined confirmation,
renewed confirmed withdrawal, correct return selection, each policy, no duplicate
reward, fresh action after reset, reload, and editing away withdrawal/resumption.
Also test contested retreat and an optional bedtime interruption. Check native
records as well as narration; correct coins with prose announcing another payment
is still a failure to fix. Automated checks alone do not establish live behavior.
