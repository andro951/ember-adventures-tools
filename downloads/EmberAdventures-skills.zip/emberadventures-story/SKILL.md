---
name: emberadventures-story
description: Create, update, migrate, validate, or review normal EmberAdventures story-template JSON files. This is the authoritative base story skill and schema contract. Use it directly for original/source-free stories and always load it before Source EmberAdventures Story for source/canon work.
---

## Version and Update Check

Current skill version: `1.0.85`.

For ordinary story creation, review, repair, or migration, use the installed
skill text as the active instructions. Do not interrupt the creator workflow to
download, install, clone, replace, or update skills unless the user explicitly
asks to update or verify skill currency.

For maintenance, download the complete [EmberAdventures skills ZIP](https://github.com/andro951/ember-adventures-tools/raw/refs/heads/main/downloads/EmberAdventures-skills.zip).
Versions are recorded in the bundled SKILL.md files and manifest.json. When the
user authorizes an update, replace the affected local skill folder from that
archive while preserving private preferences. Do not install loose GitHub files.

# EmberAdventures Story

This is the authoritative normal EmberAdventures story-template skill. Use it
directly for source-free stories, including invented premises, player options,
party members, NPCs, objective chains, future cast, maps, title cards, opening
messages, migrations, validation, and quality review.

For a story based on a game, anime, manga, book, movie, mythology, or another
existing source, load this skill first and then load `Source EmberAdventures
Story`. The source skill extends this contract with research, canon scope,
adaptation, milestone, and source-validation rules. It does not replace or
restate this schema.

This skill must work as a standalone public skill. Do not assume an EmberAdventures
maintainer or a separate main thread will repair the story after output. The
generated JSON may be imported directly, so major schema, premise, objective,
character-depth, visibility, or field-purpose issues must be fixed before final
export.

The linked references are this skill package's complete schema contract. Do not require or inspect
external app source files, private local project paths, or existing story files
for new story creation. The only external skill
dependency this story skill may assume is access to the EmberAdventures character
skills for character definitions.

Sections explicitly titled or qualified as `Original` or `source-free` apply
only when this skill is used directly for an invented story. For source/canon
work, keep this skill active for the schema and general workflow while the
Source EmberAdventures Story extension supplies source-specific values and
rules.

This skill creates and updates normal EmberAdventures story-template files. The
filesystem-backed Codex version uses a separate campaign packet shape; when the
user asks for that format, use `original-emberadventures-codex-story` instead of
forcing one schema into the other. Normal story-template exports do not use a
`story_engine` or `schema_version` discriminator.

## Model Readiness Check

Before substantial story creation, verify the current model and
reasoning/intelligence/effort level with the creator when it is not already
known. The minimum recommended setup for this skill is a thinking model at
medium effort/intelligence or higher, such as ChatGPT/Codex 5.4 or higher at
Medium. The optimal setup is 5.6 Sol at Medium effort/intelligence.

If the current setup is below optimal but still at or above the minimum, stop
before story design and warn that lower model/intelligence settings may create
a weaker story, miss long-range structure, or produce an invalid JSON file.
Suggest increasing to 5.6 Sol Medium, then continue only if the creator chooses
to proceed.

If the current setup is below the minimum, stop before story design and say it
is extremely unlikely to create a valid EmberAdventures story JSON file. Tell
the creator they probably should not continue until they raise the
model/intelligence/effort to at least the minimum.

## Story File Storage Check

Before substantial story design, ask where the creator wants to keep the story
files while work is in progress. Explain the tradeoff clearly:

- ChatGPT local storage is the default and requires no setup, but the creator
  cannot directly browse or edit those files. Provide download links whenever
  the creator wants to inspect, save, or move the current design document,
  notes, or JSON file.
- Google Drive is usually best for nontechnical creators because the creator
  can directly view, edit, organize, and share the files.
- GitHub is best for creators who want version history or are comfortable with
  repos. Use one stories repo, not one repo per story.
- Another shared folder service is acceptable if the creator already uses it.

Ask: "Where would you like to keep the story files while we work? The default
is ChatGPT local storage, but those files are not directly viewable by you
unless I provide download links. Better options are Google Drive, GitHub, or
another shared folder. Would you like help setting up Google Drive or a GitHub
stories repo?"

If the creator chooses Google Drive, help create or use this structure:

```text
Ember Adventures Stories/
  Stories/
    Story Name.json
  Design/
    Story Name/
      Story Name - Design Document.md
      Story Name - Notes.md
```

If the creator chooses GitHub, help create or use one stories repository with
this structure:

```text
ember-adventures-stories/
  stories/
    Story Name.json
  design/
    Story Name/
      Story Name - Design Document.md
      Story Name - Notes.md
```

If the creator skips setup or says to continue, use ChatGPT local storage and
provide download links at major checkpoints: first design document draft,
objective/arc plan, and final playable JSON.

Do not use existing EmberAdventures story files on the user's computer as creation
references, quality references, structure references, style references, or
coverage references when creating a new story. This includes active stories,
archived stories, generated output folders, downloaded examples, and previous
drafts. Existing story files may only be opened when the task is explicitly to
inspect, review, migrate, compare, or update that exact file.

For new original-story creation, build quality from the schema docs, this
skill's reference docs, and the user's requested premise. Do not copy depth,
wording, objective shape, opening style, or
character structure from existing local story files.

## Required Reads

Before producing, reviewing, or migrating final story-template JSON:

1. Use this skill as the schema and authoring source. Do not inspect app source
   files for new story creation.
2. Inspect the target story JSON only if updating, migrating, reviewing, or
   comparing that exact story file. Do not inspect existing local story files
   as examples or references for new story creation.
   When updating an existing story, first read and preserve its
   `story_memory`, `story_rules`, `story_inventory`, `story_shops`,
   `future_cast`, current objectives, player options, hidden notes, and
   runtime-design constraints. Do not overwrite or simplify those systems
   unless the user explicitly asks to change them.
3. If the story creates, embeds, or updates player/party/NPC definitions, load
   `EmberAdventures Character`. Do not duplicate its full character process
   here.

The complete field contract and design guidance are bundled references:

- [story-contract.md](references/story-contract.md): exact wrapper, fields, metadata, placement and runtime separation. Read before writing JSON.
- [authoring-guide.md](references/authoring-guide.md): creative intake, design and core workflow. Read for new stories or substantial revisions.
- [objective-guidance.md](references/objective-guidance.md): routing, handoffs, programmatic required cast, pacing and reusable objective patterns. Read when designing or editing the objective graph.
- [numeric-requirements-and-pending-outcomes.md](references/numeric-requirements-and-pending-outcomes.md): exact upfront arithmetic gates and AI outcome classification that can remain pending without effects. Read before authoring either behavior.
- [job-trees.md](references/job-trees.md): exact authored job graphs, named text dictionaries, frozen instances and repeatable listings. Read before authoring either job flow.
- [objective-handoffs.md](references/objective-handoffs.md): terminal side choices/tasks, timed main-story waits, empty automatic routers and ordinary map closure. Read before authoring these behaviors.
- [main-plot-points.md](references/main-plot-points.md): scheduled or AI-paced main-story availability while the player pursues optional activities. Read before authoring this timeline variant.
- [short-interruptions.md](references/short-interruptions.md): triggered side quest trees with normal branches, free selection, nesting, and return to the interrupted questline. Read before authoring triggered events.
- [objective-abandonment.md](references/objective-abandonment.md): confirmed withdrawal, authored consequences, resume/restart/checkpoint/permanent policies and retained world history. Read before making quests abandonable.
- [interactive-cutscenes.md](references/interactive-cutscenes.md): one fixed authored beat per completed narrator reply, with player reactions and no completion classifier. Read before authoring cutscene sequences.
- [combat.md](references/combat.md): the fixed opt-in combat engine, six-value profiles, activation rewards, damage ownership and nonlethal outcomes. Read before authoring combat support.
- [player-home.md](references/player-home.md): optional accepted accommodation, local pricing guidance and charges for actually used nights. Read before authoring Home or lodging.
- [world-map-patterns.md](references/world-map-patterns.md): hierarchy, map shape and NPC pointers. Read when authoring a map.
- [hex-exploration.md](references/hex-exploration.md): optional bounded hex areas, explicit passages, room outcomes and staged generation. Read when authoring exploration.
- [quality-checklist.md](references/quality-checklist.md): complete release review. Read before delivering a finished story.
- [reference-story.json](references/reference-story.json): complete canonical short story with an authored ending.

Apply the relevant resources; do not substitute an illustrative partial JSON
block for the complete export. The normal Character skill supplies actor data.

When character creation is needed, load `EmberAdventures Character`; do not
duplicate its full character-design process here.



## Canonical validation and delivery

`node ../emberadventures-character/scripts/validate-content.cjs <absolute-normal-EA-repository> <story.json>`

The optional helper invokes normal EA's canonical validators without repairing
the input. Review every authored ending path and the linked quality checklist.
Without a local checkout, use the bundled contract and verify through game import.

## Distribution and maintenance

Publish user-facing skill updates only as the complete ZIP bundle. Keep editable
skill folders locally; do not publish loose skill files or separate version files.
After any change, update the installed copies, validate the affected references and
scripts, rebuild the ZIP and its manifest, update archive links, and push the ZIP.
The package includes maintainer/package_skills.py for rebuilding both bundles.
Never include private preferences, personal data, tokens, caches or test output.
