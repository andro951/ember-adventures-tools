---
name: emberadventures-play
description: Playtest normal EmberAdventures through its existing Perchance harness with real text, images, and the complete local game UI. Use for manual gameplay, feature acceptance, response and retry review, and save/reload verification.
---

# EmberAdventures Play

Current skill version: `1.2.23`.

Use the existing normal-game interactive controller and Perchance worker, acting
as a player one action at a time. Read the replies, inspect images and actual
state, and adapt the next action. This is browser gameplay, not filesystem GM
play, a prompt-only probe, or an unattended smoke sequence.

Read [references/live-session.md](references/live-session.md) before launching.
It contains the tested startup, control commands, evidence checks, and recovery
details. Read the selected repository's working rules as well.

## Working route

- For ordinary Windows startup, use the checkout's
  `tools/perchance-ai-text-harness/Open EmberAdventures Playtest.cmd`. It now
  ATTACHES to normal external Edge at the configured CDP address, default
  `http://127.0.0.1:9223`, and opens the isolated local game. The external worker
  must already be opened separately with its dedicated persistent profile and
  `https://perchance.org/056uh2nc6k` page. An unavailable endpoint is an error;
  the launcher does not silently substitute another worker method.
- The original `open_controlled_worker_browser.bat` opens that worker on port
  9222. Match the local launcher configuration to the actual port. Keep the
  external worker open across local-game reloads and controller reconnections;
  do not reopen it or replace its profile merely to refresh game code.
- Use the canonical local normal EA checkout. On the verified laptop it is
  `D:/Program Files/JS Dev/EmberAdventures`; discover the corresponding checkout
  on another machine instead of copying that machine's paths blindly.
- Use `tools/perchance-ai-text-harness/interactive_emberadventures_ui_controller.mjs`
  with **`--real-all-text --real-images`** and isolated command, status and event
  files. Add `--capture-provider-evidence` for response review. Choose the worker
  connection described in the reference; reuse an available controlled worker.
- The desktop's supplied successful route uses an external Edge worker with its
  own dedicated persistent profile and attaches through the actual CDP port.
  To reproduce that setup, omit `--managed-worker`. Do not confuse persistence of
  the game profile with persistence of the Perchance worker profile.
- The launcher omits --managed-worker, --worker-profile, --no-harness and
  --local-worker-source. Use the existing HOSTED worker through browser-page-runner.mjs;
  normal attachment must not replace its adapter or install live chunk relay bindings.
  Completed text is delivered through the existing worker API. This follows the
  desktop's supplied working route; it is not proof that verification will succeed.
  Local adapter injection/live-stream relay is an experimental alternative requiring
  an explicit change of approach, not a routine reconnect or verification repair.
  Changing launcher code does not remove an adapter already injected into a running
  page. To restore the hosted code, first settle or explicitly cancel pending jobs,
  disconnect the old controller, and reload the existing worker once. Preserve its
  profile and saved game; do not repeatedly refresh verification or clear cookies.
- Optional alternatives require an explicit change of approach. The existing
  `--managed-worker` route uses the harness's Playwright
  browser approach. External Edge opens the actual Perchance worker at
  `https://perchance.org/056uh2nc6k` in its own window; the local game opens in a
  separate isolated browser context. The same `browser-page-runner.mjs` runs
  actual plugin jobs inside the worker iframe.
- This mode uses a private automation pipe, without opening a TCP debugging port.
  Keep one dedicated, reusable test-game browser profile and its saved games and
  images. Resume that game after reopening; do not start over or regenerate
  portraits merely to reconnect. Never use the player's personal browser profile.
  Its worker profile is temporary by default. Add
  `--worker-profile=<dedicated-worker-directory>` to retain worker site state
  through the private automation pipe without a TCP debugging port. This is
  separate from `--playtest-profile`, which retains the local saved game.
  Both modes previously generated real results, but they are different browser
  sessions; a restart or profile change is a comparison variable, not a proven
  fix for provider verification errors.
- Allow page content to follow the browser window: headed contexts use
  `viewport: null`. A forced 1500x950 viewport makes the content stay fixed when
  the user resizes the window and is unsuitable for ordinary manual playtesting.
- Keep both windows available. Use the local game, not the published EA game.
  The real worker must report both text and image plugins available. A local
  game page by itself has no functioning Perchance generation provider.
- Keep one Playwright/CDP owner attached to the external worker during gameplay.
  Disconnect finished comparison or diagnostic clients before using the game
  controller; leaving a second client attached can break live-stream callbacks.
  See the reference for the observed failure and recovery evidence.

## Play and judge

For a new feature, run the isolated scenario first, then test in the actual
current story requested by the user before calling the feature finished.
An isolated pass never replaces that requested-story acceptance. Record the exact
selected story file, hash and revision, and verify that the saved game uses that
immutable story definition. A matching title does not establish currency: an
existing game retains its original definition after its library template changes.
Use a separate fresh save to accept an updated story, preserving the earlier
game and images. Reconcile a pending local draft with the selected release
before calling that draft tested; never silently substitute one for the other.
If the story
has no authored instance of the new feature, explain the gap and discuss the
required story change; do not silently rewrite it or claim unrelated regression
play covers the feature itself.

When the user requests a continuous error-free acceptance run, any error fails
that run. Fix the issue,then restart from the beginning. Undo/retry and repaired
midpoint checkpoints are useful diagnosis but cannot convert a failed run into
a clean acceptance pass. Preserve the failed evidence. Follow the exact endpoint
and scheduling in the project plan;do not claim the whole game was tested.

Every new feature requires manual acceptance in a real story or a realistic
story situation on the full game. Give the scene believable character goals,
context and consequences relevant to the feature, and play naturally rather
than scripting everyone to cooperate or dictating the expected outcome. Check
the feature's behavior as the surrounding story unfolds, including relevant
failure and edge cases. Controlled workshops, tiny prototypes and automated
checks are supporting evidence; they cannot satisfy this story acceptance gate
by themselves. Record which story situation was played and what actually
happened. If only controlled cases were tested, report story acceptance as
incomplete and do not call the feature fully verified.

1. Write a short plan before playing: starting state, intended actions, expected
   and forbidden outcomes, and checkpoints. For a new system, use a tiny scenario
   on the production engine before full-game integration.
2. Start through the UI, or use the documented story-start bridge when menu setup
   is not what is being tested. Dismiss the actual Start Playing dialog. Never
   force objective completion or silently patch state to pass a checkpoint.
3. Issue one player action, read the actual reply, then inspect state and every
   retry. Prefer `waitVisible:false` during long generation so the controller
   remains available for status and UI observation. State updates may continue
   after narration; a returned dialogue reply does not establish state completion.
4. Use the UI to navigate and perform gameplay actions such as NPC inspection,
   presence changes, shopping, selecting images, editing, and saving. Switch to
   developer inspection for outcome verification and debugging: read runtime
   state, persisted save records, provider evidence, logs, and code directly.
   Do not open menus or navigate the UI merely to retrieve data that is cheaper
   and more precise to inspect directly. Use UI checks when the display or
   interaction itself is under test. Verify persistence from persisted records,
   not just an in-memory success flag; read saves without altering them.
   Use complete persisted text for message edits. Control summaries and status
   previews can be truncated; never write those projections back over a message.
   Once an issue is identified, act as the developer until the investigation or
   authorized repair is complete, then return to playing. Keep hidden knowledge
   out of the player's choices.
5. Inspect successful provider results and real decoded/displayed images. Record
   format failures separately from provider failures, unclear prompts, model
   interpretation problems and engine errors. Tell the user about meaningful
   issues and proposed fixes.
6. Keep test data isolated. Do not erase or reuse player browser storage, personal
   profiles, account sessions or existing provider jobs. Do not add elapsed-time
   cancellation to live jobs. Explicit tester cancellation is an intervention.

## Isolate unfinished schemas and choose exact controls

Keep the normal generated page on the last published stable build while a new
feature is unfinished. Assemble a separate unpublished preview HTML file from
`assembleBottomSource({includeTests:false})` when resuming an ordinary saved
session;this retains the normal runtime database and actual saved images.
The `--private-tests` page uses separate diagnostic databases,so an empty profile
there does not mean ordinary saves disappeared. Use it for the automated suite.
Use a dedicated reusable profile for fixtures with an incompatible experimental
schema. Before testing an older stable build in a shared test profile, archive
only explicitly owned experimental library entries;preserve their portable
sources,native saves and image assets. Never relax validation,clear player data
or migrate fixtures merely to get startup to pass.

For authored choices,use a control bound to the exact choice ID and verify the
response dialog's heading before confirming. Broad text/context matching can
match several Choose buttons because an ancestor contains all their labels.
Verify the persisted selected output ID;the narrated action alone does not prove
which branch was selected. On `fill_control`,use an explicit control ID plus
`value`,or a selector plus `value` without `text`;the controller can interpret
`text` as both a locator and the text to type.

Offscreen controls are not missing controls. Check the current popup and scroll
its owning container before assuming it closed or failed. A screenshot is useful
when layout/visibility is genuinely uncertain;diagnose records and logs directly
once the UI issue is identified.

## Work efficiently while generation runs

Subscribe to completion events before sending a generation action. The bundled
`scripts/watch-generation-events.mjs` streams text/image completions from the
controller's event file. Connect that stream to the active agent session's
notification mechanism when available; see the reference for the tool pattern
and its limits. A terminal printing output alone is not an agent notification.
Do not rely exclusively on repeatedly opening status files or screenshots.

While Perchance is pending, do useful independent work: inspect the owning code
for the next checkpoint, compare accepted state with persisted records, review
earlier responses/retries, reproduce an issue in a focused local check, or plan
the smallest relevant fix. Do not change the state under test or send dependent
gameplay actions before their prerequisites finish. If an answer genuinely
blocks all useful work, wait on completion events instead of busy polling.
Completion pings identify provider results; check whether application processing,
state updates, and persistence have finished before declaring a turn complete.

## Evidence and limits

The normal-EA route was exercised on 23 October 2026: actual local-game controls,
story startup, a live narration turn and provider retry, plain-text objective and
state responses, real scene/profile image bytes, and responsive window resizing.
This proves the setup, not acceptance of every engine feature. Record subsequent
acceptance results separately; never treat Lite's older successful run as normal
EA proof or infer that prototype systems are integrated.

The external Edge/CDP route was also verified in normal EA on 23 October 2026:
the user opened the original worker BAT on 9222, the attachment launcher resumed
the same saved game, real text completed, and real image generation/download
returned decoded image bytes that displayed after a local-game reload. This is
separate evidence from the managed/private-pipe route.

Perchance verification errors can be transient. In the verified run, initial
`600010` errors were followed by successful text and images in the same worker.
Check the current request's final result before declaring a permanent blocker.
Any human verification must be handled normally by the user; never automate or
bypass a security challenge. A ready plugin or HTTP 200 verification response is
not proof of successful generation.

## Distribution

Download the complete [EmberAdventures play skill ZIP](https://github.com/andro951/ember-adventures-tools/raw/refs/heads/main/downloads/EmberAdventures-play-skills.zip).
For ordinary play, use the installed skill rather than updating it first.
Maintainers keep editable sources locally, validate, rebuild with the bundle's
`maintainer/package_skills.py --kind play`, update installed copies and archive
links, and push the complete ZIP. Publish ZIP files only. Never package raw
playtest reports, browser profiles, private preferences, generated images,
provider URL query strings, access keys, or caches.
