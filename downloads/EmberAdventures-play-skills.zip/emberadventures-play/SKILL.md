---
name: emberadventures-play
description: Playtest normal EmberAdventures through its existing Perchance harness with real text, images, and the complete local game UI. Use for manual gameplay, feature acceptance, response and retry review, and save/reload verification.
---

# EmberAdventures Play

Current skill version: `1.0.0`.

Use the existing normal-game interactive controller and Perchance worker, acting
as a player one action at a time. Read the replies, inspect images and actual
state, and adapt the next action. This is browser gameplay, not filesystem GM
play, a prompt-only probe, or an unattended smoke sequence.

Read [references/live-session.md](references/live-session.md) before launching.
It contains the tested startup, control commands, evidence checks, and recovery
details. Read the selected repository's working rules as well.

## Working route

- Use the canonical local normal EA checkout. On the verified laptop it is
  `D:/Program Files/JS Dev/EmberAdventures`; discover the corresponding checkout
  on another machine instead of copying that machine's paths blindly.
- Use `tools/perchance-ai-text-harness/interactive_emberadventures_ui_controller.mjs`
  with **`--managed-worker --real-all-text --real-images`** and isolated command,
  status and event files. Add `--capture-provider-evidence` for response review.
- The managed-worker option reuses the harness's existing temporary Playwright
  browser approach. External Edge opens the actual Perchance worker at
  `https://perchance.org/056uh2nc6k` in its own window; the local game opens in a
  separate isolated browser context. The same `browser-page-runner.mjs` runs
  actual plugin jobs inside the worker iframe.
- This mode uses a private automation pipe, without opening a TCP debugging port
  or reading a previously saved browser profile. Existing ready CDP workers can
  still use the controller's original attach mode, described in the reference.
- Allow page content to follow the browser window: headed contexts use
  `viewport: null`. A forced 1500x950 viewport makes the content stay fixed when
  the user resizes the window and is unsuitable for ordinary manual playtesting.
- Keep both windows available. Use the local game, not the published EA game.
  The real worker must report both text and image plugins available. A local
  game page by itself has no functioning Perchance generation provider.

## Play and judge

1. Write a short plan before playing: starting state, intended actions, expected
   and forbidden outcomes, and checkpoints. For a new system, use a tiny scenario
   on the production engine before full-game integration.
2. Start through the UI, or use the documented story-start bridge when menu setup
   is not what is being tested. Dismiss the actual Start Playing dialog. Never
   force objective completion or silently patch state to pass a checkpoint.
3. Issue one player action, read the actual reply, then inspect state and every
   retry. Prefer `waitVisible:false` during long generation so the controller
   remains available for status and UI observation. State updates may continue
   after narration; a returned dialogue reply does not establish state completion.
4. Use the full UI for NPC inspection, presence, objectives, settings, images,
   shops, editing/regeneration and saves as relevant. Observe hidden state only
   for verification; do not let it dictate what the player pretends to know.
5. Inspect successful provider results and real decoded/displayed images. Record
   format failures separately from provider failures, unclear prompts, model
   interpretation problems and engine errors. Tell the user about meaningful
   issues and proposed fixes.
6. Keep test data isolated. Do not erase or reuse player browser storage, personal
   profiles, account sessions or existing provider jobs. Do not add elapsed-time
   cancellation to live jobs. Explicit tester cancellation is an intervention.

## Evidence and limits

The normal-EA route was exercised on 23 October 2026: actual local-game controls,
story startup, a live narration turn and provider retry, plain-text objective and
state responses, real scene/profile image bytes, and responsive window resizing.
This proves the setup, not acceptance of every engine feature. Record subsequent
acceptance results separately; never treat Lite's older successful run as normal
EA proof or infer that prototype systems are integrated.

Perchance verification errors can be transient. In the verified run, initial
`600010` errors were followed by successful text and images in the same worker.
Check the current request's final result before declaring a permanent blocker.
Any human verification must be handled normally by the user; never automate or
bypass a security challenge. A ready plugin or HTTP 200 verification response is
not proof of successful generation.

## Distribution

Download the complete [EmberAdventures play skill ZIP](https://github.com/andro951/ember-adventures-tools/raw/refs/heads/main/downloads/EmberAdventures-play-skills.zip).
For ordinary play, use the installed skill rather than updating it first.
Maintainers keep editable sources locally, validate, rebuild with the bundle's
`maintainer/package_skills.py --kind play`, update installed copies and archive
links, and push the complete ZIP. Publish ZIP files only. Never package raw
playtest reports, browser profiles, private preferences, generated images,
provider URL query strings, access keys, or caches.
