# Tested normal-EA live session

## Start

Use the existing `tools/perchance-ai-text-harness` directory inside the normal
game checkout. Verify Node and Playwright dependencies there. On the verified
Windows laptop Node was `D:/nvm4w/nodejs/node.exe`; prefer the installed `node`
command where available. Rebuild with `node build_bottom_compressed.js` after
changing application source; changing only harness code does not change the game
build. Read a current story/fixture's contract before choosing playerIndex.

For ordinary Windows startup, double-click
`tools/perchance-ai-text-harness/Open EmberAdventures Playtest.cmd`, or run
`node tools/perchance-ai-text-harness/launch_playtest.mjs`. The launcher attaches
to the existing normal external Edge worker through CDP, default
http://127.0.0.1:9223, then starts the local game with its persistent game profile,
both real-generation flags and fresh command/status/event files. It prints
their directory and stays open. Edge must be opened separately first. An
unavailable endpoint is an error; no replacement worker is launched. An existing
older controller is not switched to the new method by changing configuration.
It does not start a generation or new story; resume through Continue Adventure.

Verified external-worker startup sequence:

1. Reuse an already-open controlled worker when available. Otherwise the original
   `tools/perchance-ai-text-harness/open_controlled_worker_browser.bat` opens
   external Edge with its dedicated persistent worker profile and the real
   Perchance worker on port 9222. If command execution rejects browser startup,
   have the user double-click that existing launcher normally.
2. Match `workerCdpUrl` in the local ignored configuration to the actual listening
   port (9222 for that BAT, rather than the attachment launcher's default 9223).
   Preserve the existing `gameProfile`.
3. Run the attachment launcher. Confirm `worker_ready` says `existing-browser`
   with both plugins, then resume through the local game's menus.
4. Verify real text and image results. A successful port/plugin check alone is
   insufficient. Initial verification errors can resolve in this same worker.
5. Keep this worker open. Refresh only the local game to load app edits after
   pending work settles; do not quit the controller merely to refresh game code.
   If a controller disconnect is necessary, preserve the independently opened
   worker and its profile. Never send Browser.close to the external worker's CDP
   session. Closing the user's worker requires a concrete reason and notice.

When replaying an edited turn, compare the actual persisted message rows with
runtime messages before and after reopening. A superseded reply disappearing
from runtime alone does not prove its stored row was deleted; an orphaned row
can return after reopening and incorrectly enter background state processing.

The optional local `state/playtest-launcher-config.json` contains exactly
`workerCdpUrl` and `gameProfile` non-empty strings. workerCdpUrl must be an HTTP
loopback address with an explicit valid port; default http://127.0.0.1:9223.
gameProfile is resolved against the checkout and must be a dedicated profile
under harness state or test-output; its default is state/interactive-browser-profile.
Preserve the SAME chosen game profile across connection changes. Old workerProfile
config is rejected rather than silently migrated. Keep this local configuration
and browser storage out of skill ZIPs/public commits. --check reports existing
controller ids, the configured address and endpoint reachability, not plugin or
generation success. --dry-run prints the arguments and CDP environment. Neither
option opens a browser.

The launcher omits --managed-worker, --worker-profile and --no-harness, and now
includes --local-worker-source. The external Edge/CDP connection and dedicated
profiles are unchanged; this option updates the task-owned worker adapter in
its existing frame so real onChunk events reach the local game before the final
response. Older controllers delivered one whole-response chunk, which did not
exercise live-stream rendering. After the real Perchance page
imports both plugins, the runner checks the HTTPS frame origin and idle-job
state, rebinds only the harness's three batch controls, and initializes the complete
checked-in perchance-browser-worker-bottom.html there without replacing its panel. Perchance imports and
provider-owned verification frames remain intact. The worker_source event logs
the exact local SHA-256 and resulting plugin environment. Matching source is
not installed twice, and active text/image jobs prevent replacement.

This is a private test-runtime source load, not a publication of the hosted
generator or a change to provider verification. It ensures local worker fixes,
including provider-lifetime image waits, are actually running. Inspect the
source event before assuming that pushing local files updated a Perchance page.
Verify real chunk events and displayed text rather than treating plugin-ready
status or a final response as proof of streaming. Pushing source does not
publish the hosted generator.

Choose the worker connection before starting the controller. The desktop handoff
used a normal external Edge worker with a dedicated persistent worker profile,
then attached through CDP. The optional managed-worker route below uses a
temporary worker profile unless --worker-profile is supplied. The game's
persistent profile is separate in both cases. Reopening a default temporary
managed worker does not preserve its cookies/site state.

To attach to an existing controlled worker, inspect the actual listening port,
set EMBERADVENTURES_AI_TEXT_HARNESS_CDP_URL to that local address, and omit
--managed-worker. The existing open_controlled_worker_browser.bat defaults to
9222; the desktop handoff used 9223. Reuse the available worker rather than
launching duplicates. Only use a dedicated harness profile, not a personal one.

```powershell
$env:EMBERADVENTURES_AI_TEXT_HARNESS_CDP_URL = "http://127.0.0.1:9223"
node tools/perchance-ai-text-harness/interactive_emberadventures_ui_controller.mjs --real-all-text --real-images --capture-provider-evidence --local-worker-source --playtest-profile=test-output/manual-play-profile --commands=test-output/manual-play-UNIQUE/commands.jsonl --status=test-output/manual-play-UNIQUE/status.json --events=test-output/manual-play-UNIQUE/events.jsonl
```

Use the actual explicitly selected port. This connects to an already-open browser;
it does not launch the worker. If a required browser launch is rejected by
execution policy, record the exact rejection and ask for the normal manual
launch; do not retry it through another wrapper. Continue independent work while
awaiting that prerequisite. Never copy verification tokens or clear cookies to
manufacture a successful connection.

Only when a different approach is explicitly chosen, the temporary managed-worker
mode can be run as follows from the game repository
through a long-lived terminal/tool session and retain its session id. Choose
fresh command/event files after a controller restart (commands replay from the
beginning), but keep the SAME dedicated test-game profile and resume its save.

```powershell
node tools/perchance-ai-text-harness/interactive_emberadventures_ui_controller.mjs --managed-worker --real-all-text --real-images --capture-provider-evidence --local-worker-source --playtest-profile=test-output/manual-play-profile --commands=test-output/manual-play-UNIQUE/commands.jsonl --status=test-output/manual-play-UNIQUE/status.json --events=test-output/manual-play-UNIQUE/events.jsonl
```

For a persistent worker through that same private automation pipe, add
`--worker-profile=tools/perchance-ai-text-harness/state/edge-harness-profile`.
That is the dedicated worker directory, not the saved-game profile. Reuse it
only while no other browser owns it. The controller uses launchPersistentContext
and reuses its initial tab, preserving site state without adding a TCP debugging
port or overriding browser security. Do not claim this transport is identical to
the desktop's CDP attachment. Readiness events record persistent versus temporary
worker mode; actual generation results are still required for acceptance.

The controller serves the local game at `http://127.0.0.1:51818/bottom.html` if
needed. `EMBERADVENTURES_LOCAL_URL` can select a private production-engine feature
page on that server. It derives the repository from its own location. Do not
start a competing server or open multiple controllers against the same files.

For an isolated feature build, `open_local_game` accepts a repository-relative
HTML `path`, such as `test-output/feature-prototypes/memories-beliefs/bottom.html`.
It navigates the SAME local game tab, keeps its persistent profile, and keeps the
external worker connection. It refuses pending game/generation/state/image work
and files outside the checkout or existing local server. Return to `bottom.html`
with the same command and resume the desired saved adventure through the menu.
Starting a separate feature save is intentional; do not overwrite the main test
adventure or regenerate its images when switching pages. An assembled feature
overlay must guard DOM/runtime hooks to an actual Window because story validation
also executes application source in a worker with DOM stubs.

On 24 October the existing external worker stayed open across a controller quit
and restart; the new controller reported the same worker origin and both plugins.
For the installed Playwright CDP adapter, Browser.close disconnects its transport
and does not send Chromium Browser.close. Do not assume this for other adapters
or explicitly send Browser.close through CDP. Refresh only the local page for
application edits; controller changes alone require a reconnection.

Managed-worker mode opens one worker browser and one local-game
browser. The game uses its dedicated persistent test profile by default; the
Perchance worker is temporary unless --worker-profile is provided. Do not use --ephemeral for ordinary reusable
playtesting. It does not need a CDP listener, a personal profile, a login, or
a host token. Reuse the game's initial tab instead of leaving about:blank next
to it. Leave the worker visible in its own external window. Both headed
contexts use `viewport:null`, allowing native resizing. The normal controller
and browser-page-runner remain the request and game-control implementation.

The managed worker uses a private pipe without a debugging socket. Its storage
is temporary or persistent according to --worker-profile; the local-game profile
is configured independently. Compare
these details explicitly when asked whether a setup matches an earlier run.
The direct browser-page runner invokes imported plugins inside the real worker
iframe in either mode. Do not replace it with direct HTTP generation requests.
The older handoff's timeoutMs option is not permission to reintroduce a live
provider deadline; the current direct runner waits for the provider result.

## One action at a time

Append one JSON object per line to this run's command file. Use unique ids.
The existing `enqueue_interactive_command.mjs` accepts `--commands=...` and
`--json=...`, or JSON through stdin. Alternatively use a literal here-string and
`Add-Content -LiteralPath ...`; never interpolate dialogue as shell code.

```json
{"id":"start","cmd":"start_story","story":"Mayor-Goostave.json","playerIndex":0}
{"id":"begin","cmd":"modal_click","text":"Start Playing","waitVisible":false}
{"id":"look","cmd":"send_text","text":"I quietly observe the room before approaching the counter.","waitVisible":false}
{"id":"observe","cmd":"status"}
{"id":"controls","cmd":"list_controls"}
{"id":"picture","cmd":"screenshot","path":"D:/absolute/test-output/run/game.png"}
```

These illustrate separate actions, not a batch to send without reading results.
Use an actual current story and natural player messages suited to its response.
Story files can be absolute paths, including a tiny scenario on the production
engine. Starting through the bridge is test setup, not evidence of menu import.

For a real local-file import, click Import in the actual library and wait for
its Import Files source dialog. Use `choose_file` with `text:"Computer"` and
`file` (or `files`) pointing to the original JSON, Brotli or ZIP file. The
controller listens for the native file chooser before clicking Computer and
supplies the file through that chooser, preserving the app's real decoder,
validator, import worker and confirmation flow. For an attached file input,
`upload_control` remains available. `import_story_files`/`loadStoryPayload` are
bridge setup; they do not prove the compressed-file or UI import path worked.

After sending text, inspect `status.json`, `events.jsonl`, provider evidence and
the visible game. The status file updates after a command finishes; it is not a
continuous heartbeat. A default send command waits for a visible reply and can
hold the command loop while a provider job is pending. `waitVisible:false` returns
control after submitting the action so subsequent status/screenshots can run.
Do not submit the next story action just because the controller accepted the
previous command. Check `aiActive`, queue counts, stateSync processing and each
message's sync status. Background state checks can outlast the visible reply.

Prefer `waitVisible:false` for UI-only clicks too, especially a navigation or
metadata action that might leave the visible controls unchanged. Inspect its
result with status afterward. The default click observer can otherwise hold the
command queue for six minutes while waiting for a change that did not occur;
that observation wait is not a pending provider job or permission to restart it.

Read `status.controls` for current labels, context, ids and values. Modal-open
controls are scoped to that modal. Use the existing `click_control`,
`fill_control`, `select_control`, `set_checked`, `upload_control`, `press`,
`scroll`, `open_characters`, `open_state`, `open_images`, `open_settings`,
`open_shops` and related commands. Dismiss a modal before acting behind it.
Use `worker_screenshot` to inspect the separate worker without changing the
game. Use `resize_window` with width/height for native-window verification;
it uses the owned browser's private connection, not a new remote-debugging port.

Use `quit` only when the session should close. Closing cancels outstanding work;
record that as explicit test cancellation, not a provider failure. The game
context is persistent by default. Verify its owning save transaction has finished
before closing; reopen the same profile and resume the existing game and images.
Do not rerun start_story on every controller launch. Use the reload command to
test an actual browser-page refresh, not a keyboard shortcut that the app may
intercept. The reload command refuses to interrupt pending generation/state work.
An explicit --ephemeral context does not survive closing. Treat recovery/reimport
as an intervention, not ordinary save/resume evidence.

## Player actions versus developer verification

Navigate and play through the actual UI. After an action, use the bridge's
read-only runtime summary, persisted records/exported save, provider responses,
logs, and source code to verify the expected result efficiently. For example,
count NPC identities in state/save records; do not open Characters just to count
them. Compare stable ids, selected portrait ids, stored image assets, inspection
state and full definitions directly when checking persistence. Do not modify an
active database behind the game or manufacture a successful checkpoint.

Use the UI separately to verify card rendering, displayed image bytes/captions,
button behavior, and actual reload/resume. Once a failure is identified, switch
to developer diagnosis and the authorized fix. If needed data is not exposed,
add a narrow read-only inspection hook rather than navigating editor screens
solely to scrape internal values. Resume player actions after that work; hidden
developer information must not become player knowledge.

## Completion notifications and concurrent work

The controller appends ai_text and image events when real provider calls return.
Evidence files, when enabled, are written before these events. Subscribe BEFORE
triggering generation using the bundled watcher (replace SKILL_ROOT):

```powershell
node "SKILL_ROOT/scripts/watch-generation-events.mjs" --events=D:/absolute/run/events.jsonl
```

It watches filesystem changes without a timer loop, ignores existing history and
stubs, buffers incomplete lines, and prints one compact JSON notice per real
text/image result. --once exits after the next notice; --from-start replays
history for diagnosis only. Notices include evidence paths and stop reasons,
never generated content, prompts, image data or provider URL queries. A text result stopped with error, artificial, user, interrupted, or another
unrecognized reason is reported as failed even when ok:true. Only EA's natural/stop/complete/completed reasons count as successful named stops.

Connect watcher output to the active agent tool session instead of relying only
on manual status polling. With functions.exec, start the --once watcher through
tools.exec_command, retain its session_id, and keep an awaited monitor alive:

```javascript
//Use a correctly quoted command for the current shell and installed skill path.
let result = await tools.exec_command({cmd: watcherCommand, yield_time_ms: 1000});
if (result.output) notify(result.output);
await yield_control();
while (result.session_id) {
  result = await tools.write_stdin({session_id: result.session_id, chars: "", yield_time_ms: 1000});
  if (result.output) notify(result.output);
}
```

This forwards completion output while that exec cell is active, allowing useful
independent work between notifications. Keep/rearm the subscription for later
jobs. Do not leave unawaited promises: the tool discards them when the cell ends.
The terminal printing by itself does not notify the agent, and this mechanism
does not schedule a new turn after the conversation/tool cell has ended. If the
host cannot deliver asynchronous notifications, state that limitation and use
bounded event waits at work checkpoints; do not pretend it can wake the agent.

While generation is pending, inspect relevant code, verify earlier accepted
changes/persistence, review retries, or prepare the next targeted test/fix. Do
not edit live test state, refresh, or send dependent turns while prerequisites
are unresolved. A provider completion is not proof that NPC extraction,
background state application, image presentation, or save transactions finished.
Read the final application state and the actual provider evidence at the next
checkpoint. Run scripts/test-generation-events.mjs to verify the watcher without
starting a model or playing the game.

## Real-provider proof and retry review

Check worker_ready.environment for BOTH `hasAiTextPlugin` and
`hasTextToImagePlugin`; they live inside the Perchance iframe. Verify the game
menu/bridge, `EmberAdventures.isReady() === true` AND
`EmberAdventures.isSystemReady() === true`. Bridge existence and worker services
can precede saved-data hydration. The controller now waits for both readiness
checks; the story-start bridge rejects premature calls before importing or
mutating anything. On an older already-running controller, wait until the
summary reports `ready:true` and `systemReady:true` after each reload before
starting or importing a story. A fixed one-second sleep is insufficient. Do not
block normal menu artwork such as user.uploads.dev.

Evidence capture records exact provider prompts and returned answers under the
run's `provider/` folder. Inspect every repair/retry and accepted mutation.
The current promptKind label can say json when the prompt says "Do not return
JSON"; inspect the actual contract and answer rather than that diagnostic label.
Structured prompt inputs are compatible with the plain-text output policy.

Check `result.meta.stopReason` too: a result envelope can be ok:true with partial
text and stopReason:error. In the verified run, such a narration attempt retried
and was replaced by a natural completion. Classify that as a provider retry,
not a text-format repair. Never silently count a partial/error response as a
completed successful turn.

Successful responses from these provider routes corroborate generation:

- `text-generation.perchance.org/api/generate`
- `image-generation.perchance.org/api/generate`
- `image-generation.perchance.org/api/downloadTemporaryImageViaProxy`

HTTP responses alone are insufficient. Read returned prose and internal text;
decode image data from the returned dataUrl, save it as a local image, inspect
its pixels with the image viewer, and verify the game's displayed image.
Verify stored appearance/subjects and current UI state rather than assuming a
model followed the prompt. Do not print base64 data or provider userKey values.
Network summaries keep origin/path/status only, not credential-bearing queries.

Initial verification failures do not necessarily end a job. On 23 October the
worker emitted 600010 errors, then returned real scene/profile images and text
without a replacement worker or a challenge bypass. Observe the pending result;
ask the user about any actual visible verification control only when needed.
Do not declare the entire setup broken solely from a historical verification
request. Do not add timeouts or a stealth/verification bypass.

## Evidence boundary

The 23 October setup proved normal EA startup, real narration with provider
recovery, plain-text objective/state answers, real scene/profile images and
native viewport resizing. It did not complete all plot-point, memory/belief,
save/replay, editing, or gameplay acceptance scenarios. Use prewritten plans,
record results per checkpoint, and clearly distinguish implementation, offline
checks, live checks, outstanding failures and manual interventions.

Keep raw reports and temporary browser state out of Git/skill archives. Public
notes should contain generic reproduction steps and conclusions only. Publish
the skill as a complete ZIP via maintainer/package_skills.py; never loose files.


## Foreground dialogs and saved-record inspection

The current controller discovers and acts on the foreground popup before the
underlying main modal. Use the fresh control inventory after opening or closing
a popup. Menu clicks recognize UI changes; narration waits still require a
finished message. A card's selected portrait may move to the first position,
so compare its stable id or numbered badge rather than its gallery position.

For an updated story import,verify the selected source before a long replay.
A success notice alone does not prove the adventure used that revision. After
startup,use inspect_save with includeStory:true and an isolated output path.
Its persisted.immutableDefinition comes from the saved storyId/revisionId through
the existing read-only persistence API,not the library's latest pointer. Compare
the changed authored objectives/rewards with the intended file before playing
on. Ordinary inspect_save omits this large definition. Preserve existing saves'
immutable revisions;do not patch them to manufacture the new source. A27October
file-import regression retained an older first entry for the same ID despite a
successful updated-file import,so an actual started-save source check matters.

`inspect_save` writes a read-only diagnostic combining the persistence save
query (including message pages) with shared portrait and selection records from
the existing reconstruction API. Reconstruction alone does not load message
pages. Compare runtime and persisted values after the relevant work settles;
do not flush or patch storage merely to make a checkpoint pass.

The normal game's developer summary also exposes detached `state.combat`
(including pending openings and applied round receipts) and
`state.combat_participants` (stable ids, original death eligibility and current
profiles). Use these in `inspect_save` for damage, cancellation, once-only
opening and reload comparisons; preserve the complete evidence locally.
Absent characters are not combat participants. Their condition must still
survive in the narrator's absent-character context when returning to them.
A narrative recovery is a failure even when numerical HP stayed unchanged.
Read the actual provider request to distinguish omitted state from ignored
instructions, and never silently rewrite HP/conditions to make a test pass.
Use an absolute events-file path for the generation watcher, and verify a
completion notice actually arrives after a new generation before relying on it.

For newly generated combat hits, verify an explicit `nonlethal` boolean in
every event,independently for repeated or opposing hits. The private account
must decide nonlethal or potentially lethal. Reduced Strength or restrained
technique alone is not a declaration. Extraction must not invent that choice.
Missing choices trigger a separate private prose clarification and re-extraction;
original hit count/order,attacker,target,type,Strength and any existing decision
must remain exact. No HP or receipt is committed until the complete decision and
final narration succeed. Normal complete decisions need no clarification call.
Test both the ordinary full-game path and actual provider clarification;label a
read-only replay of a recorded account as component evidence,not new gameplay.
Check nonlethal at positive/negative HP,lethal at the negative floor,failed or
canceled clarification,and undo/reload. Historical canonical optional flags
remain valid;do not migrate or patch saved receipts to make this check pass.




## Scene ownership and replay checks

The quick movement check and final presence-only check own physical scene
membership. NPC identity discovery runs separately before that final check.
The final check reuses the movement checker after the completed exchange; it
adds one small per-reply provider call instead of making the slow updater or
identity classification decide proximity. The slow updater must not change those lists, create/inspect NPCs,
rewrite identity/name knowledge, image composition/actions, or fields owned by
immediate condition, knowledge, combat and exploration checks. Summary/time and
other slow-owned facts still catch up normally. Inspect both grouped and combined
mode boundaries, including repairs and forced catch-up; a rejected response must
not retain a protected write as an accepted partial patch.

Verify the final scene after immediate work AND after slow catch-up. Test split
rooms inside one map location, silent companions/animals, an arrival followed by
departure, offscreen voices, and actual re-entry. A new person who speaks briefly
or is individually seen and then leaves still needs a stored NPC, absent at the
end. Existing records/portraits must survive separation and be reused on return.
New unnamed people need distinct singular public descriptions based on observed
traits. Their short player_facing_label is separate from the literal original
source reference and private generated name. Test two people with the same role,
reversed definition order, duplicate labels, genuine name disclosure, and reload.
Definitions must bind to exact individual source references; never assign by list
order or share a group label. A bad batch must be corrected before creating any
NPC, and repair replaces that batch instead of appending duplicates. Existing
known names/IDs/portraits must survive rediscovery.

Identity-only known records cannot establish arrival. Newly added absent people
need exact physical evidence; repeating an exact already-present arrival is a
no-op and must not invalidate other supported changes.

Each presence change or group can have its own exact evidence line. Test a
physical departure and a silent arrival established in different paragraphs;
the response must not have to join them into one invented quote. All evidence
must validate before any change applies. Show latest source as ordinary text,
not an escaped JSON string that encourages copying literal newline escapes.

For a no-change memory answer, the AI boundary logs and normalizes only the
exact standalone provider phrase return none to none. Mixed/malformed memory
records still reject; canonical saved data never passes through this normalizer.
A formatting correction passing unit checks is not live acceptance: replay the
failed edit and verify the completed exchange receipt and native reload.

Assistant text edits must rerun the same completed-reply people check as generated
replies; regeneration must not run it twice. Check native undo/reload and stale
results after message revision or save replacement. Do not patch a saved presence
list to pass these tests. A successful narration or correct initial membership
does not prove later background work, images and persisted records stayed correct.

Keep mechanical extraction tasks free from narrator-role and story-writing
instructions. Mark an already complete extraction prompt with
hasUniversalContext:true so aiText does not add universal narration guidance.
Give the model an explicit output cue after source text. Review the actual final
prompt: on26October a discovery request contained two copies of story guidance
and ended on story prose, and Perchance continued the story instead of emitting
records. Test this boundary separately from creative character definition.

## NPC name visibility acceptance

An NPC's canonical full name/ID is private identity and voice-routing data until
actually learned. Present and absent narrator records carry player_known_name
and player_facing_label. Test a newly observed silent person,not just an old NPC
whose name already leaked in a prior reply. Capture the generated private name,
false flag and distinct public descriptor through native inspection. Follow up
without asking a name;public prose and speaker headings must keep the descriptor.
Then ask a first name and full name naturally,and verify public labels change
only with actual disclosure while the same identity/portrait survives inspection
and reload. Internal parenthesized voice tags alone are not disclosure evidence.
Name privacy must hold for inspected/uninspected NPCs and nonhumanoids too.

The narrator can describe an unnamed person and use a descriptive new-speaker
tag;the separate identity generator still assigns an internal full name. Existing
recorded speakers keep canonical tags so voice/recovery routing stays exact.
Failed-speaker LookAt remains available for unresolved tags. Never rename saved
people,merge duplicate descriptors or replace words after display to fake a pass.
Explicitly distinguish model prose leakage from a UI heading that wrongly shows
the private name;both are acceptance failures but have different owning code.

Identity matching must receive the actual linked player turn as well as the
completed narrator reply. Verify explicit unfamiliar/new-person constraints are
not dropped before matching;shared gender,age or species is not identity proof.
Do not invent a costume change to force a stranger onto an existing person's ID.
Discovery source references must remain literal contiguous passages;when prose
describes a person and their coat in separate sentences,the source reference can
be short and the later public label can be descriptive. Keep that distinction
instead of relaxing exact-source validation after a paraphrased model response.

Once identity matching selects a NEW person,the creative-definition and
serialization stages must preserve that decision. Review the serialized result
before normalization can turn a duplicate reserved name into an existing-person
reference. A rejected duplicate must retry the whole new definition batch,
without redesigning the existing person or adding a duplicate directory entry.
Check native prompt-editor replay metadata also retains the selected-new scope.
A character refusing a name request is a valid story outcome;verify it leaves
the unknown flag/descriptor unchanged instead of forcing an introduction.

Include Scene/In Images buttons,directory search text,inspection progress,
inspection completion,stats button accessibility/panel headings and the optional
library-save offer in name-privacy UI
checks. Canonical click/save targets stay unchanged. Test native edit/undo after
inspection:the full definition should rewind with its source capture while an
NPC introduced earlier retains its identity. Do not count a newly anonymous
stranger as proof that narration no longer repeats old names already leaked in
history;record that separate case explicitly.

The completion watcher also checks the event-file stat every500ms because native
Windows directory notifications can be missed. This is a local script fallback,
not another model call or browser-status loop. `--poll-only` tests that route.
Both routes share one offset and must not emit a completion twice.

## Browser-crash and memory diagnostics

Normal builds keep a bounded, local technical journal and recover suspected
unclean exits on reopening. Tools has Performance / crash report. A detected
unclean exit requests one report download and shows a retry/dismiss notice;
browser download policy can require the manual button. These reports do not
prove out-of-memory. They record counters, phases, JavaScript heap (when the
browser exposes it) and timing, not narration, images, prompts or credentials.

The controller captures only emberadventures-browser-report-*.txt downloads in
its session's browser-diagnostic-downloads folder. Check the download event and
actual file, not merely the banner. Private smoke builds intentionally skip
the normal journal/recovery. Suspended hidden tabs release diagnostic locks
and timers; another tab must not label them as crashed. Hidden-document
recovery needs same-tab reload/discard evidence. Normal pagehide removes the
current journal. Detection is best effort, especially when browser storage or
Web Locks are unavailable or the browser removes session storage.

For an owned, idle local game only, memory_start with a host path records CDP
heap/DOM measurements without changing game data. memory_stop ends it;
collectGarbage:true requests an explicit diagnostic GC and must be disclosed
when interpreting results. A lower heap after forced GC does not disprove a
renderer/worker/image memory problem. Stop probes after the measurement.

To verify crash recovery, preserve a native-save checkpoint, confirm all live
text/image/state/save work has settled, then use simulate_crash. This really
crashes only the owned test game's renderer; keep the external worker open.
Quit the controller and rerun the launcher with the same game profile; attempting
page.goto on the crashed Playwright page can remain rejected as Page crashed.
Compare native records after normal UI resume, inspect the automatically captured report and retry button,
then check that a clean reload does not download it again. Never do this in a
personal player session or interrupt an active provider request. Record a
successful recovery separately from any claim to have fixed the crash cause.
