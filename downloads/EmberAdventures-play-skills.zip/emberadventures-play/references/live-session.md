# Tested normal-EA live session

## Start

Use the existing `tools/perchance-ai-text-harness` directory inside the normal
game checkout. Verify Node and Playwright dependencies there. On the verified
Windows laptop Node was `D:/nvm4w/nodejs/node.exe`; prefer the installed `node`
command where available. Rebuild with `node build_bottom_compressed.js` after
changing application source; changing only harness code does not change the game
build. Read a current story/fixture's contract before choosing playerIndex.

From the game repository, run this command through a long-lived terminal/tool
session and retain its session id. Choose a fresh run folder each time; command
files are replayed from the beginning in a new controller process.

```powershell
node tools/perchance-ai-text-harness/interactive_emberadventures_ui_controller.mjs --managed-worker --real-all-text --real-images --capture-provider-evidence --commands=test-output/manual-play-UNIQUE/commands.jsonl --status=test-output/manual-play-UNIQUE/status.json --events=test-output/manual-play-UNIQUE/events.jsonl
```

The controller serves the local game at `http://127.0.0.1:51818/bottom.html` if
needed. `EMBERADVENTURES_LOCAL_URL` can select a private production-engine feature
page on that server. It derives the repository from its own location. Do not
start a competing server or open multiple controllers against the same files.

Managed-worker mode opens exactly one temporary worker browser and one local-game
browser. It does not need a CDP listener, a supplied private profile, a login, or
a host token. Leave the worker visible in its own external window. Both headed
contexts use `viewport:null`, allowing native resizing. The normal controller
and browser-page-runner remain the request and game-control implementation.

If an already-open worker has an accessible CDP listener and working plugins,
the original attach route remains supported: omit `--managed-worker`, set
`EMBERADVENTURES_AI_TEXT_HARNESS_CDP_URL` to the actual listener, and retain both
real flags. The laptop launcher defaults to 9222; the desktop handoff used 9223.
Do not assume a port is active. Do not retry a rejected launch through an
equivalent wrapper; follow tool restrictions and report the exact rejected
action. The tested managed route has a narrower boundary: an ephemeral browser
and private pipe, without a debugging socket or stored-profile access.

## One action at a time

Append one JSON object per line to this run's command file. Use unique ids.
The existing `enqueue_interactive_command.mjs` accepts `--commands=...` and
`--json=...`, or JSON through stdin. Alternatively use a literal here-string and
`Add-Content -LiteralPath ...`; never interpolate dialogue as shell code.

```json
{"id":"start","cmd":"start_story","story":"Mayor-Goostave.json","playerIndex":0}
{"id":"begin","cmd":"modal_click","text":"Start Playing","waitVisible":false}
{"id":"look","cmd":"send_text","text":"I quietly observe the room before approaching the counter.","waitVisible":false}
{"id":"observe","cmd":"status"}
{"id":"controls","cmd":"list_controls"}
{"id":"picture","cmd":"screenshot","path":"D:/absolute/test-output/run/game.png"}
```

These illustrate separate actions, not a batch to send without reading results.
Use an actual current story and natural player messages suited to its response.
Story files can be absolute paths, including a tiny scenario on the production
engine. Starting through the bridge is test setup, not evidence of menu import.

After sending text, inspect `status.json`, `events.jsonl`, provider evidence and
the visible game. The status file updates after a command finishes; it is not a
continuous heartbeat. A default send command waits for a visible reply and can
hold the command loop while a provider job is pending. `waitVisible:false` returns
control after submitting the action so subsequent status/screenshots can run.
Do not submit the next story action just because the controller accepted the
previous command. Check `aiActive`, queue counts, stateSync processing and each
message's sync status. Background state checks can outlast the visible reply.

Read `status.controls` for current labels, context, ids and values. Modal-open
controls are scoped to that modal. Use the existing `click_control`,
`fill_control`, `select_control`, `set_checked`, `upload_control`, `press`,
`scroll`, `open_characters`, `open_state`, `open_images`, `open_settings`,
`open_shops` and related commands. Dismiss a modal before acting behind it.
Use `worker_screenshot` to inspect the separate worker without changing the
game. Use `resize_window` with width/height for native-window verification;
it uses the owned browser's private connection, not a new remote-debugging port.

Use `quit` only when the session should close. Closing cancels outstanding work;
record that as explicit test cancellation, not a provider failure. The default
game context is temporary. Save/export through the actual UI before closing if
the playthrough must survive; persist:true alone does not preserve an ephemeral
browser directory. Treat any recovery or reimport as an intervention.

## Real-provider proof and retry review

Check worker_ready.environment for BOTH `hasAiTextPlugin` and
`hasTextToImagePlugin`; they live inside the Perchance iframe. Verify the game
menu/bridge and `EmberAdventures.isSystemReady()`, not isReady() alone. Do not
block normal menu artwork such as user.uploads.dev.

Evidence capture records exact provider prompts and returned answers under the
run's `provider/` folder. Inspect every repair/retry and accepted mutation.
The current promptKind label can say json when the prompt says "Do not return
JSON"; inspect the actual contract and answer rather than that diagnostic label.
Structured prompt inputs are compatible with the plain-text output policy.

Check `result.meta.stopReason` too: a result envelope can be ok:true with partial
text and stopReason:error. In the verified run, such a narration attempt retried
and was replaced by a natural completion. Classify that as a provider retry,
not a text-format repair. Never silently count a partial/error response as a
completed successful turn.

Successful responses from these provider routes corroborate generation:

- `text-generation.perchance.org/api/generate`
- `image-generation.perchance.org/api/generate`
- `image-generation.perchance.org/api/downloadTemporaryImageViaProxy`

HTTP responses alone are insufficient. Read returned prose and internal text;
decode image data from the returned dataUrl, save it as a local image, inspect
its pixels with the image viewer, and verify the game's displayed image.
Verify stored appearance/subjects and current UI state rather than assuming a
model followed the prompt. Do not print base64 data or provider userKey values.
Network summaries keep origin/path/status only, not credential-bearing queries.

Initial verification failures do not necessarily end a job. On 23 October the
worker emitted 600010 errors, then returned real scene/profile images and text
without a replacement worker or a challenge bypass. Observe the pending result;
ask the user about any actual visible verification control only when needed.
Do not declare the entire setup broken solely from a historical verification
request. Do not add timeouts or a stealth/verification bypass.

## Evidence boundary

The 23 October setup proved normal EA startup, real narration with provider
recovery, plain-text objective/state answers, real scene/profile images and
native viewport resizing. It did not complete all plot-point, memory/belief,
save/replay, editing, or gameplay acceptance scenarios. Use prewritten plans,
record results per checkpoint, and clearly distinguish implementation, offline
checks, live checks, outstanding failures and manual interventions.

Keep raw reports and temporary browser state out of Git/skill archives. Public
notes should contain generic reproduction steps and conclusions only. Publish
the skill as a complete ZIP via maintainer/package_skills.py; never loose files.
