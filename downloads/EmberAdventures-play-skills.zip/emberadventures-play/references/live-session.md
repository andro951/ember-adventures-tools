# Tested normal-EA live session

## Start

Use the existing `tools/perchance-ai-text-harness` directory inside the normal
game checkout. Verify Node and Playwright dependencies there. On the verified
Windows laptop Node was `D:/nvm4w/nodejs/node.exe`; prefer the installed `node`
command where available. Rebuild with `node build_bottom_compressed.js` after
changing application source; changing only harness code does not change the game
build. Read a current story/fixture's contract before choosing playerIndex.

From the game repository, run this command through a long-lived terminal/tool
session and retain its session id. Choose fresh command/event files after a
controller restart (commands replay from the beginning), but keep the SAME
dedicated test-game profile and resume its existing save.

```powershell
node tools/perchance-ai-text-harness/interactive_emberadventures_ui_controller.mjs --managed-worker --real-all-text --real-images --capture-provider-evidence --playtest-profile=test-output/manual-play-profile --commands=test-output/manual-play-UNIQUE/commands.jsonl --status=test-output/manual-play-UNIQUE/status.json --events=test-output/manual-play-UNIQUE/events.jsonl
```

The controller serves the local game at `http://127.0.0.1:51818/bottom.html` if
needed. `EMBERADVENTURES_LOCAL_URL` can select a private production-engine feature
page on that server. It derives the repository from its own location. Do not
start a competing server or open multiple controllers against the same files.

Managed-worker mode opens exactly one temporary worker browser and one local-game
browser. The game uses its dedicated persistent test profile by default; the
Perchance worker remains temporary. Do not use --ephemeral for ordinary reusable
playtesting. It does not need a CDP listener, a personal profile, a login, or
a host token. Reuse the game's initial tab instead of leaving about:blank next
to it. Leave the worker visible in its own external window. Both headed
contexts use `viewport:null`, allowing native resizing. The normal controller
and browser-page-runner remain the request and game-control implementation.

If an already-open worker has an accessible CDP listener and working plugins,
the original attach route remains supported: omit `--managed-worker`, set
`EMBERADVENTURES_AI_TEXT_HARNESS_CDP_URL` to the actual listener, and retain both
real flags. The laptop launcher defaults to 9222; the desktop handoff used 9223.
Do not assume a port is active. Do not retry a rejected launch through an
equivalent wrapper; follow tool restrictions and report the exact rejected
action. The managed worker uses an ephemeral browser and private pipe without a
debugging socket; only the isolated test-game context uses persistent storage.

## One action at a time

Append one JSON object per line to this run's command file. Use unique ids.
The existing `enqueue_interactive_command.mjs` accepts `--commands=...` and
`--json=...`, or JSON through stdin. Alternatively use a literal here-string and
`Add-Content -LiteralPath ...`; never interpolate dialogue as shell code.

```json
{"id":"start","cmd":"start_story","story":"Mayor-Goostave.json","playerIndex":0}
{"id":"begin","cmd":"modal_click","text":"Start Playing","waitVisible":false}
{"id":"look","cmd":"send_text","text":"I quietly observe the room before approaching the counter.","waitVisible":false}
{"id":"observe","cmd":"status"}
{"id":"controls","cmd":"list_controls"}
{"id":"picture","cmd":"screenshot","path":"D:/absolute/test-output/run/game.png"}
```

These illustrate separate actions, not a batch to send without reading results.
Use an actual current story and natural player messages suited to its response.
Story files can be absolute paths, including a tiny scenario on the production
engine. Starting through the bridge is test setup, not evidence of menu import.

After sending text, inspect `status.json`, `events.jsonl`, provider evidence and
the visible game. The status file updates after a command finishes; it is not a
continuous heartbeat. A default send command waits for a visible reply and can
hold the command loop while a provider job is pending. `waitVisible:false` returns
control after submitting the action so subsequent status/screenshots can run.
Do not submit the next story action just because the controller accepted the
previous command. Check `aiActive`, queue counts, stateSync processing and each
message's sync status. Background state checks can outlast the visible reply.

Read `status.controls` for current labels, context, ids and values. Modal-open
controls are scoped to that modal. Use the existing `click_control`,
`fill_control`, `select_control`, `set_checked`, `upload_control`, `press`,
`scroll`, `open_characters`, `open_state`, `open_images`, `open_settings`,
`open_shops` and related commands. Dismiss a modal before acting behind it.
Use `worker_screenshot` to inspect the separate worker without changing the
game. Use `resize_window` with width/height for native-window verification;
it uses the owned browser's private connection, not a new remote-debugging port.

Use `quit` only when the session should close. Closing cancels outstanding work;
record that as explicit test cancellation, not a provider failure. The game
context is persistent by default. Verify its owning save transaction has finished
before closing; reopen the same profile and resume the existing game and images.
Do not rerun start_story on every controller launch. Use the reload command to
test an actual browser-page refresh, not a keyboard shortcut that the app may
intercept. The reload command refuses to interrupt pending generation/state work.
An explicit --ephemeral context does not survive closing. Treat recovery/reimport
as an intervention, not ordinary save/resume evidence.

## Player actions versus developer verification

Navigate and play through the actual UI. After an action, use the bridge's
read-only runtime summary, persisted records/exported save, provider responses,
logs, and source code to verify the expected result efficiently. For example,
count NPC identities in state/save records; do not open Characters just to count
them. Compare stable ids, selected portrait ids, stored image assets, inspection
state and full definitions directly when checking persistence. Do not modify an
active database behind the game or manufacture a successful checkpoint.

Use the UI separately to verify card rendering, displayed image bytes/captions,
button behavior, and actual reload/resume. Once a failure is identified, switch
to developer diagnosis and the authorized fix. If needed data is not exposed,
add a narrow read-only inspection hook rather than navigating editor screens
solely to scrape internal values. Resume player actions after that work; hidden
developer information must not become player knowledge.

## Completion notifications and concurrent work

The controller appends ai_text and image events when real provider calls return.
Evidence files, when enabled, are written before these events. Subscribe BEFORE
triggering generation using the bundled watcher (replace SKILL_ROOT):

```powershell
node "SKILL_ROOT/scripts/watch-generation-events.mjs" --events=D:/absolute/run/events.jsonl
```

It watches filesystem changes without a timer loop, ignores existing history and
stubs, buffers incomplete lines, and prints one compact JSON notice per real
text/image result. --once exits after the next notice; --from-start replays
history for diagnosis only. Notices include evidence paths and stop reasons,
never generated content, prompts, image data or provider URL queries. A text result stopped with error, artificial, user, interrupted, or another
unrecognized reason is reported as failed even when ok:true. Only EA's natural/stop/complete/completed reasons count as successful named stops.

Connect watcher output to the active agent tool session instead of relying only
on manual status polling. With functions.exec, start the --once watcher through
tools.exec_command, retain its session_id, and keep an awaited monitor alive:

```javascript
//Use a correctly quoted command for the current shell and installed skill path.
let result = await tools.exec_command({cmd: watcherCommand, yield_time_ms: 1000});
if (result.output) notify(result.output);
await yield_control();
while (result.session_id) {
  result = await tools.write_stdin({session_id: result.session_id, chars: "", yield_time_ms: 1000});
  if (result.output) notify(result.output);
}
```

This forwards completion output while that exec cell is active, allowing useful
independent work between notifications. Keep/rearm the subscription for later
jobs. Do not leave unawaited promises: the tool discards them when the cell ends.
The terminal printing by itself does not notify the agent, and this mechanism
does not schedule a new turn after the conversation/tool cell has ended. If the
host cannot deliver asynchronous notifications, state that limitation and use
bounded event waits at work checkpoints; do not pretend it can wake the agent.

While generation is pending, inspect relevant code, verify earlier accepted
changes/persistence, review retries, or prepare the next targeted test/fix. Do
not edit live test state, refresh, or send dependent turns while prerequisites
are unresolved. A provider completion is not proof that NPC extraction,
background state application, image presentation, or save transactions finished.
Read the final application state and the actual provider evidence at the next
checkpoint. Run scripts/test-generation-events.mjs to verify the watcher without
starting a model or playing the game.

## Real-provider proof and retry review

Check worker_ready.environment for BOTH `hasAiTextPlugin` and
`hasTextToImagePlugin`; they live inside the Perchance iframe. Verify the game
menu/bridge and `EmberAdventures.isSystemReady()`, not isReady() alone. Do not
block normal menu artwork such as user.uploads.dev.

Evidence capture records exact provider prompts and returned answers under the
run's `provider/` folder. Inspect every repair/retry and accepted mutation.
The current promptKind label can say json when the prompt says "Do not return
JSON"; inspect the actual contract and answer rather than that diagnostic label.
Structured prompt inputs are compatible with the plain-text output policy.

Check `result.meta.stopReason` too: a result envelope can be ok:true with partial
text and stopReason:error. In the verified run, such a narration attempt retried
and was replaced by a natural completion. Classify that as a provider retry,
not a text-format repair. Never silently count a partial/error response as a
completed successful turn.

Successful responses from these provider routes corroborate generation:

- `text-generation.perchance.org/api/generate`
- `image-generation.perchance.org/api/generate`
- `image-generation.perchance.org/api/downloadTemporaryImageViaProxy`

HTTP responses alone are insufficient. Read returned prose and internal text;
decode image data from the returned dataUrl, save it as a local image, inspect
its pixels with the image viewer, and verify the game's displayed image.
Verify stored appearance/subjects and current UI state rather than assuming a
model followed the prompt. Do not print base64 data or provider userKey values.
Network summaries keep origin/path/status only, not credential-bearing queries.

Initial verification failures do not necessarily end a job. On 23 October the
worker emitted 600010 errors, then returned real scene/profile images and text
without a replacement worker or a challenge bypass. Observe the pending result;
ask the user about any actual visible verification control only when needed.
Do not declare the entire setup broken solely from a historical verification
request. Do not add timeouts or a stealth/verification bypass.

## Evidence boundary

The 23 October setup proved normal EA startup, real narration with provider
recovery, plain-text objective/state answers, real scene/profile images and
native viewport resizing. It did not complete all plot-point, memory/belief,
save/replay, editing, or gameplay acceptance scenarios. Use prewritten plans,
record results per checkpoint, and clearly distinguish implementation, offline
checks, live checks, outstanding failures and manual interventions.

Keep raw reports and temporary browser state out of Git/skill archives. Public
notes should contain generic reproduction steps and conclusions only. Publish
the skill as a complete ZIP via maintainer/package_skills.py; never loose files.


## Foreground dialogs and saved-record inspection

The current controller discovers and acts on the foreground popup before the
underlying main modal. Use the fresh control inventory after opening or closing
a popup. Menu clicks recognize UI changes; narration waits still require a
finished message. A card's selected portrait may move to the first position,
so compare its stable id or numbered badge rather than its gallery position.

`inspect_save` writes a read-only diagnostic combining the persistence save
query (including message pages) with shared portrait and selection records from
the existing reconstruction API. Reconstruction alone does not load message
pages. Compare runtime and persisted values after the relevant work settles;
do not flush or patch storage merely to make a checkpoint pass.
