"use strict";
const fs=require("node:fs"),path=require("node:path"),childProcess=require("node:child_process");
const value=name=>process.argv.find(arg=>arg.startsWith(`--${name}=`))?.slice(name.length+3);
const repository=path.resolve(value("repository")||""),output=value("output");
if(!value("repository")||!output)
    throw new Error("Provide --repository=<normal-EA-checkout> and --output=<local-log.jsonl>.");

const destination=path.resolve(output),now=Date.now();
if(fs.existsSync(destination)&&!process.argv.includes("--force")) {
    const descriptor=fs.openSync(destination,"r"),length=fs.fstatSync(descriptor).size;
    const tail=Buffer.alloc(Math.min(length,65536));
    fs.readSync(descriptor,tail,0,tail.length,length-tail.length);fs.closeSync(descriptor);
    const last=tail.toString("utf8").trim().split(/\r?\n/).at(-1);
    const prior=last ? JSON.parse(last) : null;
    if(prior&&now-Date.parse(prior.at)<60*60*1000) {
        console.log(JSON.stringify({checked:false,lastSample:prior.at,nextDue:new Date(Date.parse(prior.at)+60*60*1000).toISOString()}));
        process.exit(0);
    }
}

if(process.platform!=="win32")
    throw new Error("This OS resource helper supports Windows sessions.");

const configuration=path.join(repository,"tools/perchance-ai-text-harness/state/playtest-launcher-config.json");
const cdp=fs.existsSync(configuration) ? JSON.parse(fs.readFileSync(configuration,"utf8")).workerCdpUrl : "http://127.0.0.1:9222";
const port=new URL(cdp).port||"80";
const script=`$ErrorActionPreference='Stop';$memory=@{};Get-Process node,msedge -ErrorAction SilentlyContinue|ForEach-Object {$memory[[int]$_.Id]=@{private=$_.PrivateMemorySize64;working=$_.WorkingSet64}};$items=@(Get-CimInstance Win32_Process -Filter "Name = 'node.exe' OR Name = 'msedge.exe'"|ForEach-Object {[pscustomobject]@{id=[int]$_.ProcessId;parent=[int]$_.ParentProcessId;name=$_.Name;command=$_.CommandLine;memory=$memory[[int]$_.ProcessId]}});$os=Get-CimInstance Win32_OperatingSystem;@{availableBytes=[double]$os.FreePhysicalMemory*1024;totalBytes=[double]$os.TotalVisibleMemorySize*1024;processes=$items}|ConvertTo-Json -Depth 5 -Compress`;
const data=JSON.parse(childProcess.execFileSync("powershell.exe",["-NoProfile","-NonInteractive","-Command",script],{encoding:"utf8",windowsHide:true,maxBuffer:4*1024*1024}));
const normalize=text=>String(text||"").replaceAll("\\","/").toLowerCase();
const controllerScript=normalize(path.join(repository,"tools/perchance-ai-text-harness/interactive_emberadventures_ui_controller.mjs"));
const controllers=data.processes.filter(item=>item.name==="node.exe"&&normalize(item.command).includes(controllerScript));
const roots=data.processes.filter(item=>item.name==="msedge.exe"&&!/--type=/.test(item.command||""));
function group(root) {
    const ids=new Set([root.id]);let added;
    do {
        added=false;
        for(const item of data.processes) {
            if(ids.has(item.parent)&&!ids.has(item.id)) {ids.add(item.id);added=true;}
        }
    }while(added);
    const members=data.processes.filter(item=>ids.has(item.id));
    return {root:root.id,processCount:members.length,privateBytes:members.reduce((sum,item)=>sum+(item.memory?.private||0),0),workingBytes:members.reduce((sum,item)=>sum+(item.memory?.working||0),0)};
}
const sample={at:new Date(now).toISOString(),availableBytes:data.availableBytes,totalBytes:data.totalBytes,
    worker:roots.filter(item=>new RegExp(`--remote-debugging-port(?:=|\\s+)${port}(?:\\s|$)`).test(item.command||"")).map(group),
    game:roots.filter(item=>controllers.some(controller=>controller.id===item.parent)).map(group),
    controller:controllers.map(item=>({id:item.id,privateBytes:item.memory?.private||0,workingBytes:item.memory?.working||0}))};
fs.mkdirSync(path.dirname(destination),{recursive:true});fs.appendFileSync(destination,JSON.stringify(sample)+"\n");
console.log(JSON.stringify({checked:true,...sample}));
