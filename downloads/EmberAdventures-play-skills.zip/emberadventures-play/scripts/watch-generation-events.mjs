import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

export function completionNotice(event, eventFile) {
  if (!["ai_text", "image"].includes(event.type)) return null;
  const evidence = path.join(path.dirname(eventFile), "provider", `${path.basename(String(event.id))}.json`);
  const result = fs.existsSync(evidence) ? JSON.parse(fs.readFileSync(evidence, "utf8")).result : null;
  const stopReason = String(result?.meta?.stopReason || event.stopReason || "").trim().toLowerCase();
  const textStoppedIncomplete = event.type === "ai_text" && !!stopReason &&
    !["natural", "stop", "complete", "completed"].includes(stopReason);
  const failed = event.ok === false || result?.ok === false || textStoppedIncomplete ||
    ["error", "cancelled", "canceled"].includes(stopReason);
  return {
    type: "provider_completion",
    id: event.id,
    kind: event.type === "image" ? "image" : "text",
    label: event.label || "",
    outcome: failed ? "failed" : result?.ok === true || event.ok === true ? "completed" : "returned",
    stopReason,
    elapsedMs: event.elapsedMs,
    evidence: fs.existsSync(evidence) ? evidence : "",
  };
}

export function watchGenerationEvents(eventFile, { fromStart = false, once = false, emit = console.log, pollOnly = false } = {}) {
  const file = path.resolve(eventFile);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, "");
  let offset = fromStart ? 0 : fs.statSync(file).size;
  let pending = Buffer.alloc(0);
  let closed = false;
  const close = () => { closed = true; watcher?.close(); fs.unwatchFile(file,drain); };
  const drain = () => {
    if (closed) return;
    const size = fs.statSync(file).size;
    if (size < offset) { offset = 0; pending = Buffer.alloc(0); }
    if (size === offset) return;
    const fd = fs.openSync(file, "r");
    const chunk = Buffer.alloc(size - offset);
    let count;
    try { count = fs.readSync(fd, chunk, 0, chunk.length, offset); }
    finally { fs.closeSync(fd); }
    offset += count;
    pending = Buffer.concat([pending, chunk.subarray(0, count)]);
    for (;;) {
      const newline = pending.indexOf(10);
      if (newline < 0) break;
      const line = pending.subarray(0, newline).toString("utf8").trim();
      pending = pending.subarray(newline + 1);
      if (!line) continue;
      const notice = completionNotice(JSON.parse(line), file);
      if (!notice) continue;
      emit(JSON.stringify(notice));
      if (once) { close(); break; }
    }
  };
  const watcher = pollOnly ? null : fs.watch(path.dirname(file), (_event, changed) => {
    if (changed == null || String(changed) === path.basename(file)) drain();
  });
  //Windows directory notifications can be missed;stat polling is a completion notification fallback.
  fs.watchFile(file,{interval:500},drain);
  drain();
  return close;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const events = process.argv.find((arg) => arg.startsWith("--events="))?.slice(9);
  if (!events) throw new Error("Use --events=/absolute/path/events.jsonl [--once] [--from-start].");
  const close = watchGenerationEvents(events, {
    once: process.argv.includes("--once"),
    pollOnly: process.argv.includes("--poll-only"),
    fromStart: process.argv.includes("--from-start"),
  });
  process.on("SIGINT", close);
  process.on("SIGTERM", close);
}