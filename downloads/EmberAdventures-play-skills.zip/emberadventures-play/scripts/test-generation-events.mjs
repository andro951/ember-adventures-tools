import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { test } from "node:test";
import { once } from "node:events";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { completionNotice, watchGenerationEvents } from "./watch-generation-events.mjs";

test("completion stream ignores history/stubs, buffers partial writes, and reports text/images without leaking payloads", async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "ea-generation-notices-"));
  const file = path.join(root, "events.jsonl");
  const evidence = path.join(root, "provider");
  fs.mkdirSync(evidence);
  fs.writeFileSync(file, JSON.stringify({type:"image",id:"old"}) + "\n");
  fs.writeFileSync(path.join(evidence, "new.json"), JSON.stringify({result:{ok:true,meta:{stopReason:"error"},response:"private generated text"}}));
  const watcher = fileURLToPath(new URL("./watch-generation-events.mjs", import.meta.url));
  //The child announces readiness after installing its watcher; no timing sleep.
  const child = spawn(process.execPath, ["--input-type=module", "-e",
    `import {watchGenerationEvents} from ${JSON.stringify(new URL("./watch-generation-events.mjs", import.meta.url).href)}; watchGenerationEvents(${JSON.stringify(file)},{once:true}); console.log('ready');`], {stdio:["ignore","pipe","pipe"]});
  const messages = [];
  const ready = new Promise((resolve) => child.stdout.on("data", (data) => {
    messages.push(String(data));
    if (messages.join("").includes("ready\n")) resolve();
  }));
  try {
    await ready;
    fs.appendFileSync(file, JSON.stringify({type:"image_stub",id:"stub"}) + "\n");
    const line = JSON.stringify({type:"ai_text",id:"new",label:"NPC discovery",elapsedMs:123});
    fs.appendFileSync(file, line.slice(0, 18));
    fs.appendFileSync(file, line.slice(18) + "\n");
    const [code] = await once(child, "exit");
    assert.equal(code, 0);
    const notices = messages.join("").split("\n").filter((line) => line.startsWith("{" )).map(JSON.parse);
    assert.equal(notices.length, 1);
    assert.equal(notices[0].id, "new");
    assert.equal(notices[0].kind, "text");
    assert.equal(notices[0].outcome, "failed");
    assert.equal(notices[0].stopReason, "error");
    assert.ok(!messages.join("").includes("private generated text"));
    const image = completionNotice({type:"image",id:"picture",ok:true}, file);
    assert.equal(image.kind, "image");
    assert.equal(image.outcome, "completed");
    assert.equal(completionNotice({type:"provider_http"}, file), null);
    assert.ok(fs.existsSync(watcher));
  }
  finally {
    child.kill();
    fs.unlinkSync(path.join(evidence, "new.json"));
    fs.rmdirSync(evidence);
    fs.unlinkSync(file);
    fs.rmdirSync(root);
  }
});


test("text stop reasons match EA acceptance, including artificial truncation", () => {
  const eventFile = path.join(os.tmpdir(), "ea-no-provider-evidence", "events.jsonl");
  for (const stopReason of ["artificial", "user", "interrupted", "error", "unknown"])
    assert.equal(completionNotice({type:"ai_text",id:"stop-test",ok:true,stopReason},eventFile).outcome,"failed",stopReason);
  for (const stopReason of ["natural", "stop", "complete", "completed", " NATURAL "])
    assert.equal(completionNotice({type:"ai_text",id:"stop-test",ok:true,stopReason},eventFile).outcome,"completed",stopReason);
});


test("file-stat fallback emits once even without native directory notifications",async()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),"ea-poll-completions-")),file=path.join(directory,"events.jsonl");
  fs.writeFileSync(file,"");let close;
  try {
    const notice=new Promise(resolve=>{close=watchGenerationEvents(file,{pollOnly:true,once:true,emit:resolve});});
    fs.appendFileSync(file,JSON.stringify({type:"image",id:"polled-image",ok:true})+"\n");
    const result=JSON.parse(await notice);
    assert.equal(result.id,"polled-image");assert.equal(result.outcome,"completed");
  }
  finally {close?.();fs.unlinkSync(file);fs.rmdirSync(directory);}
});