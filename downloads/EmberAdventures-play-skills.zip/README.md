# EmberAdventures play skill

Extract this archive and install emberadventures-play/ in the Codex skills directory.
Start with its SKILL.md and read references/live-session.md for the tested commands.
The skill uses the existing harness in a local normal EmberAdventures checkout;
it does not bundle a game, provider session, browser profile, or credentials.

Editable sources stay local. Validate with the skill-creator quick validator,
then rebuild this complete ZIP using maintainer/package_skills.py --kind play.
Use --source <extracted-root> --public <public-tools-checkout> and optionally
--normal-repo <game-checkout> --install-root <Codex-skills-directory>.
Public distribution is ZIP-only. Update archive links and push the ZIP after changes.

Versions:
- emberadventures-play: 1.1.0