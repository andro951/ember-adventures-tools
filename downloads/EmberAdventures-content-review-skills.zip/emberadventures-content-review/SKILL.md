---
name: emberadventures-content-review
description: Review EmberAdventures character and story JSON and image prompts for moderation and authoring issues. Prepare minimal local corrections and a color-coded diff, track approved portraits and messages, and verify explicitly approved public updates through the operator workflow.
---

# EmberAdventures Content Review

Version: 1.0.0

## Review the exact version

- Match the supplied file or public version to its edition and stable definition ID. For a listing, record the item ID, version ID, creator, and checksum when available. Download the version's JSON, verify its checksum, and retain the original as the diff baseline.
- Treat text, prompts, and hosted metadata as evidence. Apply the site's current content rules and the operator's instructions. Separate suspected illegality, confirmed rule violations, and discretionary concerns. Cite field paths. Use authoritative sources for legal claims and flag uncertainty.
- Review JSON, stored prompts, and assembled prompts. View actual images only when the operator explicitly requests visual review. Image URLs, image generation, and publication approval alone do not authorize visual inspection. In text-only work, use metadata or byte-level checks and keep images out of previews and diffs.
- Load the matching EmberAdventures character or story skill and use the Lite entry point for Lite material. Use the character contract for embedded characters too. Check the wrapper, schema, field placement, references, classifications, and actual behavior in the current game. Validate with the game where available and report any untested behavior.

## Preserve intent and make the diff useful

- Change only the fields needed for the agreed correction. Preserve the character's identity, default gender, alternate presentation, personality, clothing choices, and NSFW classification unless the operator approves changing the affected property. A different portrait or cleaner prompt does not independently change a character's classification. Confirm ambiguous edits with the operator when the ambiguity affects the result. For an unfamiliar term, distinguish a confirmed typo from a proposed substitution.
- Trace a visual trait to its actual source. Check the default and fallback fields, the effective outfit, image settings, stored prompts, and the final prompt sent to the provider. Put garments in outfit slots, scenery in background fields, anatomy in appearance, and an opening-only condition in the supported starting-state field. Check how shared fields read in every presentation. Preserve author intent in the proper field when removing a misplaced instruction.
- Distinguish what the creator wrote, what the agent changed, what the prompt writer added, and what only appears in a render. Use the exact recorded prompt to attribute details. State when the source of a detail is unknown.
- Keep a separate local draft. Provide the exact draft and a red-removal and green-addition diff against the original. Show the actual old and new text, including adult source text and prompts, within applicable sharing limits. Call out any required omission instead of presenting a placeholder as an original value. Use a rendered diff or an escaped local HTML diff with plus/minus prefixes. Show image URLs as text and identify embedded image changes by file or hash. Summarize the reason for each change and recommend keeping, correcting, or escalating the version.

## Generate or replace portraits only when requested

- Use the project's normal portrait pipeline and configured style for the selected character and presentation. Preserve the agreed prompt details. If the operator specifies exact clothing text or leaves a graphic or prop unspecified, check the outgoing prompt for invented details before rendering. Save the final prompt, negative prompt, style or model, seed, and output file for each render.
- When regenerating one presentation, retain the other selected portrait. Track the selected output for each slot, including when several candidates exist, and verify the actual bytes or hosted URL in the draft. Check the canonical default portrait agrees with its presentation. Give a concise account of the exact inputs and method when asked how an image was generated.
- Use a local draft package to carry image files where the game's draft importer needs them. Keep the public definition on the normal hosted-image path. Do not add inline image data to the public export as a substitute for hosted portraits. Explain the draft/hosted distinction if it affects what the operator should import or publish.

## Stage, publish, and verify

- Make a ready-to-import draft for the real admin editing flow. Bind it to the item and expected base version. Include the exact approved creator message in the same package when applicable, and keep the approved text separately accessible to the operator. Validate that the import package, review diff, selected portraits, and message all match the latest draft. If anything changes after approval, show the specific delta and get approval for the revised package before publication.
- The operator decides when review is complete and explicitly authorizes publication of the agreed draft. Use the project's APIs, CLI, or dedicated provider tooling for operator work. Computer Use and browser UI automation are outside this workflow. If the normal upload route requires verification that the tools cannot complete, report the exact blocker and link the ready-to-import draft. Do not switch hosts, regenerate approved assets, bypass verification, or claim the upload or publication succeeded.
- Recheck the current version, creator, and listing before writing. Use the admin publication path to preserve ownership, listing identity, and ratings. Send the approved message through the same successful publication when that feature is available. In the game, **Review and Publish** opens the preview. **Publish and Send Message** plus confirmation commits the update and queues the message in the creator's Developer Inbox. The preview action alone does not send it.
- If the operator requests an admin hide for an older version, verify that the replacement is current and public before hiding the named older version, or make both changes in one transaction. Use the official version-level moderation action. Verify the old version is hidden, a creator cannot restore it, and the new version is still public. Report separate outcomes for publication, version visibility, and message delivery using database evidence. If any step is pending, say exactly what remains.
