"""Build complete, reproducible skill archives; public repositories contain ZIPs only."""
import argparse
import hashlib
import json
import pathlib
import re
import shutil

import subprocess
import zipfile

PRODUCTS = {
    "normal": ("EmberAdventures", ["emberadventures-character", "emberadventures-story"]),
    "lite": ("EmberAdventuresLite", ["emberadventureslite-character", "emberadventureslite-story"]),
    "play": ("EmberAdventures-play", ["emberadventures-play"]),
    "review": ("EmberAdventures-content-review", ["emberadventures-content-review"]),
}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_skill(source, name):
    return (source / name / "SKILL.md").read_text(encoding="utf-8-sig")

def skill_body(text):
    return text.split("\n---\n", 1)[1].strip()

def extract_section(text, name):
    start = f"<!-- {name}:start -->"
    end = f"<!-- {name}:end -->"
    return text.split(start, 1)[1].split(end, 1)[0].strip()

def resource_block(text, filename):
    marker = f"<!-- resource:{filename} -->"
    block = re.search(re.escape(marker) + r"\s*```json\n.*?\n```", text, re.S)
    if not block:
        raise ValueError(f"Missing embedded resource: {filename}")
    return block.group()

def compose_skills(source, names):
    texts = {name: read_skill(source, name) for name in names}
    if not any("<!-- insert:" in text for text in texts.values()):
        return texts

    shared_character = read_skill(source, "emberadventures-character")
    story = texts.get("emberadventures-story") or read_skill(source, "emberadventures-story")
    intake = extract_section(shared_character, "shared-intake")
    handoff_section = "objective-turn-handoff"
    handoff = extract_section(story, handoff_section)
    handoff_insert = f"<!-- insert:{handoff_section} -->"
    if "emberadventures-character" in texts:
        embedded_story = extract_section(story, "embedded-story")
        character = shared_character.replace("<!-- insert:embedded-story -->",
            "## Author a story for Character Chat\n\nUse the inner \`storyTemplate\` object as \`chat_story_template\`. It has its own opening.\n\n" + embedded_story)
        character_body = re.sub(r"<!-- shared-intake:start -->.*?<!-- shared-intake:end -->", "", skill_body(character), flags=re.S).replace(handoff_insert, "")
        character = character.replace(handoff_insert, handoff)
        # A Story file includes the complete character guidance and reuses its source.
        story = story.replace("<!-- insert:shared-intake -->", intake).replace(handoff_insert, "")
        story = story.replace("<!-- insert:character -->", "# Character authoring reference\n\n" + character_body)
        character += (
            "\n## Validated story example\n\nFor Character Chat, copy the inner storyTemplate object.\n\n"
            + resource_block(story, "reference-story.json") + "\n\n"
            + "## Exact story field lists\n\n" + resource_block(story, "story-field-sets.json") + "\n"
        )
        return {"emberadventures-character": character, "emberadventures-story": story}

    lite_character = texts["emberadventureslite-character"]
    lite_character_guide = lite_character.split("## EmberAdventures character authoring", 1)[1].split("## EmberAdventures story authoring", 1)[0].strip()
    texts["emberadventureslite-story"] = texts["emberadventureslite-story"].replace(
        "<!-- insert:lite-character -->", "## EmberAdventures character authoring\n\n" + lite_character_guide)
    return {
        name: text.replace("<!-- insert:shared-intake -->", intake).replace(handoff_insert, handoff)
        for name, text in texts.items()
    }

def package(source, product, names, script):
    files = {}
    versions = {}
    is_authoring = len(names) == 2
    texts = compose_skills(source, names) if is_authoring else {}
    for name in names:
        folder = source / name
        text = texts[name] if is_authoring else read_skill(source, name)
        version = re.search(r"(?:Current skill version: `|Version: )([0-9]+\.[0-9]+\.[0-9]+)", text)
        if not version:
            raise ValueError(f"Missing version: {name}")
        versions[name] = version.group(1)
        if is_authoring:
            if "<!-- insert:" in text:
                raise ValueError(f"Unresolved include in {name}")
            files[f"{name}/SKILL.md"] = (text.strip() + "\n").encode("utf-8")
            continue

        for file in sorted(folder.rglob("*")):
            if not file.is_file():
                continue
            relative = file.relative_to(folder)
            if any(part.startswith(".") or part in {"__pycache__", "node_modules", "private-data", "test-output"} for part in relative.parts):
                raise ValueError(f"Do not package private/cache files: {file}")
            if file.suffix not in {".md", ".json", ".yaml", ".cjs", ".mjs"}:
                raise ValueError(f"Unexpected resource: {file}")
            files[f"{name}/{relative.as_posix()}"] = file.read_bytes()

    files["maintainer/package_skills.py"] = script.read_bytes()
    if is_authoring:
        validator = script.with_name("build_authoring_data.cjs")
        if validator.is_file():
            files["maintainer/build_authoring_data.cjs"] = validator.read_bytes()
        files["README.md"] = (
            f"# {product} authoring skills\n\n"
            "Each skill directory contains one complete SKILL.md. Use it directly as an AI attachment or install that directory in Codex. "
            "The game downloads the same file.\n\n"
            "Rebuild archives with maintainer/package_skills.py. Supply --normal-repo <shared game checkout> "
            "to validate the embedded examples and update both installed game bundles.\n"
        ).encode("utf-8")
    if names == ["emberadventures-play"]:
        files["README.md"] = ("""# EmberAdventures play skill

Extract this archive and install emberadventures-play/ in the Codex skills directory.
Start with its SKILL.md and read references/live-session.md for the tested commands.
The skill uses the existing harness in a local normal EmberAdventures checkout;
it does not bundle a game, provider session, browser profile, or credentials.

Editable sources stay local. Validate with the skill-creator quick validator,
then rebuild this complete ZIP using maintainer/package_skills.py --kind play.
Use --source <extracted-root> --public <public-tools-checkout> and optionally
--normal-repo <game-checkout> --install-root <Codex-skills-directory>.
Public distribution is ZIP-only. Update archive links and push the ZIP after changes.

Versions:
""" + "".join(f"- {name}: {versions[name]}\n" for name in names)).rstrip().encode()
    manifest = {"product": product, "skills": versions, "files": {name:digest(data) for name,data in sorted(files.items())}}
    files["manifest.json"] = json.dumps(manifest, indent=2, ensure_ascii=False).encode()
    return files

def write_zip(file, files):
    file.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(file, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data, compresslevel=9)
    with zipfile.ZipFile(file) as archive:
        if archive.testzip() is not None or set(archive.namelist()) != set(files):
            raise ValueError(f"ZIP verification failed: {file}")
        for name,data in files.items():
            if archive.read(name) != data:
                raise ValueError(f"ZIP entry mismatch: {name}")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=pathlib.Path, required=True)
    parser.add_argument("--public", type=pathlib.Path, required=True, help="Public ember-adventures-tools checkout")
    parser.add_argument("--kind", choices=[*PRODUCTS, "authoring", "all"], default="all")
    parser.add_argument("--normal-repo", type=pathlib.Path)
    parser.add_argument("--lite-repo", type=pathlib.Path)
    parser.add_argument("--install-root", type=pathlib.Path)
    parser.add_argument("--node", default="node")
    args = parser.parse_args()
    if (args.public.resolve() / ".git").exists():
        tracked = subprocess.run(["git", "ls-files"], cwd=args.public, check=True, capture_output=True, text=True).stdout.splitlines()
        if any(not name.endswith(".zip") for name in tracked):
            raise ValueError("The public skill repository must track ZIP files only. Preserve editable sources locally before removing loose published files.")
    source = args.source.resolve()
    if (source / "skills").is_dir():
        source /= "skills"
    selected = list(PRODUCTS) if args.kind == "all" else ["normal", "lite"] if args.kind == "authoring" else [args.kind]
    for kind in selected:
        product, names = PRODUCTS[kind]
        repo = (args.lite_repo or args.normal_repo) if kind == "lite" else args.normal_repo
        files = package(source, product, names, pathlib.Path(__file__).resolve())
        if kind in {"normal", "lite"} and args.normal_repo:
            validate = pathlib.Path(__file__).with_name("build_authoring_data.cjs")
            if not validate.is_file():
                raise ValueError("Run validation from the editable maintainer workspace.")
            shipped = {name: files[f"{name}/SKILL.md"].decode("utf-8") for name in names}
            subprocess.run(
                [args.node, str(validate), str(args.normal_repo.resolve()), kind],
                input=json.dumps(shipped, ensure_ascii=False), check=True, encoding="utf-8",
            )
        output = args.public.resolve()/"downloads"/(product+"-skills.zip")
        write_zip(output,files)
        if repo:
            destination=repo.resolve()/"skills"/output.name
            destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(output,destination)
        if args.install_root:
            for entry, data in files.items():
                if entry.split("/", 1)[0] not in names:
                    continue
                destination = args.install_root.resolve() / entry
                if destination.resolve() == (source / entry).resolve():
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
        print(f"Packaged {product}: {len(files)} files; SHA-256 {digest(output.read_bytes())}")

if __name__ == "__main__":
    main()
